import React, { useState } from 'react';
import {
  Clock,
  Calendar,
  ChevronDown,
  AlertCircle,
  Infinity
} from 'lucide-react';

interface CodeExpirationPickerProps {
  value: Date | null;
  onChange: (date: Date | null) => void;
  maxDays?: number;
  isPremium?: boolean;
}

const PRESET_OPTIONS = [
  { label: 'No expiration', value: null, days: 0 },
  { label: '1 day', value: 1, days: 1 },
  { label: '3 days', value: 3, days: 3 },
  { label: '7 days', value: 7, days: 7 },
  { label: '14 days', value: 14, days: 14 },
  { label: '30 days', value: 30, days: 30 }
];

const CodeExpirationPicker: React.FC<CodeExpirationPickerProps> = ({
  value,
  onChange,
  maxDays = 30,
  isPremium = false
}) => {
  const [showCustom, setShowCustom] = useState(false);
  const [customDate, setCustomDate] = useState('');

  const handlePresetSelect = (days: number | null) => {
    if (days === null) {
      onChange(null);
    } else {
      const date = new Date();
      date.setDate(date.getDate() + days);
      date.setHours(23, 59, 59, 999);
      onChange(date);
    }
    setShowCustom(false);
  };

  const handleCustomDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const dateStr = e.target.value;
    setCustomDate(dateStr);
    
    if (dateStr) {
      const date = new Date(dateStr);
      date.setHours(23, 59, 59, 999);
      
      // Validate date is in the future and within limits
      const now = new Date();
      const maxDate = new Date();
      maxDate.setDate(maxDate.getDate() + maxDays);
      
      if (date > now && date <= maxDate) {
        onChange(date);
      }
    }
  };

  const getSelectedLabel = () => {
    if (!value) return 'No expiration';
    
    const now = new Date();
    const diffTime = value.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 1) return '1 day';
    if (diffDays <= 3) return '3 days';
    if (diffDays <= 7) return '7 days';
    if (diffDays <= 14) return '14 days';
    if (diffDays <= 30) return '30 days';
    
    return value.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  const getMaxDate = () => {
    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + maxDays);
    return maxDate.toISOString().split('T')[0];
  };

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Clock className="w-4 h-4 text-orange-400" />
        <span className="text-sm font-medium text-white">Code Expiration</span>
        <span className="text-xs text-gray-500">(optional)</span>
      </div>

      {/* Preset Options */}
      <div className="grid grid-cols-3 gap-2">
        {PRESET_OPTIONS.map((option) => {
          const isDisabled = option.days > maxDays && option.days !== 0;
          const isSelected = option.value === null 
            ? value === null 
            : value && Math.ceil((value.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)) === option.days;
          
          return (
            <button
              key={option.label}
              onClick={() => !isDisabled && handlePresetSelect(option.value)}
              disabled={isDisabled}
              className={`py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                isSelected
                  ? 'bg-gold/20 text-gold border border-gold/50'
                  : isDisabled
                    ? 'bg-charcoal-700 text-gray-600 border border-charcoal-600 cursor-not-allowed'
                    : 'bg-charcoal-700 text-gray-300 border border-charcoal-600 hover:border-charcoal-500 hover:text-white'
              }`}
            >
              <div className="flex items-center justify-center gap-1">
                {option.value === null && <Infinity className="w-3 h-3" />}
                {option.label}
              </div>
              {isDisabled && !isPremium && (
                <span className="text-[10px] text-gold block mt-0.5">Premium</span>
              )}
            </button>
          );
        })}
      </div>

      {/* Custom Date Toggle */}
      <button
        onClick={() => setShowCustom(!showCustom)}
        className="w-full flex items-center justify-between p-3 bg-charcoal-700 hover:bg-charcoal-600 border border-charcoal-600 rounded-lg transition-colors"
      >
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-gray-400" />
          <span className="text-sm text-gray-300">Custom date</span>
        </div>
        <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${showCustom ? 'rotate-180' : ''}`} />
      </button>

      {/* Custom Date Input */}
      {showCustom && (
        <div className="p-4 bg-charcoal-700 rounded-lg border border-charcoal-600 space-y-3">
          <input
            type="date"
            value={customDate}
            onChange={handleCustomDateChange}
            min={getMinDate()}
            max={getMaxDate()}
            className="w-full bg-charcoal-800 border border-charcoal-600 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-gold"
          />
          <p className="text-xs text-gray-500">
            Select a date up to {maxDays} days from now
            {!isPremium && maxDays < 90 && (
              <span className="text-gold"> (Premium users get up to 90 days)</span>
            )}
          </p>
        </div>
      )}

      {/* Selected Value Display */}
      {value && (
        <div className="flex items-center gap-2 p-3 bg-orange-500/10 border border-orange-500/30 rounded-lg">
          <AlertCircle className="w-4 h-4 text-orange-400 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-sm text-orange-300">
              Code expires: <span className="font-medium">{value.toLocaleDateString(undefined, { 
                weekday: 'short',
                month: 'short', 
                day: 'numeric',
                year: 'numeric',
                hour: 'numeric',
                minute: '2-digit'
              })}</span>
            </p>
            <p className="text-xs text-orange-400/70 mt-0.5">
              You'll receive reminders before it expires
            </p>
          </div>
        </div>
      )}

      {/* No Expiration Info */}
      {!value && (
        <div className="flex items-center gap-2 p-3 bg-charcoal-700/50 border border-charcoal-600 rounded-lg">
          <Infinity className="w-4 h-4 text-gray-400 flex-shrink-0" />
          <p className="text-sm text-gray-400">
            Code won't expire automatically (still subject to system limits)
          </p>
        </div>
      )}
    </div>
  );
};

export default CodeExpirationPicker;
