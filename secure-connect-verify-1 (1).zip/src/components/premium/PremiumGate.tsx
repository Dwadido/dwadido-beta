import React, { useState, useCallback } from 'react';
import { usePremium, PremiumFeatures } from '@/contexts/PremiumContext';
import { Lock, Crown } from 'lucide-react';
import PremiumFeatureModal from './PremiumFeatureModal';

interface PremiumGateProps {
  /** The feature key to check access for */
  feature: keyof PremiumFeatures | string;
  /** Content to render when user has access (premium) */
  children: React.ReactNode;
  /** Optional: Custom fallback content for non-premium users (if not provided, shows locked overlay) */
  fallback?: React.ReactNode;
  /** Optional: Completely hide the feature instead of showing locked state */
  hideWhenLocked?: boolean;
  /** Optional: Show a compact lock indicator instead of full overlay */
  compactLock?: boolean;
  /** Optional: Custom class name for the wrapper */
  className?: string;
  /** Optional: Callback when premium modal is shown */
  onPremiumPrompt?: () => void;
  /** Optional: Allow click-through to show modal (default: true) */
  showModalOnClick?: boolean;
}

/**
 * PremiumGate - A wrapper component that gates premium features
 * 
 * Usage:
 * ```tsx
 * <PremiumGate feature="advancedFilters">
 *   <AdvancedFiltersComponent />
 * </PremiumGate>
 * ```
 * 
 * With custom fallback:
 * ```tsx
 * <PremiumGate 
 *   feature="videoSpeedDate" 
 *   fallback={<LockedVideoButton />}
 * >
 *   <VideoCallButton />
 * </PremiumGate>
 * ```
 */
const PremiumGate: React.FC<PremiumGateProps> = ({
  feature,
  children,
  fallback,
  hideWhenLocked = false,
  compactLock = false,
  className = '',
  onPremiumPrompt,
  showModalOnClick = true,
}) => {
  const { canUseFeature, isPremium } = usePremium();
  const [showModal, setShowModal] = useState(false);

  // Check if user can use this feature
  const hasAccess = canUseFeature(feature as keyof PremiumFeatures);

  const handleLockedClick = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (showModalOnClick) {
      setShowModal(true);
      onPremiumPrompt?.();
    }
  }, [showModalOnClick, onPremiumPrompt]);

  // If user has access, render children normally
  if (hasAccess) {
    return <>{children}</>;
  }

  // If hideWhenLocked is true, don't render anything
  if (hideWhenLocked) {
    return null;
  }

  // If custom fallback is provided, use it
  if (fallback) {
    return (
      <>
        <div onClick={handleLockedClick} className={className}>
          {fallback}
        </div>
        <PremiumFeatureModal
          isOpen={showModal}
          onClose={() => setShowModal(false)}
          featureId={feature}
        />
      </>
    );
  }

  // Compact lock indicator
  if (compactLock) {
    return (
      <>
        <div 
          className={`relative cursor-pointer ${className}`}
          onClick={handleLockedClick}
        >
          {/* Render children with reduced opacity */}
          <div className="opacity-50 pointer-events-none select-none">
            {children}
          </div>
          
          {/* Lock badge */}
          <div className="absolute top-1 right-1 flex items-center gap-1 px-2 py-1 bg-charcoal-800/90 rounded-full border border-gold/30">
            <Lock className="w-3 h-3 text-gold" />
            <span className="text-xs text-gold font-medium">Premium</span>
          </div>
        </div>
        
        <PremiumFeatureModal
          isOpen={showModal}
          onClose={() => setShowModal(false)}
          featureId={feature}
        />
      </>
    );
  }

  // Default: Full locked overlay
  return (
    <>
      <div 
        className={`relative cursor-pointer group ${className}`}
        onClick={handleLockedClick}
      >
        {/* Render children with blur and reduced opacity */}
        <div className="opacity-40 blur-[2px] pointer-events-none select-none transition-all group-hover:opacity-50 group-hover:blur-[1px]">
          {children}
        </div>
        
        {/* Locked overlay */}
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-charcoal-900/60 backdrop-blur-[1px] rounded-xl transition-all group-hover:bg-charcoal-900/50">
          <div className="text-center p-4">
            {/* Lock icon */}
            <div className="w-14 h-14 mx-auto mb-3 bg-gold/20 rounded-full flex items-center justify-center border border-gold/30 group-hover:scale-110 transition-transform">
              <Lock className="w-7 h-7 text-gold" />
            </div>
            
            {/* Premium badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gold/20 rounded-full border border-gold/30 mb-2">
              <Crown className="w-4 h-4 text-gold" />
              <span className="text-sm font-medium text-gold">Premium Feature</span>
            </div>
            
            {/* CTA hint */}
            <p className="text-xs text-gray-400 group-hover:text-gray-300 transition-colors">
              Tap to learn more
            </p>
          </div>
        </div>
      </div>
      
      <PremiumFeatureModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        featureId={feature}
      />
    </>
  );
};

export default PremiumGate;

/**
 * Hook for programmatic premium feature gating
 * Returns a function that checks access and shows modal if needed
 */
export const usePremiumGate = () => {
  const { canUseFeature, isPremium } = usePremium();
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    featureId: string | null;
  }>({ isOpen: false, featureId: null });

  const checkAccess = useCallback((
    feature: keyof PremiumFeatures | string,
    onAllowed?: () => void
  ): boolean => {
    const hasAccess = canUseFeature(feature as keyof PremiumFeatures);
    
    if (hasAccess) {
      onAllowed?.();
      return true;
    }
    
    // Show modal for non-premium users
    setModalState({ isOpen: true, featureId: feature });
    return false;
  }, [canUseFeature]);

  const closeModal = useCallback(() => {
    setModalState({ isOpen: false, featureId: null });
  }, []);

  const PremiumModal = useCallback(() => {
    if (!modalState.isOpen || !modalState.featureId) return null;
    
    return (
      <PremiumFeatureModal
        isOpen={modalState.isOpen}
        onClose={closeModal}
        featureId={modalState.featureId}
      />
    );
  }, [modalState, closeModal]);

  return {
    checkAccess,
    isPremium,
    PremiumModal,
    closeModal,
  };
};

/**
 * Higher-order component for premium feature gating
 */
export function withPremiumGate<P extends object>(
  WrappedComponent: React.ComponentType<P>,
  feature: keyof PremiumFeatures | string,
  options?: Omit<PremiumGateProps, 'feature' | 'children'>
) {
  return function PremiumGatedComponent(props: P) {
    return (
      <PremiumGate feature={feature} {...options}>
        <WrappedComponent {...props} />
      </PremiumGate>
    );
  };
}
