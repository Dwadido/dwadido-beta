/**
 * AISettings — REMOVED
 * 
 * All user-facing AI controls have been removed per product decision.
 * AI capabilities are internal-only (support/admin/moderation).
 * This file is kept as a no-op export to prevent import errors.
 */
const AISettings: React.FC = () => null;

import React from 'react';

export default AISettings;
