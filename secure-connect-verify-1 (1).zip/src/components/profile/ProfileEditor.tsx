import React, { useState, useEffect } from 'react';
import { useAuth, IntentType, RelationshipStatusType, GenderType, INTENT_LABELS, RELATIONSHIP_STATUS_LABELS, GENDER_LABELS } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { Camera, User, Save, Loader2, X, Check, Heart, Users, AlertCircle, Globe, MapPin, Clock, Languages, Image, Lightbulb, UserCircle, Calendar, Cake, Bug, Copy, ChevronDown, ChevronUp } from 'lucide-react';
import { COUNTRIES, CITIES, TIMEZONES, getCitiesByCountry, getCountryByCode, detectUserTimezone, normalizeTimezone } from '@/lib/globalData';
import { supabase, SUPABASE_URL, SUPABASE_ANON_KEY } from '@/lib/supabase';

import { SUPPORTED_LANGUAGES, ACTIVE_LANGUAGES, LanguageCode } from '@/lib/i18n';
import PhotoManager from './PhotoManager';


const INTEREST_OPTIONS = [

  'Travel', 'Music', 'Movies', 'Reading', 'Fitness', 'Cooking', 'Art', 'Gaming',
  'Photography', 'Technology', 'Nature', 'Sports', 'Fashion', 'Food', 'Dancing',
  'Writing', 'Yoga', 'Hiking', 'Coffee', 'Wine', 'Pets', 'Volunteering'
];


// Intent options aligned with Dwadido's core philosophy
// Intent is a HARD FILTER: Intent mismatch = no match | Intent alignment = match eligible
// VALUES MUST MATCH DB constraint: friends_first, dating, long_term_relationship, lifetime_partner
const INTENT_OPTIONS: { value: IntentType; label: string; description: string }[] = [
  { value: 'friends_first', label: 'Friends First', description: 'Build a friendship foundation before anything else' },
  { value: 'dating', label: 'Dating', description: 'Open to meeting new people and exploring connections' },
  { value: 'long_term_relationship', label: 'Long-Term Relationship', description: 'Seeking a committed, lasting relationship' },
  { value: 'lifetime_partner', label: 'Lifetime Partner / Marriage', description: 'Looking for marriage or lifelong commitment' }
];

// Default intent if none selected (prevents null/empty constraint violation)
const DEFAULT_INTENT: IntentType = 'dating';

// Map legacy DB values to current IntentType values
const INTENT_MIGRATION_MAP: Record<string, IntentType> = {
  'relationship': 'long_term_relationship',
};

// Validate that an intent value is one of the allowed DB values
const isValidIntent = (value: string | null | undefined): value is IntentType => {
  if (!value) return false;
  return ['friends_first', 'dating', 'long_term_relationship', 'lifetime_partner'].includes(value);
};



const RELATIONSHIP_STATUS_OPTIONS: { value: RelationshipStatusType; label: string }[] = [
  { value: 'single', label: 'Single' },
  { value: 'separated', label: 'Separated' },
  { value: 'divorced', label: 'Divorced' },
  { value: 'widowed', label: 'Widowed' }
];

const GENDER_OPTIONS: { value: GenderType; label: string; icon: string }[] = [
  { value: 'women', label: 'Women', icon: '👩' },
  { value: 'men', label: 'Men', icon: '👨' },
  { value: 'everyone', label: 'Everyone', icon: '👥' }
];

// Helper function to calculate age from a date string
function calculateAgeFromDate(dateString: string): number | null {
  if (!dateString) return null;
  
  const today = new Date();
  const birthDate = new Date(dateString);
  
  if (isNaN(birthDate.getTime())) return null;
  
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  
  return age;
}

// Helper to get max date for 18+ validation (18 years ago from today)
function getMaxDateForAge18(): string {
  const today = new Date();
  const maxDate = new Date(today.getFullYear() - 18, today.getMonth(), today.getDate());
  return maxDate.toISOString().split('T')[0];
}

// Helper to get min date (reasonable minimum - 120 years ago)
function getMinDate(): string {
  const today = new Date();
  const minDate = new Date(today.getFullYear() - 120, 0, 1);
  return minDate.toISOString().split('T')[0];
}

interface ProfileEditorProps {
  isOpen: boolean;
  onClose: () => void;
}

const ProfileEditor: React.FC<ProfileEditorProps> = ({ isOpen, onClose }) => {
  const { user, profile, updateProfile, session } = useAuth();
  const { t, language, setLanguage } = useI18n();
  
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [interests, setInterests] = useState<string[]>([]);
  // Intent always has a value — DB is NOT NULL DEFAULT 'dating'
  const [intent, setIntent] = useState<IntentType>(DEFAULT_INTENT);

  const [relationshipStatus, setRelationshipStatus] = useState<RelationshipStatusType | null>(null);
  const [gender, setGender] = useState<GenderType | null>(null);
  const [showBioBeforeMatch, setShowBioBeforeMatch] = useState(false);
  const [showInterestsBeforeMatch, setShowInterestsBeforeMatch] = useState(true);
  
  // Date of birth state
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [dobError, setDobError] = useState('');
  const [savedAge, setSavedAge] = useState<number | null>(null);
  
  // Global-ready fields
  const [country, setCountry] = useState('');
  const [city, setCity] = useState('');
  const [timezone, setTimezone] = useState(() => {
    const detected = detectUserTimezone();
    console.log('[ProfileEditor] Initial timezone from browser detection:', detected);
    return detected;
  });
  const [preferredLanguage, setPreferredLanguage] = useState<LanguageCode>('en');
  
  // V1: Filter preferences removed - Dwadido is intent-led, not search-led
  

  
  const [loading, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [validationError, setValidationError] = useState('');
  const [activeTab, setActiveTab] = useState<'profile' | 'photos' | 'location'>('profile');

  // =========================================================================
  // ON-SCREEN DEBUG STATE — visible on iPhone without DevTools
  // =========================================================================
  const [debugInfo, setDebugInfo] = useState<string | null>(null);
  const [showDebugPanel, setShowDebugPanel] = useState(false);
  const [debugCopied, setDebugCopied] = useState(false);
  const [diagRunning, setDiagRunning] = useState(false);

  // =========================================================================
  // ON-SCREEN DIAGNOSTICS — runs checks and shows results in the UI
  // =========================================================================
  const runOnScreenDiagnostics = async () => {
    setDiagRunning(true);
    const lines: string[] = [];
    const ts = new Date().toISOString();
    lines.push(`=== DWADIDO DEBUG REPORT ===`);
    lines.push(`Time: ${ts}`);
    lines.push(`App URL: ${window.location.origin}`);
    lines.push(``);

    // A) Supabase credentials
    const keyFingerprint = SUPABASE_ANON_KEY 
      ? `${SUPABASE_ANON_KEY.substring(0, 10)}...${SUPABASE_ANON_KEY.substring(SUPABASE_ANON_KEY.length - 8)}`
      : 'MISSING';
    lines.push(`[A] SUPABASE CREDENTIALS`);
    lines.push(`  URL: ${SUPABASE_URL}`);
    lines.push(`  Anon Key: ${keyFingerprint}`);
    lines.push(``);

    // B) Auth session state (from React)
    lines.push(`[B] AUTH SESSION (React state)`);
    lines.push(`  user.id: ${user?.id || 'NULL'}`);
    lines.push(`  user.email: ${user?.email || 'NULL'}`);
    lines.push(`  user.aud: ${(user as any)?.aud || 'NULL'}`);
    lines.push(`  session exists: ${!!session}`);
    lines.push(`  token prefix: ${session?.access_token?.substring(0, 20) || 'NULL'}...`);
    lines.push(``);

    // C) Profile state (from React)
    lines.push(`[C] PROFILE (React state)`);
    lines.push(`  profile.id: ${profile?.id || 'NULL'}`);
    lines.push(`  profile.email: ${profile?.email || 'NULL'}`);
    lines.push(`  profile.display_name: ${profile?.display_name || 'NULL'}`);
    lines.push(`  id match: ${user?.id === profile?.id ? 'YES' : 'NO (MISMATCH!)'}`);
    lines.push(``);

    // D) Server-side auth verification
    lines.push(`[D] AUTH VERIFICATION (server-side getUser)`);
    try {
      const { data: userData, error: userError } = await supabase.auth.getUser();
      if (userError) {
        lines.push(`  ERROR: ${userError.message}`);
      } else if (userData?.user) {
        lines.push(`  getUser.id: ${userData.user.id}`);
        lines.push(`  getUser.email: ${userData.user.email}`);
        lines.push(`  getUser.aud: ${(userData.user as any)?.aud || 'NULL'}`);
        lines.push(`  getUser.created_at: ${userData.user.created_at}`);
        lines.push(`  id matches React user: ${userData.user.id === user?.id ? 'YES' : 'NO (MISMATCH!)'}`);
      } else {
        lines.push(`  NO USER RETURNED (session may be invalid)`);
      }
    } catch (e: any) {
      lines.push(`  EXCEPTION: ${e.message}`);
    }
    lines.push(``);

    // E) Profile SELECT test
    lines.push(`[E] PROFILE SELECT TEST`);
    if (user?.id) {
      try {
        const { data: selData, error: selError } = await supabase
          .from('profiles')
          .select('id, email, display_name, updated_at')
          .eq('id', user.id)
          .maybeSingle();
        if (selError) {
          lines.push(`  SELECT ERROR: ${selError.message} (code: ${selError.code})`);
        } else if (selData) {
          lines.push(`  FOUND: id=${selData.id}, email=${selData.email}`);
          lines.push(`  display_name: ${selData.display_name}`);
          lines.push(`  updated_at: ${selData.updated_at}`);
        } else {
          lines.push(`  NOT FOUND — no profile row for this user.id!`);
        }
      } catch (e: any) {
        lines.push(`  EXCEPTION: ${e.message}`);
      }
    } else {
      lines.push(`  SKIPPED — no user.id`);
    }
    lines.push(``);

    // F) UPDATE test (dry run — only touches updated_at)
    lines.push(`[F] UPDATE TEST (dry run)`);
    if (user?.id) {
      try {
        const { data: upData, error: upError } = await supabase
          .from('profiles')
          .update({ updated_at: new Date().toISOString() })
          .eq('id', user.id)
          .select('id')
          .maybeSingle();
        if (upError) {
          lines.push(`  UPDATE ERROR: ${upError.message} (code: ${upError.code})`);
          if (upError.message?.includes('profiles_id_fkey')) {
            lines.push(`  >>> FK VIOLATION ON UPDATE — this confirms env mismatch!`);
          }
        } else if (upData) {
          lines.push(`  SUCCESS — UPDATE works (returned id: ${upData.id})`);
        } else {
          lines.push(`  NO ROWS AFFECTED — profile may not exist or RLS blocks it`);
        }
      } catch (e: any) {
        lines.push(`  EXCEPTION: ${e.message}`);
      }
    } else {
      lines.push(`  SKIPPED — no user.id`);
    }
    lines.push(``);
    lines.push(`=== END DEBUG REPORT ===`);

    const report = lines.join('\n');
    setDebugInfo(report);
    setShowDebugPanel(true);
    setDiagRunning(false);
  };

  const copyDebugInfo = async () => {
    if (!debugInfo) return;
    try {
      await navigator.clipboard.writeText(debugInfo);
      setDebugCopied(true);
      setTimeout(() => setDebugCopied(false), 2000);
    } catch {
      // Fallback for iPhone: create a textarea, select, and prompt copy
      const ta = document.createElement('textarea');
      ta.value = debugInfo;
      ta.style.position = 'fixed';
      ta.style.left = '-9999px';
      document.body.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, debugInfo.length);
      document.execCommand('copy');
      document.body.removeChild(ta);
      setDebugCopied(true);
      setTimeout(() => setDebugCopied(false), 2000);
    }
  };



  // Get cities for selected country
  const availableCities = country ? getCitiesByCountry(country) : [];
  const selectedCountry = country ? getCountryByCode(country) : null;

  useEffect(() => {
    if (isOpen) {
      // Close the support chat if it's open — only one modal at a time
      window.dispatchEvent(new CustomEvent('requestCloseSupportChat'));

      const scrollY = window.scrollY;
      document.body.style.position = 'fixed';
      document.body.style.top = `-${scrollY}px`;
      document.body.style.width = '100%';
    } else {
      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);
    }

    return () => {
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
    };
  }, [isOpen]);


  useEffect(() => {
    if (profile) {
      setDisplayName(profile.display_name || '');
      setBio(profile.bio || '');
      setInterests(profile.interest_tags || []);
      
      // === INTENT: Resolve from DB value → valid IntentType ===
      // DB column is NOT NULL DEFAULT 'dating', so profile.intent should always exist.
      // Defensive handling for legacy/edge cases.
      const rawIntent = profile.intent;
      let resolvedIntent: IntentType = DEFAULT_INTENT;
      
      if (rawIntent) {
        // Check if it's a legacy value that needs migration
        if (INTENT_MIGRATION_MAP[rawIntent]) {
          resolvedIntent = INTENT_MIGRATION_MAP[rawIntent];
          console.log(`[ProfileEditor] Migrated legacy intent "${rawIntent}" → "${resolvedIntent}"`);
        } else if (isValidIntent(rawIntent)) {
          resolvedIntent = rawIntent;
        } else {
          console.warn(`[ProfileEditor] Unknown intent value from DB: "${rawIntent}", defaulting to "${DEFAULT_INTENT}"`);
          resolvedIntent = DEFAULT_INTENT;
        }
      } else {
        // rawIntent is null/undefined/empty — shouldn't happen with NOT NULL column, but be safe
        console.warn(`[ProfileEditor] Intent is null/empty from DB, defaulting to "${DEFAULT_INTENT}"`);
        resolvedIntent = DEFAULT_INTENT;
      }
      setIntent(resolvedIntent);
      
      setRelationshipStatus(profile.relationship_status || null);
      setGender(profile.gender || null);
      setShowBioBeforeMatch(profile.privacy_settings?.show_bio_before_match || false);
      setShowInterestsBeforeMatch(profile.privacy_settings?.show_interests_before_match ?? true);
      
      // Global fields
      setCountry(profile.country || '');
      setCity(profile.city || '');
      
      // ── TIMEZONE LOADING (FIX for "stuck on Hawaii" bug) ──
      // If DB has a timezone, normalize it to a dropdown-valid value.
      // If DB is null/empty, detect from browser.
      // NEVER fall back to TIMEZONES[0] (Hawaii).
      const rawTz = profile.timezone;
      let resolvedTz: string;
      if (rawTz && rawTz.trim() !== '') {
        resolvedTz = normalizeTimezone(rawTz);
        console.log(`[ProfileEditor] Timezone from DB: "${rawTz}" → normalized: "${resolvedTz}"`);
      } else {
        resolvedTz = detectUserTimezone();
        console.log(`[ProfileEditor] Timezone DB is null/empty → browser detected: "${resolvedTz}"`);
      }
      // Final safety: verify resolvedTz is actually in the TIMEZONES dropdown
      const isInDropdown = TIMEZONES.some(tz => tz.value === resolvedTz);
      if (!isInDropdown) {
        console.warn(`[ProfileEditor] resolvedTz "${resolvedTz}" NOT in TIMEZONES dropdown! Falling back to detectUserTimezone()`);
        resolvedTz = detectUserTimezone();
      }
      console.log(`[ProfileEditor] Setting timezone state to: "${resolvedTz}"`);
      setTimezone(resolvedTz);

      setPreferredLanguage((profile.preferred_language as LanguageCode) || 'en');
      
      // Date of birth
      if (profile.date_of_birth) {
        setDateOfBirth(profile.date_of_birth);
        setSavedAge(calculateAgeFromDate(profile.date_of_birth));
      }
    }
  }, [profile]);




  // Reset city when country changes
  useEffect(() => {
    if (country && city) {
      const cityExists = availableCities.some(c => c.name === city);
      if (!cityExists) {
        setCity('');
      }
    }
  }, [country, availableCities]);

  // Auto-set timezone when city is selected — normalize to dropdown value
  useEffect(() => {
    if (city && country) {
      const selectedCity = availableCities.find(c => c.name === city);
      if (selectedCity) {
        setTimezone(normalizeTimezone(selectedCity.timezone));
      }
    }
  }, [city, country, availableCities]);


  const toggleInterest = (interest: string) => {
    if (interests.includes(interest)) {
      setInterests(interests.filter(i => i !== interest));
    } else if (interests.length < 8) {
      setInterests([...interests, interest]);
    }
  };

  const handleLanguageChange = (lang: LanguageCode) => {
    setPreferredLanguage(lang);
    // Also update the app language immediately
    if (ACTIVE_LANGUAGES.includes(lang)) {
      setLanguage(lang);
    }
  };

  // Validate date of birth
  const validateDateOfBirth = (dob: string): boolean => {
    if (!dob) {
      setDobError('');
      return true; // Optional field
    }

    const age = calculateAgeFromDate(dob);
    
    if (age === null) {
      setDobError('Please enter a valid date');
      return false;
    }
    
    if (age < 18) {
      setDobError('You must be at least 18 years old to use this service');
      return false;
    }
    
    if (age > 120) {
      setDobError('Please enter a valid date of birth');
      return false;
    }
    
    setDobError('');
    return true;
  };

  const handleDateOfBirthChange = (value: string) => {
    setDateOfBirth(value);
    validateDateOfBirth(value);
  };

  const handleSave = async () => {
    // === INTENT VALIDATION: Never allow null/empty to reach the DB ===
    const safeIntent: IntentType = isValidIntent(intent) ? intent : DEFAULT_INTENT;
    
    if (!isValidIntent(intent)) {
      console.warn(`[ProfileEditor] Intent is invalid ("${intent}") at save time. Auto-correcting to "${DEFAULT_INTENT}".`);
      setIntent(DEFAULT_INTENT);
    }
    
    if (!relationshipStatus) {
      setValidationError(t('profile.statusRequired') || 'Please select your relationship status');
      return;
    }
    
    if (dateOfBirth && !validateDateOfBirth(dateOfBirth)) {
      setValidationError(dobError || 'Please fix the date of birth error');
      return;
    }

    setSaving(true);
    setSuccess(false);
    setValidationError('');

    // =========================================================================
    // ON-SCREEN DEBUG: Only populate in development (never in production)
    // SECURITY: preDebugLines contain DB URL, user.id, user.email, profile.id
    // =========================================================================
    const preDebugLines: string[] = [];
    if (import.meta.env.DEV) {
      preDebugLines.push(`--- SAVE ATTEMPT ---`);
      preDebugLines.push(`DB URL: ${SUPABASE_URL}`);
      preDebugLines.push(`Auth user.id: ${user?.id || 'NULL'}`);
      preDebugLines.push(`Auth user.email: ${user?.email || 'NULL'}`);
      preDebugLines.push(`Profile.id (React): ${profile?.id || 'NULL'}`);
      preDebugLines.push(`Payload keys: display_name, bio, intent=${safeIntent}, ...`);
      preDebugLines.push(`Saving...`);
      setDebugInfo(preDebugLines.join('\n'));
      setShowDebugPanel(true);
    }

    const updateData: any = {
      display_name: displayName,
      bio,
      interest_tags: interests,
      intent: safeIntent,
      relationship_status: relationshipStatus,
      gender,
      country,
      city,
      timezone,
      preferred_language: preferredLanguage,
      privacy_settings: {
        show_bio_before_match: showBioBeforeMatch,
        show_interests_before_match: showInterestsBeforeMatch
      }
    };

    if (dateOfBirth) {
      updateData.date_of_birth = dateOfBirth;
    }
    
    const { error } = await updateProfile(updateData);

    if (error) {
      const errMsg = error.message || 'Unknown error';
      
      // Update debug info with error result (dev only)
      if (import.meta.env.DEV) {
        const postDebugLines = [...preDebugLines];
        postDebugLines.pop(); // Remove "Saving..."
        postDebugLines.push(`RESULT: ERROR`);
        postDebugLines.push(`Error: ${errMsg.substring(0, 300)}`);
        
        if (errMsg.includes('profiles_id_fkey')) {
          postDebugLines.push(``);
          postDebugLines.push(`>>> FK VIOLATION DETECTED <<<`);
          postDebugLines.push(`This means the user.id does NOT exist`);
          postDebugLines.push(`in the auth.users table that the FK references.`);
          postDebugLines.push(`Tap "Run Full Diagnostics" below for details.`);
        }
        setDebugInfo(postDebugLines.join('\n'));
      }

      if (errMsg.includes('profiles_id_fkey')) {
        setValidationError(
          `Database error. Please try signing out and back in. If the issue persists, contact support.`
        );
      } else if (errMsg.includes('profiles_intent_check')) {
        setValidationError(`Intent value "${safeIntent}" was rejected by the database.`);
      } else {
        setValidationError(`Failed to save profile: ${errMsg}`);
      }
      
      setSaving(false);
      return;
    }

    // Success — update debug info (dev only)
    if (import.meta.env.DEV) {
      const successDebugLines = [...preDebugLines];
      successDebugLines.pop();
      successDebugLines.push(`RESULT: SUCCESS`);
      setDebugInfo(successDebugLines.join('\n'));
    }
    
    setSuccess(true);
    if (dateOfBirth) {
      setSavedAge(calculateAgeFromDate(dateOfBirth));
    }
    setTimeout(() => {
      setSuccess(false);
      if (import.meta.env.DEV) {
        setShowDebugPanel(false);
      }
    }, 3000);
    setSaving(false);
  };






  if (!isOpen) return null;

  const isProfileIncomplete = !intent || !relationshipStatus;
  const currentAge = dateOfBirth ? calculateAgeFromDate(dateOfBirth) : null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden" style={{ WebkitOverflowScrolling: 'touch' }}>
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative min-h-full flex items-center justify-center p-4 py-8">
        <div className="relative w-full max-w-lg bg-[#141414] rounded-2xl shadow-2xl animate-in fade-in zoom-in duration-300 border border-[#2a2a2a]">
          {/* Header */}
          <div className="sticky top-0 bg-[#1a1a1a] border-b border-[#2a2a2a] px-6 py-4 flex items-center justify-between z-10 rounded-t-2xl">
            <h2 className="text-xl font-bold text-white">{t('profile.title')}</h2>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white hover:bg-[#2a2a2a] rounded-full transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Tab Navigation */}
          <div className="flex border-b border-[#2a2a2a]">
            <button
              onClick={() => setActiveTab('profile')}
              className={`flex-1 py-3 text-sm font-medium transition-all ${
                activeTab === 'profile'
                  ? 'text-[#C9A24D] border-b-2 border-[#C9A24D]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <User className="w-4 h-4 inline mr-2" />
              {t('profile.title')}
            </button>
            <button
              onClick={() => setActiveTab('photos')}
              className={`flex-1 py-3 text-sm font-medium transition-all ${
                activeTab === 'photos'
                  ? 'text-[#C9A24D] border-b-2 border-[#C9A24D]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Image className="w-4 h-4 inline mr-2" />
              Photos
            </button>
            <button
              onClick={() => setActiveTab('location')}
              className={`flex-1 py-3 text-sm font-medium transition-all ${
                activeTab === 'location'
                  ? 'text-[#C9A24D] border-b-2 border-[#C9A24D]'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Globe className="w-4 h-4 inline mr-2" />
              {t('profile.location')}
            </button>
          </div>

          <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
            {activeTab === 'profile' ? (
              <>
                {/* Profile Incomplete Warning */}
                {isProfileIncomplete && (
                  <div className="p-4 bg-[#C9A24D]/10 border border-[#C9A24D]/30 rounded-xl">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-[#C9A24D] flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-[#C9A24D] font-medium text-sm">Complete Your Profile</p>
                        <p className="text-gray-400 text-xs mt-1">
                          Intent and relationship status are required for verified intent transparency.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Photo prompt — no avatar preview */}
                <div className="flex flex-col items-center">
                  <div className="w-24 h-24 rounded-full bg-[#C9A24D]/20 flex items-center justify-center border border-[#C9A24D]/30 relative">
                    <User className="w-12 h-12 text-[#C9A24D]" />
                    <button 
                      onClick={() => setActiveTab('photos')}
                      className="absolute bottom-0 right-0 p-2 bg-[#C9A24D] text-[#141414] rounded-full shadow-lg hover:bg-[#d4af5a] transition-all"
                    >
                      <Camera className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-gray-500 text-sm mt-2">Manage your photo in the Photos tab</p>
                </div>



                {/* Intent Selection - REQUIRED */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-white mb-3">
                    <Heart className="w-4 h-4 text-[#C9A24D]" />
                    Relationship Intent
                    <span className="text-[#C9A24D] text-xs">*{t('common.required')}</span>
                  </label>
                  <div className="space-y-2">
                    {INTENT_OPTIONS.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => {
                          setIntent(option.value);
                          setValidationError('');
                        }}
                        className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                          intent === option.value
                            ? 'bg-[#C9A24D]/10 border-[#C9A24D] text-white'
                            : 'bg-[#1a1a1a] border-[#2a2a2a] text-gray-300 hover:border-[#C9A24D]/50'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{option.label}</p>
                            <p className="text-sm text-gray-500 mt-0.5">{option.description}</p>
                          </div>
                          {intent === option.value && (
                            <div className="w-6 h-6 bg-[#C9A24D] rounded-full flex items-center justify-center">
                              <Check className="w-4 h-4 text-[#141414]" />
                            </div>
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Relationship Status - REQUIRED */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-white mb-3">
                    <Users className="w-4 h-4 text-[#C9A24D]" />
                    Relationship Status
                    <span className="text-[#C9A24D] text-xs">*{t('common.required')}</span>
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {RELATIONSHIP_STATUS_OPTIONS.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => {
                          setRelationshipStatus(option.value);
                          setValidationError('');
                        }}
                        className={`p-3 rounded-xl border-2 text-center transition-all ${
                          relationshipStatus === option.value
                            ? 'bg-[#C9A24D]/10 border-[#C9A24D] text-white'
                            : 'bg-[#1a1a1a] border-[#2a2a2a] text-gray-300 hover:border-[#C9A24D]/50'
                        }`}
                      >
                        <span className="font-medium">{option.label}</span>
                      </button>
                    ))}
                  </div>
                </div>


                {/* Gender Selection - Show Me Preference */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-white mb-3">
                    <UserCircle className="w-4 h-4 text-[#C9A24D]" />
                    {t('profile.showMe') || 'Show Me'}
                  </label>
                  <p className="text-gray-500 text-xs mb-3">
                    {t('profile.showMeDescription') || 'Choose who you want to see in your matches'}
                  </p>
                  <div className="grid grid-cols-3 gap-2">
                    {GENDER_OPTIONS.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => setGender(option.value)}
                        className={`p-4 rounded-xl border-2 text-center transition-all flex flex-col items-center gap-2 ${
                          gender === option.value
                            ? 'bg-[#C9A24D]/10 border-[#C9A24D] text-white'
                            : 'bg-[#1a1a1a] border-[#2a2a2a] text-gray-300 hover:border-[#C9A24D]/50'
                        }`}
                      >
                        <span className="text-2xl">{option.icon}</span>
                        <span className="font-medium text-sm">{option.label}</span>
                        {gender === option.value && (
                          <div className="w-5 h-5 bg-[#C9A24D] rounded-full flex items-center justify-center">
                            <Check className="w-3 h-3 text-[#141414]" />
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>


                {/* Display Name */}

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    {t('profile.displayName')}
                  </label>
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder={t('profile.displayNamePlaceholder')}
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] text-white placeholder-gray-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#C9A24D]/50 focus:border-[#C9A24D] transition-all"
                  />
                </div>

                {/* Date of Birth - NEW SECTION */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-white mb-2">
                    <Cake className="w-4 h-4 text-[#C9A24D]" />
                    {t('profile.dateOfBirth') || 'Date of Birth'}
                  </label>
                  <p className="text-gray-500 text-xs mb-3">
                    {t('profile.dateOfBirthDescription') || 'Your age will be shown on your profile. You must be 18 or older.'}
                  </p>
                  
                  <div className="relative">
                    <input
                      type="date"
                      value={dateOfBirth}
                      onChange={(e) => handleDateOfBirthChange(e.target.value)}
                      max={getMaxDateForAge18()}
                      min={getMinDate()}
                      className={`w-full px-4 py-3 bg-[#1a1a1a] border text-white rounded-xl focus:outline-none focus:ring-2 transition-all appearance-none ${
                        dobError 
                          ? 'border-red-500 focus:ring-red-500/50 focus:border-red-500' 
                          : 'border-[#2a2a2a] focus:ring-[#C9A24D]/50 focus:border-[#C9A24D]'
                      }`}
                      style={{ colorScheme: 'dark' }}
                    />
                    <Calendar className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500 pointer-events-none" />
                  </div>
                  
                  {/* Error message */}
                  {dobError && (
                    <div className="mt-2 flex items-center gap-2 text-red-400">
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                      <p className="text-sm">{dobError}</p>
                    </div>
                  )}
                  
                  {/* Age display */}
                  {currentAge !== null && currentAge >= 18 && !dobError && (
                    <div className="mt-3 p-3 bg-[#C9A24D]/10 border border-[#C9A24D]/30 rounded-xl">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-[#C9A24D]/20 rounded-full flex items-center justify-center">
                          <Cake className="w-5 h-5 text-[#C9A24D]" />
                        </div>
                        <div>
                          <p className="text-white font-medium">
                            {t('profile.yourAge') || 'Your Age'}: <span className="text-[#C9A24D]">{currentAge}</span>
                          </p>
                          <p className="text-gray-400 text-xs">
                            {t('profile.ageWillBeDisplayed') || 'This will be displayed on your profile'}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Saved age confirmation */}
                  {savedAge !== null && success && (
                    <div className="mt-2 flex items-center gap-2 text-green-400">
                      <Check className="w-4 h-4" />
                      <p className="text-sm">{t('profile.ageSaved') || `Age ${savedAge} saved successfully`}</p>
                    </div>
                  )}
                </div>

                {/* Bio */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    {t('profile.bio')} <span className="text-gray-500 font-normal">({bio.length}/250)</span>
                  </label>
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value.slice(0, 250))}
                    placeholder={t('profile.bioPlaceholder')}
                    rows={3}
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] text-white placeholder-gray-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#C9A24D]/50 focus:border-[#C9A24D] transition-all resize-none"
                  />
                </div>

                {/* Interests */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Interests <span className="text-gray-500 font-normal">({interests.length}/8)</span>
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {INTEREST_OPTIONS.map((interest) => {
                      const isSelected = interests.includes(interest);
                      return (
                        <button
                          key={interest}
                          onClick={() => toggleInterest(interest)}
                          disabled={!isSelected && interests.length >= 8}
                          className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                            isSelected
                              ? 'bg-[#C9A24D] text-[#141414]'
                              : 'bg-[#1a1a1a] text-gray-400 hover:bg-[#2a2a2a] border border-[#2a2a2a] disabled:opacity-50 disabled:cursor-not-allowed'
                          }`}
                        >
                          {interest}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Privacy Settings */}
                <div className="bg-[#1a1a1a] rounded-xl p-4 space-y-4 border border-[#2a2a2a]">
                  <h3 className="font-medium text-white">{t('settings.privacy')}</h3>
                  
                  <label className="flex items-center justify-between cursor-pointer">
                    <span className="text-sm text-gray-400">Show bio before match</span>
                    <button
                      onClick={() => setShowBioBeforeMatch(!showBioBeforeMatch)}
                      className={`w-11 h-6 rounded-full transition-all ${
                        showBioBeforeMatch ? 'bg-[#C9A24D]' : 'bg-[#2a2a2a]'
                      }`}
                    >
                      <div className={`w-5 h-5 bg-white rounded-full shadow transform transition-transform ${
                        showBioBeforeMatch ? 'translate-x-5' : 'translate-x-0.5'
                      }`} />
                    </button>
                  </label>

                  <label className="flex items-center justify-between cursor-pointer">
                    <span className="text-sm text-gray-400">Show interests before match</span>
                    <button
                      onClick={() => setShowInterestsBeforeMatch(!showInterestsBeforeMatch)}
                      className={`w-11 h-6 rounded-full transition-all ${
                        showInterestsBeforeMatch ? 'bg-[#C9A24D]' : 'bg-[#2a2a2a]'
                      }`}
                    >
                      <div className={`w-5 h-5 bg-white rounded-full shadow transform transition-transform ${
                        showInterestsBeforeMatch ? 'translate-x-5' : 'translate-x-0.5'
                      }`} />
                    </button>
                  </label>

                  <p className="text-xs text-gray-500 pt-2 border-t border-[#2a2a2a]">
                    Note: Intent and relationship status are always visible for transparency.
                  </p>
                </div>
              </>



            ) : activeTab === 'photos' ? (
              /* Photos Tab */
              <PhotoManager />
            ) : (
              <>
                {/* Location & Language Tab */}
                
                {/* Country Selection */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-white mb-3">
                    <Globe className="w-4 h-4 text-[#C9A24D]" />
                    {t('profile.country')}
                  </label>
                  <select
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-[#C9A24D]/50 focus:border-[#C9A24D] transition-all appearance-none cursor-pointer"
                  >
                    <option value="">{t('profile.selectCountry')}</option>
                    {COUNTRIES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.flag} {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* City Selection */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-white mb-3">
                    <MapPin className="w-4 h-4 text-[#C9A24D]" />
                    {t('profile.city')}
                  </label>
                  <select
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    disabled={!country}
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-[#C9A24D]/50 focus:border-[#C9A24D] transition-all appearance-none cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <option value="">{t('profile.selectCity')}</option>
                    {availableCities.map((c) => (
                      <option key={c.name} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                  {country && availableCities.length === 0 && (
                    <p className="text-gray-500 text-xs mt-2">
                      No cities available for this country yet. More coming soon!
                    </p>
                  )}
                </div>

                {/* Selected Location Display */}
                {country && city && (
                  <div className="p-4 bg-[#C9A24D]/10 border border-[#C9A24D]/30 rounded-xl">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">{selectedCountry?.flag}</div>
                      <div>
                        <p className="text-white font-medium">{city}, {selectedCountry?.name}</p>
                        <p className="text-gray-400 text-sm">Your profile location</p>

                      </div>
                    </div>
                  </div>
                )}

                {/* Timezone Selection */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-white mb-3">
                    <Clock className="w-4 h-4 text-[#C9A24D]" />
                    {t('profile.timezone')}
                  </label>
                  <select
                    value={timezone}
                    onChange={(e) => {
                      const newTz = e.target.value;
                      console.log(`[ProfileEditor] Timezone changed via dropdown: "${newTz}"`);
                      setTimezone(newTz);
                    }}
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] text-white rounded-xl focus:outline-none focus:ring-2 focus:ring-[#C9A24D]/50 focus:border-[#C9A24D] transition-all cursor-pointer"
                  >
                    {TIMEZONES.map((tz) => (
                      <option key={tz.value} value={tz.value}>
                        {tz.label} ({tz.offset})
                      </option>
                    ))}
                  </select>
                  {/* Show current selection as confirmation */}
                  {timezone && (
                    <div className="mt-2 flex items-center gap-2">
                      <Check className="w-3.5 h-3.5 text-[#C9A24D]" />
                      <p className="text-[#C9A24D] text-xs font-medium">
                        Selected: {TIMEZONES.find(tz => tz.value === timezone)?.label || timezone} ({TIMEZONES.find(tz => tz.value === timezone)?.offset || '?'})
                      </p>
                    </div>
                  )}
                  <p className="text-gray-500 text-xs mt-1">
                    Used to show times in your local timezone
                  </p>
                </div>

                {/* Language Selection */}
                <div>
                  <label className="flex items-center gap-2 text-sm font-medium text-white mb-3">
                    <Languages className="w-4 h-4 text-[#C9A24D]" />
                    {t('profile.language')}
                  </label>
                  <div className="space-y-2">
                    {SUPPORTED_LANGUAGES.map((lang) => {
                      const isActive = ACTIVE_LANGUAGES.includes(lang.code);
                      const isSelected = preferredLanguage === lang.code;
                      
                      return (
                        <button
                          key={lang.code}
                          onClick={() => isActive && handleLanguageChange(lang.code)}
                          disabled={!isActive}
                          className={`w-full p-3 rounded-xl border-2 text-left transition-all ${
                            isSelected
                              ? 'bg-[#C9A24D]/10 border-[#C9A24D] text-white'
                              : isActive
                                ? 'bg-[#1a1a1a] border-[#2a2a2a] text-gray-300 hover:border-[#C9A24D]/50'
                                : 'bg-[#1a1a1a] border-[#2a2a2a] text-gray-500 opacity-50 cursor-not-allowed'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <span className="text-lg">{lang.nativeName}</span>
                              <span className="text-sm text-gray-500">({lang.name})</span>
                            </div>
                            {isSelected && (
                              <div className="w-6 h-6 bg-[#C9A24D] rounded-full flex items-center justify-center">
                                <Check className="w-4 h-4 text-[#141414]" />
                              </div>
                            )}
                            {!isActive && (
                              <span className="text-xs text-gray-500 bg-[#2a2a2a] px-2 py-1 rounded">
                                Coming Soon
                              </span>
                            )}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                  <p className="text-gray-500 text-xs mt-3">
                    More languages coming soon! English is the default for V1.
                  </p>
                </div>

                {/* Global Info */}
                <div className="bg-[#1a1a1a] rounded-xl p-4 border border-[#2a2a2a]">
                  <h3 className="font-medium text-white mb-2 flex items-center gap-2">
                    <Globe className="w-4 h-4 text-[#C9A24D]" />
                    Why set your location?
                  </h3>
                  <ul className="text-sm text-gray-400 space-y-2">
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-[#C9A24D] mt-0.5 flex-shrink-0" />
                      <span>Help matches know your general area</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-[#C9A24D] mt-0.5 flex-shrink-0" />
                      <span>See times displayed in your local timezone</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-[#C9A24D] mt-0.5 flex-shrink-0" />
                      <span>Connect with people in your area (optional map feature)</span>
                    </li>
                  </ul>

                </div>
              </>
            )}

            {/* Validation Error - Only show on profile/location tabs */}
            {activeTab !== 'photos' && validationError && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl">
                <p className="text-red-400 text-sm text-left break-words whitespace-pre-wrap">{validationError}</p>
              </div>
            )}

            {/* ============================================================= */}
            {/* ON-SCREEN DEBUG PANEL — DEV ONLY                               */}
            {/* SECURITY: Never rendered in production builds.                  */}
            {/* Shows: Supabase URL, anon key fingerprint, auth user id/email, */}
            {/* payload id, save result, and full diagnostic report.            */}
            {/* ============================================================= */}
            {import.meta.env.DEV && activeTab !== 'photos' && (
              <div className="space-y-3">
                {/* Debug Toggle + Quick Info (dev only) */}
                <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-xl">
                  <button
                    onClick={() => setShowDebugPanel(!showDebugPanel)}
                    className="w-full flex items-center justify-between text-left"
                  >
                    <div className="flex items-center gap-2">
                      <Bug className="w-4 h-4 text-blue-400" />
                      <span className="text-blue-400 text-sm font-medium">Debug Info (DEV ONLY)</span>
                    </div>
                    {showDebugPanel ? (
                      <ChevronUp className="w-4 h-4 text-blue-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-blue-400" />
                    )}
                  </button>
                  
                  {/* Quick summary (dev only) */}
                  <div className="mt-2 text-xs text-blue-300/70 space-y-0.5">
                    <p>DB: {SUPABASE_URL ? SUPABASE_URL.replace('https://', '') : 'NULL'}</p>
                    <p>User: {user?.email || 'not signed in'} ({user?.id?.substring(0, 8) || 'no-id'}...)</p>
                    <p>Profile: {profile?.id ? `${profile.id.substring(0, 8)}... (${profile.email})` : 'NULL'}</p>
                  </div>
                </div>

                {/* Expanded Debug Panel */}
                {showDebugPanel && (
                  <div className="p-3 bg-[#0a0a1a] border border-blue-500/20 rounded-xl space-y-3">
                    {/* Debug output */}
                    {debugInfo && (
                      <pre className="text-xs text-blue-200/80 whitespace-pre-wrap break-all font-mono bg-[#050510] p-3 rounded-lg max-h-60 overflow-y-auto">
                        {debugInfo}
                      </pre>
                    )}

                    {/* Action buttons */}
                    <div className="flex gap-2">
                      <button
                        onClick={runOnScreenDiagnostics}
                        disabled={diagRunning}
                        className="flex-1 py-2 px-3 bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 rounded-lg text-xs font-medium transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50"
                      >
                        {diagRunning ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Bug className="w-3.5 h-3.5" />
                        )}
                        {diagRunning ? 'Running...' : 'Run Full Diagnostics'}
                      </button>
                      
                      {debugInfo && (
                        <button
                          onClick={copyDebugInfo}
                          className="py-2 px-3 bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5"
                        >
                          {debugCopied ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              Copied!
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              Copy
                            </>
                          )}
                        </button>
                      )}
                    </div>

                    <p className="text-xs text-gray-500">
                      Tap "Run Full Diagnostics" then "Copy" and paste the report to support.
                    </p>
                  </div>
                )}
              </div>
            )}


            {/* Save Button - Only show on profile/location tabs */}
            {activeTab !== 'photos' && (
              <button
                onClick={handleSave}
                disabled={loading || !!dobError}
                className="w-full py-3 bg-[#C9A24D] text-[#141414] font-semibold rounded-xl hover:bg-[#d4af5a] focus:outline-none focus:ring-2 focus:ring-[#C9A24D] focus:ring-offset-2 focus:ring-offset-[#141414] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(201,162,77,0.3)]"
              >
                {loading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : success ? (
                  <>
                    <Check className="w-5 h-5" />
                    {t('success.profileUpdated')}
                  </>
                ) : (
                  <>
                    <Save className="w-5 h-5" />
                    {t('profile.saveProfile')}
                  </>
                )}
              </button>
            )}

          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileEditor;
