import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import PrivacyMap from '@/components/map/PrivacyMap';
import { Loader2 } from 'lucide-react';

const MapPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-charcoal flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-gold animate-spin" />
      </div>
    );
  }

  if (!user) {
    // Redirect to home if not logged in
    navigate('/');
    return null;
  }

  return <PrivacyMap onBack={() => navigate('/dashboard')} />;
};

export default MapPage;
