import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { usePremium } from '@/contexts/PremiumContext';
import {
  Clock,
  Bell,
  BellOff,
  ChevronDown,
  Loader2,
  Check,
  Calendar,
  RefreshCw,
  AlertTriangle,
  Crown,
  Lock
} from 'lucide-react';

interface ExpirationSettings {
  crush_code_expiration_reminders: boolean;
  crush_code_reminder_24h: boolean;
  crush_code_reminder_12h: boolean;
  crush_code_reminder_6h: boolean;
  crush_code_reminder_1h: boolean;
}

interface SentReminder {
  id: string;
  code_id: string;
  reminder_type: string;
  sent_at: string;
  code?: string;
}

const CrushCodeExpirationSettings: React.FC = () => {
  const { user } = useAuth();
  const { isPremium, features } = usePremium();
  const [settings, setSettings] = useState<ExpirationSettings>({
    crush_code_expiration_reminders: true,
    crush_code_reminder_24h: true,
    crush_code_reminder_12h: true,
    crush_code_reminder_6h: true,
    crush_code_reminder_1h: true
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [recentReminders, setRecentReminders] = useState<SentReminder[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  // Check feature access
  const hasBasicAlerts = features.basicExpirationAlerts;
  const hasAdvancedAlerts = features.advancedExpirationAlerts;

  useEffect(() => {
    if (user?.id) {
      loadSettings();
    }
  }, [user?.id]);

  const loadSettings = async () => {
    if (!user?.id) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('email_preferences')
        .select('crush_code_expiration_reminders, crush_code_reminder_24h, crush_code_reminder_12h, crush_code_reminder_6h, crush_code_reminder_1h')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!error && data) {
        setSettings({
          crush_code_expiration_reminders: data.crush_code_expiration_reminders ?? true,
          crush_code_reminder_24h: data.crush_code_reminder_24h ?? true,
          crush_code_reminder_12h: data.crush_code_reminder_12h ?? true,
          crush_code_reminder_6h: data.crush_code_reminder_6h ?? true,
          crush_code_reminder_1h: data.crush_code_reminder_1h ?? true
        });
      }
    } catch (err) {
      console.error('Error loading settings:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadRecentReminders = async () => {
    if (!user?.id) return;
    
    setLoadingHistory(true);
    try {
      // Get user's crush codes first
      const { data: codes } = await supabase
        .from('crush_cards')
        .select('id, code')
        .eq('creator_id', user.id);

      if (codes && codes.length > 0) {
        const codeIds = codes.map(c => c.id);
        const codeMap = new Map(codes.map(c => [c.id, c.code]));

        const { data: reminders } = await supabase
          .from('crush_code_expiration_reminders')
          .select('*')
          .in('code_id', codeIds)
          .order('sent_at', { ascending: false })
          .limit(10);

        if (reminders) {
          setRecentReminders(reminders.map(r => ({
            ...r,
            code: codeMap.get(r.code_id) || 'Unknown'
          })));
        }
      }
    } catch (err) {
      console.error('Error loading reminders:', err);
    } finally {
      setLoadingHistory(false);
    }
  };

  const updateSetting = async (key: keyof ExpirationSettings, value: boolean) => {
    if (!user?.id) return;
    
    // Check if user has access to this setting
    if (!hasBasicAlerts) return;
    if (['crush_code_reminder_12h', 'crush_code_reminder_6h', 'crush_code_reminder_1h'].includes(key) && !hasAdvancedAlerts) {
      return;
    }
    
    setSaving(true);
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);

    try {
      const { error } = await supabase
        .from('email_preferences')
        .upsert({
          user_id: user.id,
          [key]: value,
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        });

      if (error) throw error;
    } catch (err) {
      console.error('Error saving setting:', err);
      // Revert on error
      setSettings(settings);
    } finally {
      setSaving(false);
    }
  };

  const formatReminderTime = (sentAt: string) => {
    const date = new Date(sentAt);
    return date.toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  const getReminderTypeLabel = (type: string) => {
    switch (type) {
      case '24h': return '24 hours before';
      case '12h': return '12 hours before';
      case '6h': return '6 hours before';
      case '1h': return '1 hour before';
      default: return type;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 text-gold animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-orange-500/20 rounded-xl flex items-center justify-center">
          <Clock className="w-5 h-5 text-orange-400" />
        </div>
        <div>
          <h3 className="font-semibold text-white">Code Expiration Reminders</h3>
          <p className="text-sm text-gray-400">Get notified before your crush codes expire</p>
        </div>
      </div>

      {/* Main Toggle - FREE for all users */}
      <div className="bg-charcoal-700 rounded-xl border border-charcoal-600 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {settings.crush_code_expiration_reminders ? (
              <Bell className="w-5 h-5 text-gold" />
            ) : (
              <BellOff className="w-5 h-5 text-gray-500" />
            )}
            <div>
              <p className="font-medium text-white">Expiration Reminders</p>
              <p className="text-sm text-gray-400">Receive email alerts before codes expire</p>
            </div>
          </div>
          <button
            onClick={() => updateSetting('crush_code_expiration_reminders', !settings.crush_code_expiration_reminders)}
            disabled={saving || !hasBasicAlerts}
            className={`relative w-12 h-6 rounded-full transition-colors ${
              settings.crush_code_expiration_reminders ? 'bg-gold' : 'bg-charcoal-500'
            } ${!hasBasicAlerts ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
              settings.crush_code_expiration_reminders ? 'translate-x-7' : 'translate-x-1'
            }`} />
          </button>
        </div>
      </div>

      {/* Reminder Timing Options */}
      {settings.crush_code_expiration_reminders && (
        <div className="bg-charcoal-700 rounded-xl border border-charcoal-600 overflow-hidden">
          <div className="p-4 border-b border-charcoal-600">
            <p className="text-sm font-medium text-white">When to remind me</p>
            <p className="text-xs text-gray-400 mt-1">Choose which reminders you want to receive</p>
          </div>

          <div className="divide-y divide-charcoal-600">
            {/* 24 hours - FREE for all users */}
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gold/10 rounded-lg flex items-center justify-center">
                  <span className="text-xs font-bold text-gold">24h</span>
                </div>
                <div>
                  <p className="text-sm font-medium text-white">24 hours before</p>
                  <p className="text-xs text-gray-400">
                    {hasBasicAlerts ? 'Always enabled' : 'Included in free tier'}
                  </p>
                </div>
              </div>
              <div className="w-12 h-6 bg-gold/30 rounded-full flex items-center justify-center">
                <Check className="w-4 h-4 text-gold" />
              </div>
            </div>

            {/* 12 hours - PREMIUM only */}
            <div className={`flex items-center justify-between p-4 ${!hasAdvancedAlerts ? 'opacity-60' : ''}`}>
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  hasAdvancedAlerts && settings.crush_code_reminder_12h ? 'bg-gold/10' : 'bg-charcoal-600'
                }`}>
                  <span className={`text-xs font-bold ${
                    hasAdvancedAlerts && settings.crush_code_reminder_12h ? 'text-gold' : 'text-gray-500'
                  }`}>12h</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-white">12 hours before</p>
                    {!hasAdvancedAlerts && (
                      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-gold/20 rounded text-[10px] font-medium text-gold">
                        <Crown className="w-2.5 h-2.5" />
                        Premium
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-gray-400">Additional reminder</p>
                </div>
              </div>
              {hasAdvancedAlerts ? (
                <button
                  onClick={() => updateSetting('crush_code_reminder_12h', !settings.crush_code_reminder_12h)}
                  disabled={saving}
                  className={`relative w-12 h-6 rounded-full transition-colors ${
                    settings.crush_code_reminder_12h ? 'bg-gold' : 'bg-charcoal-500'
                  }`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                    settings.crush_code_reminder_12h ? 'translate-x-7' : 'translate-x-1'
                  }`} />
                </button>
              ) : (
                <div className="w-12 h-6 bg-charcoal-600 rounded-full flex items-center justify-center">
                  <Lock className="w-3 h-3 text-gray-500" />
                </div>
              )}
            </div>

            {/* 6 hours - PREMIUM only */}
            <div className={`flex items-center justify-between p-4 ${!hasAdvancedAlerts ? 'opacity-60' : ''}`}>
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  hasAdvancedAlerts && settings.crush_code_reminder_6h ? 'bg-orange-500/10' : 'bg-charcoal-600'
                }`}>
                  <span className={`text-xs font-bold ${
                    hasAdvancedAlerts && settings.crush_code_reminder_6h ? 'text-orange-400' : 'text-gray-500'
                  }`}>6h</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-white">6 hours before</p>
                    {!hasAdvancedAlerts && (
                      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-gold/20 rounded text-[10px] font-medium text-gold">
                        <Crown className="w-2.5 h-2.5" />
                        Premium
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-gray-400">Getting close</p>
                </div>
              </div>
              {hasAdvancedAlerts ? (
                <button
                  onClick={() => updateSetting('crush_code_reminder_6h', !settings.crush_code_reminder_6h)}
                  disabled={saving}
                  className={`relative w-12 h-6 rounded-full transition-colors ${
                    settings.crush_code_reminder_6h ? 'bg-gold' : 'bg-charcoal-500'
                  }`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                    settings.crush_code_reminder_6h ? 'translate-x-7' : 'translate-x-1'
                  }`} />
                </button>
              ) : (
                <div className="w-12 h-6 bg-charcoal-600 rounded-full flex items-center justify-center">
                  <Lock className="w-3 h-3 text-gray-500" />
                </div>
              )}
            </div>

            {/* 1 hour - PREMIUM only */}
            <div className={`flex items-center justify-between p-4 ${!hasAdvancedAlerts ? 'opacity-60' : ''}`}>
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                  hasAdvancedAlerts && settings.crush_code_reminder_1h ? 'bg-red-500/10' : 'bg-charcoal-600'
                }`}>
                  <span className={`text-xs font-bold ${
                    hasAdvancedAlerts && settings.crush_code_reminder_1h ? 'text-red-400' : 'text-gray-500'
                  }`}>1h</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium text-white">1 hour before</p>
                    {!hasAdvancedAlerts && (
                      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-gold/20 rounded text-[10px] font-medium text-gold">
                        <Crown className="w-2.5 h-2.5" />
                        Premium
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-gray-400">Last chance alert</p>
                </div>
              </div>
              {hasAdvancedAlerts ? (
                <button
                  onClick={() => updateSetting('crush_code_reminder_1h', !settings.crush_code_reminder_1h)}
                  disabled={saving}
                  className={`relative w-12 h-6 rounded-full transition-colors ${
                    settings.crush_code_reminder_1h ? 'bg-gold' : 'bg-charcoal-500'
                  }`}
                >
                  <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${
                    settings.crush_code_reminder_1h ? 'translate-x-7' : 'translate-x-1'
                  }`} />
                </button>
              ) : (
                <div className="w-12 h-6 bg-charcoal-600 rounded-full flex items-center justify-center">
                  <Lock className="w-3 h-3 text-gray-500" />
                </div>
              )}
            </div>
          </div>

          {/* Premium Upsell for Advanced Alerts */}
          {!hasAdvancedAlerts && (
            <div className="p-4 bg-gradient-to-r from-gold/10 to-orange-500/10 border-t border-gold/20">
              <div className="flex items-start gap-3">
                <Crown className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-white">Unlock Custom Alert Timing</p>
                  <p className="text-xs text-gray-400 mt-1">
                    Premium members can customize reminder timing with 12h, 6h, and 1h alerts.
                  </p>
                  <a 
                    href="/premium" 
                    className="inline-flex items-center gap-1 mt-2 text-xs font-medium text-gold hover:text-gold/80 transition-colors"
                  >
                    Upgrade to Premium
                    <ChevronDown className="w-3 h-3 rotate-[-90deg]" />
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Recent Reminders History - PREMIUM only */}
      <div className="border border-charcoal-600 rounded-xl overflow-hidden">
        <button
          onClick={() => {
            if (!isPremium) return;
            setShowHistory(!showHistory);
            if (!showHistory && recentReminders.length === 0) {
              loadRecentReminders();
            }
          }}
          disabled={!isPremium}
          className={`w-full flex items-center justify-between p-4 bg-charcoal-700 transition-colors ${
            isPremium ? 'hover:bg-charcoal-600' : 'cursor-not-allowed'
          }`}
        >
          <div className="flex items-center gap-3">
            <Calendar className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-medium text-white">Recent Reminders</span>
            {!isPremium && (
              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-gold/20 rounded text-[10px] font-medium text-gold">
                <Crown className="w-2.5 h-2.5" />
                Premium
              </span>
            )}
          </div>
          {isPremium ? (
            <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${showHistory ? 'rotate-180' : ''}`} />
          ) : (
            <Lock className="w-4 h-4 text-gray-500" />
          )}
        </button>

        {showHistory && isPremium && (
          <div className="bg-charcoal-800 border-t border-charcoal-600">
            {loadingHistory ? (
              <div className="flex items-center justify-center p-6">
                <Loader2 className="w-5 h-5 text-gold animate-spin" />
              </div>
            ) : recentReminders.length === 0 ? (
              <div className="p-6 text-center">
                <AlertTriangle className="w-8 h-8 text-gray-500 mx-auto mb-2" />
                <p className="text-sm text-gray-400">No reminders sent yet</p>
                <p className="text-xs text-gray-500 mt-1">Reminders will appear here when sent</p>
              </div>
            ) : (
              <div className="divide-y divide-charcoal-600">
                {recentReminders.map((reminder) => (
                  <div key={reminder.id} className="flex items-center justify-between p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-gold/10 rounded-lg flex items-center justify-center">
                        <Bell className="w-4 h-4 text-gold" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-white">
                          Code: <span className="font-mono text-gold">{reminder.code}</span>
                        </p>
                        <p className="text-xs text-gray-400">{getReminderTypeLabel(reminder.reminder_type)}</p>
                      </div>
                    </div>
                    <span className="text-xs text-gray-500">{formatReminderTime(reminder.sent_at)}</span>
                  </div>
                ))}
              </div>
            )}

            {recentReminders.length > 0 && (
              <div className="p-3 border-t border-charcoal-600">
                <button
                  onClick={loadRecentReminders}
                  disabled={loadingHistory}
                  className="w-full flex items-center justify-center gap-2 py-2 text-sm text-gray-400 hover:text-white transition-colors"
                >
                  <RefreshCw className={`w-4 h-4 ${loadingHistory ? 'animate-spin' : ''}`} />
                  Refresh
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Info Note */}
      <div className="flex items-start gap-3 p-4 bg-charcoal-700/50 rounded-xl border border-charcoal-600">
        <AlertTriangle className="w-5 h-5 text-orange-400 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-sm text-gray-300">
            {isPremium 
              ? 'Reminders are sent via email to help you share your codes before they expire.'
              : 'Free users receive a 24-hour expiration alert. Upgrade to Premium for customizable timing.'
            }
          </p>
          <p className="text-xs text-gray-500 mt-1">
            {isPremium
              ? 'You can also set custom expiration dates when generating new codes.'
              : 'Premium members can also renew expired codes.'
            }
          </p>
        </div>
      </div>
    </div>
  );
};

export default CrushCodeExpirationSettings;
