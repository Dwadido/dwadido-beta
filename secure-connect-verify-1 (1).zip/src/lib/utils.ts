import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// =============================================================================
// TIMEOUT UTILITY FOR DATABASE QUERIES
// Prevents infinite loading states by failing gracefully after timeout
// =============================================================================
const DEFAULT_TIMEOUT_MS = 10000; // 10 seconds

export class TimeoutError extends Error {
  constructor(message: string = 'Operation timed out') {
    super(message);
    this.name = 'TimeoutError';
  }
}

/**
 * Wraps a promise with a timeout. If the promise doesn't resolve within
 * the specified time, it rejects with a TimeoutError.
 * 
 * @param promise - The promise to wrap
 * @param timeoutMs - Timeout in milliseconds (default: 10000)
 * @param operationName - Optional name for better error messages
 * @returns The result of the promise if it resolves in time
 * @throws TimeoutError if the operation times out
 */
export async function withTimeout<T>(
  promise: Promise<T>,
  timeoutMs: number = DEFAULT_TIMEOUT_MS,
  operationName?: string
): Promise<T> {
  let timeoutId: ReturnType<typeof setTimeout>;
  
  const timeoutPromise = new Promise<never>((_, reject) => {
    timeoutId = setTimeout(() => {
      const message = operationName 
        ? `${operationName} timed out after ${timeoutMs}ms`
        : `Operation timed out after ${timeoutMs}ms`;
      reject(new TimeoutError(message));
    }, timeoutMs);
  });

  try {
    const result = await Promise.race([promise, timeoutPromise]);
    clearTimeout(timeoutId!);
    return result;
  } catch (error) {
    clearTimeout(timeoutId!);
    throw error;
  }
}

/**
 * Wraps a promise with a timeout, returning a default value on timeout
 * instead of throwing an error. Useful for non-critical operations.
 * 
 * @param promise - The promise to wrap
 * @param defaultValue - Value to return if timeout occurs
 * @param timeoutMs - Timeout in milliseconds (default: 10000)
 * @param operationName - Optional name for logging
 * @returns The result of the promise or the default value on timeout
 */
export async function withTimeoutFallback<T>(
  promise: Promise<T>,
  defaultValue: T,
  timeoutMs: number = DEFAULT_TIMEOUT_MS,
  operationName?: string
): Promise<T> {
  try {
    return await withTimeout(promise, timeoutMs, operationName);
  } catch (error) {
    if (error instanceof TimeoutError) {
      console.warn(`[Timeout] ${operationName || 'Operation'} timed out, using fallback value`);
      return defaultValue;
    }
    throw error;
  }
}
