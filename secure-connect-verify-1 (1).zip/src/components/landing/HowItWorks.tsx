import React from 'react';
import { CreditCard, Share2, Scan, MessageCircle, CheckCircle, Clock, Shield, XCircle } from 'lucide-react';

const stages = [
  {
    stage: 0,
    icon: XCircle,
    title: 'No Connection',
    description: 'No digital connection exists. Users cannot message or interact until intent is verified.',
    status: 'Default State'
  },
  {
    stage: 1,
    icon: CreditCard,
    title: 'Generate Intent Code',
    description: 'Create a unique, one-time Crush Code. Share it with someone you want to connect with.',

    status: 'Intent Signal'
  },
  {
    stage: 2,
    icon: Scan,
    title: 'Verify & Accept',
    description: 'The receiver enters your code. The system verifies and requires explicit acceptance.',
    status: 'Verification'
  },
  {
    stage: 3,
    icon: MessageCircle,
    title: '17-Day Window',
    description: 'Upon verification, a restricted communication window opens for 17 days maximum.',
    status: 'Active Connection'
  },
  {
    stage: 4,
    icon: CheckCircle,
    title: 'Connection Closure',
    description: 'Connection ends via success confirmation, opt-out, or time expiry. All interaction disabled.',
    status: 'Resolution'
  },
  {
    stage: 5,
    icon: Shield,
    title: 'Outcome Recording',
    description: 'System records outcome for feedback, safety metrics, and platform integrity.',
    status: 'Complete'
  }
];

interface HowItWorksProps {
  cardImage: string;
}

const HowItWorks: React.FC<HowItWorksProps> = ({ cardImage }) => {
  return (
    <section className="py-24 bg-charcoal-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold/10 rounded-full text-gold font-medium text-sm mb-6 border border-gold/20">
            <Clock className="w-4 h-4" />
            Controlled Progression
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            The 5-Stage Verified Intent System
          </h2>
          <p className="text-lg text-gray-400">
            Communication only happens after verified initiation and is never persistent beyond controlled stages.
          </p>
        </div>

        {/* Stages Timeline */}
        <div className="relative mb-20">
          {/* Connection line */}
          <div className="absolute top-8 left-0 right-0 h-1 bg-gradient-to-r from-charcoal-600 via-gold/30 to-charcoal-600 hidden lg:block" />
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {stages.map((stage, index) => (
              <div key={index} className="relative group">
                {/* Stage indicator */}
                <div className="flex flex-col items-center">
                  <div className={`w-16 h-16 ${stage.stage === 3 ? 'bg-gold' : 'bg-charcoal-600 border border-gold/30'} rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform mb-4 relative z-10`}>
                    <stage.icon className={`w-8 h-8 ${stage.stage === 3 ? 'text-charcoal' : 'text-gold'}`} />
                  </div>
                  <span className="text-xs font-bold text-gold mb-1">STAGE {stage.stage}</span>
                  <h3 className="text-sm font-semibold text-white text-center mb-2">{stage.title}</h3>
                  <p className="text-xs text-gray-500 text-center leading-relaxed">{stage.description}</p>
                  <span className={`mt-3 px-2 py-1 text-xs font-medium rounded-full ${
                    stage.stage === 3 ? 'bg-gold/20 text-gold border border-gold/30' : 'bg-charcoal-600 text-gray-400 border border-charcoal-500'
                  }`}>
                    {stage.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Key Features Grid */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Visual */}
          <div className="relative order-2 lg:order-1">
            <div className="absolute inset-0 bg-gold/5 rounded-3xl blur-3xl" />
            <div className="relative bg-charcoal-700 rounded-3xl p-8 border border-charcoal-600">
              <img
                src={cardImage}
                alt="Crush Code Card"

                className="w-full h-auto rounded-2xl shadow-2xl"
              />
              
              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 bg-charcoal-700 rounded-xl shadow-lg p-3 flex items-center gap-2 border border-gold/30">
                <div className="w-8 h-8 bg-gold/20 rounded-full flex items-center justify-center">
                  <svg className="w-5 h-5 text-gold" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                <span className="text-sm font-medium text-white">Verified!</span>
              </div>

              <div className="absolute -bottom-4 -left-4 bg-charcoal-700 rounded-xl shadow-lg p-3 border border-gold/30">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-gold" />
                  <span className="text-sm font-medium text-white">17 days remaining</span>
                </div>
              </div>
            </div>
          </div>

          {/* Key Points */}
          <div className="space-y-6 order-1 lg:order-2">
            <h3 className="text-2xl font-bold text-white">Why Controlled Progression?</h3>
            
            <div className="space-y-4">
              <div className="flex gap-4 p-4 bg-charcoal-700 rounded-xl border border-charcoal-600">
                <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center flex-shrink-0 border border-gold/20">
                  <Shield className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <h4 className="font-semibold text-white mb-1">Reduces Unwanted Contact</h4>
                  <p className="text-sm text-gray-400">No messages until both parties explicitly confirm interest through verified codes.</p>
                </div>
              </div>

              <div className="flex gap-4 p-4 bg-charcoal-700 rounded-xl border border-charcoal-600">
                <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center flex-shrink-0 border border-gold/20">
                  <CheckCircle className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <h4 className="font-semibold text-white mb-1">Improves Trust</h4>
                  <p className="text-sm text-gray-400">Every connection starts with clear mutual intent, building trust from the first interaction.</p>
                </div>
              </div>

              <div className="flex gap-4 p-4 bg-charcoal-700 rounded-xl border border-charcoal-600">
                <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center flex-shrink-0 border border-gold/20">
                  <Clock className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <h4 className="font-semibold text-white mb-1">Time-Bounded Safety</h4>
                  <p className="text-sm text-gray-400">17-day window ensures connections progress to real-world meetings or close naturally.</p>
                </div>
              </div>

              <div className="flex gap-4 p-4 bg-charcoal-700 rounded-xl border border-charcoal-600">
                <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center flex-shrink-0 border border-gold/20">
                  <XCircle className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <h4 className="font-semibold text-white mb-1">Easy Opt-Out</h4>
                  <p className="text-sm text-gray-400">Either user can opt out at any time. No persistent connections, no pressure.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
