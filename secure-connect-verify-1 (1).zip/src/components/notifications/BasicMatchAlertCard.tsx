import React from 'react';
import { Heart, MapPin, Coffee, ArrowRight, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { 
  IntentType, 
  INTENT_LABELS,
  CommunicationStyleType,
  COMMUNICATION_STYLE_LABELS
} from '@/contexts/AuthContext';

// =============================================================================
// DWADIDO BASIC MATCH ALERT CARD
// 
// Design Philosophy (from Dwadido AI Matching Instructions):
// - Match alerts must be minimal, calm, and non-addictive
// - NO flashing animations, NO red badges, NO gamification
// - NO urgency language like "Don't miss out!" or "Act now!"
// - Explain WHY the match exists in one sentence
// - Invite offline action, not endless chat
// 
// The explanation is more important than the alert itself.
// =============================================================================

interface MatchAlertData {
  matchId: string;
  otherUser: {
    id: string;
    display_name?: string | null;
    avatar_url?: string | null;
    intent?: IntentType | null;
    communication_style?: CommunicationStyleType;
    city?: string | null;
    interest_tags?: string[];
  };
  myProfile?: {
    intent?: IntentType | null;
    communication_style?: CommunicationStyleType;
    interest_tags?: string[];
  };
  createdAt: string;
}

interface BasicMatchAlertCardProps {
  match: MatchAlertData;
  onDismiss?: () => void;
  onViewMatch?: (matchId: string) => void;
}

// Generate a calm, natural language explanation for WHY this match exists
function generateMatchExplanation(
  myProfile: MatchAlertData['myProfile'],
  otherUser: MatchAlertData['otherUser']
): string {
  const theirName = otherUser.display_name || 'They';
  const parts: string[] = [];
  
  // Intent alignment (highest priority per Dwadido rules)
  if (myProfile?.intent && otherUser.intent) {
    if (myProfile.intent === otherUser.intent) {
      parts.push(`your relationship intentions align`);
    } else {
      // Check compatible intents - Updated for new Dwadido intent types
      // - friends_first: Friends First
      // - dating: Dating
      // - long_term_relationship: Long-Term Relationship
      // - lifetime_partner: Lifetime Partner / Marriage
      const compatiblePairs: Record<IntentType, IntentType[]> = {
        'friends_first': ['dating'],
        'dating': ['friends_first', 'long_term_relationship'],
        'long_term_relationship': ['dating', 'lifetime_partner'],
        'lifetime_partner': ['long_term_relationship']
      };

      
      if (compatiblePairs[myProfile.intent]?.includes(otherUser.intent)) {
        parts.push(`your relationship goals complement each other`);
      }
    }
  }
  
  // Communication style compatibility
  if (myProfile?.communication_style && otherUser.communication_style) {
    if (myProfile.communication_style === otherUser.communication_style) {
      parts.push(`your communication styles suggest in-person meetings may feel natural`);
    } else {
      parts.push(`your communication styles can balance each other well`);
    }
  }
  
  // Shared interests
  if (myProfile?.interest_tags?.length && otherUser.interest_tags?.length) {
    const shared = myProfile.interest_tags.filter(interest => 
      otherUser.interest_tags?.some(ti => ti.toLowerCase() === interest.toLowerCase())
    );
    if (shared.length > 0) {
      parts.push(`you share interests that could inspire a first meetup`);
    }
  }
  
  // Build the explanation
  if (parts.length === 0) {
    return `You have a new connection. Take your time to explore their profile and see if meeting in person feels right.`;
  }
  
  if (parts.length === 1) {
    return `You have a new connection. ${parts[0].charAt(0).toUpperCase() + parts[0].slice(1)}.`;
  }
  
  // Combine multiple parts naturally
  const lastPart = parts.pop();
  return `You have a new connection. ${parts.join(', ')}${parts.length > 0 ? ', and ' : ''}${lastPart}.`;
}

// Format time in a calm, non-urgent way
function formatTimeCalm(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);
  
  if (diffHours < 1) return 'Recently';
  if (diffHours < 24) return 'Today';
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric'
  });
}

const BasicMatchAlertCard: React.FC<BasicMatchAlertCardProps> = ({
  match,
  onDismiss,
  onViewMatch
}) => {
  const navigate = useNavigate();
  
  const explanation = generateMatchExplanation(match.myProfile, match.otherUser);
  const theirName = match.otherUser.display_name || 'Someone';
  
  // Find shared interests for potential date suggestion
  const sharedInterests = match.myProfile?.interest_tags?.filter(interest => 
    match.otherUser.interest_tags?.some(ti => ti.toLowerCase() === interest.toLowerCase())
  ) || [];
  
  const handleViewMatch = () => {
    if (onViewMatch) {
      onViewMatch(match.matchId);
    } else {
      navigate('/dashboard');
    }
  };
  
  return (
    <div className="bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] overflow-hidden">
      {/* Main content - calm, minimal design */}
      <div className="p-5">
        {/* Header with avatar and name - no badges, no counts */}
        <div className="flex items-start gap-4">
          {/* Avatar */}
          <div className="flex-shrink-0">
            {match.otherUser.avatar_url ? (
              <img
                src={match.otherUser.avatar_url}
                alt=""
                className="w-12 h-12 rounded-full object-cover ring-2 ring-[#2a2a2a]"
              />
            ) : (
              <div className="w-12 h-12 rounded-full bg-[#2a2a2a] flex items-center justify-center">
                <User className="w-6 h-6 text-gray-500" />
              </div>
            )}
          </div>
          
          {/* Content */}
          <div className="flex-1 min-w-0">
            {/* Name and time - calm, no urgency */}
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-medium text-white truncate">
                {theirName}
              </h3>
              <span className="text-xs text-gray-500 flex-shrink-0 ml-2">
                {formatTimeCalm(match.createdAt)}
              </span>
            </div>
            
            {/* The explanation - this is the most important part */}
            <p className="text-sm text-gray-300 leading-relaxed">
              {explanation}
            </p>
          </div>
        </div>
        
        {/* Intent alignment indicator - subtle, informative */}
        {match.otherUser.intent && (
          <div className="mt-4 flex items-center gap-2 text-sm text-gray-400">
            <Heart className="w-4 h-4 text-[#C9A24D]/60" />
            <span>Looking for: {INTENT_LABELS[match.otherUser.intent]}</span>
          </div>
        )}
        
        {/* Location - for real-world context, not ranking */}
        {match.otherUser.city && (
          <div className="mt-2 flex items-center gap-2 text-sm text-gray-400">
            <MapPin className="w-4 h-4 text-gray-500" />
            <span>{match.otherUser.city}</span>
          </div>
        )}
        
        {/* Shared interests - conversation starters, not matching criteria */}
        {sharedInterests.length > 0 && (
          <div className="mt-4 pt-4 border-t border-[#2a2a2a]">
            <div className="flex items-center gap-2 mb-2">
              <Coffee className="w-4 h-4 text-[#C9A24D]/60" />
              <span className="text-xs text-gray-500 uppercase tracking-wide">
                Conversation starters
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {sharedInterests.slice(0, 3).map((interest, i) => (
                <span 
                  key={i}
                  className="px-2.5 py-1 bg-[#2a2a2a] text-gray-300 text-xs rounded-full"
                >
                  {interest}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
      
      {/* Action footer - invites offline action, not endless chat */}
      <div className="px-5 py-4 bg-[#141414] border-t border-[#2a2a2a]">
        <button
          onClick={handleViewMatch}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-[#2a2a2a] hover:bg-[#3a3a3a] text-white text-sm font-medium rounded-lg transition-colors"
        >
          <span>View profile</span>
          <ArrowRight className="w-4 h-4" />
        </button>
        
        {/* Gentle suggestion for offline action */}
        <p className="mt-3 text-xs text-gray-500 text-center">
          Take your time. When you're ready, consider suggesting a place to meet.
        </p>
      </div>
    </div>
  );
};

export default BasicMatchAlertCard;
