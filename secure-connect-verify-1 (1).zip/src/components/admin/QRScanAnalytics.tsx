import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Smartphone, 
  Monitor, 
  Tablet, 
  Globe, 
  TrendingUp, 
  TrendingDown,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Shield,
  Info,
  Calendar
} from 'lucide-react';
import { supabase } from '@/lib/supabase';

/**
 * QR Scan Analytics Dashboard
 * 
 * PRIVACY-FIRST DESIGN:
 * - All data is AGGREGATE only
 * - No individual user tracking
 * - No behavioral profiling
 * - Used for product decisions, NOT matching influence
 * 
 * Purpose:
 * - Understanding overall offline activation success
 * - Improving QR placement and timing
 * - Detecting system-level issues
 */

interface AggregateData {
  scan_date: string;
  scan_context: string;
  device_category: string;
  region_country: string | null;
  total_scans: number;
  successful_redemptions: number;
  failed_scans: number;
  avg_scan_to_redemption_seconds: number | null;
}

interface SummaryStats {
  totalScans: number;
  successfulRedemptions: number;
  failedScans: number;
  successRate: number;
  avgRedemptionTime: number | null;
  topContext: string;
  topDevice: string;
  topRegion: string;
}

const CONTEXT_LABELS: Record<string, string> = {
  event: 'Events',
  cafe: 'Cafes & Venues',
  personal: 'Personal Sharing',
  printed_card: 'Printed Cards',
  digital_share: 'Digital Shares',
  unknown: 'Other'
};

const DEVICE_ICONS: Record<string, React.ReactNode> = {
  mobile: <Smartphone className="w-4 h-4" />,
  desktop: <Monitor className="w-4 h-4" />,
  tablet: <Tablet className="w-4 h-4" />,
  unknown: <Globe className="w-4 h-4" />
};

const QRScanAnalytics: React.FC = () => {
  const [data, setData] = useState<AggregateData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d'>('30d');
  const [summary, setSummary] = useState<SummaryStats | null>(null);

  useEffect(() => {
    fetchAnalytics();
  }, [dateRange]);

  const fetchAnalytics = async () => {
    setLoading(true);
    setError(null);

    try {
      // Calculate date range
      const now = new Date();
      const daysBack = dateRange === '7d' ? 7 : dateRange === '30d' ? 30 : 90;
      const startDate = new Date(now.getTime() - daysBack * 24 * 60 * 60 * 1000);
      const startDateStr = startDate.toISOString().split('T')[0];

      const { data: analyticsData, error: fetchError } = await supabase
        .from('qr_scan_analytics')
        .select('*')
        .gte('scan_date', startDateStr)
        .order('scan_date', { ascending: false });

      if (fetchError) throw fetchError;

      setData(analyticsData || []);
      calculateSummary(analyticsData || []);
    } catch (err: any) {
      console.error('Failed to fetch analytics:', err);
      setError('Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  const calculateSummary = (analyticsData: AggregateData[]) => {
    if (!analyticsData.length) {
      setSummary(null);
      return;
    }

    // Aggregate totals
    let totalScans = 0;
    let successfulRedemptions = 0;
    let failedScans = 0;
    let totalRedemptionTime = 0;
    let redemptionTimeCount = 0;

    const contextCounts: Record<string, number> = {};
    const deviceCounts: Record<string, number> = {};
    const regionCounts: Record<string, number> = {};

    analyticsData.forEach(row => {
      totalScans += row.total_scans;
      successfulRedemptions += row.successful_redemptions;
      failedScans += row.failed_scans;

      if (row.avg_scan_to_redemption_seconds && row.successful_redemptions > 0) {
        totalRedemptionTime += row.avg_scan_to_redemption_seconds * row.successful_redemptions;
        redemptionTimeCount += row.successful_redemptions;
      }

      contextCounts[row.scan_context] = (contextCounts[row.scan_context] || 0) + row.total_scans;
      deviceCounts[row.device_category] = (deviceCounts[row.device_category] || 0) + row.total_scans;
      if (row.region_country) {
        regionCounts[row.region_country] = (regionCounts[row.region_country] || 0) + row.total_scans;
      }
    });

    const topContext = Object.entries(contextCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'unknown';
    const topDevice = Object.entries(deviceCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'unknown';
    const topRegion = Object.entries(regionCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

    setSummary({
      totalScans,
      successfulRedemptions,
      failedScans,
      successRate: totalScans > 0 ? (successfulRedemptions / totalScans) * 100 : 0,
      avgRedemptionTime: redemptionTimeCount > 0 ? Math.round(totalRedemptionTime / redemptionTimeCount) : null,
      topContext,
      topDevice,
      topRegion
    });
  };

  // Group data by context for chart
  const getContextBreakdown = () => {
    const breakdown: Record<string, { scans: number; redemptions: number }> = {};
    
    data.forEach(row => {
      if (!breakdown[row.scan_context]) {
        breakdown[row.scan_context] = { scans: 0, redemptions: 0 };
      }
      breakdown[row.scan_context].scans += row.total_scans;
      breakdown[row.scan_context].redemptions += row.successful_redemptions;
    });

    return Object.entries(breakdown)
      .map(([context, stats]) => ({
        context,
        label: CONTEXT_LABELS[context] || context,
        ...stats,
        rate: stats.scans > 0 ? (stats.redemptions / stats.scans) * 100 : 0
      }))
      .sort((a, b) => b.scans - a.scans);
  };

  // Group data by device
  const getDeviceBreakdown = () => {
    const breakdown: Record<string, number> = {};
    
    data.forEach(row => {
      breakdown[row.device_category] = (breakdown[row.device_category] || 0) + row.total_scans;
    });

    const total = Object.values(breakdown).reduce((a, b) => a + b, 0);

    return Object.entries(breakdown)
      .map(([device, count]) => ({
        device,
        count,
        percentage: total > 0 ? (count / total) * 100 : 0
      }))
      .sort((a, b) => b.count - a.count);
  };

  // Get daily trend
  const getDailyTrend = () => {
    const dailyTotals: Record<string, { scans: number; redemptions: number }> = {};
    
    data.forEach(row => {
      if (!dailyTotals[row.scan_date]) {
        dailyTotals[row.scan_date] = { scans: 0, redemptions: 0 };
      }
      dailyTotals[row.scan_date].scans += row.total_scans;
      dailyTotals[row.scan_date].redemptions += row.successful_redemptions;
    });

    return Object.entries(dailyTotals)
      .map(([date, stats]) => ({ date, ...stats }))
      .sort((a, b) => a.date.localeCompare(b.date))
      .slice(-14); // Last 14 days
  };

  if (loading) {
    return (
      <div className="p-6 bg-charcoal-800 rounded-2xl border border-charcoal-700">
        <div className="flex items-center justify-center py-12">
          <RefreshCw className="w-8 h-8 text-gold animate-spin" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Privacy Notice */}
      <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl">
        <div className="flex items-start gap-3">
          <Shield className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
          <div>
            <h3 className="text-emerald-400 font-medium text-sm">Privacy-First Analytics</h3>
            <p className="text-emerald-400/70 text-xs mt-1">
              All data shown is aggregate and anonymous. No individual user tracking or behavioral profiling. 
              Used for product improvement only, never for matching or scoring.
            </p>
          </div>
        </div>
      </div>

      {/* Header with Date Range */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-gold" />
          </div>
          <div>
            <h2 className="text-white font-semibold">QR Scan Analytics</h2>
            <p className="text-gray-400 text-sm">Aggregate offline activation insights</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchAnalytics}
            className="p-2 text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-lg transition-all"
            title="Refresh"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
          <div className="flex bg-charcoal-700 rounded-lg p-1">
            {(['7d', '30d', '90d'] as const).map((range) => (
              <button
                key={range}
                onClick={() => setDateRange(range)}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-all ${
                  dateRange === range
                    ? 'bg-gold text-charcoal'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {range === '7d' ? '7 Days' : range === '30d' ? '30 Days' : '90 Days'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {error ? (
        <div className="p-6 bg-red-500/10 border border-red-500/30 rounded-xl text-center">
          <AlertTriangle className="w-8 h-8 text-red-400 mx-auto mb-2" />
          <p className="text-red-400">{error}</p>
          <button
            onClick={fetchAnalytics}
            className="mt-3 px-4 py-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-all"
          >
            Try Again
          </button>
        </div>
      ) : !summary ? (
        <div className="p-12 bg-charcoal-800 rounded-2xl border border-charcoal-700 text-center">
          <Info className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <h3 className="text-white font-medium mb-2">No Data Yet</h3>
          <p className="text-gray-400 text-sm">
            QR scan analytics will appear here once users start scanning codes.
          </p>
        </div>
      ) : (
        <>
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 bg-charcoal-800 rounded-xl border border-charcoal-700">
              <div className="flex items-center gap-2 text-gray-400 text-sm mb-2">
                <BarChart3 className="w-4 h-4" />
                Total Scans
              </div>
              <p className="text-2xl font-bold text-white">{summary.totalScans.toLocaleString()}</p>
            </div>

            <div className="p-4 bg-charcoal-800 rounded-xl border border-charcoal-700">
              <div className="flex items-center gap-2 text-gray-400 text-sm mb-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                Success Rate
              </div>
              <p className="text-2xl font-bold text-emerald-400">{summary.successRate.toFixed(1)}%</p>
            </div>

            <div className="p-4 bg-charcoal-800 rounded-xl border border-charcoal-700">
              <div className="flex items-center gap-2 text-gray-400 text-sm mb-2">
                <Clock className="w-4 h-4 text-blue-400" />
                Avg. Time to Redeem
              </div>
              <p className="text-2xl font-bold text-blue-400">
                {summary.avgRedemptionTime ? `${summary.avgRedemptionTime}s` : 'N/A'}
              </p>
            </div>

            <div className="p-4 bg-charcoal-800 rounded-xl border border-charcoal-700">
              <div className="flex items-center gap-2 text-gray-400 text-sm mb-2">
                <XCircle className="w-4 h-4 text-red-400" />
                Failed Scans
              </div>
              <p className="text-2xl font-bold text-red-400">{summary.failedScans.toLocaleString()}</p>
            </div>
          </div>

          {/* Context Breakdown */}
          <div className="p-6 bg-charcoal-800 rounded-2xl border border-charcoal-700">
            <h3 className="text-white font-semibold mb-4">Scans by Context</h3>
            <p className="text-gray-400 text-xs mb-4">
              Understanding where QR codes perform best helps improve placement decisions.
            </p>
            <div className="space-y-3">
              {getContextBreakdown().map(({ context, label, scans, redemptions, rate }) => (
                <div key={context} className="space-y-1">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-300">{label}</span>
                    <span className="text-gray-400">
                      {scans.toLocaleString()} scans • {rate.toFixed(1)}% success
                    </span>
                  </div>
                  <div className="h-2 bg-charcoal-700 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-gold to-gold-400 rounded-full transition-all"
                      style={{ width: `${(scans / summary.totalScans) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Device Breakdown */}
          <div className="p-6 bg-charcoal-800 rounded-2xl border border-charcoal-700">
            <h3 className="text-white font-semibold mb-4">Device Categories</h3>
            <p className="text-gray-400 text-xs mb-4">
              Device distribution helps optimize QR code sizing and UX decisions.
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {getDeviceBreakdown().map(({ device, count, percentage }) => (
                <div
                  key={device}
                  className="p-4 bg-charcoal-700 rounded-xl text-center"
                >
                  <div className="w-10 h-10 bg-charcoal-600 rounded-full flex items-center justify-center mx-auto mb-2 text-gold">
                    {DEVICE_ICONS[device]}
                  </div>
                  <p className="text-white font-medium capitalize">{device}</p>
                  <p className="text-gray-400 text-sm">{percentage.toFixed(1)}%</p>
                  <p className="text-gray-500 text-xs">{count.toLocaleString()} scans</p>
                </div>
              ))}
            </div>
          </div>

          {/* Daily Trend */}
          <div className="p-6 bg-charcoal-800 rounded-2xl border border-charcoal-700">
            <h3 className="text-white font-semibold mb-4">Daily Trend (Last 14 Days)</h3>
            <p className="text-gray-400 text-xs mb-4">
              Tracking daily patterns helps identify system issues and seasonal trends.
            </p>
            <div className="flex items-end gap-1 h-32">
              {getDailyTrend().map(({ date, scans, redemptions }) => {
                const maxScans = Math.max(...getDailyTrend().map(d => d.scans), 1);
                const height = (scans / maxScans) * 100;
                const successHeight = scans > 0 ? (redemptions / scans) * height : 0;
                
                return (
                  <div
                    key={date}
                    className="flex-1 flex flex-col justify-end group relative"
                  >
                    <div
                      className="bg-charcoal-600 rounded-t relative overflow-hidden transition-all group-hover:bg-charcoal-500"
                      style={{ height: `${height}%`, minHeight: scans > 0 ? '4px' : '0' }}
                    >
                      <div
                        className="absolute bottom-0 left-0 right-0 bg-emerald-500/50"
                        style={{ height: `${(redemptions / Math.max(scans, 1)) * 100}%` }}
                      />
                    </div>
                    {/* Tooltip */}
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-charcoal-900 rounded text-xs text-white whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                      {new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                      <br />
                      {scans} scans • {redemptions} success
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
              <span>{getDailyTrend()[0]?.date ? new Date(getDailyTrend()[0].date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : ''}</span>
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-charcoal-600 rounded" /> Total
                </span>
                <span className="flex items-center gap-1">
                  <div className="w-3 h-3 bg-emerald-500/50 rounded" /> Success
                </span>
              </div>
              <span>{getDailyTrend()[getDailyTrend().length - 1]?.date ? new Date(getDailyTrend()[getDailyTrend().length - 1].date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : ''}</span>
            </div>
          </div>

          {/* Insights */}
          <div className="p-6 bg-charcoal-800 rounded-2xl border border-charcoal-700">
            <h3 className="text-white font-semibold mb-4">Product Insights</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-charcoal-700 rounded-xl">
                <TrendingUp className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-white text-sm font-medium">Top Performing Context</p>
                  <p className="text-gray-400 text-sm">
                    {CONTEXT_LABELS[summary.topContext]} generates the most scans. Consider focusing QR placement efforts here.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-charcoal-700 rounded-xl">
                <Smartphone className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-white text-sm font-medium">Primary Device</p>
                  <p className="text-gray-400 text-sm">
                    Most scans come from {summary.topDevice} devices. Ensure QR codes are optimized for this experience.
                  </p>
                </div>
              </div>

              {summary.failedScans > summary.totalScans * 0.1 && (
                <div className="flex items-start gap-3 p-3 bg-red-500/10 border border-red-500/30 rounded-xl">
                  <AlertTriangle className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-red-400 text-sm font-medium">High Failure Rate Detected</p>
                    <p className="text-red-400/70 text-sm">
                      {((summary.failedScans / summary.totalScans) * 100).toFixed(1)}% of scans are failing. 
                      Consider investigating QR code quality or technical issues.
                    </p>
                  </div>
                </div>
              )}

              {summary.avgRedemptionTime && summary.avgRedemptionTime > 30 && (
                <div className="flex items-start gap-3 p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl">
                  <Clock className="w-5 h-5 text-amber-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-amber-400 text-sm font-medium">Slow Redemption Time</p>
                    <p className="text-amber-400/70 text-sm">
                      Average time to redeem is {summary.avgRedemptionTime}s. Consider simplifying the redemption flow.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default QRScanAnalytics;
