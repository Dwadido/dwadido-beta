/**
 * SupportChatContext
 * ─────────────────
 * Controls whether the global SupportChat component is mounted in the DOM.
 *
 * Problem solved:
 *   On mobile (iPhone Safari), the SupportChat floating button (fixed,
 *   bottom-right, z-50) overlaps ChatModal's Send button. Previous attempts
 *   used CustomEvent-based hiding (`requestHideSupportChat`), but events are
 *   fragile — they can be missed due to mount-order race conditions, and
 *   CSS-only hiding (opacity/visibility) still captures touch events on iOS.
 *
 * Solution:
 *   This context lets any component (e.g. ChatModal) call `hide()` to
 *   **conditionally unmount** SupportChat entirely from the React tree.
 *   App.tsx reads `hidden` and renders `<SupportChat />` only when false.
 *   This guarantees zero DOM presence — no z-index stacking, no ghost
 *   touch targets, no race conditions.
 *
 * Usage:
 *   // In ChatModal (or any full-screen modal):
 *   const { hide, show } = useSupportChatVisibility();
 *   useEffect(() => { hide(); return () => show(); }, []);
 *
 *   // In App.tsx:
 *   const { hidden } = useSupportChatVisibility();
 *   {!hidden && <SupportChat />}
 */

import React, { createContext, useContext, useState, useCallback } from 'react';

interface SupportChatVisibility {
  /** When true, SupportChat should NOT be rendered at all */
  hidden: boolean;
  /** Unmount SupportChat (call when a full-screen modal opens) */
  hide: () => void;
  /** Re-mount SupportChat (call when the full-screen modal closes) */
  show: () => void;
}

const SupportChatContext = createContext<SupportChatVisibility>({
  hidden: false,
  hide: () => {},
  show: () => {},
});

export const SupportChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [hidden, setHidden] = useState(false);

  const hide = useCallback(() => setHidden(true), []);
  const show = useCallback(() => setHidden(false), []);

  return (
    <SupportChatContext.Provider value={{ hidden, hide, show }}>
      {children}
    </SupportChatContext.Provider>
  );
};

export const useSupportChatVisibility = () => useContext(SupportChatContext);
