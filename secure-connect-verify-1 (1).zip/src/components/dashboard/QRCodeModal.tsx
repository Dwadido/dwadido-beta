import React, { useRef, useEffect, useState } from 'react';
import { X, Download, Copy, Check, Share2, QrCode, Loader2, Printer, History, Sparkles, Lock, Crown } from 'lucide-react';
import { usePremium } from '@/contexts/PremiumContext';
import FreemiumUpsell, { UpsellTrigger } from './FreemiumUpsell';

interface QRCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  code: string;
  shareUrl: string;
  onPrintCard?: () => void;
}

// QR Code constants
const ALPHANUMERIC_CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:';
const VERSION_CAPACITY = [0, 20, 38, 61, 90, 122, 154, 195, 230, 271, 311, 370, 428, 461, 523, 589, 647, 721, 795, 861, 932];

// Galois Field tables for error correction
const GF256_EXP = new Uint8Array(512);
const GF256_LOG = new Uint8Array(256);

// Initialize Galois Field tables
(function initGF256() {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF256_EXP[i] = x;
    GF256_LOG[x] = i;
    x = (x << 1) ^ (x >= 128 ? 0x11d : 0);
  }
  for (let i = 255; i < 512; i++) {
    GF256_EXP[i] = GF256_EXP[i - 255];
  }
})();

function gfMul(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return GF256_EXP[GF256_LOG[a] + GF256_LOG[b]];
}

function generateErrorCorrectionCodewords(data: number[], ecCount: number): number[] {
  const gen = [1];
  for (let i = 0; i < ecCount; i++) {
    const newGen = new Array(gen.length + 1).fill(0);
    for (let j = 0; j < gen.length; j++) {
      newGen[j] ^= gen[j];
      newGen[j + 1] ^= gfMul(gen[j], GF256_EXP[i]);
    }
    gen.length = 0;
    gen.push(...newGen);
  }

  const result = new Array(ecCount).fill(0);
  for (const byte of data) {
    const factor = byte ^ result[0];
    result.shift();
    result.push(0);
    for (let i = 0; i < ecCount; i++) {
      result[i] ^= gfMul(gen[i + 1], factor);
    }
  }
  return result;
}

function encodeByte(text: string): number[] {
  const bits: number[] = [];
  
  // Mode indicator (4 bits) - Byte = 0100
  bits.push(0, 1, 0, 0);
  
  // Character count indicator (8 bits for version 1-9)
  const countBits = text.length.toString(2).padStart(8, '0');
  for (const bit of countBits) bits.push(parseInt(bit));
  
  // Encode each character as 8-bit byte
  for (let i = 0; i < text.length; i++) {
    const charCode = text.charCodeAt(i);
    const charBits = charCode.toString(2).padStart(8, '0');
    for (const bit of charBits) bits.push(parseInt(bit));
  }
  
  return bits;
}

function getVersionForUrl(text: string): number {
  // Byte mode capacity for M error correction
  const byteCapacity = [0, 14, 26, 42, 62, 84, 106, 122, 152, 180, 213, 251, 287, 331, 362, 412, 450, 504, 560, 624, 666];
  for (let v = 1; v <= 20; v++) {
    if (text.length <= byteCapacity[v]) return v;
  }
  return 20;
}

function getModuleCount(version: number): number {
  return 17 + version * 4;
}

// Data codewords and EC codewords for each version (M level)
const VERSION_INFO: { [key: number]: { dataCodewords: number; ecCodewords: number } } = {
  1: { dataCodewords: 16, ecCodewords: 10 },
  2: { dataCodewords: 28, ecCodewords: 16 },
  3: { dataCodewords: 44, ecCodewords: 26 },
  4: { dataCodewords: 64, ecCodewords: 18 },
  5: { dataCodewords: 86, ecCodewords: 24 },
  6: { dataCodewords: 108, ecCodewords: 16 },
  7: { dataCodewords: 124, ecCodewords: 18 },
  8: { dataCodewords: 154, ecCodewords: 22 },
  9: { dataCodewords: 182, ecCodewords: 22 },
  10: { dataCodewords: 216, ecCodewords: 26 },
};

function createQRMatrix(text: string): boolean[][] {
  const version = Math.min(getVersionForUrl(text), 10);
  const size = getModuleCount(version);
  const matrix: (boolean | null)[][] = Array(size).fill(null).map(() => Array(size).fill(null));
  
  // Add finder patterns
  const addFinderPattern = (row: number, col: number) => {
    for (let r = -1; r <= 7; r++) {
      for (let c = -1; c <= 7; c++) {
        const nr = row + r, nc = col + c;
        if (nr < 0 || nr >= size || nc < 0 || nc >= size) continue;
        
        if (r === -1 || r === 7 || c === -1 || c === 7) {
          matrix[nr][nc] = false;
        } else if (r === 0 || r === 6 || c === 0 || c === 6) {
          matrix[nr][nc] = true;
        } else if (r >= 2 && r <= 4 && c >= 2 && c <= 4) {
          matrix[nr][nc] = true;
        } else {
          matrix[nr][nc] = false;
        }
      }
    }
  };
  
  addFinderPattern(0, 0);
  addFinderPattern(0, size - 7);
  addFinderPattern(size - 7, 0);
  
  // Add timing patterns
  for (let i = 8; i < size - 8; i++) {
    matrix[6][i] = i % 2 === 0;
    matrix[i][6] = i % 2 === 0;
  }
  
  // Add dark module
  matrix[size - 8][8] = true;
  
  // Reserve format information areas
  for (let i = 0; i < 9; i++) {
    if (matrix[8][i] === null) matrix[8][i] = false;
    if (matrix[i][8] === null) matrix[i][8] = false;
    if (i < 8) {
      if (matrix[8][size - 1 - i] === null) matrix[8][size - 1 - i] = false;
      if (matrix[size - 1 - i][8] === null) matrix[size - 1 - i][8] = false;
    }
  }
  
  // Add alignment pattern for version >= 2
  if (version >= 2) {
    const alignPos = size - 7;
    for (let r = -2; r <= 2; r++) {
      for (let c = -2; c <= 2; c++) {
        const nr = alignPos + r, nc = alignPos + c;
        if (Math.abs(r) === 2 || Math.abs(c) === 2) {
          matrix[nr][nc] = true;
        } else if (r === 0 && c === 0) {
          matrix[nr][nc] = true;
        } else {
          matrix[nr][nc] = false;
        }
      }
    }
  }
  
  // Encode data using byte mode for URLs
  const dataBits = encodeByte(text);
  const versionInfo = VERSION_INFO[version] || VERSION_INFO[1];
  const totalBits = versionInfo.dataCodewords * 8;
  
  // Add terminator
  const terminatorLength = Math.min(4, totalBits - dataBits.length);
  for (let i = 0; i < terminatorLength; i++) dataBits.push(0);
  
  // Pad to byte boundary
  while (dataBits.length % 8 !== 0) dataBits.push(0);
  
  // Add padding codewords
  const padPatterns = [0xEC, 0x11];
  let padIndex = 0;
  while (dataBits.length < totalBits) {
    const pad = padPatterns[padIndex % 2];
    for (let i = 7; i >= 0; i--) dataBits.push((pad >> i) & 1);
    padIndex++;
  }
  
  // Convert to bytes
  const dataBytes: number[] = [];
  for (let i = 0; i < dataBits.length; i += 8) {
    let byte = 0;
    for (let j = 0; j < 8; j++) {
      byte = (byte << 1) | (dataBits[i + j] || 0);
    }
    dataBytes.push(byte);
  }
  
  // Generate error correction
  const ecBytes = generateErrorCorrectionCodewords(dataBytes, versionInfo.ecCodewords);
  
  // Combine data and EC
  const allBytes = [...dataBytes, ...ecBytes];
  const allBits: number[] = [];
  for (const byte of allBytes) {
    for (let i = 7; i >= 0; i--) {
      allBits.push((byte >> i) & 1);
    }
  }
  
  // Place data in matrix using zigzag pattern
  let bitIndex = 0;
  let upward = true;
  
  for (let col = size - 1; col >= 0; col -= 2) {
    if (col === 6) col = 5;
    
    const rows = upward ? 
      Array.from({ length: size }, (_, i) => size - 1 - i) :
      Array.from({ length: size }, (_, i) => i);
    
    for (const row of rows) {
      for (let c = 0; c < 2; c++) {
        const actualCol = col - c;
        if (matrix[row][actualCol] === null) {
          matrix[row][actualCol] = bitIndex < allBits.length ? allBits[bitIndex++] === 1 : false;
        }
      }
    }
    upward = !upward;
  }
  
  // Apply mask pattern 0 (checkerboard)
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (isReserved(row, col, size, version)) continue;
      if ((row + col) % 2 === 0) {
        matrix[row][col] = !matrix[row][col];
      }
    }
  }
  
  // Add format information (mask 0, M error correction)
  const formatBits = [1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1];
  
  for (let i = 0; i < 6; i++) matrix[8][i] = formatBits[i] === 1;
  matrix[8][7] = formatBits[6] === 1;
  matrix[8][8] = formatBits[7] === 1;
  matrix[7][8] = formatBits[8] === 1;
  for (let i = 9; i < 15; i++) matrix[14 - i][8] = formatBits[i] === 1;
  
  for (let i = 0; i < 8; i++) matrix[8][size - 8 + i] = formatBits[7 + i] === 1;
  for (let i = 0; i < 7; i++) matrix[size - 1 - i][8] = formatBits[i] === 1;
  
  return matrix.map(row => row.map(cell => cell === true));
}

function isReserved(row: number, col: number, size: number, version: number): boolean {
  if (row < 9 && col < 9) return true;
  if (row < 9 && col >= size - 8) return true;
  if (row >= size - 8 && col < 9) return true;
  if (row === 6 || col === 6) return true;
  
  if (version >= 2) {
    const alignPos = size - 7;
    if (Math.abs(row - alignPos) <= 2 && Math.abs(col - alignPos) <= 2) return true;
  }
  
  return false;
}

const QRCodeModal: React.FC<QRCodeModalProps> = ({
  isOpen,
  onClose,
  code,
  shareUrl,
  onPrintCard
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { isPremium, canUseFeature } = usePremium();
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [generating, setGenerating] = useState(true);
  const [upsellModal, setUpsellModal] = useState<{
    isOpen: boolean;
    trigger: UpsellTrigger;
  }>({ isOpen: false, trigger: 'printing' });

  useEffect(() => {
    if (!isOpen || !shareUrl) return;
    
    setGenerating(true);
    
    // Small delay to show loading state
    const timer = setTimeout(() => {
      try {
        const qrMatrix = createQRMatrix(shareUrl);
        
        const canvas = canvasRef.current;
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        
        const size = 280;
        const moduleCount = qrMatrix.length;
        const moduleSize = Math.floor(size / (moduleCount + 8));
        const actualSize = moduleSize * (moduleCount + 8);
        
        canvas.width = actualSize;
        canvas.height = actualSize;
        
        // White background with rounded corners effect
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, actualSize, actualSize);
        
        // Draw modules with slight rounding
        ctx.fillStyle = '#1a1a1a';
        const offset = moduleSize * 4;
        
        for (let row = 0; row < moduleCount; row++) {
          for (let col = 0; col < moduleCount; col++) {
            if (qrMatrix[row][col]) {
              const x = offset + col * moduleSize;
              const y = offset + row * moduleSize;
              const radius = moduleSize * 0.15;
              
              ctx.beginPath();
              ctx.roundRect(x, y, moduleSize, moduleSize, radius);
              ctx.fill();
            }
          }
        }
        
        // Add Dwadido logo/branding in center
        const centerSize = moduleSize * 7;
        const centerX = (actualSize - centerSize) / 2;
        const centerY = (actualSize - centerSize) / 2;
        
        // White background for logo
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.roundRect(centerX - 4, centerY - 4, centerSize + 8, centerSize + 8, 8);
        ctx.fill();
        
        // Gold accent
        ctx.fillStyle = '#D4AF37';
        ctx.beginPath();
        ctx.roundRect(centerX, centerY, centerSize, centerSize, 6);
        ctx.fill();
        
        // D letter
        ctx.fillStyle = '#1a1a1a';
        ctx.font = `bold ${centerSize * 0.6}px system-ui, sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('D', actualSize / 2, actualSize / 2 + 2);
        
        setGenerating(false);
      } catch (error) {
        console.error('QR Code generation error:', error);
        setGenerating(false);
      }
    }, 300);
    
    return () => clearTimeout(timer);
  }, [isOpen, shareUrl]);

  const handleDownload = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    setDownloading(true);
    
    // Create a new canvas with branding
    const exportCanvas = document.createElement('canvas');
    const exportCtx = exportCanvas.getContext('2d');
    if (!exportCtx) return;
    
    const padding = 40;
    const headerHeight = 60;
    const footerHeight = 80;
    
    exportCanvas.width = canvas.width + padding * 2;
    exportCanvas.height = canvas.height + padding * 2 + headerHeight + footerHeight;
    
    // Background gradient
    const gradient = exportCtx.createLinearGradient(0, 0, 0, exportCanvas.height);
    gradient.addColorStop(0, '#1a1a1a');
    gradient.addColorStop(1, '#2d2d2d');
    exportCtx.fillStyle = gradient;
    exportCtx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);
    
    // Header text
    exportCtx.fillStyle = '#D4AF37';
    exportCtx.font = 'bold 24px system-ui, sans-serif';
    exportCtx.textAlign = 'center';
    exportCtx.fillText('Dwadido', exportCanvas.width / 2, padding + 30);
    
    // QR Code
    exportCtx.drawImage(canvas, padding, padding + headerHeight);
    
    // Code text
    exportCtx.fillStyle = '#FFFFFF';
    exportCtx.font = 'bold 20px monospace';
    exportCtx.fillText(`Code: ${code}`, exportCanvas.width / 2, canvas.height + padding + headerHeight + 35);
    
    // Instruction text
    exportCtx.fillStyle = '#888888';
    exportCtx.font = '14px system-ui, sans-serif';
    exportCtx.fillText('Scan to connect with me!', exportCanvas.width / 2, canvas.height + padding + headerHeight + 60);
    
    // Download
    const link = document.createElement('a');
    link.download = `dwadido-qr-${code}.png`;
    link.href = exportCanvas.toDataURL('image/png');
    link.click();
    
    setTimeout(() => setDownloading(false), 500);
  };

  const handleCopy = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    try {
      canvas.toBlob(async (blob) => {
        if (blob) {
          await navigator.clipboard.write([
            new ClipboardItem({ 'image/png': blob })
          ]);
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        }
      });
    } catch (error) {
      console.error('Failed to copy QR code:', error);
    }
  };

  const handleShare = async () => {
    const canvas = canvasRef.current;
    if (!canvas || !navigator.share) return;
    
    try {
      canvas.toBlob(async (blob) => {
        if (blob) {
          const file = new File([blob], `dwadido-qr-${code}.png`, { type: 'image/png' });
          await navigator.share({
            title: 'Dwadido - Connect with me',
            text: `Scan this QR code to connect with me on Dwadido! Code: ${code}`,
            files: [file]
          });
        }
      });
    } catch (error) {
      if ((error as Error).name !== 'AbortError') {
        console.error('Share failed:', error);
      }
    }
  };

  // Premium-gated: Print QR Card
  const handlePrintCard = () => {
    if (!canUseFeature('printQRCards')) {
      setUpsellModal({ isOpen: true, trigger: 'printing' });
      return;
    }
    onPrintCard?.();
  };

  // Premium-gated: Animated QR
  const handleAnimatedQR = () => {
    if (!canUseFeature('animatedQRCodes')) {
      setUpsellModal({ isOpen: true, trigger: 'animated_qr' });
      return;
    }
    // TODO: Implement animated QR code feature
  };

  // Premium-gated: QR Scan History
  const handleScanHistory = () => {
    if (!canUseFeature('qrScanHistory')) {
      setUpsellModal({ isOpen: true, trigger: 'qr_scan_history' });
      return;
    }
    // TODO: Implement scan history view
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
        {/* Backdrop */}
        <div 
          className="absolute inset-0 bg-black/80 backdrop-blur-md"
          onClick={onClose}
        />

        {/* Modal */}
        <div className="relative bg-charcoal-800 rounded-2xl border border-charcoal-600 w-full max-w-sm overflow-hidden animate-in fade-in zoom-in duration-200 max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-charcoal-600">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center">
                <QrCode className="w-5 h-5 text-gold" />
              </div>
              <div>
                <h3 className="font-semibold text-white">QR Code</h3>
                <p className="text-sm text-gray-400">Scan to redeem</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="p-6">
            {/* Free tier badge */}
            {!isPremium && (
              <div className="mb-4 px-3 py-1.5 bg-charcoal-700 rounded-lg border border-charcoal-600 flex items-center justify-center gap-2">
                <span className="text-xs text-gray-400">Basic Digital QR</span>
                <span className="text-xs text-gray-500">•</span>
                <span className="text-xs text-gold">Free</span>
              </div>
            )}

            {/* QR Code Display */}
            <div className="flex flex-col items-center">
              <div className="relative bg-white p-4 rounded-2xl shadow-2xl">
                {generating && (
                  <div className="absolute inset-0 flex items-center justify-center bg-white rounded-2xl">
                    <Loader2 className="w-8 h-8 text-gold animate-spin" />
                  </div>
                )}
                <canvas 
                  ref={canvasRef} 
                  className={`block transition-opacity duration-300 ${generating ? 'opacity-0' : 'opacity-100'}`}
                  style={{ width: 240, height: 240 }}
                />
              </div>
              
              {/* Code Display */}
              <div className="mt-4 px-4 py-2 bg-charcoal-700 rounded-lg border border-charcoal-600">
                <p className="text-xs text-gray-400 text-center mb-1">Your Code</p>
                <p className="font-mono text-xl font-bold text-gold tracking-widest text-center">{code}</p>
              </div>
              
              {/* Instructions */}
              <p className="mt-3 text-sm text-gray-400 text-center">
                Share this QR code for quick scanning
              </p>
            </div>

            {/* Action Buttons */}
            <div className="mt-6 grid grid-cols-2 gap-3">
              <button
                onClick={handleDownload}
                disabled={generating || downloading}
                className="flex items-center justify-center gap-2 py-3 bg-gold hover:bg-gold-400 disabled:bg-charcoal-600 text-charcoal font-semibold rounded-xl transition-all"
              >
                {downloading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Download className="w-5 h-5" />
                )}
                <span>Download</span>
              </button>
              
              <button
                onClick={handleCopy}
                disabled={generating}
                className="flex items-center justify-center gap-2 py-3 bg-charcoal-700 hover:bg-charcoal-600 disabled:bg-charcoal-600 text-white font-medium rounded-xl transition-all border border-charcoal-600"
              >
                {copied ? (
                  <>
                    <Check className="w-5 h-5 text-green-400" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-5 h-5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            {/* Native Share (if available) */}
            {typeof navigator !== 'undefined' && navigator.share && navigator.canShare && (
              <button
                onClick={handleShare}
                disabled={generating}
                className="w-full mt-3 flex items-center justify-center gap-2 py-3 bg-charcoal-700 hover:bg-charcoal-600 text-gray-300 hover:text-white font-medium rounded-xl transition-all border border-charcoal-600"
              >
                <Share2 className="w-5 h-5" />
                <span>Share QR Code</span>
              </button>
            )}

            {/* Premium Features Section */}
            <div className="mt-6 pt-6 border-t border-charcoal-600">
              <p className="text-xs text-gray-500 uppercase tracking-wide mb-3">Premium QR Features</p>
              
              {/* Print QR Card - Premium */}
              <button
                onClick={handlePrintCard}
                className="w-full flex items-center justify-between p-3 bg-charcoal-700/50 hover:bg-charcoal-700 rounded-xl border border-charcoal-600 transition-all mb-2"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-pink-500/20 rounded-lg flex items-center justify-center">
                    <Printer className="w-4 h-4 text-pink-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-medium text-white flex items-center gap-2">
                      Print QR Cards
                      {!isPremium && <Lock className="w-3 h-3 text-gray-500" />}
                    </p>
                    <p className="text-xs text-gray-400">Business cards with tear-off tabs</p>
                  </div>
                </div>
                {!isPremium && <Crown className="w-4 h-4 text-gold" />}
              </button>

              {/* Animated QR - Premium */}
              <button
                onClick={handleAnimatedQR}
                className="w-full flex items-center justify-between p-3 bg-charcoal-700/50 hover:bg-charcoal-700 rounded-xl border border-charcoal-600 transition-all mb-2"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-medium text-white flex items-center gap-2">
                      Animated QR Codes
                      {!isPremium && <Lock className="w-3 h-3 text-gray-500" />}
                    </p>
                    <p className="text-xs text-gray-400">Eye-catching animated designs</p>
                  </div>
                </div>
                {!isPremium && <Crown className="w-4 h-4 text-gold" />}
              </button>

              {/* QR Scan History - Premium */}
              <button
                onClick={handleScanHistory}
                className="w-full flex items-center justify-between p-3 bg-charcoal-700/50 hover:bg-charcoal-700 rounded-xl border border-charcoal-600 transition-all"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-indigo-500/20 rounded-lg flex items-center justify-center">
                    <History className="w-4 h-4 text-indigo-400" />
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-medium text-white flex items-center gap-2">
                      QR Scan History
                      {!isPremium && <Lock className="w-3 h-3 text-gray-500" />}
                    </p>
                    <p className="text-xs text-gray-400">Track when & where scanned</p>
                  </div>
                </div>
                {!isPremium && <Crown className="w-4 h-4 text-gold" />}
              </button>
            </div>
          </div>

          {/* Footer */}
          <div className="px-6 pb-6">
            <p className="text-xs text-gray-500 text-center">
              When scanned, this QR code will open the redemption page with your code pre-filled.
            </p>
          </div>
        </div>
      </div>

      {/* Freemium Upsell Modal */}
      <FreemiumUpsell
        isOpen={upsellModal.isOpen}
        onClose={() => setUpsellModal({ ...upsellModal, isOpen: false })}
        trigger={upsellModal.trigger}
      />
    </>
  );
};

export default QRCodeModal;
