// Dwadido Service Worker v3 — 2026-02-19T16:44:00Z
// CRITICAL: Network-first for all app assets to prevent stale JS bundles

const CACHE_NAME = 'dwadido-v3';
const APP_URL = self.location.origin;

// Install event — skip waiting immediately to activate new SW
self.addEventListener('install', (event) => {
  console.log('[SW v3] Installing — will skip waiting');
  self.skipWaiting();
});

// Activate event — claim all clients and purge old caches
self.addEventListener('activate', (event) => {
  console.log('[SW v3] Activating — purging old caches');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => {
            console.log('[SW v3] Deleting old cache:', name);
            return caches.delete(name);
          })
      );
    }).then(() => {
      console.log('[SW v3] Claiming all clients');
      return clients.claim();
    })
  );
});

// Fetch event — NETWORK-FIRST for all app assets
// This prevents stale JS bundles from being served from cache
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // Skip non-GET requests
  if (event.request.method !== 'GET') return;
  
  // Skip cross-origin requests (Supabase API calls, etc.)
  if (url.origin !== self.location.origin) return;
  
  // Skip /src/ paths in dev mode
  if (url.pathname.startsWith('/src/')) return;
  
  // Network-first strategy for all same-origin assets
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Clone and cache the fresh response
        if (response.ok) {
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseClone);
          });
        }
        return response;
      })
      .catch(() => {
        // Fallback to cache only if network fails
        return caches.match(event.request);
      })
  );
});

// Push notification event
self.addEventListener('push', (event) => {
  console.log('Push notification received:', event);

  let data = {
    title: 'Dwadido',
    body: 'You have a new notification',
    icon: '/dwadido-icon.png',
    badge: '/dwadido-badge.png',
    tag: 'dwadido-notification',
    data: { url: '/dashboard' },
  };

  if (event.data) {
    try {
      const payload = event.data.json();
      data = { ...data, ...payload };
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const notificationOptions = {
    body: data.body,
    icon: data.icon || '/dwadido-icon.png',
    badge: data.badge || '/dwadido-badge.png',
    tag: data.tag || 'dwadido-notification',
    vibrate: [200, 100, 200],
    requireInteraction: data.requireInteraction || false,
    data: data.data || { url: '/dashboard' },
    actions: data.actions || getActionsForType(data.type || data.tag),
    image: data.image,
    renotify: true,
    silent: data.silent || false,
  };

  event.waitUntil(
    self.registration.showNotification(data.title, notificationOptions)
  );
});

function getActionsForType(type) {
  if (!type) return [];
  switch (type) {
    case 'new_match':
    case 'mutual_match':
      return [
        { action: 'open_chat', title: 'Say Hi', icon: '/icons/chat.png' },
        { action: 'view_profile', title: 'View Profile', icon: '/icons/profile.png' },
      ];
    case 'new_message':
      return [
        { action: 'reply', title: 'Reply', icon: '/icons/reply.png' },
        { action: 'view', title: 'View', icon: '/icons/view.png' },
      ];
    case 'crush_code_redeemed':
      return [
        { action: 'view', title: 'View Connection', icon: '/icons/heart.png' },
      ];
    case 'photo_request':
      return [
        { action: 'approve', title: 'Share Photos', icon: '/icons/approve.png' },
        { action: 'decline', title: 'Decline', icon: '/icons/decline.png' },
      ];
    case 'photo_request_response':
      return [
        { action: 'view', title: 'View Photos', icon: '/icons/view.png' },
      ];
    case 'meeting_suggestion':
      return [
        { action: 'accept', title: 'Accept', icon: '/icons/check.png' },
        { action: 'suggest_different', title: 'Suggest Different', icon: '/icons/edit.png' },
      ];
    case 'meeting_response':
      return [
        { action: 'view', title: 'View Details', icon: '/icons/calendar.png' },
      ];
    case 'verification_update':
      return [
        { action: 'view', title: 'View Status', icon: '/icons/badge.png' },
      ];
    default:
      return [];
  }
}

// Notification click event
self.addEventListener('notificationclick', (event) => {
  console.log('Notification clicked:', event);
  event.notification.close();

  let targetUrl = '/dashboard';
  const notificationData = event.notification.data || {};
  const notificationType = notificationData.type;

  switch (event.action) {
    case 'open_chat':
    case 'reply':
      if (notificationData.connectionId) {
        targetUrl = `/dashboard?chat=${notificationData.connectionId}`;
      } else if (notificationData.matchId) {
        targetUrl = `/dashboard?chat=${notificationData.matchId}`;
      }
      break;
    case 'view_profile':
      if (notificationData.matchId) {
        targetUrl = `/dashboard?profile=${notificationData.matchId}`;
      } else if (notificationData.userId) {
        targetUrl = `/dashboard?profile=${notificationData.userId}`;
      }
      break;
    case 'approve':
    case 'decline':
      if (notificationData.connectionId) {
        targetUrl = `/dashboard?photo_request=${notificationData.connectionId}&action=${event.action}`;
      }
      break;
    case 'accept':
    case 'suggest_different':
      if (notificationData.connectionId) {
        targetUrl = `/dashboard?meeting=${notificationData.connectionId}&action=${event.action}`;
      }
      break;
    case 'view':
    default:
      if (notificationData.url) {
        targetUrl = notificationData.url;
      } else {
        switch (notificationType) {
          case 'new_match':
          case 'mutual_match':
          case 'crush_code_redeemed':
            targetUrl = '/dashboard';
            break;
          case 'new_message':
            targetUrl = notificationData.connectionId
              ? `/dashboard?chat=${notificationData.connectionId}`
              : '/dashboard';
            break;
          case 'verification_update':
            targetUrl = '/settings';
            break;
          case 'photo_request':
          case 'photo_request_response':
          case 'meeting_suggestion':
          case 'meeting_response':
            targetUrl = notificationData.connectionId
              ? `/dashboard?chat=${notificationData.connectionId}`
              : '/dashboard';
            break;
          default:
            targetUrl = '/dashboard';
        }
      }
      break;
  }

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        for (const client of clientList) {
          if (client.url.includes(APP_URL) && 'focus' in client) {
            client.focus();
            client.postMessage({
              type: 'NOTIFICATION_CLICK',
              url: targetUrl,
              data: notificationData,
              action: event.action
            });
            return;
          }
        }
        if (clients.openWindow) {
          return clients.openWindow(targetUrl);
        }
      })
  );
});

// Notification close event
self.addEventListener('notificationclose', (event) => {
  console.log('Notification closed:', event.notification.tag);
  const notificationData = event.notification.data || {};
  clients.matchAll({ type: 'window', includeUncontrolled: true })
    .then((clientList) => {
      for (const client of clientList) {
        client.postMessage({
          type: 'NOTIFICATION_DISMISSED',
          data: notificationData
        });
      }
    });
});

// Background sync
self.addEventListener('sync', (event) => {
  console.log('Background sync:', event.tag);
  if (event.tag === 'sync-messages') {
    event.waitUntil(syncMessages());
  }
  if (event.tag === 'sync-notifications') {
    event.waitUntil(syncNotifications());
  }
});

async function syncMessages() {
  console.log('Syncing messages...');
}

async function syncNotifications() {
  console.log('Syncing notifications...');
}

// Handle message from main thread
self.addEventListener('message', (event) => {
  console.log('Service Worker received message:', event.data);

  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }

  if (event.data && event.data.type === 'TEST_NOTIFICATION') {
    self.registration.showNotification('Test Notification', {
      body: 'Push notifications are working!',
      icon: '/dwadido-icon.png',
      badge: '/dwadido-badge.png',
      tag: 'test-notification',
      data: { url: '/dashboard' }
    });
  }

  if (event.data && event.data.type === 'CLEAR_NOTIFICATIONS') {
    self.registration.getNotifications().then((notifications) => {
      notifications.forEach((notification) => notification.close());
    });
  }
});

// Periodic background sync
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'check-notifications') {
    event.waitUntil(checkForNewNotifications());
  }
});

async function checkForNewNotifications() {
  console.log('Checking for new notifications...');
}
