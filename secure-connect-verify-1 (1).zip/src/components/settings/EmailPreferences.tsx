import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { usePremium } from '@/contexts/PremiumContext';
import { 
  Mail, 
  CreditCard, 
  Crown, 
  Megaphone, 
  Calendar,
  Loader2,
  Check,
  AlertCircle,
  Globe,
  RotateCcw,
  Heart,
  MessageCircle,
  QrCode,
  Shield,
  Eye,
  Send,
  History,
  Smartphone,
  Lock,
  Edit3,
  Clock,
  Sliders
} from 'lucide-react';
import FreemiumUpsell, { UpsellTrigger } from '@/components/dashboard/FreemiumUpsell';

type SupportedLanguage = 'en' | 'es' | 'fr' | 'de';

interface EmailPreferencesData {
  id?: string;
  user_id: string;
  email_enabled: boolean;
  payment_alerts: boolean;
  subscription_alerts: boolean;
  marketing_emails: boolean;
  weekly_digest: boolean;
  retry_notifications: boolean;
  new_matches: boolean;
  new_messages: boolean;
  crush_code_alerts: boolean;
  verification_alerts: boolean;
  profile_views: boolean;
  language: string;
  unsubscribe_token?: string;
  // SMS preferences
  sms_enabled?: boolean;
  sms_new_match?: boolean;
  sms_code_used?: boolean;
  sms_code_expiring?: boolean;
  sms_code_expired?: boolean;
  // Digest preferences
  digest_frequency?: 'daily' | 'weekly' | 'monthly';
  digest_include_matches?: boolean;
  digest_include_messages?: boolean;
  digest_include_codes?: boolean;
  digest_include_tips?: boolean;
}

interface EmailLogEntry {
  id: string;
  email_type: string;
  subject: string;
  status: string;
  created_at: string;
}

// UI translations
const UI_TEXT = {
  en: {
    title: 'Email Notifications',
    description: 'Manage which emails you receive from us',
    masterToggle: 'Email Notifications',
    masterToggleDesc: 'Receive email notifications',
    
    // Activity notifications
    activitySection: 'Activity Notifications',
    newMatches: 'New Matches',
    newMatchesDesc: 'Get notified when someone matches with you',
    newMessages: 'New Messages',
    newMessagesDesc: 'Receive emails when you get new messages while offline',
    crushCodeAlerts: 'Crush Code Alerts',
    crushCodeAlertsDesc: 'Get notified when someone redeems your Crush Code',
    verificationAlerts: 'Verification Updates',
    verificationAlertsDesc: 'Updates about your profile verification status',
    profileViews: 'Profile Views',
    profileViewsDesc: 'Know when someone views your profile (Premium)',
    
    // Payment notifications
    paymentSection: 'Payment & Subscription',
    paymentAlerts: 'Payment Alerts',
    paymentAlertsDesc: 'Card expiring, payment failed, payment method updates',
    subscriptionAlerts: 'Subscription Alerts',
    subscriptionAlertsDesc: 'Renewal reminders, subscription expiring, plan changes',
    retryNotifications: 'Payment Retry Updates',
    retryNotificationsDesc: 'Get notified when automatic payment retries are attempted',
    
    // SMS Section
    smsSection: 'SMS Notifications',
    smsSectionDesc: 'Text message alerts for high-intent events',
    smsEnabled: 'SMS Notifications',
    smsEnabledDesc: 'Receive text message alerts',
    smsNewMatch: 'New Match SMS',
    smsNewMatchDesc: 'Get a text when you match with someone',
    smsCodeUsed: 'Code Used SMS',
    smsCodeUsedDesc: 'Get a text when someone uses your code',
    smsCodeExpiring: 'Code Expiring SMS',
    smsCodeExpiringDesc: 'Get a text when your code is about to expire',
    smsCodeExpired: 'Code Expired SMS',
    smsCodeExpiredDesc: 'Get a text when your code has expired',
    
    // Digest Settings
    digestSection: 'Digest Settings',
    digestSectionDesc: 'Control your notification summary frequency',
    digestFrequency: 'Digest Frequency',
    digestFrequencyDesc: 'How often to receive your activity summary',
    digestDaily: 'Daily',
    digestWeekly: 'Weekly',
    digestMonthly: 'Monthly',
    digestIncludeMatches: 'Include Matches',
    digestIncludeMatchesDesc: 'Include match activity in digest',
    digestIncludeMessages: 'Include Messages',
    digestIncludeMessagesDesc: 'Include message summary in digest',
    digestIncludeCodes: 'Include Codes',
    digestIncludeCodesDesc: 'Include code activity in digest',
    digestIncludeTips: 'Include Tips',
    digestIncludeTipsDesc: 'Include personalized tips in digest',
    
    // Email Templates
    templateSection: 'Email Templates',
    templateSectionDesc: 'Customize your email notifications',
    templateEditor: 'Template Editor',
    templateEditorDesc: 'Customize the wording and tone of your emails',
    
    // Other
    otherSection: 'Other',
    marketingEmails: 'Marketing & Promotions',
    marketingEmailsDesc: 'Special offers, new features, and promotional content',
    weeklyDigest: 'Weekly Digest',
    weeklyDigestDesc: 'Weekly summary of your activity, matches, and messages',
    
    emailLanguage: 'Email Language',
    emailLanguageDesc: 'Receive emails in your preferred language',
    saving: 'Saving...',
    saved: 'Preferences saved',
    error: 'Failed to save preferences',
    legalNotice: 'Important transactional emails (security alerts, legal notices) will always be sent regardless of your preferences.',
    retryInfo: 'When a payment fails, we automatically retry at optimal times.',
    
    // Email history
    emailHistory: 'Recent Emails',
    emailHistoryDesc: 'Emails sent to you in the last 30 days',
    noEmails: 'No recent emails',
    viewAll: 'View all',
    
    languages: {
      en: 'English',
      es: 'Español',
      fr: 'Français',
      de: 'Deutsch'
    },
    
    // Test email
    testEmail: 'Send Test Email',
    testEmailSending: 'Sending...',
    testEmailSent: 'Test email sent!',
    testEmailError: 'Failed to send test email',
    
    // Premium
    premiumFeature: 'Premium Feature',
    upgradeToUnlock: 'Upgrade to unlock',
  },
  es: {
    title: 'Notificaciones por Email',
    description: 'Gestiona qué correos recibes de nosotros',
    masterToggle: 'Notificaciones por Email',
    masterToggleDesc: 'Recibir notificaciones por correo',
    
    activitySection: 'Notificaciones de Actividad',
    newMatches: 'Nuevos Matches',
    newMatchesDesc: 'Recibe notificación cuando alguien hace match contigo',
    newMessages: 'Nuevos Mensajes',
    newMessagesDesc: 'Recibe correos cuando tienes nuevos mensajes mientras estás desconectado',
    crushCodeAlerts: 'Alertas de Crush Code',
    crushCodeAlertsDesc: 'Recibe notificación cuando alguien canjea tu Crush Code',
    verificationAlerts: 'Actualizaciones de Verificación',
    verificationAlertsDesc: 'Actualizaciones sobre el estado de verificación de tu perfil',
    profileViews: 'Vistas de Perfil',
    profileViewsDesc: 'Saber cuando alguien ve tu perfil (Premium)',
    
    paymentSection: 'Pago y Suscripción',
    paymentAlerts: 'Alertas de Pago',
    paymentAlertsDesc: 'Tarjeta expirando, pago fallido, actualizaciones de método de pago',
    subscriptionAlerts: 'Alertas de Suscripción',
    subscriptionAlertsDesc: 'Recordatorios de renovación, suscripción expirando, cambios de plan',
    retryNotifications: 'Actualizaciones de Reintentos',
    retryNotificationsDesc: 'Recibe notificaciones cuando se intenten reintentos automáticos de pago',
    
    smsSection: 'Notificaciones SMS',
    smsSectionDesc: 'Alertas por mensaje de texto para eventos importantes',
    smsEnabled: 'Notificaciones SMS',
    smsEnabledDesc: 'Recibir alertas por mensaje de texto',
    smsNewMatch: 'SMS de Nuevo Match',
    smsNewMatchDesc: 'Recibe un mensaje cuando haces match con alguien',
    smsCodeUsed: 'SMS de Código Usado',
    smsCodeUsedDesc: 'Recibe un mensaje cuando alguien usa tu código',
    smsCodeExpiring: 'SMS de Código Expirando',
    smsCodeExpiringDesc: 'Recibe un mensaje cuando tu código está por expirar',
    smsCodeExpired: 'SMS de Código Expirado',
    smsCodeExpiredDesc: 'Recibe un mensaje cuando tu código ha expirado',
    
    digestSection: 'Configuración de Resumen',
    digestSectionDesc: 'Controla la frecuencia de tu resumen de notificaciones',
    digestFrequency: 'Frecuencia del Resumen',
    digestFrequencyDesc: 'Con qué frecuencia recibir tu resumen de actividad',
    digestDaily: 'Diario',
    digestWeekly: 'Semanal',
    digestMonthly: 'Mensual',
    digestIncludeMatches: 'Incluir Matches',
    digestIncludeMatchesDesc: 'Incluir actividad de matches en el resumen',
    digestIncludeMessages: 'Incluir Mensajes',
    digestIncludeMessagesDesc: 'Incluir resumen de mensajes en el resumen',
    digestIncludeCodes: 'Incluir Códigos',
    digestIncludeCodesDesc: 'Incluir actividad de códigos en el resumen',
    digestIncludeTips: 'Incluir Consejos',
    digestIncludeTipsDesc: 'Incluir consejos personalizados en el resumen',
    
    templateSection: 'Plantillas de Email',
    templateSectionDesc: 'Personaliza tus notificaciones por email',
    templateEditor: 'Editor de Plantillas',
    templateEditorDesc: 'Personaliza el texto y tono de tus emails',
    
    otherSection: 'Otros',
    marketingEmails: 'Marketing y Promociones',
    marketingEmailsDesc: 'Ofertas especiales, nuevas funciones y contenido promocional',
    weeklyDigest: 'Resumen Semanal',
    weeklyDigestDesc: 'Resumen semanal de tu actividad, matches y mensajes',
    
    emailLanguage: 'Idioma de Emails',
    emailLanguageDesc: 'Recibe correos en tu idioma preferido',
    saving: 'Guardando...',
    saved: 'Preferencias guardadas',
    error: 'Error al guardar preferencias',
    legalNotice: 'Los correos transaccionales importantes siempre se enviarán independientemente de tus preferencias.',
    retryInfo: 'Cuando un pago falla, reintentamos automáticamente en momentos óptimos.',
    
    emailHistory: 'Correos Recientes',
    emailHistoryDesc: 'Correos enviados en los últimos 30 días',
    noEmails: 'No hay correos recientes',
    viewAll: 'Ver todos',
    
    languages: {
      en: 'English',
      es: 'Español',
      fr: 'Français',
      de: 'Deutsch'
    },
    
    testEmail: 'Enviar Email de Prueba',
    testEmailSending: 'Enviando...',
    testEmailSent: '¡Email de prueba enviado!',
    testEmailError: 'Error al enviar email de prueba',
    
    premiumFeature: 'Función Premium',
    upgradeToUnlock: 'Actualiza para desbloquear',
  },
  fr: {
    title: 'Notifications par Email',
    description: 'Gérez les emails que vous recevez de notre part',
    masterToggle: 'Notifications par Email',
    masterToggleDesc: 'Recevoir des notifications par email',
    
    activitySection: 'Notifications d\'Activité',
    newMatches: 'Nouveaux Matchs',
    newMatchesDesc: 'Soyez notifié quand quelqu\'un matche avec vous',
    newMessages: 'Nouveaux Messages',
    newMessagesDesc: 'Recevez des emails quand vous avez de nouveaux messages hors ligne',
    crushCodeAlerts: 'Alertes Crush Code',
    crushCodeAlertsDesc: 'Soyez notifié quand quelqu\'un utilise votre Crush Code',
    verificationAlerts: 'Mises à Jour de Vérification',
    verificationAlertsDesc: 'Mises à jour sur le statut de vérification de votre profil',
    profileViews: 'Vues du Profil',
    profileViewsDesc: 'Savoir quand quelqu\'un voit votre profil (Premium)',
    
    paymentSection: 'Paiement et Abonnement',
    paymentAlerts: 'Alertes de Paiement',
    paymentAlertsDesc: 'Carte expirante, paiement échoué, mises à jour de paiement',
    subscriptionAlerts: 'Alertes d\'Abonnement',
    subscriptionAlertsDesc: 'Rappels de renouvellement, abonnement expirant, changements de plan',
    retryNotifications: 'Mises à jour des Réessais',
    retryNotificationsDesc: 'Soyez notifié lorsque des réessais automatiques de paiement sont tentés',
    
    smsSection: 'Notifications SMS',
    smsSectionDesc: 'Alertes par SMS pour les événements importants',
    smsEnabled: 'Notifications SMS',
    smsEnabledDesc: 'Recevoir des alertes par SMS',
    smsNewMatch: 'SMS Nouveau Match',
    smsNewMatchDesc: 'Recevoir un SMS quand vous matchez avec quelqu\'un',
    smsCodeUsed: 'SMS Code Utilisé',
    smsCodeUsedDesc: 'Recevoir un SMS quand quelqu\'un utilise votre code',
    smsCodeExpiring: 'SMS Code Expirant',
    smsCodeExpiringDesc: 'Recevoir un SMS quand votre code va expirer',
    smsCodeExpired: 'SMS Code Expiré',
    smsCodeExpiredDesc: 'Recevoir un SMS quand votre code a expiré',
    
    digestSection: 'Paramètres du Résumé',
    digestSectionDesc: 'Contrôlez la fréquence de votre résumé de notifications',
    digestFrequency: 'Fréquence du Résumé',
    digestFrequencyDesc: 'À quelle fréquence recevoir votre résumé d\'activité',
    digestDaily: 'Quotidien',
    digestWeekly: 'Hebdomadaire',
    digestMonthly: 'Mensuel',
    digestIncludeMatches: 'Inclure les Matchs',
    digestIncludeMatchesDesc: 'Inclure l\'activité des matchs dans le résumé',
    digestIncludeMessages: 'Inclure les Messages',
    digestIncludeMessagesDesc: 'Inclure le résumé des messages dans le résumé',
    digestIncludeCodes: 'Inclure les Codes',
    digestIncludeCodesDesc: 'Inclure l\'activité des codes dans le résumé',
    digestIncludeTips: 'Inclure les Conseils',
    digestIncludeTipsDesc: 'Inclure des conseils personnalisés dans le résumé',
    
    templateSection: 'Modèles d\'Email',
    templateSectionDesc: 'Personnalisez vos notifications par email',
    templateEditor: 'Éditeur de Modèles',
    templateEditorDesc: 'Personnalisez le texte et le ton de vos emails',
    
    otherSection: 'Autres',
    marketingEmails: 'Marketing et Promotions',
    marketingEmailsDesc: 'Offres spéciales, nouvelles fonctionnalités et contenu promotionnel',
    weeklyDigest: 'Résumé Hebdomadaire',
    weeklyDigestDesc: 'Résumé hebdomadaire de votre activité, matchs et messages',
    
    emailLanguage: 'Langue des Emails',
    emailLanguageDesc: 'Recevez les emails dans votre langue préférée',
    saving: 'Enregistrement...',
    saved: 'Préférences enregistrées',
    error: 'Échec de l\'enregistrement',
    legalNotice: 'Les emails transactionnels importants seront toujours envoyés indépendamment de vos préférences.',
    retryInfo: 'Lorsqu\'un paiement échoue, nous réessayons automatiquement aux moments optimaux.',
    
    emailHistory: 'Emails Récents',
    emailHistoryDesc: 'Emails envoyés au cours des 30 derniers jours',
    noEmails: 'Pas d\'emails récents',
    viewAll: 'Voir tout',
    
    languages: {
      en: 'English',
      es: 'Español',
      fr: 'Français',
      de: 'Deutsch'
    },
    
    testEmail: 'Envoyer un Email Test',
    testEmailSending: 'Envoi...',
    testEmailSent: 'Email test envoyé!',
    testEmailError: 'Échec de l\'envoi de l\'email test',
    
    premiumFeature: 'Fonction Premium',
    upgradeToUnlock: 'Mettez à niveau pour débloquer',
  },
  de: {
    title: 'E-Mail-Benachrichtigungen',
    description: 'Verwalten Sie, welche E-Mails Sie von uns erhalten',
    masterToggle: 'E-Mail-Benachrichtigungen',
    masterToggleDesc: 'E-Mail-Benachrichtigungen erhalten',
    
    activitySection: 'Aktivitätsbenachrichtigungen',
    newMatches: 'Neue Matches',
    newMatchesDesc: 'Benachrichtigung wenn jemand mit dir matcht',
    newMessages: 'Neue Nachrichten',
    newMessagesDesc: 'E-Mails erhalten wenn du neue Nachrichten hast während du offline bist',
    crushCodeAlerts: 'Crush Code Benachrichtigungen',
    crushCodeAlertsDesc: 'Benachrichtigung wenn jemand deinen Crush Code einlöst',
    verificationAlerts: 'Verifizierungs-Updates',
    verificationAlertsDesc: 'Updates über deinen Profil-Verifizierungsstatus',
    profileViews: 'Profilaufrufe',
    profileViewsDesc: 'Wissen wenn jemand dein Profil ansieht (Premium)',
    
    paymentSection: 'Zahlung und Abonnement',
    paymentAlerts: 'Zahlungsbenachrichtigungen',
    paymentAlertsDesc: 'Karte läuft ab, Zahlung fehlgeschlagen, Zahlungsmethoden-Updates',
    subscriptionAlerts: 'Abonnement-Benachrichtigungen',
    subscriptionAlertsDesc: 'Verlängerungserinnerungen, Abonnement läuft ab, Planänderungen',
    retryNotifications: 'Wiederholungs-Updates',
    retryNotificationsDesc: 'Benachrichtigung bei automatischen Zahlungswiederholungen',
    
    smsSection: 'SMS-Benachrichtigungen',
    smsSectionDesc: 'SMS-Benachrichtigungen für wichtige Ereignisse',
    smsEnabled: 'SMS-Benachrichtigungen',
    smsEnabledDesc: 'SMS-Benachrichtigungen erhalten',
    smsNewMatch: 'Neues Match SMS',
    smsNewMatchDesc: 'SMS erhalten wenn du mit jemandem matchst',
    smsCodeUsed: 'Code Verwendet SMS',
    smsCodeUsedDesc: 'SMS erhalten wenn jemand deinen Code verwendet',
    smsCodeExpiring: 'Code Läuft Ab SMS',
    smsCodeExpiringDesc: 'SMS erhalten wenn dein Code bald abläuft',
    smsCodeExpired: 'Code Abgelaufen SMS',
    smsCodeExpiredDesc: 'SMS erhalten wenn dein Code abgelaufen ist',
    
    digestSection: 'Zusammenfassungs-Einstellungen',
    digestSectionDesc: 'Steuern Sie die Häufigkeit Ihrer Benachrichtigungszusammenfassung',
    digestFrequency: 'Zusammenfassungs-Häufigkeit',
    digestFrequencyDesc: 'Wie oft Sie Ihre Aktivitätszusammenfassung erhalten',
    digestDaily: 'Täglich',
    digestWeekly: 'Wöchentlich',
    digestMonthly: 'Monatlich',
    digestIncludeMatches: 'Matches Einschließen',
    digestIncludeMatchesDesc: 'Match-Aktivität in Zusammenfassung einschließen',
    digestIncludeMessages: 'Nachrichten Einschließen',
    digestIncludeMessagesDesc: 'Nachrichtenzusammenfassung in Zusammenfassung einschließen',
    digestIncludeCodes: 'Codes Einschließen',
    digestIncludeCodesDesc: 'Code-Aktivität in Zusammenfassung einschließen',
    digestIncludeTips: 'Tipps Einschließen',
    digestIncludeTipsDesc: 'Personalisierte Tipps in Zusammenfassung einschließen',
    
    templateSection: 'E-Mail-Vorlagen',
    templateSectionDesc: 'Passen Sie Ihre E-Mail-Benachrichtigungen an',
    templateEditor: 'Vorlagen-Editor',
    templateEditorDesc: 'Passen Sie den Text und Ton Ihrer E-Mails an',
    
    otherSection: 'Sonstiges',
    marketingEmails: 'Marketing & Aktionen',
    marketingEmailsDesc: 'Sonderangebote, neue Funktionen und Werbeinhalte',
    weeklyDigest: 'Wöchentliche Zusammenfassung',
    weeklyDigestDesc: 'Wöchentliche Zusammenfassung Ihrer Aktivitäten, Matches und Nachrichten',
    
    emailLanguage: 'E-Mail-Sprache',
    emailLanguageDesc: 'E-Mails in Ihrer bevorzugten Sprache erhalten',
    saving: 'Speichern...',
    saved: 'Einstellungen gespeichert',
    error: 'Speichern fehlgeschlagen',
    legalNotice: 'Wichtige Transaktions-E-Mails werden unabhängig von Ihren Einstellungen immer gesendet.',
    retryInfo: 'Bei fehlgeschlagenen Zahlungen versuchen wir automatisch zu optimalen Zeiten erneut.',
    
    emailHistory: 'Letzte E-Mails',
    emailHistoryDesc: 'E-Mails der letzten 30 Tage',
    noEmails: 'Keine aktuellen E-Mails',
    viewAll: 'Alle anzeigen',
    
    languages: {
      en: 'English',
      es: 'Español',
      fr: 'Français',
      de: 'Deutsch'
    },
    
    testEmail: 'Test-E-Mail Senden',
    testEmailSending: 'Senden...',
    testEmailSent: 'Test-E-Mail gesendet!',
    testEmailError: 'Fehler beim Senden der Test-E-Mail',
    
    premiumFeature: 'Premium-Funktion',
    upgradeToUnlock: 'Upgrade zum Freischalten',
  }
};

const EMAIL_TYPE_LABELS: Record<string, Record<SupportedLanguage, string>> = {
  new_match: { en: 'New Match', es: 'Nuevo Match', fr: 'Nouveau Match', de: 'Neues Match' },
  new_message: { en: 'New Message', es: 'Nuevo Mensaje', fr: 'Nouveau Message', de: 'Neue Nachricht' },
  message_reminder: { en: 'Message Reminder', es: 'Recordatorio', fr: 'Rappel', de: 'Erinnerung' },
  weekly_summary: { en: 'Weekly Summary', es: 'Resumen Semanal', fr: 'Résumé Hebdo', de: 'Wochenzusammenfassung' },
  crush_code_redeemed: { en: 'Code Redeemed', es: 'Código Canjeado', fr: 'Code Utilisé', de: 'Code Eingelöst' },
  verification_approved: { en: 'Verified', es: 'Verificado', fr: 'Vérifié', de: 'Verifiziert' },
  verification_rejected: { en: 'Verification Update', es: 'Actualización', fr: 'Mise à jour', de: 'Update' },
  profile_view: { en: 'Profile View', es: 'Vista de Perfil', fr: 'Vue du Profil', de: 'Profilaufruf' },
  welcome: { en: 'Welcome', es: 'Bienvenida', fr: 'Bienvenue', de: 'Willkommen' },
  payment_expiring: { en: 'Payment Alert', es: 'Alerta de Pago', fr: 'Alerte Paiement', de: 'Zahlungsalert' },
  payment_failed: { en: 'Payment Failed', es: 'Pago Fallido', fr: 'Paiement Échoué', de: 'Zahlung Fehlgeschlagen' },
  renewal_reminder: { en: 'Renewal Reminder', es: 'Recordatorio', fr: 'Rappel', de: 'Erinnerung' },
  subscription_expiring: { en: 'Sub Expiring', es: 'Sub Expirando', fr: 'Abo Expirant', de: 'Abo Läuft Ab' }
};

const EmailPreferences: React.FC = () => {
  const { user } = useAuth();
  const { language: appLanguage } = useI18n();
  const { isPremium, canUseFeature } = usePremium();
  
  const language: SupportedLanguage = ['en', 'es', 'fr', 'de'].includes(appLanguage) 
    ? appLanguage as SupportedLanguage 
    : 'en';
  
  const text = UI_TEXT[language];
  
  const [preferences, setPreferences] = useState<EmailPreferencesData | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [emailHistory, setEmailHistory] = useState<EmailLogEntry[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [testEmailStatus, setTestEmailStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  // Upsell modal state
  const [upsellModal, setUpsellModal] = useState<{
    isOpen: boolean;
    trigger: UpsellTrigger;
  }>({ isOpen: false, trigger: 'sms_notifications' });

  // Feature access checks
  const canUseSMS = canUseFeature('smsNotifications');
  const canUseDigestControl = canUseFeature('notificationDigestControl');
  // Note: Email Template Preview is internal/admin-only and not exposed to users
  // Note: Notification History Log is a Premium feature
  const canViewNotificationHistory = canUseFeature('notificationHistoryLog' as any);

  useEffect(() => {
    if (user) {
      loadPreferences();
      loadEmailHistory();
    }
  }, [user]);

  const loadPreferences = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('email_preferences')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setPreferences({
          ...data,
          retry_notifications: data.retry_notifications ?? true,
          new_matches: data.new_matches ?? true,
          new_messages: data.new_messages ?? true,
          crush_code_alerts: data.crush_code_alerts ?? true,
          verification_alerts: data.verification_alerts ?? true,
          profile_views: data.profile_views ?? false,
          sms_enabled: data.sms_enabled ?? false,
          sms_new_match: data.sms_new_match ?? true,
          sms_code_used: data.sms_code_used ?? true,
          sms_code_expiring: data.sms_code_expiring ?? true,
          sms_code_expired: data.sms_code_expired ?? true,
          digest_frequency: data.digest_frequency ?? 'weekly',
          digest_include_matches: data.digest_include_matches ?? true,
          digest_include_messages: data.digest_include_messages ?? true,
          digest_include_codes: data.digest_include_codes ?? true,
          digest_include_tips: data.digest_include_tips ?? true,
        });
      } else {
        // Create default preferences
        const defaultPrefs: EmailPreferencesData = {
          user_id: user.id,
          email_enabled: true,
          payment_alerts: true,
          subscription_alerts: true,
          marketing_emails: false,
          weekly_digest: true,
          retry_notifications: true,
          new_matches: true,
          new_messages: true,
          crush_code_alerts: true,
          verification_alerts: true,
          profile_views: false,
          language: language,
          sms_enabled: false,
          sms_new_match: true,
          sms_code_used: true,
          sms_code_expiring: true,
          sms_code_expired: true,
          digest_frequency: 'weekly',
          digest_include_matches: true,
          digest_include_messages: true,
          digest_include_codes: true,
          digest_include_tips: true,
        };
        
        const { data: newData, error: insertError } = await supabase
          .from('email_preferences')
          .insert(defaultPrefs)
          .select()
          .single();

        if (insertError) throw insertError;
        setPreferences(newData);
      }
    } catch (err) {
      console.error('Failed to load email preferences:', err);
      setError(text.error);
    } finally {
      setLoading(false);
    }
  };

  const loadEmailHistory = async () => {
    if (!user) return;
    
    try {
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
      const { data, error } = await supabase
        .from('email_log')
        .select('id, email_type, subject, status, created_at')
        .eq('user_id', user.id)
        .gte('created_at', thirtyDaysAgo)
        .order('created_at', { ascending: false })
        .limit(10);

      if (!error && data) {
        setEmailHistory(data);
      }
    } catch (err) {
      console.error('Failed to load email history:', err);
    }
  };

  const updatePreference = async (key: keyof EmailPreferencesData, value: boolean | string) => {
    if (!user || !preferences) return;

    const newPrefs = { ...preferences, [key]: value };
    setPreferences(newPrefs);
    setSaving(true);
    setError(null);

    try {
      const { error } = await supabase
        .from('email_preferences')
        .update({ [key]: value, updated_at: new Date().toISOString() })
        .eq('user_id', user.id);

      if (error) throw error;

      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      console.error('Failed to update email preference:', err);
      setError(text.error);
      setPreferences(preferences);
    } finally {
      setSaving(false);
    }
  };

  const sendTestEmail = async () => {
    if (!user) return;
    
    setTestEmailStatus('sending');
    try {
      const { data, error } = await supabase.functions.invoke('send-email-notification', {
        body: {
          userId: user.id,
          emailType: 'welcome',
          data: {},
          language: preferences?.language || language
        }
      });

      if (error) throw error;
      
      setTestEmailStatus('sent');
      setTimeout(() => setTestEmailStatus('idle'), 3000);
      loadEmailHistory();
    } catch (err) {
      console.error('Failed to send test email:', err);
      setTestEmailStatus('error');
      setTimeout(() => setTestEmailStatus('idle'), 3000);
    }
  };

  const Toggle = ({ 
    enabled, 
    onChange, 
    disabled,
    locked = false
  }: { 
    enabled: boolean; 
    onChange: () => void; 
    disabled?: boolean;
    locked?: boolean;
  }) => (
    <button
      onClick={onChange}
      disabled={disabled || locked}
      className={`w-11 h-6 rounded-full transition-all relative ${
        locked ? 'bg-charcoal-600' : enabled ? 'bg-gold' : 'bg-charcoal-500'
      } ${disabled || locked ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      {locked ? (
        <div className="absolute inset-0 flex items-center justify-center">
          <Lock className="w-3 h-3 text-gray-500" />
        </div>
      ) : (
        <div className={`w-5 h-5 bg-white rounded-full shadow transform transition-transform ${
          enabled ? 'translate-x-5' : 'translate-x-0.5'
        }`} />
      )}
    </button>
  );

  const SectionHeader = ({ icon: Icon, title, premium = false, onPremiumClick }: { 
    icon: React.ElementType; 
    title: string;
    premium?: boolean;
    onPremiumClick?: () => void;
  }) => (
    <div className="flex items-center justify-between mt-6 mb-3">
      <div className="flex items-center gap-2">
        <Icon className="w-4 h-4 text-gold" />
        <h4 className="text-sm font-semibold text-gold uppercase tracking-wide">{title}</h4>
      </div>
      {premium && (
        <button 
          onClick={onPremiumClick}
          className="flex items-center gap-1 px-2 py-1 bg-gold/20 text-gold text-xs font-medium rounded-full hover:bg-gold/30 transition-colors"
        >
          <Crown className="w-3 h-3" />
          Premium
        </button>
      )}
    </div>
  );

  const LockedFeatureCard = ({ 
    icon: Icon, 
    title, 
    description, 
    onUnlock 
  }: { 
    icon: React.ElementType; 
    title: string; 
    description: string;
    onUnlock: () => void;
  }) => (
    <div 
      onClick={onUnlock}
      className="p-4 bg-charcoal-700/50 rounded-xl border border-charcoal-600 cursor-pointer hover:border-gold/30 transition-all"
    >
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-charcoal-600 rounded-xl flex items-center justify-center">
          <Icon className="w-5 h-5 text-gray-500" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <p className="font-medium text-gray-400">{title}</p>
            <Lock className="w-3.5 h-3.5 text-gray-500" />
          </div>
          <p className="text-sm text-gray-500 mt-1">{description}</p>
        </div>
        <div className="flex items-center gap-1 px-2 py-1 bg-gold/10 text-gold text-xs font-medium rounded-full">
          <Crown className="w-3 h-3" />
          Premium
        </div>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 text-gold animate-spin" />
      </div>
    );
  }

  if (!preferences) {
    return (
      <div className="text-center py-8 text-gray-400">
        <AlertCircle className="w-8 h-8 mx-auto mb-2" />
        <p>{text.error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Mail className="w-5 h-5 text-gold" />
          {text.title}
        </h3>
        <p className="text-sm text-gray-400 mt-1">{text.description}</p>
      </div>

      {/* Status indicator */}
      {(saving || saved || error) && (
        <div className={`flex items-center gap-2 text-sm ${
          error ? 'text-red-400' : saved ? 'text-green-400' : 'text-gray-400'
        }`}>
          {saving && <Loader2 className="w-4 h-4 animate-spin" />}
          {saved && <Check className="w-4 h-4" />}
          {error && <AlertCircle className="w-4 h-4" />}
          <span>{saving ? text.saving : saved ? text.saved : error}</span>
        </div>
      )}

      {/* Master toggle */}
      <div className="p-4 bg-charcoal-600 rounded-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              preferences.email_enabled ? 'bg-gold/20' : 'bg-charcoal-500'
            }`}>
              <Mail className={`w-5 h-5 ${
                preferences.email_enabled ? 'text-gold' : 'text-gray-400'
              }`} />
            </div>
            <div>
              <p className="font-medium text-white">{text.masterToggle}</p>
              <p className="text-sm text-gray-400">{text.masterToggleDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.email_enabled} 
            onChange={() => updatePreference('email_enabled', !preferences.email_enabled)}
            disabled={saving}
          />
        </div>
      </div>

      {/* Individual preferences */}
      <div className={`space-y-1 ${!preferences.email_enabled ? 'opacity-50 pointer-events-none' : ''}`}>
        
        {/* Activity Notifications Section */}
        <SectionHeader icon={Heart} title={text.activitySection} />
        
        {/* New Matches */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <Heart className="w-5 h-5 text-pink-400" />
            <div>
              <p className="font-medium text-white">{text.newMatches}</p>
              <p className="text-sm text-gray-400">{text.newMatchesDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.new_matches} 
            onChange={() => updatePreference('new_matches', !preferences.new_matches)}
            disabled={saving || !preferences.email_enabled}
          />
        </div>

        {/* New Messages */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <MessageCircle className="w-5 h-5 text-blue-400" />
            <div>
              <p className="font-medium text-white">{text.newMessages}</p>
              <p className="text-sm text-gray-400">{text.newMessagesDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.new_messages} 
            onChange={() => updatePreference('new_messages', !preferences.new_messages)}
            disabled={saving || !preferences.email_enabled}
          />
        </div>

        {/* Crush Code Alerts */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <QrCode className="w-5 h-5 text-purple-400" />
            <div>
              <p className="font-medium text-white">{text.crushCodeAlerts}</p>
              <p className="text-sm text-gray-400">{text.crushCodeAlertsDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.crush_code_alerts} 
            onChange={() => updatePreference('crush_code_alerts', !preferences.crush_code_alerts)}
            disabled={saving || !preferences.email_enabled}
          />
        </div>

        {/* Verification Alerts */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <Shield className="w-5 h-5 text-green-400" />
            <div>
              <p className="font-medium text-white">{text.verificationAlerts}</p>
              <p className="text-sm text-gray-400">{text.verificationAlertsDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.verification_alerts} 
            onChange={() => updatePreference('verification_alerts', !preferences.verification_alerts)}
            disabled={saving || !preferences.email_enabled}
          />
        </div>

        {/* Profile Views */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <Eye className="w-5 h-5 text-amber-400" />
            <div>
              <p className="font-medium text-white">{text.profileViews}</p>
              <p className="text-sm text-gray-400">{text.profileViewsDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.profile_views} 
            onChange={() => updatePreference('profile_views', !preferences.profile_views)}
            disabled={saving || !preferences.email_enabled}
          />
        </div>

        {/* SMS Notifications Section - Premium Only */}
        <SectionHeader 
          icon={Smartphone} 
          title={text.smsSection} 
          premium={!canUseSMS}
          onPremiumClick={() => setUpsellModal({ isOpen: true, trigger: 'sms_notifications' })}
        />
        
        {canUseSMS ? (
          <>
            {/* SMS Master Toggle */}
            <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
              <div className="flex items-center gap-3">
                <Smartphone className="w-5 h-5 text-green-400" />
                <div>
                  <p className="font-medium text-white">{text.smsEnabled}</p>
                  <p className="text-sm text-gray-400">{text.smsEnabledDesc}</p>
                </div>
              </div>
              <Toggle 
                enabled={preferences.sms_enabled || false} 
                onChange={() => updatePreference('sms_enabled', !preferences.sms_enabled)}
                disabled={saving}
              />
            </div>

            {/* SMS Event Toggles */}
            <div className={`space-y-0 ${!preferences.sms_enabled ? 'opacity-50 pointer-events-none' : ''}`}>
              <div className="flex items-center justify-between py-3 pl-8 border-b border-charcoal-600">
                <div>
                  <p className="text-sm font-medium text-white">{text.smsNewMatch}</p>
                  <p className="text-xs text-gray-500">{text.smsNewMatchDesc}</p>
                </div>
                <Toggle 
                  enabled={preferences.sms_new_match || false} 
                  onChange={() => updatePreference('sms_new_match', !preferences.sms_new_match)}
                  disabled={saving || !preferences.sms_enabled}
                />
              </div>
              <div className="flex items-center justify-between py-3 pl-8 border-b border-charcoal-600">
                <div>
                  <p className="text-sm font-medium text-white">{text.smsCodeUsed}</p>
                  <p className="text-xs text-gray-500">{text.smsCodeUsedDesc}</p>
                </div>
                <Toggle 
                  enabled={preferences.sms_code_used || false} 
                  onChange={() => updatePreference('sms_code_used', !preferences.sms_code_used)}
                  disabled={saving || !preferences.sms_enabled}
                />
              </div>
              <div className="flex items-center justify-between py-3 pl-8 border-b border-charcoal-600">
                <div>
                  <p className="text-sm font-medium text-white">{text.smsCodeExpiring}</p>
                  <p className="text-xs text-gray-500">{text.smsCodeExpiringDesc}</p>
                </div>
                <Toggle 
                  enabled={preferences.sms_code_expiring || false} 
                  onChange={() => updatePreference('sms_code_expiring', !preferences.sms_code_expiring)}
                  disabled={saving || !preferences.sms_enabled}
                />
              </div>
              <div className="flex items-center justify-between py-3 pl-8 border-b border-charcoal-600">
                <div>
                  <p className="text-sm font-medium text-white">{text.smsCodeExpired}</p>
                  <p className="text-xs text-gray-500">{text.smsCodeExpiredDesc}</p>
                </div>
                <Toggle 
                  enabled={preferences.sms_code_expired || false} 
                  onChange={() => updatePreference('sms_code_expired', !preferences.sms_code_expired)}
                  disabled={saving || !preferences.sms_enabled}
                />
              </div>
            </div>
          </>
        ) : (
          <LockedFeatureCard
            icon={Smartphone}
            title={text.smsSection}
            description={text.smsSectionDesc}
            onUnlock={() => setUpsellModal({ isOpen: true, trigger: 'sms_notifications' })}
          />
        )}

        {/* 
          NOTE: Email Template Editor/Preview is an INTERNAL/ADMIN-ONLY feature
          for quality control and branding. It is NOT exposed to end users
          and is NOT monetised. This section has been removed from user-facing settings.
        */}


        {/* Digest Settings Section */}
        <SectionHeader 
          icon={Sliders} 
          title={text.digestSection} 
          premium={!canUseDigestControl}
          onPremiumClick={() => setUpsellModal({ isOpen: true, trigger: 'digest_settings' })}
        />
        
        {/* Basic digest toggle for free users */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <Calendar className="w-5 h-5 text-gold" />
            <div>
              <p className="font-medium text-white">{text.weeklyDigest}</p>
              <p className="text-sm text-gray-400">{text.weeklyDigestDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.weekly_digest} 
            onChange={() => updatePreference('weekly_digest', !preferences.weekly_digest)}
            disabled={saving || !preferences.email_enabled}
          />
        </div>

        {/* Advanced digest controls - Premium Only */}
        {canUseDigestControl ? (
          <div className={`space-y-0 ${!preferences.weekly_digest ? 'opacity-50 pointer-events-none' : ''}`}>
            {/* Frequency selector */}
            <div className="flex items-center justify-between py-4 pl-8 border-b border-charcoal-600">
              <div>
                <p className="text-sm font-medium text-white">{text.digestFrequency}</p>
                <p className="text-xs text-gray-500">{text.digestFrequencyDesc}</p>
              </div>
              <select
                value={preferences.digest_frequency || 'weekly'}
                onChange={(e) => updatePreference('digest_frequency', e.target.value)}
                disabled={saving || !preferences.weekly_digest}
                className="px-3 py-2 bg-charcoal-600 border border-charcoal-500 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-gold"
              >
                <option value="daily">{text.digestDaily}</option>
                <option value="weekly">{text.digestWeekly}</option>
                <option value="monthly">{text.digestMonthly}</option>
              </select>
            </div>

            {/* Include toggles */}
            <div className="flex items-center justify-between py-3 pl-8 border-b border-charcoal-600">
              <div>
                <p className="text-sm font-medium text-white">{text.digestIncludeMatches}</p>
                <p className="text-xs text-gray-500">{text.digestIncludeMatchesDesc}</p>
              </div>
              <Toggle 
                enabled={preferences.digest_include_matches || false} 
                onChange={() => updatePreference('digest_include_matches', !preferences.digest_include_matches)}
                disabled={saving || !preferences.weekly_digest}
              />
            </div>
            <div className="flex items-center justify-between py-3 pl-8 border-b border-charcoal-600">
              <div>
                <p className="text-sm font-medium text-white">{text.digestIncludeMessages}</p>
                <p className="text-xs text-gray-500">{text.digestIncludeMessagesDesc}</p>
              </div>
              <Toggle 
                enabled={preferences.digest_include_messages || false} 
                onChange={() => updatePreference('digest_include_messages', !preferences.digest_include_messages)}
                disabled={saving || !preferences.weekly_digest}
              />
            </div>
            <div className="flex items-center justify-between py-3 pl-8 border-b border-charcoal-600">
              <div>
                <p className="text-sm font-medium text-white">{text.digestIncludeCodes}</p>
                <p className="text-xs text-gray-500">{text.digestIncludeCodesDesc}</p>
              </div>
              <Toggle 
                enabled={preferences.digest_include_codes || false} 
                onChange={() => updatePreference('digest_include_codes', !preferences.digest_include_codes)}
                disabled={saving || !preferences.weekly_digest}
              />
            </div>
            <div className="flex items-center justify-between py-3 pl-8 border-b border-charcoal-600">
              <div>
                <p className="text-sm font-medium text-white">{text.digestIncludeTips}</p>
                <p className="text-xs text-gray-500">{text.digestIncludeTipsDesc}</p>
              </div>
              <Toggle 
                enabled={preferences.digest_include_tips || false} 
                onChange={() => updatePreference('digest_include_tips', !preferences.digest_include_tips)}
                disabled={saving || !preferences.weekly_digest}
              />
            </div>
          </div>
        ) : (
          <div className="mt-2">
            <LockedFeatureCard
              icon={Sliders}
              title={text.digestFrequency}
              description={text.digestSectionDesc}
              onUnlock={() => setUpsellModal({ isOpen: true, trigger: 'digest_settings' })}
            />
          </div>
        )}

        {/* Payment & Subscription Section */}
        <SectionHeader icon={CreditCard} title={text.paymentSection} />

        {/* Payment Alerts */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <CreditCard className="w-5 h-5 text-gold" />
            <div>
              <p className="font-medium text-white">{text.paymentAlerts}</p>
              <p className="text-sm text-gray-400">{text.paymentAlertsDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.payment_alerts} 
            onChange={() => updatePreference('payment_alerts', !preferences.payment_alerts)}
            disabled={saving || !preferences.email_enabled}
          />
        </div>

        {/* Payment Retry Notifications */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <RotateCcw className="w-5 h-5 text-gold" />
            <div>
              <p className="font-medium text-white">{text.retryNotifications}</p>
              <p className="text-sm text-gray-400">{text.retryNotificationsDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.retry_notifications} 
            onChange={() => updatePreference('retry_notifications', !preferences.retry_notifications)}
            disabled={saving || !preferences.email_enabled || !preferences.payment_alerts}
          />
        </div>

        {/* Subscription Alerts */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <Crown className="w-5 h-5 text-gold" />
            <div>
              <p className="font-medium text-white">{text.subscriptionAlerts}</p>
              <p className="text-sm text-gray-400">{text.subscriptionAlertsDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.subscription_alerts} 
            onChange={() => updatePreference('subscription_alerts', !preferences.subscription_alerts)}
            disabled={saving || !preferences.email_enabled}
          />
        </div>

        {/* Other Section */}
        <SectionHeader icon={Megaphone} title={text.otherSection} />

        {/* Marketing Emails */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <Megaphone className="w-5 h-5 text-gold" />
            <div>
              <p className="font-medium text-white">{text.marketingEmails}</p>
              <p className="text-sm text-gray-400">{text.marketingEmailsDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.marketing_emails} 
            onChange={() => updatePreference('marketing_emails', !preferences.marketing_emails)}
            disabled={saving || !preferences.email_enabled}
          />
        </div>

        {/* Email Language */}
        <div className="flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <Globe className="w-5 h-5 text-gold" />
            <div>
              <p className="font-medium text-white">{text.emailLanguage}</p>
              <p className="text-sm text-gray-400">{text.emailLanguageDesc}</p>
            </div>
          </div>
          <select
            value={preferences.language}
            onChange={(e) => updatePreference('language', e.target.value)}
            disabled={saving || !preferences.email_enabled}
            className="px-3 py-2 bg-charcoal-600 border border-charcoal-500 rounded-lg text-white text-sm focus:outline-none focus:ring-2 focus:ring-gold"
          >
            <option value="en">{text.languages.en}</option>
            <option value="es">{text.languages.es}</option>
            <option value="fr">{text.languages.fr}</option>
            <option value="de">{text.languages.de}</option>
          </select>
        </div>
      </div>

      {/* Test Email Button */}
      <div className="pt-4">
        <button
          onClick={sendTestEmail}
          disabled={testEmailStatus === 'sending' || !preferences.email_enabled}
          className={`w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-medium transition-all ${
            testEmailStatus === 'sent' 
              ? 'bg-green-500/20 text-green-400 border border-green-500/30'
              : testEmailStatus === 'error'
              ? 'bg-red-500/20 text-red-400 border border-red-500/30'
              : 'bg-charcoal-600 text-white hover:bg-charcoal-500 border border-charcoal-500'
          } ${!preferences.email_enabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {testEmailStatus === 'sending' ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              {text.testEmailSending}
            </>
          ) : testEmailStatus === 'sent' ? (
            <>
              <Check className="w-4 h-4" />
              {text.testEmailSent}
            </>
          ) : testEmailStatus === 'error' ? (
            <>
              <AlertCircle className="w-4 h-4" />
              {text.testEmailError}
            </>
          ) : (
            <>
              <Send className="w-4 h-4" />
              {text.testEmail}
            </>
          )}
        </button>
      </div>

      {/* Email History */}
      {emailHistory.length > 0 && (
        <div className="pt-4">
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"
          >
            <History className="w-4 h-4" />
            {text.emailHistory}
            <span className="text-xs bg-charcoal-600 px-2 py-0.5 rounded-full">
              {emailHistory.length}
            </span>
          </button>
          
          {showHistory && (
            <div className="mt-3 space-y-2">
              {emailHistory.map((email) => (
                <div 
                  key={email.id}
                  className="flex items-center justify-between p-3 bg-charcoal-700/50 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${
                      email.status === 'sent' ? 'bg-green-400' : 'bg-red-400'
                    }`} />
                    <div>
                      <p className="text-sm text-white">
                        {EMAIL_TYPE_LABELS[email.email_type]?.[language] || email.email_type}
                      </p>
                      <p className="text-xs text-gray-500 truncate max-w-[200px]">
                        {email.subject}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">
                    {new Date(email.created_at).toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Legal notice */}
      <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
        <p className="text-xs text-blue-300">
          {text.legalNotice}
        </p>
      </div>

      {/* Upsell Modal */}
      <FreemiumUpsell
        isOpen={upsellModal.isOpen}
        onClose={() => setUpsellModal({ ...upsellModal, isOpen: false })}
        trigger={upsellModal.trigger}
      />
    </div>
  );
};

export default EmailPreferences;
