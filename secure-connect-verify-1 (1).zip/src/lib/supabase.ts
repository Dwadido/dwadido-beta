// Build: 2026-02-19T16:44:00Z-v3
import { createClient } from '@supabase/supabase-js';

// ─── Supabase Client Configuration ──────────────────────────────────────
// The URL and anon key are HARDCODED (not from env vars) to ensure they
// survive all build/deploy pipelines. This is intentional.
const supabaseUrl = 'https://gktojofjgkmvgmuvtydt.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImUxZjQ2NTVjLTQzZGQtNDZjMS1hMzhmLTA3OTk5YmJhYzIyZSJ9.eyJwcm9qZWN0SWQiOiJna3Rvam9mamdrbXZnbXV2dHlkdCIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzY3NzQxODQxLCJleHAiOjIwODMxMDE4NDEsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.p4-UG6dith8i82NMGOcZVdsIVCglRQIrQLE_SaRSRKU';

// Runtime diagnostic — confirms URL is available in the production bundle
console.log('[supabase.ts] URL:', supabaseUrl ? 'SET' : '*** MISSING ***', '| Key:', supabaseKey ? 'SET' : '*** MISSING ***');

// ─── Resilient Fetch Configuration ──────────────────────────────────────
// Tuned so total worst-case time ≈ 28s (fits within the 30s outer timeout).
//   Attempt 0:  0ms wait + 8s timeout  =  8s
//   Attempt 1: ~1s wait + 8s timeout   = ~9s  (cumulative ~17s)
//   Attempt 2: ~2.4s wait + 8s timeout = ~10.4s (cumulative ~28s)
const MAX_RETRIES = 2;
const INITIAL_BACKOFF_MS = 600;
const BACKOFF_MULTIPLIER = 2;
const JITTER_MAX_MS = 400;
const REQUEST_TIMEOUT_MS = 8_000; // 8s per-request timeout
const RETRYABLE_STATUS_CODES = new Set([429, 502, 503, 504]);

// Network error patterns (browser-specific messages)
const NETWORK_ERROR_PATTERNS = [
  'failed to fetch',    // Chrome / Firefox
  'load failed',        // Safari
  'networkerror',       // Firefox
  'network request failed',
  'aborted',
  'timeout',
  'econnrefused',
  'econnreset',
  'enotfound',
  'epipe',
];

function isNetworkError(err: unknown): boolean {
  if (!(err instanceof Error)) return false;
  const msg = err.message.toLowerCase();
  return NETWORK_ERROR_PATTERNS.some(pattern => msg.includes(pattern));
}

function isRetryableResponse(status: number): boolean {
  return RETRYABLE_STATUS_CODES.has(status);
}

function jitter(): number {
  return Math.floor(Math.random() * JITTER_MAX_MS);
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ─── Connectivity State (shared across app) ─────────────────────────────
let _lastConnectivityCheck = 0;
let _isBackendReachable = true;
let _connectivityPromise: Promise<boolean> | null = null;
const CONNECTIVITY_CACHE_MS = 15_000; // cache result for 15s

export function isBackendReachable(): boolean {
  return _isBackendReachable;
}

/**
 * Lightweight connectivity probe — HEAD request to the Supabase REST endpoint.
 * Caches result for 15s to avoid hammering. De-duplicates concurrent calls.
 *
 * CRITICAL FIX: Any HTTP response (even 404, 405, etc.) means the server IS
 * reachable. Only network-level failures (fetch throws) mean unreachable.
 * Previous logic required res.ok || res.status===400, which caused false
 * negatives on databasepad.com where /rest/v1/ may return other codes.
 */
export async function checkBackendConnectivity(): Promise<boolean> {
  const now = Date.now();
  if (now - _lastConnectivityCheck < CONNECTIVITY_CACHE_MS) {
    return _isBackendReachable;
  }

  // De-duplicate: if a check is already in flight, wait for it
  if (_connectivityPromise) {
    return _connectivityPromise;
  }

  _connectivityPromise = (async () => {
    _lastConnectivityCheck = Date.now();
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 5_000);
      await fetch(`${supabaseUrl}/rest/v1/`, {
        method: 'HEAD',
        headers: { 'apikey': supabaseKey },
        signal: controller.signal,
      });
      clearTimeout(timer);
      // ANY HTTP response = server is reachable (even 404, 405, etc.)
      _isBackendReachable = true;
      return true;
    } catch {
      _isBackendReachable = false;
      return false;
    } finally {
      _connectivityPromise = null;
    }
  })();

  return _connectivityPromise;
}


// ─── Resilient Fetch Wrapper ────────────────────────────────────────────
/**
 * A fetch wrapper with:
 * - Per-request AbortController timeout (8s)
 * - Automatic retry with exponential backoff + jitter (max 2 retries)
 * - Retries on network errors (TypeError: Failed to fetch / Load failed)
 * - Retries on 429, 502, 503, 504
 * - Updates shared connectivity state
 *
 * Total worst-case time: ~28s (3 attempts × 8s + backoff)
 *
 * Drop-in replacement for window.fetch — same signature.
 */
export async function resilientFetch(
  input: RequestInfo | URL,
  init?: RequestInit
): Promise<Response> {
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    // ── Backoff wait (skip first attempt) ──
    if (attempt > 0) {
      const delayMs =
        INITIAL_BACKOFF_MS * Math.pow(BACKOFF_MULTIPLIER, attempt - 1) + jitter();
      console.warn(
        `[resilientFetch] Retry ${attempt}/${MAX_RETRIES} in ${delayMs}ms — ${lastError?.message || 'unknown'}`
      );
      await sleep(delayMs);
    }

    // ── Create per-request timeout via AbortController ──
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    // Merge caller's signal with our timeout signal
    const callerSignal = init?.signal;
    if (callerSignal?.aborted) {
      clearTimeout(timeoutId);
      throw new DOMException('Aborted', 'AbortError');
    }

    // If caller provided their own signal, listen for it
    const onCallerAbort = () => controller.abort();
    callerSignal?.addEventListener('abort', onCallerAbort);

    try {
      const response = await fetch(input, {
        ...init,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      callerSignal?.removeEventListener('abort', onCallerAbort);

      // ── Success or non-retryable status ──
      if (response.ok || !isRetryableResponse(response.status)) {
        _isBackendReachable = true;
        return response;
      }

      // ── Retryable HTTP status (429, 502, 503, 504) ──
      lastError = new Error(`HTTP ${response.status}`);
      if (attempt === MAX_RETRIES) {
        // Exhausted retries — return the response as-is so caller sees the status
        return response;
      }
      // else: loop continues with backoff
    } catch (err: any) {
      clearTimeout(timeoutId);
      callerSignal?.removeEventListener('abort', onCallerAbort);

      // If caller explicitly aborted, don't retry
      if (callerSignal?.aborted) {
        throw err;
      }

      // Our own timeout
      if (controller.signal.aborted && !callerSignal?.aborted) {
        lastError = new Error(`Request timed out after ${REQUEST_TIMEOUT_MS}ms`);
        _isBackendReachable = false;
        if (attempt === MAX_RETRIES) {
          throw new Error(
            `Request timed out after ${MAX_RETRIES + 1} attempts (${REQUEST_TIMEOUT_MS / 1000}s each). The server may be unreachable.`
          );
        }
        continue;
      }

      // Network-level error — retryable
      if (isNetworkError(err)) {
        lastError = err;
        _isBackendReachable = false;
        if (attempt === MAX_RETRIES) {
          throw new Error(
            `Network error after ${MAX_RETRIES + 1} attempts: ${err.message}. The server may be unreachable.`
          );
        }
        continue;
      }

      // Unknown error — don't retry
      throw err;
    }
  }

  // Safety net (should not reach here)
  throw lastError || new Error('resilientFetch: unexpected failure');
}

// ─── Create Supabase Client with Resilient Fetch ────────────────────────
const supabase = createClient(supabaseUrl, supabaseKey, {
  global: {
    fetch: resilientFetch,
  },
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
  },
});
// ─── Edge Function Helper ───────────────────────────────────────────────
// Edge functions have longer cold-start times (5-15s) than REST API calls.
// Using resilientFetch (8s timeout) for edge functions causes false timeouts.
// This helper uses native fetch with a configurable timeout — no retry multiplication.
const DEFAULT_EDGE_FN_TIMEOUT_MS = 30_000;

/**
 * Invoke a Supabase Edge Function directly, bypassing resilientFetch.
 *
 * Why: resilientFetch has an 8s per-request timeout tuned for fast REST API
 * calls. Edge functions can cold-start in 5-15s, so the 8s timeout kills
 * them prematurely. This helper uses native fetch with a single timeout.
 *
 * @param name      - Edge function name (e.g. 'upload-photo')
 * @param body      - JSON body to send
 * @param token     - Optional auth token (auto-fetched from session if omitted)
 * @param options   - Optional: { timeoutMs, signal } for custom timeout or external abort
 * @returns { data, error } matching supabase.functions.invoke() interface
 */
export async function invokeEdgeFunction<T = any>(
  name: string,
  body: Record<string, unknown> = {},
  token?: string,
  options?: { timeoutMs?: number; signal?: AbortSignal }
): Promise<{ data: T | null; error: Error | null }> {
  const url = `${supabaseUrl}/functions/v1/${name}`;
  const timeoutMs = options?.timeoutMs ?? DEFAULT_EDGE_FN_TIMEOUT_MS;
  const externalSignal = options?.signal;

  // If caller already aborted, bail immediately
  if (externalSignal?.aborted) {
    return { data: null, error: new Error('Request was cancelled.') };
  }

  // Get auth token if not provided
  let authToken = token;
  if (!authToken) {
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      authToken = sessionData?.session?.access_token || undefined;
    } catch {
      // No session — proceed without auth (some functions allow unauthenticated calls)
    }
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'apikey': supabaseKey,
  };
  if (authToken) {
    headers['Authorization'] = `Bearer ${authToken}`;
  }

  // Create internal AbortController for timeout
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  // If caller provides an external signal, wire it to our controller
  const onExternalAbort = () => controller.abort();
  externalSignal?.addEventListener('abort', onExternalAbort);

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    externalSignal?.removeEventListener('abort', onExternalAbort);

    let data: any = null;
    try {
      data = await res.json();
    } catch {
      // Non-JSON response
    }

    if (!res.ok) {
      const errMsg = data?.error || data?.message || `HTTP ${res.status}`;
      const err = new Error(errMsg) as Error & { code?: string; errorData?: any };
      // CRITICAL FIX: Preserve structured error code from edge function response
      // so the frontend can distinguish NOT_FOUND vs EXPIRED vs OWN_CODE etc.
      if (data?.code) err.code = data.code;
      err.errorData = data;
      return { data: null, error: err };
    }

    return { data: data as T, error: null };

  } catch (err: any) {
    clearTimeout(timeoutId);
    externalSignal?.removeEventListener('abort', onExternalAbort);

    // External abort (caller cancelled)
    if (externalSignal?.aborted) {
      return { data: null, error: new Error('Request was cancelled.') };
    }

    // Internal timeout
    if (controller.signal.aborted) {
      return {
        data: null,
        error: new Error(
          `Edge function "${name}" timed out after ${timeoutMs / 1000}s. The server may be busy — please try again.`
        ),
      };
    }

    return { data: null, error: err instanceof Error ? err : new Error(String(err)) };
  }
}



// Export URL and key so components can build edge function URLs dynamically
export const SUPABASE_URL = supabaseUrl;
export const SUPABASE_ANON_KEY = supabaseKey;

/**
 * Build a public URL for a profile photo stored in the profile-photos bucket.
 * Uses the public bucket URL pattern — NO signed URLs, NO edge functions.
 *
 * @param photoPath - The path within the bucket, e.g. "user-id/primary.jpg"
 * @param updatedAt - Optional timestamp for cache busting (ISO string or epoch ms)
 * @returns Full public URL string, or null if photoPath is falsy
 */
export function getPublicPhotoUrl(photoPath: string | null | undefined, updatedAt?: string | number | null): string | null {
  if (!photoPath) return null;
  const base = `${supabaseUrl}/storage/v1/object/public/profile-photos/${photoPath}`;
  if (updatedAt) {
    const t = typeof updatedAt === 'string' ? new Date(updatedAt).getTime() : updatedAt;
    return `${base}?t=${t}`;
  }
  return `${base}?t=${Date.now()}`;
}

export { supabase };
