import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';

import { useAuth } from '@/contexts/AuthContext';
import { usePremium } from '@/contexts/PremiumContext';
import {
  Layers,
  Loader2,
  CheckCircle,
  Copy,
  Download,
  X,
  Crown,
  AlertCircle
} from 'lucide-react';

interface BulkCodeGeneratorProps {
  isOpen: boolean;
  onClose: () => void;
  onCodesGenerated?: (codes: any[]) => void;
}

function generateCrushCode(length = 6): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const arr = new Uint8Array(length);
  crypto.getRandomValues(arr);
  let code = '';
  for (let i = 0; i < length; i++) code += chars[arr[i] % chars.length];
  return code;
}

const BulkCodeGenerator: React.FC<BulkCodeGeneratorProps> = ({
  isOpen,
  onClose,
  onCodesGenerated
}) => {
  const { user } = useAuth();
  const { isPremium } = usePremium();
  const [count, setCount] = useState(5);
  const [expiryHours, setExpiryHours] = useState(408); // 17 days
  const [generating, setGenerating] = useState(false);
  const [generatedCodes, setGeneratedCodes] = useState<any[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    if (!user || !isPremium) return;

    setGenerating(true);
    setError(null);

    try {
      const expiresAt = new Date(Date.now() + expiryHours * 60 * 60 * 1000).toISOString();
      const codes: any[] = [];

      // Ensure profile exists (FK constraint)
      const { data: profileExists } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', user.id)
        .maybeSingle();

      if (!profileExists) {
        console.warn('[BulkCodeGenerator] Profile missing — auto-creating');
        const { error: insertErr } = await supabase
          .from('profiles')
          .insert({ id: user.id, email: user.email || '', display_name: user.email?.split('@')[0] || 'User', intent: 'dating', created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
        if (insertErr && insertErr.code !== '23505') {
          throw new Error('Could not verify your profile. Please refresh and try again.');
        }
      }

      console.log('[BulkCodeGenerator] Generating', count, 'codes via direct DB insert');

      for (let i = 0; i < count; i++) {
        let lastError: any = null;
        for (let attempt = 0; attempt < 3; attempt++) {
          const code = generateCrushCode();
          const { data, error: insertError } = await supabase
            .from('crush_cards')
            .insert({ creator_id: user.id, code, expires_at: expiresAt, status: 'active' })
            .select('id, code, status, expires_at, created_at')
            .single();

          if (insertError) {
            lastError = insertError;
            if (insertError.code === '23505') continue; // collision — retry
            break;
          }
          if (data) {
            codes.push(data);
            break;
          }
        }
        if (codes.length <= i) {
          console.warn(`[BulkCodeGenerator] Failed to generate code #${i + 1}:`, lastError?.message);
        }
      }

      if (codes.length === 0) {
        throw new Error('Failed to generate any codes. Please try again.');
      }

      console.log('[BulkCodeGenerator] Generated', codes.length, 'codes successfully');
      setGeneratedCodes(codes);
      onCodesGenerated?.(codes);
    } catch (err: any) {
      console.error('[BulkCodeGenerator] Bulk generation failed:', err);
      setError(err.message || 'Failed to generate codes');
    } finally {
      setGenerating(false);
    }
  };

  const handleCopyAll = async () => {
    const codesText = generatedCodes.map(c => c.code).join('\n');
    try {
      await navigator.clipboard.writeText(codesText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const handleDownloadCSV = () => {
    const headers = ['Code', 'Created At', 'Expires At', 'Status'];
    const rows = generatedCodes.map(c => [
      c.code,
      new Date(c.created_at).toISOString(),
      new Date(c.expires_at).toISOString(),
      c.status
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `crush-codes-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleClose = () => {
    setGeneratedCodes([]);
    setError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-charcoal-800 rounded-2xl border border-charcoal-600 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center">
              <Layers className="w-5 h-5 text-gold" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-white">Bulk Code Generator</h2>
              <p className="text-xs text-gray-400 flex items-center gap-1">
                <Crown className="w-3 h-3 text-gold" />
                Premium Feature
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4">
          {generatedCodes.length === 0 ? (
            <>
              {/* Count Selector */}
              <div className="mb-4">
                <label className="block text-sm text-gray-400 mb-2">Number of Codes</label>
                <div className="grid grid-cols-4 gap-2">
                  {[5, 10, 15, 20].map((num) => (
                    <button
                      key={num}
                      onClick={() => setCount(num)}
                      className={`py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                        count === num
                          ? 'bg-gold text-charcoal'
                          : 'bg-charcoal-600 text-gray-300 hover:bg-charcoal-500'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>

              {/* Expiry Selector */}
              <div className="mb-4">
                <label className="block text-sm text-gray-400 mb-2">Code Validity</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { hours: 408, label: '17 days' },
                    { hours: 576, label: '24 days' },
                    { hours: 744, label: '31 days' },
                  ].map(({ hours, label }) => (
                    <button
                      key={hours}
                      onClick={() => setExpiryHours(hours)}
                      className={`py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                        expiryHours === hours
                          ? 'bg-gold text-charcoal'
                          : 'bg-charcoal-600 text-gray-300 hover:bg-charcoal-500'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Error */}
              {error && (
                <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  <p className="text-sm text-red-400">{error}</p>
                </div>
              )}

              {/* Generate Button */}
              <button
                onClick={handleGenerate}
                disabled={generating}
                className="w-full py-3 bg-gold hover:bg-gold-400 text-charcoal font-semibold rounded-xl transition-all flex items-center justify-center gap-2"
              >
                {generating ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Generating {count} codes...
                  </>
                ) : (
                  <>
                    <Layers className="w-5 h-5" />
                    Generate {count} Codes
                  </>
                )}
              </button>
            </>
          ) : (
            <>
              {/* Success State */}
              <div className="text-center mb-4">
                <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
                  <CheckCircle className="w-6 h-6 text-green-400" />
                </div>
                <h3 className="text-lg font-semibold text-white">
                  {generatedCodes.length} Codes Generated!
                </h3>
                <p className="text-sm text-gray-400">
                  Your codes are ready to share
                </p>
              </div>

              {/* Codes List */}
              <div className="max-h-48 overflow-y-auto mb-4 bg-charcoal-900 rounded-xl p-3 border border-charcoal-600">
                <div className="grid grid-cols-2 gap-2">
                  {generatedCodes.map((card, index) => (
                    <div
                      key={card.id}
                      className="px-3 py-2 bg-charcoal-700 rounded-lg text-center"
                    >
                      <span className="text-xs text-gray-500">#{index + 1}</span>
                      <p className="font-mono font-bold text-white tracking-wider">
                        {card.code}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={handleCopyAll}
                  className="py-2.5 bg-charcoal-600 hover:bg-charcoal-500 text-white rounded-lg transition-all flex items-center justify-center gap-2"
                >
                  {copied ? (
                    <>
                      <CheckCircle className="w-4 h-4 text-green-400" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      Copy All
                    </>
                  )}
                </button>
                <button
                  onClick={handleDownloadCSV}
                  className="py-2.5 bg-gold hover:bg-gold-400 text-charcoal font-medium rounded-lg transition-all flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Download CSV
                </button>
              </div>

              {/* Generate More */}
              <button
                onClick={() => setGeneratedCodes([])}
                className="w-full mt-3 py-2 text-gray-400 hover:text-white text-sm transition-colors"
              >
                Generate More Codes
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default BulkCodeGenerator;
