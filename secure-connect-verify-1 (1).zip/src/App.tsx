import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/theme-provider";
import { AuthProvider } from "@/contexts/AuthContext";
import { I18nProvider } from "@/contexts/I18nContext";
import { PremiumProvider } from "@/contexts/PremiumContext";
import { NotificationProvider } from "@/contexts/NotificationContext";
import { SupportChatProvider, useSupportChatVisibility } from "@/contexts/SupportChatContext";
import Index from "./pages/Index";
import DashboardPage from "./pages/DashboardPage";
import SettingsPage from "./pages/SettingsPage";
import AdminPage from "./pages/AdminPage";
import MapPage from "./pages/MapPage";
import PremiumPage from "./pages/PremiumPage";
import RedeemPage from "./pages/RedeemPage";
import NotificationsPage from "./pages/NotificationsPage";
import UnsubscribePage from "./pages/UnsubscribePage";
import NotFound from "./pages/NotFound";
import SupportChat from "./components/support/SupportChat";

const queryClient = new QueryClient();

const GlobalSupportChat = () => {
  const { hidden } = useSupportChatVisibility();
  if (hidden) return null;
  return <SupportChat />;
};

const App = () => (
  <ThemeProvider defaultTheme="light">
    <QueryClientProvider client={queryClient}>
      <I18nProvider>
        <AuthProvider>
          <PremiumProvider>
            <NotificationProvider>
              <SupportChatProvider>
                <TooltipProvider>
                  <Toaster />
                  <Sonner />
                  <BrowserRouter>
                    <Routes>
                      <Route path="/" element={<Index />} />
                      <Route path="/dashboard" element={<DashboardPage />} />
                      <Route path="/settings" element={<SettingsPage />} />
                      <Route path="/admin" element={<AdminPage />} />
                      <Route path="/map" element={<MapPage />} />
                      <Route path="/premium" element={<PremiumPage />} />
                      <Route path="/redeem" element={<RedeemPage />} />
                      <Route path="/notifications" element={<NotificationsPage />} />
                      <Route path="/unsubscribe" element={<UnsubscribePage />} />
                      <Route path="*" element={<NotFound />} />
                    </Routes>
                  </BrowserRouter>
                  <GlobalSupportChat />
                </TooltipProvider>
              </SupportChatProvider>
            </NotificationProvider>
          </PremiumProvider>
        </AuthProvider>
      </I18nProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
