import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { 
  Clock, 
  Bell,
  Loader2,
  Check,
  AlertCircle,
  Timer,
  Info,
  History
} from 'lucide-react';

type SupportedLanguage = 'en' | 'es' | 'fr' | 'de';

interface MatchExpirationPrefs {
  match_expiration_reminders: boolean;
  match_reminder_hours: number;
  match_reminder_12h: boolean;
  match_reminder_6h: boolean;
  match_reminder_1h: boolean;
}

interface ReminderHistory {
  id: string;
  reminder_type: string;
  scheduled_for: string;
  sent_at: string;
  email_sent: boolean;
}

// UI translations
const UI_TEXT = {
  en: {
    title: 'Match Expiration Reminders',
    description: 'Get notified before your matches expire so you don\'t miss out on connections',
    mainToggle: 'Match Expiration Reminders',
    mainToggleDesc: 'Receive email reminders when matches are about to expire',
    
    additionalReminders: 'Additional Reminders',
    additionalRemindersDesc: 'Get extra reminders closer to expiration',
    
    reminder24h: '24 Hours Before',
    reminder24hDesc: 'Primary reminder sent 24 hours before expiration',
    reminder12h: '12 Hours Before',
    reminder12hDesc: 'Additional reminder 12 hours before expiration',
    reminder6h: '6 Hours Before',
    reminder6hDesc: 'Urgent reminder 6 hours before expiration',
    reminder1h: '1 Hour Before',
    reminder1hDesc: 'Final reminder 1 hour before expiration',
    
    recentReminders: 'Recent Reminders',
    noReminders: 'No reminders sent yet',
    
    saving: 'Saving...',
    saved: 'Preferences saved',
    error: 'Failed to save preferences',
    
    infoText: 'Reminders include a direct link to start a conversation with your match. Don\'t let connections slip away!',
    
    reminderTypes: {
      '24_hour': '24h reminder',
      '12_hour': '12h reminder',
      '6_hour': '6h reminder',
      '1_hour': '1h reminder'
    }
  },
  es: {
    title: 'Recordatorios de Expiración de Match',
    description: 'Recibe notificaciones antes de que tus matches expiren para no perder conexiones',
    mainToggle: 'Recordatorios de Expiración',
    mainToggleDesc: 'Recibir recordatorios por email cuando los matches estén por expirar',
    
    additionalReminders: 'Recordatorios Adicionales',
    additionalRemindersDesc: 'Recibe recordatorios extra más cerca de la expiración',
    
    reminder24h: '24 Horas Antes',
    reminder24hDesc: 'Recordatorio principal enviado 24 horas antes de expirar',
    reminder12h: '12 Horas Antes',
    reminder12hDesc: 'Recordatorio adicional 12 horas antes de expirar',
    reminder6h: '6 Horas Antes',
    reminder6hDesc: 'Recordatorio urgente 6 horas antes de expirar',
    reminder1h: '1 Hora Antes',
    reminder1hDesc: 'Recordatorio final 1 hora antes de expirar',
    
    recentReminders: 'Recordatorios Recientes',
    noReminders: 'No hay recordatorios enviados aún',
    
    saving: 'Guardando...',
    saved: 'Preferencias guardadas',
    error: 'Error al guardar preferencias',
    
    infoText: 'Los recordatorios incluyen un enlace directo para iniciar una conversación con tu match. ¡No dejes escapar conexiones!',
    
    reminderTypes: {
      '24_hour': 'Recordatorio 24h',
      '12_hour': 'Recordatorio 12h',
      '6_hour': 'Recordatorio 6h',
      '1_hour': 'Recordatorio 1h'
    }
  },
  fr: {
    title: 'Rappels d\'Expiration de Match',
    description: 'Soyez notifié avant que vos matchs expirent pour ne pas manquer de connexions',
    mainToggle: 'Rappels d\'Expiration',
    mainToggleDesc: 'Recevoir des rappels par email quand les matchs sont sur le point d\'expirer',
    
    additionalReminders: 'Rappels Supplémentaires',
    additionalRemindersDesc: 'Recevez des rappels supplémentaires plus proches de l\'expiration',
    
    reminder24h: '24 Heures Avant',
    reminder24hDesc: 'Rappel principal envoyé 24 heures avant l\'expiration',
    reminder12h: '12 Heures Avant',
    reminder12hDesc: 'Rappel supplémentaire 12 heures avant l\'expiration',
    reminder6h: '6 Heures Avant',
    reminder6hDesc: 'Rappel urgent 6 heures avant l\'expiration',
    reminder1h: '1 Heure Avant',
    reminder1hDesc: 'Rappel final 1 heure avant l\'expiration',
    
    recentReminders: 'Rappels Récents',
    noReminders: 'Aucun rappel envoyé pour le moment',
    
    saving: 'Enregistrement...',
    saved: 'Préférences enregistrées',
    error: 'Échec de l\'enregistrement',
    
    infoText: 'Les rappels incluent un lien direct pour démarrer une conversation avec votre match. Ne laissez pas les connexions s\'échapper!',
    
    reminderTypes: {
      '24_hour': 'Rappel 24h',
      '12_hour': 'Rappel 12h',
      '6_hour': 'Rappel 6h',
      '1_hour': 'Rappel 1h'
    }
  },
  de: {
    title: 'Match-Ablauf-Erinnerungen',
    description: 'Werde benachrichtigt bevor deine Matches ablaufen, um keine Verbindungen zu verpassen',
    mainToggle: 'Ablauf-Erinnerungen',
    mainToggleDesc: 'E-Mail-Erinnerungen erhalten wenn Matches bald ablaufen',
    
    additionalReminders: 'Zusätzliche Erinnerungen',
    additionalRemindersDesc: 'Erhalte zusätzliche Erinnerungen näher am Ablauf',
    
    reminder24h: '24 Stunden Vorher',
    reminder24hDesc: 'Haupt-Erinnerung 24 Stunden vor Ablauf',
    reminder12h: '12 Stunden Vorher',
    reminder12hDesc: 'Zusätzliche Erinnerung 12 Stunden vor Ablauf',
    reminder6h: '6 Stunden Vorher',
    reminder6hDesc: 'Dringende Erinnerung 6 Stunden vor Ablauf',
    reminder1h: '1 Stunde Vorher',
    reminder1hDesc: 'Letzte Erinnerung 1 Stunde vor Ablauf',
    
    recentReminders: 'Letzte Erinnerungen',
    noReminders: 'Noch keine Erinnerungen gesendet',
    
    saving: 'Speichern...',
    saved: 'Einstellungen gespeichert',
    error: 'Speichern fehlgeschlagen',
    
    infoText: 'Erinnerungen enthalten einen direkten Link um ein Gespräch mit deinem Match zu starten. Lass keine Verbindungen entgehen!',
    
    reminderTypes: {
      '24_hour': '24h Erinnerung',
      '12_hour': '12h Erinnerung',
      '6_hour': '6h Erinnerung',
      '1_hour': '1h Erinnerung'
    }
  }
};

const MatchExpirationSettings: React.FC = () => {
  const { user } = useAuth();
  const { language: appLanguage } = useI18n();
  
  const language: SupportedLanguage = ['en', 'es', 'fr', 'de'].includes(appLanguage) 
    ? appLanguage as SupportedLanguage 
    : 'en';
  
  const text = UI_TEXT[language];
  
  const [preferences, setPreferences] = useState<MatchExpirationPrefs>({
    match_expiration_reminders: true,
    match_reminder_hours: 24,
    match_reminder_12h: false,
    match_reminder_6h: false,
    match_reminder_1h: false
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reminderHistory, setReminderHistory] = useState<ReminderHistory[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    if (user) {
      loadPreferences();
      loadReminderHistory();
    }
  }, [user]);

  const loadPreferences = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('email_preferences')
        .select('match_expiration_reminders, match_reminder_hours, match_reminder_12h, match_reminder_6h, match_reminder_1h')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setPreferences({
          match_expiration_reminders: data.match_expiration_reminders ?? true,
          match_reminder_hours: data.match_reminder_hours ?? 24,
          match_reminder_12h: data.match_reminder_12h ?? false,
          match_reminder_6h: data.match_reminder_6h ?? false,
          match_reminder_1h: data.match_reminder_1h ?? false
        });
      }
    } catch (err) {
      console.error('Failed to load match expiration preferences:', err);
      setError(text.error);
    } finally {
      setLoading(false);
    }
  };

  const loadReminderHistory = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('match_expiration_reminders')
        .select('id, reminder_type, scheduled_for, sent_at, email_sent')
        .eq('user_id', user.id)
        .order('sent_at', { ascending: false })
        .limit(10);

      if (!error && data) {
        setReminderHistory(data);
      }
    } catch (err) {
      console.error('Failed to load reminder history:', err);
    }
  };

  const updatePreference = async (key: keyof MatchExpirationPrefs, value: boolean | number) => {
    if (!user) return;

    const newPrefs = { ...preferences, [key]: value };
    setPreferences(newPrefs);
    setSaving(true);
    setError(null);

    try {
      const { error } = await supabase
        .from('email_preferences')
        .update({ [key]: value, updated_at: new Date().toISOString() })
        .eq('user_id', user.id);

      if (error) throw error;

      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      console.error('Failed to update preference:', err);
      setError(text.error);
      setPreferences(preferences);
    } finally {
      setSaving(false);
    }
  };

  const Toggle = ({ 
    enabled, 
    onChange, 
    disabled 
  }: { 
    enabled: boolean; 
    onChange: () => void; 
    disabled?: boolean 
  }) => (
    <button
      onClick={onChange}
      disabled={disabled}
      className={`w-11 h-6 rounded-full transition-all ${
        enabled ? 'bg-gold' : 'bg-charcoal-500'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      <div className={`w-5 h-5 bg-white rounded-full shadow transform transition-transform ${
        enabled ? 'translate-x-5' : 'translate-x-0.5'
      }`} />
    </button>
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(language, {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 text-gold animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Clock className="w-5 h-5 text-gold" />
          {text.title}
        </h3>
        <p className="text-sm text-gray-400 mt-1">{text.description}</p>
      </div>

      {/* Status indicator */}
      {(saving || saved || error) && (
        <div className={`flex items-center gap-2 text-sm ${
          error ? 'text-red-400' : saved ? 'text-green-400' : 'text-gray-400'
        }`}>
          {saving && <Loader2 className="w-4 h-4 animate-spin" />}
          {saved && <Check className="w-4 h-4" />}
          {error && <AlertCircle className="w-4 h-4" />}
          <span>{saving ? text.saving : saved ? text.saved : error}</span>
        </div>
      )}

      {/* Main toggle */}
      <div className="p-4 bg-charcoal-600 rounded-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              preferences.match_expiration_reminders ? 'bg-gold/20' : 'bg-charcoal-500'
            }`}>
              <Bell className={`w-5 h-5 ${
                preferences.match_expiration_reminders ? 'text-gold' : 'text-gray-400'
              }`} />
            </div>
            <div>
              <p className="font-medium text-white">{text.mainToggle}</p>
              <p className="text-sm text-gray-400">{text.mainToggleDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.match_expiration_reminders} 
            onChange={() => updatePreference('match_expiration_reminders', !preferences.match_expiration_reminders)}
            disabled={saving}
          />
        </div>
      </div>

      {/* Reminder timing options */}
      <div className={`space-y-1 ${!preferences.match_expiration_reminders ? 'opacity-50 pointer-events-none' : ''}`}>
        
        {/* Section header */}
        <div className="flex items-center gap-2 mt-4 mb-3">
          <Timer className="w-4 h-4 text-gold" />
          <h4 className="text-sm font-semibold text-gold uppercase tracking-wide">{text.additionalReminders}</h4>
        </div>
        <p className="text-xs text-gray-500 mb-4">{text.additionalRemindersDesc}</p>

        {/* 24 Hour Reminder (always on if main toggle is on) */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
              <span className="text-xs font-bold text-blue-400">24h</span>
            </div>
            <div>
              <p className="font-medium text-white">{text.reminder24h}</p>
              <p className="text-sm text-gray-400">{text.reminder24hDesc}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-green-400 bg-green-500/20 px-2 py-1 rounded-full">
              Always On
            </span>
          </div>
        </div>

        {/* 12 Hour Reminder */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-yellow-500/20 flex items-center justify-center">
              <span className="text-xs font-bold text-yellow-400">12h</span>
            </div>
            <div>
              <p className="font-medium text-white">{text.reminder12h}</p>
              <p className="text-sm text-gray-400">{text.reminder12hDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.match_reminder_12h} 
            onChange={() => updatePreference('match_reminder_12h', !preferences.match_reminder_12h)}
            disabled={saving || !preferences.match_expiration_reminders}
          />
        </div>

        {/* 6 Hour Reminder */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-orange-500/20 flex items-center justify-center">
              <span className="text-xs font-bold text-orange-400">6h</span>
            </div>
            <div>
              <p className="font-medium text-white">{text.reminder6h}</p>
              <p className="text-sm text-gray-400">{text.reminder6hDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.match_reminder_6h} 
            onChange={() => updatePreference('match_reminder_6h', !preferences.match_reminder_6h)}
            disabled={saving || !preferences.match_expiration_reminders}
          />
        </div>

        {/* 1 Hour Reminder */}
        <div className="flex items-center justify-between py-4 border-b border-charcoal-600">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-red-500/20 flex items-center justify-center">
              <span className="text-xs font-bold text-red-400">1h</span>
            </div>
            <div>
              <p className="font-medium text-white">{text.reminder1h}</p>
              <p className="text-sm text-gray-400">{text.reminder1hDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.match_reminder_1h} 
            onChange={() => updatePreference('match_reminder_1h', !preferences.match_reminder_1h)}
            disabled={saving || !preferences.match_expiration_reminders}
          />
        </div>
      </div>

      {/* Info box */}
      <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl flex items-start gap-3">
        <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
        <p className="text-sm text-blue-300">
          {text.infoText}
        </p>
      </div>

      {/* Reminder History */}
      {reminderHistory.length > 0 && (
        <div className="pt-4">
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"
          >
            <History className="w-4 h-4" />
            {text.recentReminders}
            <span className="text-xs bg-charcoal-600 px-2 py-0.5 rounded-full">
              {reminderHistory.length}
            </span>
          </button>
          
          {showHistory && (
            <div className="mt-3 space-y-2">
              {reminderHistory.map((reminder) => (
                <div 
                  key={reminder.id}
                  className="flex items-center justify-between p-3 bg-charcoal-700/50 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${
                      reminder.email_sent ? 'bg-green-400' : 'bg-yellow-400'
                    }`} />
                    <div>
                      <p className="text-sm text-white">
                        {text.reminderTypes[reminder.reminder_type as keyof typeof text.reminderTypes] || reminder.reminder_type}
                      </p>
                      <p className="text-xs text-gray-500">
                        Match expires: {formatDate(reminder.scheduled_for)}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs text-gray-500">
                    {formatDate(reminder.sent_at)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {reminderHistory.length === 0 && (
        <div className="text-center py-4 text-gray-500 text-sm">
          {text.noReminders}
        </div>
      )}
    </div>
  );
};

export default MatchExpirationSettings;
