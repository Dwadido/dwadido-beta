import React, { useState, useEffect } from 'react';
import { 
  Heart, 
  MessageSquare, 
  Sparkles, 
  MapPin, 
  Coffee,
  Music,
  BookOpen,
  Lightbulb,
  RefreshCw
} from 'lucide-react';
import { 
  IntentType, 
  INTENT_LABELS,
  CommunicationStyleType,
  LoveStyleType,
  COMMUNICATION_STYLE_LABELS,
  LifestyleFactors
} from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';

// =============================================================================
// DWADIDO MATCH INSIGHT CARD - REQUIRED FOR EVERY MATCH
// 
// Purpose:
// - Explain WHY the match exists in warm, conversational language
// - Build trust through transparency
// - Help users feel confident acting offline
// 
// Rules:
// - NO scores, percentages, or rankings
// - NO coaching language ("tip:", "you should", etc.)
// - Plain-language explanations ONLY
// - MUST always show insight (never return null)
// 
// Focus areas (in priority order):
// 1. Intent alignment (PRIMARY)
// 2. Communication & interaction style (SECONDARY)
// 3. One relevant lifestyle or interest note (OPTIONAL)
// 
// The explanation is MORE IMPORTANT than the match itself.
// =============================================================================

interface MatchInsightCardProps {
  myProfile: {
    intent?: IntentType | null;
    communication_style?: CommunicationStyleType;
    love_style?: LoveStyleType;
    lifestyle_factors?: LifestyleFactors | null;
    interest_tags?: string[];
    city?: string | null;
    values_causes?: string[] | null;
    bio?: string | null;
    display_name?: string | null;
  };
  otherProfile: {
    display_name?: string | null;
    intent?: IntentType | null;
    communication_style?: CommunicationStyleType;
    love_style?: LoveStyleType;
    lifestyle_factors?: LifestyleFactors | null;
    interest_tags?: string[];
    city?: string | null;
    values_causes?: string[] | null;
    bio?: string | null;
  };
  matchId?: string;
  compact?: boolean;
  useAI?: boolean;
}

// =============================================================================
// AI EXPLANATION FETCHER
// Generates warm, conversational explanations using AI
// =============================================================================

interface AIExplanationState {
  explanation: string | null;
  loading: boolean;
  error: string | null;
}

const useAIExplanation = (
  myProfile: MatchInsightCardProps['myProfile'],
  otherProfile: MatchInsightCardProps['otherProfile'],
  matchId?: string,
  enabled: boolean = true
) => {
  const [state, setState] = useState<AIExplanationState>({
    explanation: null,
    loading: false,
    error: null
  });

  const getCacheKey = () => matchId ? `match_explanation_${matchId}` : null;

  const loadCached = () => {
    const key = getCacheKey();
    if (!key) return null;
    try {
      const cached = localStorage.getItem(key);
      if (cached) {
        const { explanation, timestamp } = JSON.parse(cached);
        // Cache for 24 hours
        if (Date.now() - timestamp < 24 * 60 * 60 * 1000) {
          return explanation;
        }
      }
    } catch { /* ignore */ }
    return null;
  };

  const saveCache = (text: string) => {
    const key = getCacheKey();
    if (!key) return;
    try {
      localStorage.setItem(key, JSON.stringify({
        explanation: text,
        timestamp: Date.now()
      }));
    } catch { /* ignore */ }
  };

  const fetchExplanation = async (forceRefresh = false) => {
    if (!enabled) return;

    // Check cache first
    if (!forceRefresh) {
      const cached = loadCached();
      if (cached) {
        setState({ explanation: cached, loading: false, error: null });
        return;
      }
    }

    setState(prev => ({ ...prev, loading: true, error: null }));

    try {
      const { data, error } = await supabase.functions.invoke('generate-match-explanation', {
        body: { myProfile, otherProfile }
      });

      if (error) throw new Error(error.message);

      if (data?.explanation) {
        setState({ explanation: data.explanation, loading: false, error: null });
        saveCache(data.explanation);
      } else {
        setState({ explanation: null, loading: false, error: 'No explanation generated' });
      }
    } catch (err) {
      console.error('AI explanation error:', err);
      setState({ explanation: null, loading: false, error: 'Unable to generate explanation' });
    }
  };

  useEffect(() => {
    if (enabled) {
      fetchExplanation();
    }
  }, [enabled, matchId]);

  return { ...state, refresh: () => fetchExplanation(true) };
};

// =============================================================================
// INSIGHT GENERATION FUNCTIONS (Fallback when AI is not used)
// All functions return plain-language explanations, never scores or rankings
// =============================================================================

// PRIMARY: Intent alignment explanation
function generateIntentInsight(
  myIntent: IntentType | null | undefined, 
  theirIntent: IntentType | null | undefined, 
  theirName: string
): { text: string; strength: 'strong' | 'compatible' | 'general' } {
  
  // Both have matching intents - strongest alignment
  if (myIntent && theirIntent && myIntent === theirIntent) {
    const intentLabel = INTENT_LABELS[theirIntent].toLowerCase();
    return {
      text: `You're both looking for ${intentLabel}. This shared intention creates a meaningful foundation for connection.`,
      strength: 'strong'
    };
  }
  
  // Compatible intents
  const compatiblePairs: Record<IntentType, IntentType[]> = {
    'friends_first': ['dating'],
    'dating': ['friends_first', 'long_term_relationship'],
    'long_term_relationship': ['dating', 'lifetime_partner'],
    'lifetime_partner': ['long_term_relationship']
  };
  
  if (myIntent && theirIntent && compatiblePairs[myIntent]?.includes(theirIntent)) {
    return {
      text: `Your relationship intentions align well. You're looking for ${INTENT_LABELS[myIntent].toLowerCase()}, and ${theirName} is open to ${INTENT_LABELS[theirIntent].toLowerCase()}. These goals can complement each other naturally.`,
      strength: 'compatible'
    };
  }
  
  // One or both haven't specified intent
  if (!myIntent && !theirIntent) {
    return {
      text: `This connection was made based on your profiles. As you get to know each other, you'll discover if your relationship goals align.`,
      strength: 'general'
    };
  }
  
  if (!myIntent) {
    return {
      text: `${theirName} is looking for ${INTENT_LABELS[theirIntent!].toLowerCase()}. Consider whether this aligns with what you're seeking.`,
      strength: 'general'
    };
  }
  
  if (!theirIntent) {
    return {
      text: `You're looking for ${INTENT_LABELS[myIntent].toLowerCase()}. ${theirName} hasn't specified their intentions yet, so this is worth discussing early.`,
      strength: 'general'
    };
  }
  
  // Different intents - still explain transparently
  return {
    text: `You're looking for ${INTENT_LABELS[myIntent].toLowerCase()}, while ${theirName} is interested in ${INTENT_LABELS[theirIntent].toLowerCase()}. This is something worth discussing to understand each other's expectations.`,
    strength: 'general'
  };
}

// SECONDARY: Communication style explanation
function generateCommunicationInsight(
  myStyle: CommunicationStyleType | undefined, 
  theirStyle: CommunicationStyleType | undefined, 
  theirName: string
): string | null {
  if (!myStyle || !theirStyle) return null;
  
  const myLabel = COMMUNICATION_STYLE_LABELS[myStyle].toLowerCase();
  const theirLabel = COMMUNICATION_STYLE_LABELS[theirStyle].toLowerCase();
  
  if (myStyle === theirStyle) {
    return `You both tend toward ${myLabel} communication, which suggests conversations may feel natural.`;
  }
  
  // Complementary style explanations - warm, non-judgmental
  const complementaryInsights: Record<string, string> = {
    'direct-thoughtful': `You're ${myLabel} while ${theirName} is more ${theirLabel}. This can create balanced conversations where quick decisions meet careful consideration.`,
    'thoughtful-direct': `You're ${myLabel} while ${theirName} is more ${theirLabel}. This combination often leads to well-rounded discussions.`,
    'direct-emotional': `You prefer ${myLabel} communication while ${theirName} leads with emotion. Being aware of this difference early can help you connect more deeply.`,
    'emotional-direct': `You lead with emotion while ${theirName} is more ${theirLabel}. Understanding this difference can strengthen your connection.`,
    'thoughtful-emotional': `You're ${myLabel} and ${theirName} is ${theirLabel}. Taking time to understand each other's style will help your conversations flow.`,
    'emotional-thoughtful': `You're ${myLabel} and ${theirName} is ${theirLabel}. This can create a balanced dynamic in your interactions.`,
  };
  
  const key = `${myStyle}-${theirStyle}`;
  const reverseKey = `${theirStyle}-${myStyle}`;
  
  return complementaryInsights[key] || complementaryInsights[reverseKey] || 
    `Your communication styles differ, which can bring richness to your conversations as you learn from each other.`;
}

// OPTIONAL: One relevant interest or lifestyle note
function generateInterestNote(
  myInterests: string[] | undefined, 
  theirInterests: string[] | undefined,
  myCity: string | null | undefined,
  theirCity: string | null | undefined,
  theirName: string
): { text: string; icon: 'music' | 'book' | 'coffee' | 'location' } | null {
  
  // Find shared interests
  if (myInterests?.length && theirInterests?.length) {
    const shared = myInterests.filter(interest => 
      theirInterests.some(ti => ti.toLowerCase() === interest.toLowerCase())
    );
    
    if (shared.length > 0) {
      const interest = shared[0];
      const interestLower = interest.toLowerCase();
      
      let icon: 'music' | 'book' | 'coffee' | 'location' = 'coffee';
      if (interestLower.includes('music') || interestLower.includes('concert')) {
        icon = 'music';
      } else if (interestLower.includes('book') || interestLower.includes('read')) {
        icon = 'book';
      }
      
      return {
        text: `You both enjoy ${interest.toLowerCase()}, which could make an easy first meet.`,
        icon
      };
    }
  }
  
  // Location-based note if same city
  if (myCity && theirCity && myCity.toLowerCase() === theirCity.toLowerCase()) {
    return {
      text: `You're both in ${myCity}, so meeting in person could be straightforward.`,
      icon: 'location'
    };
  }
  
  return null;
}

// Generate first date suggestion based on shared interests
function generateMeetingSuggestion(sharedInterests: string[]): string | null {
  if (!sharedInterests.length) return null;
  
  const suggestions: Record<string, string> = {
    'music': 'A relaxed live music event could be a natural first meet.',
    'coffee': 'A casual coffee could be a great way to start.',
    'hiking': 'A daytime walk or hike could be a relaxed way to get to know each other.',
    'art': 'Visiting a gallery together could spark great conversation.',
    'food': 'Trying a new restaurant together could be a fun first date.',
    'books': 'A bookstore café could be perfect for you both.',
    'fitness': 'A workout class or outdoor activity could be an energizing first meet.',
    'movies': 'A film followed by coffee to discuss it could work well.',
    'travel': 'Sharing travel stories over drinks could be a great icebreaker.',
    'cooking': 'A cooking class together could be a fun, interactive first date.',
  };
  
  for (const interest of sharedInterests) {
    const lower = interest.toLowerCase();
    for (const [key, suggestion] of Object.entries(suggestions)) {
      if (lower.includes(key)) {
        return suggestion;
      }
    }
  }
  
  return 'A relaxed coffee or a short walk nearby could be an easy first meet.';
}

// =============================================================================
// MAIN COMPONENT
// =============================================================================

const MatchInsightCard: React.FC<MatchInsightCardProps> = ({
  myProfile,
  otherProfile,
  matchId,
  compact = false,
  useAI = true
}) => {
  const theirName = otherProfile.display_name || 'They';
  
  // AI-generated explanation (if enabled)
  const { explanation: aiExplanation, loading: aiLoading, refresh: refreshAI } = useAIExplanation(
    myProfile,
    otherProfile,
    matchId,
    useAI
  );
  
  // Fallback insights (always generated)
  const intentInsight = generateIntentInsight(myProfile.intent, otherProfile.intent, theirName);
  const communicationInsight = generateCommunicationInsight(
    myProfile.communication_style, 
    otherProfile.communication_style, 
    theirName
  );
  const interestNote = generateInterestNote(
    myProfile.interest_tags,
    otherProfile.interest_tags,
    myProfile.city,
    otherProfile.city,
    theirName
  );
  
  // Find shared interests for meeting suggestion
  const sharedInterests = (myProfile.interest_tags || []).filter(interest => 
    (otherProfile.interest_tags || []).some(ti => ti.toLowerCase() === interest.toLowerCase())
  );
  const meetingSuggestion = generateMeetingSuggestion(sharedInterests);
  
  // Get icon for interest note
  const getInterestIcon = (iconType: string) => {
    switch (iconType) {
      case 'music': return <Music className="w-4 h-4 text-green-400" />;
      case 'book': return <BookOpen className="w-4 h-4 text-green-400" />;
      case 'location': return <MapPin className="w-4 h-4 text-purple-400" />;
      default: return <Coffee className="w-4 h-4 text-green-400" />;
    }
  };
  
  // ==========================================================================
  // COMPACT VIEW - Shows AI explanation or primary insight
  // ==========================================================================
  if (compact) {
    return (
      <div className="bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] p-4">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 bg-[#C9A24D]/20 rounded-lg flex items-center justify-center flex-shrink-0">
            {useAI ? (
              <Sparkles className="w-4 h-4 text-[#C9A24D]" />
            ) : (
              <Lightbulb className="w-4 h-4 text-[#C9A24D]" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-[#C9A24D] font-medium uppercase tracking-wide mb-1">
              Why You Might Connect
            </p>
            {aiLoading ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-[#C9A24D]/30 border-t-[#C9A24D] rounded-full animate-spin" />
                <span className="text-sm text-gray-400">Thinking...</span>
              </div>
            ) : (
              <>
                <p className="text-sm text-gray-300 leading-relaxed">
                  {aiExplanation || intentInsight.text}
                </p>
                {!aiExplanation && interestNote && (
                  <p className="text-sm text-gray-400 mt-2">
                    {interestNote.text}
                  </p>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    );
  }
  
  // ==========================================================================
  // FULL VIEW - Shows AI explanation with fallback details
  // ==========================================================================
  return (
    <div className="bg-[#1a1a1a] rounded-xl border border-[#2a2a2a] overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 border-b border-[#2a2a2a] bg-[#C9A24D]/5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#C9A24D]" />
            <h3 className="font-medium text-white">Why You Might Connect</h3>
          </div>
          {useAI && !aiLoading && (
            <button
              onClick={refreshAI}
              className="p-1.5 text-gray-500 hover:text-[#C9A24D] hover:bg-[#C9A24D]/10 rounded-lg transition-all"
              title="Get a fresh perspective"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          )}
        </div>
        <p className="text-xs text-gray-500 mt-1">
          A thoughtful look at what you might have in common
        </p>
      </div>
      
      <div className="p-4 space-y-4">
        {/* AI Explanation - Primary when available */}
        {useAI && (
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-[#C9A24D]/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-5 h-5 text-[#C9A24D]" />
            </div>
            <div className="flex-1">
              {aiLoading ? (
                <div className="flex items-center gap-3 py-2">
                  <div className="w-5 h-5 border-2 border-[#C9A24D]/30 border-t-[#C9A24D] rounded-full animate-spin" />
                  <span className="text-sm text-gray-400">Thinking about your connection...</span>
                </div>
              ) : (
                <p className="text-sm text-gray-300 leading-relaxed">
                  {aiExplanation || intentInsight.text}
                </p>
              )}
            </div>
          </div>
        )}
        
        {/* Fallback: Intent Alignment - Show if no AI or AI failed */}
        {(!useAI || (!aiLoading && !aiExplanation)) && (
          <div className="flex items-start gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
              intentInsight.strength === 'strong' 
                ? 'bg-[#C9A24D]/20' 
                : intentInsight.strength === 'compatible'
                ? 'bg-[#C9A24D]/15'
                : 'bg-gray-500/20'
            }`}>
              <Heart className={`w-5 h-5 ${
                intentInsight.strength === 'strong' || intentInsight.strength === 'compatible'
                  ? 'text-[#C9A24D]'
                  : 'text-gray-400'
              }`} />
            </div>
            <div className="flex-1">
              <p className="text-xs text-[#C9A24D] font-medium uppercase tracking-wide mb-1">
                Relationship Intentions
              </p>
              <p className="text-sm text-gray-300 leading-relaxed">
                {intentInsight.text}
              </p>
            </div>
          </div>
        )}
        
        {/* Communication Style - Show as additional context */}
        {communicationInsight && !aiLoading && (
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <MessageSquare className="w-5 h-5 text-blue-400" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-blue-400 font-medium uppercase tracking-wide mb-1">
                Communication Style
              </p>
              <p className="text-sm text-gray-300 leading-relaxed">
                {communicationInsight}
              </p>
            </div>
          </div>
        )}
        
        {/* Interest/Location Note */}
        {interestNote && !aiLoading && (
          <div className="flex items-start gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
              interestNote.icon === 'location' ? 'bg-purple-500/20' : 'bg-green-500/20'
            }`}>
              {getInterestIcon(interestNote.icon)}
            </div>
            <div className="flex-1">
              <p className={`text-xs font-medium uppercase tracking-wide mb-1 ${
                interestNote.icon === 'location' ? 'text-purple-400' : 'text-green-400'
              }`}>
                {interestNote.icon === 'location' ? 'Location' : 'Shared Interest'}
              </p>
              <p className="text-sm text-gray-300 leading-relaxed">
                {interestNote.text}
              </p>
            </div>
          </div>
        )}
        
        {/* Meeting Suggestion */}
        {meetingSuggestion && !aiLoading && (
          <div className="mt-4 pt-4 border-t border-[#2a2a2a]">
            <div className="flex items-start gap-3 p-3 bg-[#C9A24D]/5 rounded-lg border border-[#C9A24D]/10">
              <Coffee className="w-5 h-5 text-[#C9A24D] flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">
                  First Meet Idea
                </p>
                <p className="text-sm text-gray-300">
                  {meetingSuggestion}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Footer - Calm, supportive message */}
      <div className="px-4 py-3 border-t border-[#2a2a2a] bg-[#0a0a0a]">
        <p className="text-xs text-gray-500 text-center">
          Real connections take time. There's no rush.
        </p>
      </div>
    </div>
  );
};

export default MatchInsightCard;
