import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { X, Mail, Lock, User, Loader2, Eye, EyeOff, ArrowLeft, CheckCircle } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'signin' | 'signup';
}

// Dwadido Logo - Heart with gold checkmark
const DwadidoLogo = ({ className = "w-8 h-8" }: { className?: string }) => (
  <svg className={className} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path 
      d="M20 35L17.09 32.3C8.14 24.2 2 18.55 2 11.5C2 5.85 6.42 1.5 12 1.5C15.09 1.5 18.09 2.97 20 5.27C21.91 2.97 24.91 1.5 28 1.5C33.58 1.5 38 5.85 38 11.5C38 18.55 31.86 24.2 22.91 32.3L20 35Z" 
      fill="#1C1C1C"
      stroke="#C9A24D"
      strokeWidth="2"
    />
    <path 
      d="M14 19L18 23L26 15" 
      stroke="#C9A24D" 
      strokeWidth="3" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    />
  </svg>
);

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, initialMode = 'signup' }) => {
  const { signIn, signUp, resetPassword } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup' | 'reset'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resetSent, setResetSent] = useState(false);

  // Handle body scroll lock for iOS + close support chat
  useEffect(() => {
    if (isOpen) {
      // Close the support chat if it's open — only one modal at a time
      window.dispatchEvent(new CustomEvent('requestCloseSupportChat'));

      const scrollY = window.scrollY;
      document.body.style.position = 'fixed';
      document.body.style.top = `-${scrollY}px`;
      document.body.style.width = '100%';
    } else {
      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);
    }

    return () => {
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
    };
  }, [isOpen]);


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (mode === 'reset') {
        const { error } = await resetPassword(email);
        if (error) throw error;
        setResetSent(true);
      } else if (mode === 'signup') {
        const { error } = await signUp(email, password, displayName);
        if (error) throw error;
        onClose();
      } else {
        const { error } = await signIn(email, password);
        if (error) throw error;
        onClose();
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setEmail('');
    setPassword('');
    setDisplayName('');
    setError('');
    setResetSent(false);
  };

  const switchMode = (newMode: 'signin' | 'signup' | 'reset') => {
    resetForm();
    setMode(newMode);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden" style={{ WebkitOverflowScrolling: 'touch' }}>
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative min-h-full flex items-center justify-center p-4 py-8">
        <div className="relative w-full max-w-md bg-[#1C1C1C] rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300 border border-[#2a2a2a]">
          {/* Header */}
          <div className="relative bg-[#1a1a1a] px-6 py-8 text-center border-b border-[#2a2a2a]">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white hover:bg-[#2a2a2a] rounded-full transition-all"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="flex justify-center mb-4">
              <DwadidoLogo className="w-16 h-16" />
            </div>
            <h2 className="text-2xl font-bold text-white">
              {mode === 'reset' ? 'Reset Password' : mode === 'signup' ? 'Create Account' : 'Welcome Back'}
            </h2>
            <p className="text-gray-400 mt-1">
              {mode === 'reset' 
                ? 'Enter your email to reset your password' 
                : mode === 'signup' 
                  ? 'Start making verified connections'
                  : 'Sign in to your Dwadido account'}
            </p>
          </div>

          {/* Form */}
          <div className="p-6">
            {mode === 'reset' && resetSent ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 mx-auto mb-4 bg-[#C9A24D]/20 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-8 h-8 text-[#C9A24D]" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Check your email</h3>
                <p className="text-gray-400 mb-6">
                  We've sent a password reset link to <strong className="text-[#C9A24D]">{email}</strong>
                </p>
                <button
                  onClick={() => switchMode('signin')}
                  className="text-[#C9A24D] font-medium hover:text-[#D4AF5B]"
                >
                  Back to sign in
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {mode === 'reset' && (
                  <button
                    type="button"
                    onClick={() => switchMode('signin')}
                    className="flex items-center gap-2 text-gray-400 hover:text-white text-sm mb-4"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back to sign in
                  </button>
                )}

                {mode === 'signup' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Display Name</label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                      <input
                        type="text"
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        placeholder="Your name"
                        className="w-full pl-10 pr-4 py-3 bg-[#141414] border border-[#2a2a2a] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#C9A24D] focus:border-transparent transition-all"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-1">Email</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      required
                      className="w-full pl-10 pr-4 py-3 bg-[#141414] border border-[#2a2a2a] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#C9A24D] focus:border-transparent transition-all"
                    />
                  </div>
                </div>

                {mode !== 'reset' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-1">Password</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        required
                        minLength={6}
                        className="w-full pl-10 pr-12 py-3 bg-[#141414] border border-[#2a2a2a] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#C9A24D] focus:border-transparent transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300"
                      >
                        {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>
                )}

                {mode === 'signin' && (
                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => switchMode('reset')}
                      className="text-sm text-[#C9A24D] hover:text-[#D4AF5B]"
                    >
                      Forgot password?
                    </button>
                  </div>
                )}

                {error && (
                  <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 bg-[#C9A24D] text-[#141414] font-semibold rounded-xl hover:bg-[#D4AF5B] disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(201,162,77,0.2)]"
                >
                  {loading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : mode === 'reset' ? (
                    'Send Reset Link'
                  ) : mode === 'signup' ? (
                    'Create Account'
                  ) : (
                    'Sign In'
                  )}
                </button>
              </form>
            )}

            {mode !== 'reset' && (
              <div className="mt-6 text-center">
                <p className="text-gray-400 text-sm">
                  {mode === 'signup' ? 'Already have an account?' : "Don't have an account?"}
                  <button
                    onClick={() => switchMode(mode === 'signup' ? 'signin' : 'signup')}
                    className="ml-1 text-[#C9A24D] font-medium hover:text-[#D4AF5B]"
                  >
                    {mode === 'signup' ? 'Sign in' : 'Sign up'}
                  </button>
                </p>
              </div>
            )}

            {mode === 'signup' && (
              <p className="mt-4 text-center text-xs text-gray-500">
                By creating an account, you agree to our Terms of Service and Privacy Policy
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
