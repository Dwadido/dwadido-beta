import React, { useEffect, useRef, useState } from 'react';
import { Download, Copy, CheckCircle } from 'lucide-react';

interface QRCodeGeneratorProps {
  value: string;
  size?: number;
  showActions?: boolean;
  className?: string;
}

// QR Code Generator using pure JavaScript
// This creates a valid QR Code that can be scanned

// QR Code constants
const ERROR_CORRECTION_LEVEL = 1; // L = 0, M = 1, Q = 2, H = 3
const MODE_ALPHANUMERIC = 2;

// Alphanumeric character set
const ALPHANUMERIC_CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:';

// QR Code version capacities for alphanumeric mode with M error correction
const VERSION_CAPACITY = [0, 20, 38, 61, 90, 122, 154, 195, 230, 271, 311];

// Generator polynomials for error correction
const GF256_EXP = new Uint8Array(512);
const GF256_LOG = new Uint8Array(256);

// Initialize Galois Field tables
(function initGF256() {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF256_EXP[i] = x;
    GF256_LOG[x] = i;
    x = (x << 1) ^ (x >= 128 ? 0x11d : 0);
  }
  for (let i = 255; i < 512; i++) {
    GF256_EXP[i] = GF256_EXP[i - 255];
  }
})();

function gfMul(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return GF256_EXP[GF256_LOG[a] + GF256_LOG[b]];
}

function gfPow(a: number, n: number): number {
  return GF256_EXP[(GF256_LOG[a] * n) % 255];
}

function generateErrorCorrectionCodewords(data: number[], ecCount: number): number[] {
  // Generate generator polynomial
  const gen = [1];
  for (let i = 0; i < ecCount; i++) {
    const newGen = new Array(gen.length + 1).fill(0);
    for (let j = 0; j < gen.length; j++) {
      newGen[j] ^= gen[j];
      newGen[j + 1] ^= gfMul(gen[j], GF256_EXP[i]);
    }
    gen.length = 0;
    gen.push(...newGen);
  }

  // Perform polynomial division
  const result = new Array(ecCount).fill(0);
  for (const byte of data) {
    const factor = byte ^ result[0];
    result.shift();
    result.push(0);
    for (let i = 0; i < ecCount; i++) {
      result[i] ^= gfMul(gen[i + 1], factor);
    }
  }
  return result;
}

function encodeAlphanumeric(text: string): number[] {
  const bits: number[] = [];
  
  // Mode indicator (4 bits) - Alphanumeric = 0010
  bits.push(0, 0, 1, 0);
  
  // Character count indicator (9 bits for version 1-9)
  const countBits = text.length.toString(2).padStart(9, '0');
  for (const bit of countBits) bits.push(parseInt(bit));
  
  // Encode pairs
  for (let i = 0; i < text.length; i += 2) {
    const char1 = ALPHANUMERIC_CHARS.indexOf(text[i]);
    if (i + 1 < text.length) {
      const char2 = ALPHANUMERIC_CHARS.indexOf(text[i + 1]);
      const value = char1 * 45 + char2;
      const valueBits = value.toString(2).padStart(11, '0');
      for (const bit of valueBits) bits.push(parseInt(bit));
    } else {
      const valueBits = char1.toString(2).padStart(6, '0');
      for (const bit of valueBits) bits.push(parseInt(bit));
    }
  }
  
  return bits;
}

function getVersion(text: string): number {
  for (let v = 1; v <= 10; v++) {
    if (text.length <= VERSION_CAPACITY[v]) return v;
  }
  return 10;
}

function getModuleCount(version: number): number {
  return 17 + version * 4;
}

// Data codewords and EC codewords for each version (M level)
const VERSION_INFO: { [key: number]: { dataCodewords: number; ecCodewords: number; ecBlocks: number } } = {
  1: { dataCodewords: 16, ecCodewords: 10, ecBlocks: 1 },
  2: { dataCodewords: 28, ecCodewords: 16, ecBlocks: 1 },
  3: { dataCodewords: 44, ecCodewords: 26, ecBlocks: 1 },
  4: { dataCodewords: 64, ecCodewords: 18, ecBlocks: 2 },
  5: { dataCodewords: 86, ecCodewords: 24, ecBlocks: 2 },
};

function createQRMatrix(text: string): boolean[][] {
  const version = Math.min(getVersion(text), 5);
  const size = getModuleCount(version);
  const matrix: (boolean | null)[][] = Array(size).fill(null).map(() => Array(size).fill(null));
  
  // Add finder patterns
  const addFinderPattern = (row: number, col: number) => {
    for (let r = -1; r <= 7; r++) {
      for (let c = -1; c <= 7; c++) {
        const nr = row + r, nc = col + c;
        if (nr < 0 || nr >= size || nc < 0 || nc >= size) continue;
        
        if (r === -1 || r === 7 || c === -1 || c === 7) {
          matrix[nr][nc] = false; // White separator
        } else if (r === 0 || r === 6 || c === 0 || c === 6) {
          matrix[nr][nc] = true; // Black border
        } else if (r >= 2 && r <= 4 && c >= 2 && c <= 4) {
          matrix[nr][nc] = true; // Black center
        } else {
          matrix[nr][nc] = false; // White inner
        }
      }
    }
  };
  
  addFinderPattern(0, 0);
  addFinderPattern(0, size - 7);
  addFinderPattern(size - 7, 0);
  
  // Add timing patterns
  for (let i = 8; i < size - 8; i++) {
    matrix[6][i] = i % 2 === 0;
    matrix[i][6] = i % 2 === 0;
  }
  
  // Add dark module
  matrix[size - 8][8] = true;
  
  // Reserve format information areas
  for (let i = 0; i < 9; i++) {
    if (matrix[8][i] === null) matrix[8][i] = false;
    if (matrix[i][8] === null) matrix[i][8] = false;
    if (i < 8) {
      if (matrix[8][size - 1 - i] === null) matrix[8][size - 1 - i] = false;
      if (matrix[size - 1 - i][8] === null) matrix[size - 1 - i][8] = false;
    }
  }
  
  // Add alignment pattern for version >= 2
  if (version >= 2) {
    const alignPos = size - 7;
    for (let r = -2; r <= 2; r++) {
      for (let c = -2; c <= 2; c++) {
        const nr = alignPos + r, nc = alignPos + c;
        if (Math.abs(r) === 2 || Math.abs(c) === 2) {
          matrix[nr][nc] = true;
        } else if (r === 0 && c === 0) {
          matrix[nr][nc] = true;
        } else {
          matrix[nr][nc] = false;
        }
      }
    }
  }
  
  // Encode data
  const dataBits = encodeAlphanumeric(text.toUpperCase());
  const versionInfo = VERSION_INFO[version] || VERSION_INFO[1];
  const totalBits = versionInfo.dataCodewords * 8;
  
  // Add terminator
  const terminatorLength = Math.min(4, totalBits - dataBits.length);
  for (let i = 0; i < terminatorLength; i++) dataBits.push(0);
  
  // Pad to byte boundary
  while (dataBits.length % 8 !== 0) dataBits.push(0);
  
  // Add padding codewords
  const padPatterns = [0xEC, 0x11];
  let padIndex = 0;
  while (dataBits.length < totalBits) {
    const pad = padPatterns[padIndex % 2];
    for (let i = 7; i >= 0; i--) dataBits.push((pad >> i) & 1);
    padIndex++;
  }
  
  // Convert to bytes
  const dataBytes: number[] = [];
  for (let i = 0; i < dataBits.length; i += 8) {
    let byte = 0;
    for (let j = 0; j < 8; j++) {
      byte = (byte << 1) | (dataBits[i + j] || 0);
    }
    dataBytes.push(byte);
  }
  
  // Generate error correction
  const ecBytes = generateErrorCorrectionCodewords(dataBytes, versionInfo.ecCodewords);
  
  // Combine data and EC
  const allBytes = [...dataBytes, ...ecBytes];
  const allBits: number[] = [];
  for (const byte of allBytes) {
    for (let i = 7; i >= 0; i--) {
      allBits.push((byte >> i) & 1);
    }
  }
  
  // Place data in matrix using zigzag pattern
  let bitIndex = 0;
  let upward = true;
  
  for (let col = size - 1; col >= 0; col -= 2) {
    if (col === 6) col = 5; // Skip timing pattern column
    
    const rows = upward ? 
      Array.from({ length: size }, (_, i) => size - 1 - i) :
      Array.from({ length: size }, (_, i) => i);
    
    for (const row of rows) {
      for (let c = 0; c < 2; c++) {
        const actualCol = col - c;
        if (matrix[row][actualCol] === null) {
          matrix[row][actualCol] = bitIndex < allBits.length ? allBits[bitIndex++] === 1 : false;
        }
      }
    }
    upward = !upward;
  }
  
  // Apply mask pattern 0 (checkerboard)
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      // Skip function patterns
      if (isReserved(row, col, size, version)) continue;
      if ((row + col) % 2 === 0) {
        matrix[row][col] = !matrix[row][col];
      }
    }
  }
  
  // Add format information (mask 0, M error correction)
  const formatBits = [1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1];
  
  // Horizontal format info (left)
  for (let i = 0; i < 6; i++) matrix[8][i] = formatBits[i] === 1;
  matrix[8][7] = formatBits[6] === 1;
  matrix[8][8] = formatBits[7] === 1;
  matrix[7][8] = formatBits[8] === 1;
  for (let i = 9; i < 15; i++) matrix[14 - i][8] = formatBits[i] === 1;
  
  // Horizontal format info (right)
  for (let i = 0; i < 8; i++) matrix[8][size - 8 + i] = formatBits[7 + i] === 1;
  
  // Vertical format info (bottom)
  for (let i = 0; i < 7; i++) matrix[size - 1 - i][8] = formatBits[i] === 1;
  
  return matrix.map(row => row.map(cell => cell === true));
}

function isReserved(row: number, col: number, size: number, version: number): boolean {
  // Finder patterns + separators
  if (row < 9 && col < 9) return true;
  if (row < 9 && col >= size - 8) return true;
  if (row >= size - 8 && col < 9) return true;
  
  // Timing patterns
  if (row === 6 || col === 6) return true;
  
  // Alignment pattern (version >= 2)
  if (version >= 2) {
    const alignPos = size - 7;
    if (Math.abs(row - alignPos) <= 2 && Math.abs(col - alignPos) <= 2) return true;
  }
  
  return false;
}

const QRCodeGenerator: React.FC<QRCodeGeneratorProps> = ({ 
  value, 
  size = 200, 
  showActions = true,
  className = ''
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [copied, setCopied] = useState(false);
  const [matrix, setMatrix] = useState<boolean[][] | null>(null);

  useEffect(() => {
    if (!value) return;
    
    try {
      const qrMatrix = createQRMatrix(value);
      setMatrix(qrMatrix);
      
      const canvas = canvasRef.current;
      if (!canvas) return;
      
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      const moduleCount = qrMatrix.length;
      const moduleSize = Math.floor(size / (moduleCount + 8)); // Add quiet zone
      const actualSize = moduleSize * (moduleCount + 8);
      
      canvas.width = actualSize;
      canvas.height = actualSize;
      
      // White background
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, actualSize, actualSize);
      
      // Draw modules
      ctx.fillStyle = '#000000';
      const offset = moduleSize * 4; // Quiet zone
      
      for (let row = 0; row < moduleCount; row++) {
        for (let col = 0; col < moduleCount; col++) {
          if (qrMatrix[row][col]) {
            ctx.fillRect(
              offset + col * moduleSize,
              offset + row * moduleSize,
              moduleSize,
              moduleSize
            );
          }
        }
      }
    } catch (error) {
      console.error('QR Code generation error:', error);
    }
  }, [value, size]);

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const link = document.createElement('a');
    link.download = `dwadido-code-${value}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const handleCopy = async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    try {
      canvas.toBlob(async (blob) => {
        if (blob) {
          await navigator.clipboard.write([
            new ClipboardItem({ 'image/png': blob })
          ]);
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        }
      });
    } catch (error) {
      console.error('Failed to copy QR code:', error);
    }
  };

  if (!value) return null;

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <div className="bg-white p-3 rounded-xl shadow-lg">
        <canvas 
          ref={canvasRef} 
          className="block"
          style={{ width: size, height: size }}
        />
        <p className="text-center text-charcoal text-sm mt-2 font-mono font-bold tracking-wider">
          {value}
        </p>
      </div>
      
      {showActions && (
        <div className="flex gap-2 mt-3">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-charcoal-600 hover:bg-charcoal-500 text-white text-sm rounded-lg transition-all"
          >
            {copied ? (
              <>
                <CheckCircle className="w-4 h-4 text-green-400" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Copy</span>
              </>
            )}
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-charcoal-600 hover:bg-charcoal-500 text-white text-sm rounded-lg transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Save</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default QRCodeGenerator;
