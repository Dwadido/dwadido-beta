import React, { useState } from 'react';
import { supabase, SUPABASE_URL, SUPABASE_ANON_KEY } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Bug, Copy, Check, Loader2, ChevronDown, ChevronUp, AlertTriangle, Shield } from 'lucide-react';

function decodeJwtPayload(token: string): Record<string, any> | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(atob(base64));
  } catch { return null; }
}

function extractProjectId(url: string): string {
  try { return new URL(url).hostname.split('.')[0]; }
  catch { return 'PARSE_ERROR'; }
}

const EnvironmentDiagnostic: React.FC = () => {
  const { user, session, profile } = useAuth();
  const [report, setReport] = useState<Record<string, any> | null>(null);
  const [reportText, setReportText] = useState('');
  const [running, setRunning] = useState(false);
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const runDiagnostics = async () => {
    setRunning(true);
    setExpanded(true);
    const diag: Record<string, any> = {};
    const ts = new Date().toISOString();
    const projectIdFromUrl = extractProjectId(SUPABASE_URL);
    const jwtClaims = decodeJwtPayload(SUPABASE_ANON_KEY);
    const projectIdFromKey = jwtClaims?.projectId || jwtClaims?.sub || 'NOT_FOUND';
    const accessTokenClaims = session?.access_token ? decodeJwtPayload(session.access_token) : null;
    const projectIdFromAccessToken = accessTokenClaims?.projectId || accessTokenClaims?.iss || 'NOT_FOUND';

    diag['1_environment'] = {
      timestamp: ts, app_url: window.location.origin, supabase_url: SUPABASE_URL,
      project_id_from_url: projectIdFromUrl, project_id_from_anon_key: projectIdFromKey,
      project_id_from_access_token: projectIdFromAccessToken,
      url_key_match: projectIdFromUrl === projectIdFromKey,
      url_token_match: projectIdFromUrl === String(projectIdFromAccessToken),
      anon_key_fingerprint: SUPABASE_ANON_KEY ? `${SUPABASE_ANON_KEY.substring(0, 20)}...${SUPABASE_ANON_KEY.substring(SUPABASE_ANON_KEY.length - 10)}` : 'MISSING',
      anon_key_jwt_claims: jwtClaims ? { projectId: jwtClaims.projectId, role: jwtClaims.role, iss: jwtClaims.iss, aud: jwtClaims.aud } : 'DECODE_FAILED',
      access_token_jwt_claims: accessTokenClaims ? { sub: accessTokenClaims.sub, email: accessTokenClaims.email, iss: accessTokenClaims.iss, aud: accessTokenClaims.aud, role: accessTokenClaims.role, projectId: accessTokenClaims.projectId } : (session ? 'DECODE_FAILED' : 'NO_SESSION'),
    };
    diag['2_react_auth_state'] = { user_id: user?.id || null, user_email: user?.email || null, user_aud: (user as any)?.aud || null, session_exists: !!session };
    diag['3_react_profile_state'] = { profile_id: profile?.id || null, profile_email: profile?.email || null, profile_display_name: profile?.display_name || null, id_matches_user: user?.id === profile?.id };

    // 4. Server-side auth verification
    try {
      const { data: userData, error: userError } = await supabase.auth.getUser();
      if (userError) { diag['4_auth_getUser'] = { error: userError.message }; }
      else if (userData?.user) { diag['4_auth_getUser'] = { id: userData.user.id, email: userData.user.email, aud: (userData.user as any)?.aud, created_at: userData.user.created_at, id_matches_react_user: userData.user.id === user?.id }; }
      else { diag['4_auth_getUser'] = { result: 'NO_USER_RETURNED' }; }
    } catch (e: any) { diag['4_auth_getUser'] = { exception: e.message }; }

    const testUserId = user?.id || diag['4_auth_getUser']?.id;

    // 5. Profile SELECT
    if (testUserId) {
      try {
        const { data: selData, error: selError } = await supabase.from('profiles').select('id, email, display_name, intent, updated_at, created_at').eq('id', testUserId).maybeSingle();
        if (selError) { diag['5_profile_select'] = { result: 'ERROR', message: selError.message, code: selError.code }; }
        else if (selData) { diag['5_profile_select'] = { result: 'FOUND', id: selData.id, email: selData.email, display_name: selData.display_name, created_at: selData.created_at }; }
        else { diag['5_profile_select'] = { result: 'NOT_FOUND', note: 'No profile row exists for this user ID' }; }
      } catch (e: any) { diag['5_profile_select'] = { exception: e.message }; }
    } else { diag['5_profile_select'] = { skipped: 'No user ID' }; }

    // 6. Profile UPDATE test
    if (testUserId) {
      try {
        const { data: upData, error: upError } = await supabase.from('profiles').update({ updated_at: new Date().toISOString() }).eq('id', testUserId).select('id').maybeSingle();
        if (upError) { diag['6_profile_update_test'] = { result: 'ERROR', message: upError.message, code: upError.code, is_fk_violation: upError.message?.includes('profiles_id_fkey') || false }; }
        else if (upData) { diag['6_profile_update_test'] = { result: 'SUCCESS', returned_id: upData.id }; }
        else { diag['6_profile_update_test'] = { result: 'NO_ROWS_AFFECTED' }; }
      } catch (e: any) { diag['6_profile_update_test'] = { exception: e.message }; }
    } else { diag['6_profile_update_test'] = { skipped: 'No user ID' }; }

    // 7. Profile UPSERT FK test
    if (testUserId) {
      try {
        const { data: upsertData, error: upsertError } = await supabase.from('profiles').upsert({ id: testUserId, email: user?.email || '', updated_at: new Date().toISOString() }, { onConflict: 'id' }).select('id, email').maybeSingle();
        if (upsertError) { diag['7_profile_upsert_fk_test'] = { result: 'ERROR', message: upsertError.message, code: upsertError.code, is_fk_violation: upsertError.message?.includes('profiles_id_fkey') || false, diagnosis: upsertError.message?.includes('profiles_id_fkey') ? 'FK VIOLATION CONFIRMED — environment mismatch proven' : 'Non-FK error' }; }
        else if (upsertData) { diag['7_profile_upsert_fk_test'] = { result: 'SUCCESS', returned_id: upsertData.id, diagnosis: 'UPSERT succeeded — FK passed' }; }
        else { diag['7_profile_upsert_fk_test'] = { result: 'NO_DATA_RETURNED' }; }
      } catch (e: any) { diag['7_profile_upsert_fk_test'] = { exception: e.message }; }
    } else { diag['7_profile_upsert_fk_test'] = { skipped: 'No user ID' }; }

    // 8. Verdict
    const authUserId = diag['4_auth_getUser']?.id;
    const profileExists = diag['5_profile_select']?.result === 'FOUND';
    const updateWorks = diag['6_profile_update_test']?.result === 'SUCCESS';
    const fkViolation = diag['7_profile_upsert_fk_test']?.is_fk_violation === true;
    let verdict = 'UNKNOWN';
    if (fkViolation) verdict = 'ENVIRONMENT MISMATCH — FK constraint references auth.users in a different schema/project. Auth and database are NOT aligned.';
    else if (authUserId && profileExists && updateWorks) verdict = 'ALL CHECKS PASSED — environment appears aligned.';
    else if (!authUserId) verdict = 'AUTH USER NOT VERIFIED — session may be invalid.';
    else if (!profileExists) verdict = 'PROFILE MISSING — auth user exists but no profile row. Trigger may not be firing.';
    else if (!updateWorks) verdict = 'UPDATE FAILED — check RLS policies.';
    diag['8_verdict'] = verdict;

    setReport(diag);
    const jsonText = JSON.stringify(diag, null, 2);
    setReportText(jsonText);
    setRunning(false);
    try { await navigator.clipboard.writeText(jsonText); setCopied(true); setTimeout(() => setCopied(false), 3000); } catch { /* user can tap Copy */ }
  };

  const copyReport = async () => {
    if (!reportText) return;
    try { await navigator.clipboard.writeText(reportText); setCopied(true); setTimeout(() => setCopied(false), 3000); }
    catch {
      const ta = document.createElement('textarea');
      ta.value = reportText; ta.style.position = 'fixed'; ta.style.left = '-9999px'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.focus(); ta.select(); ta.setSelectionRange(0, reportText.length);
      try { document.execCommand('copy'); setCopied(true); setTimeout(() => setCopied(false), 3000); } catch { alert('Please long-press the report text and copy manually.'); }
      document.body.removeChild(ta);
    }
  };

  const projectIdFromUrl = extractProjectId(SUPABASE_URL);
  const jwtClaims = decodeJwtPayload(SUPABASE_ANON_KEY);
  const projectIdFromKey = jwtClaims?.projectId || 'N/A';
  const idsMatch = projectIdFromUrl === projectIdFromKey;

  return (
    <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
      <button onClick={() => setExpanded(!expanded)} className="w-full px-5 py-4 flex items-center justify-between text-left hover:bg-charcoal-600/50 transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center"><Bug className="w-5 h-5 text-blue-400" /></div>
          <div>
            <h3 className="text-sm font-semibold text-white">Environment Diagnostic</h3>
            <p className="text-xs text-gray-400 mt-0.5">Project: {projectIdFromUrl} | Auth: {user?.email || 'not signed in'}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {idsMatch ? <Shield className="w-4 h-4 text-green-400" /> : <AlertTriangle className="w-4 h-4 text-yellow-400" />}
          {expanded ? <ChevronUp className="w-5 h-5 text-gray-400" /> : <ChevronDown className="w-5 h-5 text-gray-400" />}
        </div>
      </button>
      <div className="px-5 pb-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500">
        <span>URL ID: <span className="text-gray-300">{projectIdFromUrl}</span></span>
        <span>Key ID: <span className={idsMatch ? 'text-gray-300' : 'text-yellow-400'}>{projectIdFromKey}</span></span>
        <span>User: <span className="text-gray-300">{user?.id?.substring(0, 8) || 'none'}...</span></span>
        <span>Profile: <span className="text-gray-300">{profile?.id ? 'exists' : 'missing'}</span></span>
      </div>
      {expanded && (
        <div className="px-5 pb-5 space-y-4 border-t border-charcoal-600 pt-4">
          <button onClick={runDiagnostics} disabled={running} className="w-full py-3 px-4 bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2 disabled:opacity-50 border border-blue-500/30">
            {running ? <><Loader2 className="w-4 h-4 animate-spin" />Running Diagnostics...</> : <><Bug className="w-4 h-4" />Run Diagnostics &amp; Copy Report</>}
          </button>
          {report && (
            <div className="space-y-3">
              <div className={`p-3 rounded-xl border ${report['8_verdict']?.includes('ALL CHECKS PASSED') ? 'bg-green-500/10 border-green-500/30' : report['8_verdict']?.includes('MISMATCH') ? 'bg-red-500/10 border-red-500/30' : 'bg-yellow-500/10 border-yellow-500/30'}`}>
                <p className={`text-sm font-medium ${report['8_verdict']?.includes('ALL CHECKS PASSED') ? 'text-green-400' : report['8_verdict']?.includes('MISMATCH') ? 'text-red-400' : 'text-yellow-400'}`}>{report['8_verdict']}</p>
              </div>
              <pre className="text-xs text-blue-200/80 whitespace-pre-wrap break-all font-mono bg-[#0a0a1a] p-4 rounded-xl max-h-80 overflow-y-auto border border-blue-500/10" style={{ WebkitUserSelect: 'all', userSelect: 'all' }}>{reportText}</pre>
              <button onClick={copyReport} className={`w-full py-3 px-4 rounded-xl text-sm font-semibold transition-colors flex items-center justify-center gap-2 border ${copied ? 'bg-green-500/20 border-green-500/30 text-green-300' : 'bg-blue-500/20 border-blue-500/30 text-blue-300 hover:bg-blue-500/30'}`}>
                {copied ? <><Check className="w-4 h-4" />Copied to Clipboard!</> : <><Copy className="w-4 h-4" />Copy Full Report</>}
              </button>
              <p className="text-xs text-gray-500 text-center">Tap "Copy Full Report" and paste it back to support.</p>
            </div>
          )}
          {!report && !running && <p className="text-xs text-gray-500 text-center py-2">Tap the button above to run a full environment check.</p>}
        </div>
      )}
    </div>
  );
};

export default EnvironmentDiagnostic;
