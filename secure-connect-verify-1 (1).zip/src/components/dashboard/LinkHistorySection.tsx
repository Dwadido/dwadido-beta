import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  History,
  Clock,
  Check,
  X,
  AlertTriangle,
  Loader2,
  Copy,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Ban,
  RefreshCw,
  Link2,
  Calendar,
  User,
  Shield
} from 'lucide-react';

interface TimeLimitedLinkHistory {
  id: string;
  token: string;
  code: string;
  created_at: string;
  expires_at: string;
  expiration_hours: number;
  redeemed_at: string | null;
  redeemed_by: string | null;
  revoked_at: string | null;
  is_active: boolean;
  status: 'active' | 'expired' | 'redeemed' | 'revoked' | 'inactive';
  time_remaining_ms: number;
}

interface LinkHistorySectionProps {
  codeId: string;
  isExpanded: boolean;
  onToggle: () => void;
}

const LinkHistorySection: React.FC<LinkHistorySectionProps> = ({
  codeId,
  isExpanded,
  onToggle
}) => {
  const { user } = useAuth();
  const [links, setLinks] = useState<TimeLimitedLinkHistory[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [revokingId, setRevokingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    redeemed: 0,
    expired: 0,
    revoked: 0
  });

  const fetchLinkHistory = async () => {
    if (!user?.id || !codeId) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fetchError } = await supabase.functions.invoke('time-limited-link', {
        body: {
          action: 'list',
          code_id: codeId,
          user_id: user.id
        }
      });

      if (fetchError) throw fetchError;
      if (data?.error) throw new Error(data.error);

      setLinks(data.links || []);
      setStats({
        total: data.total || 0,
        active: data.active_count || 0,
        redeemed: data.redeemed_count || 0,
        expired: data.expired_count || 0,
        revoked: data.revoked_count || 0
      });
    } catch (err: any) {
      console.error('Error fetching link history:', err);
      setError(err.message || 'Failed to load link history');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isExpanded && user?.id && codeId) {
      fetchLinkHistory();
    }
  }, [isExpanded, user?.id, codeId]);

  const handleRevokeLink = async (linkId: string) => {
    if (!user?.id) return;
    
    setRevokingId(linkId);
    
    try {
      const { data, error: revokeError } = await supabase.functions.invoke('time-limited-link', {
        body: {
          action: 'revoke',
          link_id: linkId,
          user_id: user.id
        }
      });

      if (revokeError) throw revokeError;
      if (data?.error) throw new Error(data.error);

      // Update the link in the list
      setLinks(prev => prev.map(link => 
        link.id === linkId 
          ? { ...link, status: 'revoked' as const, revoked_at: new Date().toISOString(), is_active: false }
          : link
      ));
      
      // Update stats
      setStats(prev => ({
        ...prev,
        active: Math.max(0, prev.active - 1),
        revoked: prev.revoked + 1
      }));
    } catch (err: any) {
      console.error('Error revoking link:', err);
      setError(err.message || 'Failed to revoke link');
    } finally {
      setRevokingId(null);
    }
  };

  const handleCopyLink = async (token: string, linkId: string) => {
    const url = `${window.location.origin}/redeem?t=${token}`;
    try {
      await navigator.clipboard.writeText(url);
      setCopiedId(linkId);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  const formatTimeRemaining = (ms: number) => {
    if (ms <= 0) return 'Expired';
    
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 0) {
      return `${hours}h ${minutes}m remaining`;
    }
    return `${minutes}m remaining`;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-green-500/20 text-green-400 text-xs font-medium rounded-full">
            {/* Static dot instead of animate-pulse for calm, non-addictive design (Dwadido Global Rule) */}
            <span className="w-1.5 h-1.5 bg-green-400 rounded-full" />
            Active
          </span>
        );

      case 'redeemed':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gold/20 text-gold text-xs font-medium rounded-full">
            <Check className="w-3 h-3" />
            Redeemed
          </span>
        );
      case 'expired':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-500/20 text-gray-400 text-xs font-medium rounded-full">
            <Clock className="w-3 h-3" />
            Expired
          </span>
        );
      case 'revoked':
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-red-500/20 text-red-400 text-xs font-medium rounded-full">
            <Ban className="w-3 h-3" />
            Revoked
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-500/20 text-gray-400 text-xs font-medium rounded-full">
            <X className="w-3 h-3" />
            Inactive
          </span>
        );
    }
  };

  return (
    <div className="border border-charcoal-600 rounded-xl overflow-hidden">
      {/* Header Toggle */}
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-4 bg-charcoal-700 hover:bg-charcoal-600 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center">
            <History className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-left">
            <p className="text-sm font-medium text-white">View Link History</p>
            <p className="text-xs text-gray-400">
              {stats.total > 0 
                ? `${stats.total} link${stats.total !== 1 ? 's' : ''} created • ${stats.active} active`
                : 'See all time-limited links'
              }
            </p>
          </div>
        </div>
        {isExpanded ? (
          <ChevronUp className="w-5 h-5 text-gray-400" />
        ) : (
          <ChevronDown className="w-5 h-5 text-gray-400" />
        )}
      </button>

      {/* Expanded Content */}
      {isExpanded && (
        <div className="p-4 bg-charcoal-800 border-t border-charcoal-600 space-y-4">
          {/* Stats Summary */}
          {stats.total > 0 && (
            <div className="grid grid-cols-4 gap-2">
              <div className="bg-charcoal-700 rounded-lg p-2 text-center">
                <p className="text-lg font-bold text-green-400">{stats.active}</p>
                <p className="text-[10px] text-gray-400">Active</p>
              </div>
              <div className="bg-charcoal-700 rounded-lg p-2 text-center">
                <p className="text-lg font-bold text-gold">{stats.redeemed}</p>
                <p className="text-[10px] text-gray-400">Redeemed</p>
              </div>
              <div className="bg-charcoal-700 rounded-lg p-2 text-center">
                <p className="text-lg font-bold text-gray-400">{stats.expired}</p>
                <p className="text-[10px] text-gray-400">Expired</p>
              </div>
              <div className="bg-charcoal-700 rounded-lg p-2 text-center">
                <p className="text-lg font-bold text-red-400">{stats.revoked}</p>
                <p className="text-[10px] text-gray-400">Revoked</p>
              </div>
            </div>
          )}

          {/* Refresh Button */}
          <div className="flex justify-end">
            <button
              onClick={fetchLinkHistory}
              disabled={loading}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-gray-400 hover:text-white bg-charcoal-700 hover:bg-charcoal-600 rounded-lg transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-red-400">{error}</p>
            </div>
          )}

          {/* Loading State */}
          {loading && links.length === 0 && (
            <div className="flex flex-col items-center justify-center py-8">
              <Loader2 className="w-8 h-8 text-blue-400 animate-spin mb-3" />
              <p className="text-sm text-gray-400">Loading link history...</p>
            </div>
          )}

          {/* Empty State */}
          {!loading && links.length === 0 && (
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="w-12 h-12 bg-charcoal-700 rounded-full flex items-center justify-center mb-3">
                <Link2 className="w-6 h-6 text-gray-500" />
              </div>
              <p className="text-sm text-gray-400 mb-1">No time-limited links yet</p>
              <p className="text-xs text-gray-500">Create your first link above to get started</p>
            </div>
          )}

          {/* Links List */}
          {links.length > 0 && (
            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
              {links.map((link) => (
                <div
                  key={link.id}
                  className={`p-3 rounded-xl border transition-all ${
                    link.status === 'active'
                      ? 'bg-charcoal-700/50 border-green-500/30'
                      : link.status === 'redeemed'
                      ? 'bg-charcoal-700/50 border-gold/30'
                      : link.status === 'revoked'
                      ? 'bg-charcoal-700/30 border-red-500/20'
                      : 'bg-charcoal-700/30 border-charcoal-600'
                  }`}
                >
                  {/* Link Header */}
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {getStatusBadge(link.status)}
                      <span className="text-xs text-gray-500">
                        {link.expiration_hours}h link
                      </span>
                    </div>
                    {link.status === 'active' && (
                      <span className="text-xs text-green-400 font-medium">
                        {formatTimeRemaining(link.time_remaining_ms)}
                      </span>
                    )}
                  </div>

                  {/* Link Token Preview */}
                  <div className="bg-charcoal-800 rounded-lg p-2 mb-2">
                    <p className="text-xs text-gray-500 font-mono truncate">
                      {window.location.origin}/redeem?t={link.token.substring(0, 12)}...
                    </p>
                  </div>

                  {/* Link Details */}
                  <div className="space-y-1.5 text-xs">
                    <div className="flex items-center gap-2 text-gray-400">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Created: {formatDate(link.created_at)}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-400">
                      <Clock className="w-3.5 h-3.5" />
                      <span>
                        {link.status === 'expired' || link.status === 'revoked'
                          ? 'Expired'
                          : `Expires: ${formatDate(link.expires_at)}`
                        }
                      </span>
                    </div>
                    {link.redeemed_at && (
                      <div className="flex items-center gap-2 text-gold">
                        <Check className="w-3.5 h-3.5" />
                        <span>Redeemed: {formatDate(link.redeemed_at)}</span>
                      </div>
                    )}
                    {link.revoked_at && (
                      <div className="flex items-center gap-2 text-red-400">
                        <Ban className="w-3.5 h-3.5" />
                        <span>Revoked: {formatDate(link.revoked_at)}</span>
                      </div>
                    )}
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 mt-3 pt-3 border-t border-charcoal-600">
                    {link.status === 'active' && (
                      <>
                        <button
                          onClick={() => handleCopyLink(link.token, link.id)}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-charcoal-600 hover:bg-charcoal-500 text-white text-xs font-medium rounded-lg transition-colors"
                        >
                          {copiedId === link.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-green-400" />
                              Copied!
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              Copy Link
                            </>
                          )}
                        </button>
                        <button
                          onClick={() => handleRevokeLink(link.id)}
                          disabled={revokingId === link.id}
                          className="flex items-center justify-center gap-1.5 px-3 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 text-xs font-medium rounded-lg transition-colors"
                        >
                          {revokingId === link.id ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <>
                              <Ban className="w-3.5 h-3.5" />
                              Revoke
                            </>
                          )}
                        </button>
                      </>
                    )}
                    {link.status !== 'active' && (
                      <div className="flex-1 flex items-center justify-center gap-2 py-2 text-xs text-gray-500">
                        <Shield className="w-3.5 h-3.5" />
                        <span>
                          {link.status === 'redeemed' 
                            ? 'Successfully connected!'
                            : link.status === 'revoked'
                            ? 'Link was deactivated'
                            : 'Link has expired'
                          }
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Info Text */}
          <div className="flex items-start gap-2 p-3 bg-charcoal-700/50 rounded-lg">
            <Shield className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-gray-400">
              Revoked links can no longer be used to connect. Use this feature if you shared a link 
              with the wrong person or changed your mind.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default LinkHistorySection;
