import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { 
  CreditCard, 
  AlertTriangle, 
  Clock, 
  X, 
  ChevronRight,
  Bell,
  RefreshCw,
  Crown,
  XCircle,
  RotateCcw,
  Calendar,
  Loader2
} from 'lucide-react';

interface RetryInfo {
  id: string;
  status: string;
  retry_count: number;
  max_retries: number;
  next_retry_at: string | null;
  last_retry_at: string | null;
  amount: number;
  currency: string;
}

interface ProactiveTrigger {
  type: 'payment_expiring' | 'renewal_reminder' | 'payment_failed' | 'subscription_expiring' | 'subscription_expired';
  priority: 'low' | 'medium' | 'high' | 'critical';
  data: Record<string, any>;
  message: Record<string, string>;
  actionLabel: Record<string, string>;
  actionType: string;
  retryInfo?: RetryInfo;
}

type SupportedLanguage = 'en' | 'es' | 'fr' | 'de' | 'ja' | 'ko' | 'zh' | 'th' | 'vi' | 'hi' | 'id' | 'ms';

// UI translations
const UI_TEXT: Record<SupportedLanguage, {
  proactiveAlerts: string;
  dismiss: string;
  dismissAll: string;
  loading: string;
  noAlerts: string;
  learnMore: string;
  retryStatus: string;
  nextRetry: string;
  lastRetry: string;
  retryAttempts: string;
  retryNow: string;
  cancelRetry: string;
  retrying: string;
  scheduled: string;
  pending: string;
  succeeded: string;
  failed: string;
  cancelled: string;
  retryScheduled: string;
  noMoreRetries: string;
  manualRetryRequired: string;
  resolutionSteps: Record<string, string[]>;
}> = {
  en: {
    proactiveAlerts: 'Important Notices',
    dismiss: 'Dismiss',
    dismissAll: 'Dismiss All',
    loading: 'Checking for alerts...',
    noAlerts: 'No alerts at this time',
    learnMore: 'Learn more',
    retryStatus: 'Retry Status',
    nextRetry: 'Next retry',
    lastRetry: 'Last attempt',
    retryAttempts: 'Attempts',
    retryNow: 'Retry Now',
    cancelRetry: 'Cancel Retries',
    retrying: 'Processing...',
    scheduled: 'Scheduled',
    pending: 'Pending',
    succeeded: 'Succeeded',
    failed: 'Failed',
    cancelled: 'Cancelled',
    retryScheduled: 'Automatic retry scheduled',
    noMoreRetries: 'No automatic retries remaining',
    manualRetryRequired: 'Please update payment method',
    resolutionSteps: {
      payment_expiring: ['Go to Settings > Payment Methods', 'Add a new card or update existing', 'Set as default payment method'],
      payment_failed: ['Check your card has sufficient funds', 'Verify card details are correct', 'Contact your bank if issues persist', 'Try a different payment method'],
      subscription_expiring: ['Visit Premium page to resubscribe', 'Your data and matches are preserved', 'Resubscribe anytime to restore access'],
      renewal_reminder: ['No action needed - auto-renewal is on', 'To cancel, go to Settings > Subscription', 'Manage payment method in Settings']
    }
  },
  es: {
    proactiveAlerts: 'Avisos Importantes',
    dismiss: 'Descartar',
    dismissAll: 'Descartar Todo',
    loading: 'Buscando alertas...',
    noAlerts: 'No hay alertas en este momento',
    learnMore: 'Más información',
    retryStatus: 'Estado del Reintento',
    nextRetry: 'Próximo reintento',
    lastRetry: 'Último intento',
    retryAttempts: 'Intentos',
    retryNow: 'Reintentar Ahora',
    cancelRetry: 'Cancelar Reintentos',
    retrying: 'Procesando...',
    scheduled: 'Programado',
    pending: 'Pendiente',
    succeeded: 'Exitoso',
    failed: 'Fallido',
    cancelled: 'Cancelado',
    retryScheduled: 'Reintento automático programado',
    noMoreRetries: 'No quedan reintentos automáticos',
    manualRetryRequired: 'Por favor actualiza tu método de pago',
    resolutionSteps: {
      payment_expiring: ['Ve a Configuración > Métodos de Pago', 'Agrega una nueva tarjeta o actualiza la existente', 'Establécela como método de pago predeterminado'],
      payment_failed: ['Verifica que tu tarjeta tenga fondos suficientes', 'Confirma que los datos de la tarjeta sean correctos', 'Contacta a tu banco si el problema persiste', 'Intenta con otro método de pago'],
      subscription_expiring: ['Visita la página Premium para volver a suscribirte', 'Tus datos y matches se conservan', 'Vuelve a suscribirte cuando quieras'],
      renewal_reminder: ['No se requiere acción - la renovación automática está activa', 'Para cancelar, ve a Configuración > Suscripción', 'Gestiona tu método de pago en Configuración']
    }
  },
  fr: {
    proactiveAlerts: 'Avis Importants',
    dismiss: 'Ignorer',
    dismissAll: 'Tout Ignorer',
    loading: 'Vérification des alertes...',
    noAlerts: 'Aucune alerte pour le moment',
    learnMore: 'En savoir plus',
    retryStatus: 'Statut du Réessai',
    nextRetry: 'Prochain réessai',
    lastRetry: 'Dernière tentative',
    retryAttempts: 'Tentatives',
    retryNow: 'Réessayer Maintenant',
    cancelRetry: 'Annuler les Réessais',
    retrying: 'Traitement...',
    scheduled: 'Programmé',
    pending: 'En attente',
    succeeded: 'Réussi',
    failed: 'Échoué',
    cancelled: 'Annulé',
    retryScheduled: 'Réessai automatique programmé',
    noMoreRetries: 'Plus de réessais automatiques',
    manualRetryRequired: 'Veuillez mettre à jour votre moyen de paiement',
    resolutionSteps: {
      payment_expiring: ['Allez dans Paramètres > Moyens de paiement', 'Ajoutez une nouvelle carte ou mettez à jour', 'Définissez comme moyen de paiement par défaut'],
      payment_failed: ['Vérifiez que votre carte a des fonds suffisants', 'Vérifiez que les détails de la carte sont corrects', 'Contactez votre banque si le problème persiste', 'Essayez un autre moyen de paiement'],
      subscription_expiring: ['Visitez la page Premium pour vous réabonner', 'Vos données et matches sont préservés', 'Réabonnez-vous à tout moment'],
      renewal_reminder: ['Aucune action requise - le renouvellement auto est actif', 'Pour annuler, allez dans Paramètres > Abonnement', 'Gérez votre moyen de paiement dans Paramètres']
    }
  },
  de: {
    proactiveAlerts: 'Wichtige Hinweise',
    dismiss: 'Schließen',
    dismissAll: 'Alle Schließen',
    loading: 'Suche nach Hinweisen...',
    noAlerts: 'Keine Hinweise zur Zeit',
    learnMore: 'Mehr erfahren',
    retryStatus: 'Wiederholungsstatus',
    nextRetry: 'Nächste Wiederholung',
    lastRetry: 'Letzter Versuch',
    retryAttempts: 'Versuche',
    retryNow: 'Jetzt Wiederholen',
    cancelRetry: 'Wiederholungen Abbrechen',
    retrying: 'Verarbeitung...',
    scheduled: 'Geplant',
    pending: 'Ausstehend',
    succeeded: 'Erfolgreich',
    failed: 'Fehlgeschlagen',
    cancelled: 'Abgebrochen',
    retryScheduled: 'Automatische Wiederholung geplant',
    noMoreRetries: 'Keine automatischen Wiederholungen mehr',
    manualRetryRequired: 'Bitte aktualisieren Sie Ihre Zahlungsmethode',
    resolutionSteps: {
      payment_expiring: ['Gehen Sie zu Einstellungen > Zahlungsmethoden', 'Fügen Sie eine neue Karte hinzu oder aktualisieren Sie', 'Als Standard-Zahlungsmethode festlegen'],
      payment_failed: ['Prüfen Sie, ob Ihre Karte ausreichend gedeckt ist', 'Überprüfen Sie die Kartendaten', 'Kontaktieren Sie Ihre Bank bei anhaltenden Problemen', 'Versuchen Sie eine andere Zahlungsmethode'],
      subscription_expiring: ['Besuchen Sie die Premium-Seite zum erneuten Abonnieren', 'Ihre Daten und Matches bleiben erhalten', 'Abonnieren Sie jederzeit erneut'],
      renewal_reminder: ['Keine Aktion erforderlich - Auto-Verlängerung ist aktiv', 'Zum Kündigen: Einstellungen > Abonnement', 'Zahlungsmethode in Einstellungen verwalten']
    }
  },
  ja: {
    proactiveAlerts: '重要なお知らせ',
    dismiss: '閉じる',
    dismissAll: 'すべて閉じる',
    loading: 'アラートを確認中...',
    noAlerts: '現在アラートはありません',
    learnMore: '詳細を見る',
    retryStatus: '再試行ステータス',
    nextRetry: '次の再試行',
    lastRetry: '前回の試行',
    retryAttempts: '試行回数',
    retryNow: '今すぐ再試行',
    cancelRetry: '再試行をキャンセル',
    retrying: '処理中...',
    scheduled: '予定',
    pending: '保留中',
    succeeded: '成功',
    failed: '失敗',
    cancelled: 'キャンセル済み',
    retryScheduled: '自動再試行が予定されています',
    noMoreRetries: '自動再試行の残りがありません',
    manualRetryRequired: '支払い方法を更新してください',
    resolutionSteps: {
      payment_expiring: ['設定 > 支払い方法に移動', '新しいカードを追加または既存のカードを更新', 'デフォルトの支払い方法として設定'],
      payment_failed: ['カードに十分な残高があるか確認', 'カード情報が正しいか確認', '問題が続く場合は銀行に連絡', '別の支払い方法を試す'],
      subscription_expiring: ['プレミアムページで再購読', 'データとマッチは保存されます', 'いつでも再購読してアクセスを復元'],
      renewal_reminder: ['自動更新がオンのため、操作は不要です', 'キャンセルするには設定 > サブスクリプション', '設定で支払い方法を管理']
    }
  },
  ko: {
    proactiveAlerts: '중요 알림',
    dismiss: '닫기',
    dismissAll: '모두 닫기',
    loading: '알림 확인 중...',
    noAlerts: '현재 알림이 없습니다',
    learnMore: '자세히 보기',
    retryStatus: '재시도 상태',
    nextRetry: '다음 재시도',
    lastRetry: '마지막 시도',
    retryAttempts: '시도 횟수',
    retryNow: '지금 재시도',
    cancelRetry: '재시도 취소',
    retrying: '처리 중...',
    scheduled: '예정됨',
    pending: '대기 중',
    succeeded: '성공',
    failed: '실패',
    cancelled: '취소됨',
    retryScheduled: '자동 재시도가 예정되어 있습니다',
    noMoreRetries: '자동 재시도가 남아있지 않습니다',
    manualRetryRequired: '결제 수단을 업데이트해 주세요',
    resolutionSteps: {
      payment_expiring: ['설정 > 결제 수단으로 이동', '새 카드 추가 또는 기존 카드 업데이트', '기본 결제 수단으로 설정'],
      payment_failed: ['카드에 충분한 잔액이 있는지 확인', '카드 정보가 올바른지 확인', '문제가 지속되면 은행에 문의', '다른 결제 수단 시도'],
      subscription_expiring: ['프리미엄 페이지에서 재구독', '데이터와 매치가 보존됩니다', '언제든지 재구독하여 액세스 복원'],
      renewal_reminder: ['자동 갱신이 켜져 있어 조치가 필요 없습니다', '취소하려면 설정 > 구독으로 이동', '설정에서 결제 수단 관리']
    }
  },
  zh: {
    proactiveAlerts: '重要通知',
    dismiss: '关闭',
    dismissAll: '全部关闭',
    loading: '正在检查提醒...',
    noAlerts: '目前没有提醒',
    learnMore: '了解更多',
    retryStatus: '重试状态',
    nextRetry: '下次重试',
    lastRetry: '上次尝试',
    retryAttempts: '尝试次数',
    retryNow: '立即重试',
    cancelRetry: '取消重试',
    retrying: '处理中...',
    scheduled: '已计划',
    pending: '待处理',
    succeeded: '成功',
    failed: '失败',
    cancelled: '已取消',
    retryScheduled: '自动重试已计划',
    noMoreRetries: '没有剩余的自动重试',
    manualRetryRequired: '请更新支付方式',
    resolutionSteps: {
      payment_expiring: ['前往设置 > 支付方式', '添加新卡或更新现有卡', '设为默认支付方式'],
      payment_failed: ['检查您的卡是否有足够余额', '验证卡信息是否正确', '如果问题持续，请联系银行', '尝试其他支付方式'],
      subscription_expiring: ['访问高级版页面重新订阅', '您的数据和匹配将被保留', '随时重新订阅以恢复访问'],
      renewal_reminder: ['自动续订已开启，无需操作', '要取消，请前往设置 > 订阅', '在设置中管理支付方式']
    }
  },
  th: {
    proactiveAlerts: 'ประกาศสำคัญ',
    dismiss: 'ปิด',
    dismissAll: 'ปิดทั้งหมด',
    loading: 'กำลังตรวจสอบการแจ้งเตือน...',
    noAlerts: 'ไม่มีการแจ้งเตือนในขณะนี้',
    learnMore: 'เรียนรู้เพิ่มเติม',
    retryStatus: 'สถานะการลองใหม่',
    nextRetry: 'ลองใหม่ครั้งถัดไป',
    lastRetry: 'ครั้งล่าสุดที่ลอง',
    retryAttempts: 'จำนวนครั้งที่ลอง',
    retryNow: 'ลองใหม่ตอนนี้',
    cancelRetry: 'ยกเลิกการลองใหม่',
    retrying: 'กำลังดำเนินการ...',
    scheduled: 'กำหนดไว้',
    pending: 'รอดำเนินการ',
    succeeded: 'สำเร็จ',
    failed: 'ล้มเหลว',
    cancelled: 'ยกเลิกแล้ว',
    retryScheduled: 'การลองใหม่อัตโนมัติถูกกำหนดไว้',
    noMoreRetries: 'ไม่มีการลองใหม่อัตโนมัติเหลือ',
    manualRetryRequired: 'กรุณาอัปเดตวิธีการชำระเงิน',
    resolutionSteps: {
      payment_expiring: ['ไปที่ การตั้งค่า > วิธีการชำระเงิน', 'เพิ่มบัตรใหม่หรืออัปเดตบัตรที่มีอยู่', 'ตั้งเป็นวิธีการชำระเงินเริ่มต้น'],
      payment_failed: ['ตรวจสอบว่าบัตรของคุณมียอดเงินเพียงพอ', 'ยืนยันว่าข้อมูลบัตรถูกต้อง', 'ติดต่อธนาคารหากปัญหายังคงอยู่', 'ลองใช้วิธีการชำระเงินอื่น'],
      subscription_expiring: ['เยี่ยมชมหน้าพรีเมียมเพื่อสมัครใหม่', 'ข้อมูลและการจับคู่ของคุณจะถูกเก็บรักษา', 'สมัครใหม่ได้ทุกเมื่อเพื่อกู้คืนการเข้าถึง'],
      renewal_reminder: ['ไม่ต้องดำเนินการ - การต่ออายุอัตโนมัติเปิดอยู่', 'หากต้องการยกเลิก ไปที่ การตั้งค่า > การสมัครสมาชิก', 'จัดการวิธีการชำระเงินในการตั้งค่า']
    }
  },
  vi: {
    proactiveAlerts: 'Thông báo quan trọng',
    dismiss: 'Đóng',
    dismissAll: 'Đóng tất cả',
    loading: 'Đang kiểm tra thông báo...',
    noAlerts: 'Không có thông báo nào lúc này',
    learnMore: 'Tìm hiểu thêm',
    retryStatus: 'Trạng thái thử lại',
    nextRetry: 'Lần thử lại tiếp theo',
    lastRetry: 'Lần thử cuối',
    retryAttempts: 'Số lần thử',
    retryNow: 'Thử lại ngay',
    cancelRetry: 'Hủy thử lại',
    retrying: 'Đang xử lý...',
    scheduled: 'Đã lên lịch',
    pending: 'Đang chờ',
    succeeded: 'Thành công',
    failed: 'Thất bại',
    cancelled: 'Đã hủy',
    retryScheduled: 'Đã lên lịch thử lại tự động',
    noMoreRetries: 'Không còn lần thử lại tự động',
    manualRetryRequired: 'Vui lòng cập nhật phương thức thanh toán',
    resolutionSteps: {
      payment_expiring: ['Đi tới Cài đặt > Phương thức thanh toán', 'Thêm thẻ mới hoặc cập nhật thẻ hiện có', 'Đặt làm phương thức thanh toán mặc định'],
      payment_failed: ['Kiểm tra thẻ của bạn có đủ số dư', 'Xác minh thông tin thẻ chính xác', 'Liên hệ ngân hàng nếu vấn đề vẫn tiếp tục', 'Thử phương thức thanh toán khác'],
      subscription_expiring: ['Truy cập trang Premium để đăng ký lại', 'Dữ liệu và kết nối của bạn được bảo toàn', 'Đăng ký lại bất cứ lúc nào để khôi phục quyền truy cập'],
      renewal_reminder: ['Không cần hành động - tự động gia hạn đang bật', 'Để hủy, đi tới Cài đặt > Đăng ký', 'Quản lý phương thức thanh toán trong Cài đặt']
    }
  },
  hi: {
    proactiveAlerts: 'महत्वपूर्ण सूचनाएं',
    dismiss: 'बंद करें',
    dismissAll: 'सभी बंद करें',
    loading: 'अलर्ट की जांच हो रही है...',
    noAlerts: 'इस समय कोई अलर्ट नहीं',
    learnMore: 'और जानें',
    retryStatus: 'पुनः प्रयास स्थिति',
    nextRetry: 'अगला पुनः प्रयास',
    lastRetry: 'अंतिम प्रयास',
    retryAttempts: 'प्रयास',
    retryNow: 'अभी पुनः प्रयास करें',
    cancelRetry: 'पुनः प्रयास रद्द करें',
    retrying: 'प्रोसेसिंग...',
    scheduled: 'निर्धारित',
    pending: 'लंबित',
    succeeded: 'सफल',
    failed: 'विफल',
    cancelled: 'रद्द',
    retryScheduled: 'स्वचालित पुनः प्रयास निर्धारित',
    noMoreRetries: 'कोई स्वचालित पुनः प्रयास शेष नहीं',
    manualRetryRequired: 'कृपया भुगतान विधि अपडेट करें',
    resolutionSteps: {
      payment_expiring: ['सेटिंग्स > भुगतान विधियां पर जाएं', 'नया कार्ड जोड़ें या मौजूदा अपडेट करें', 'डिफ़ॉल्ट भुगतान विधि के रूप में सेट करें'],
      payment_failed: ['जांचें कि आपके कार्ड में पर्याप्त बैलेंस है', 'कार्ड विवरण सही हैं यह सत्यापित करें', 'समस्या बनी रहे तो बैंक से संपर्क करें', 'अलग भुगतान विधि आज़माएं'],
      subscription_expiring: ['पुनः सदस्यता के लिए प्रीमियम पेज पर जाएं', 'आपका डेटा और मैच सुरक्षित हैं', 'एक्सेस बहाल करने के लिए कभी भी पुनः सदस्यता लें'],
      renewal_reminder: ['कोई कार्रवाई आवश्यक नहीं - ऑटो-नवीनीकरण चालू है', 'रद्द करने के लिए सेटिंग्स > सदस्यता पर जाएं', 'सेटिंग्स में भुगतान विधि प्रबंधित करें']
    }
  },
  id: {
    proactiveAlerts: 'Pemberitahuan Penting',
    dismiss: 'Tutup',
    dismissAll: 'Tutup Semua',
    loading: 'Memeriksa pemberitahuan...',
    noAlerts: 'Tidak ada pemberitahuan saat ini',
    learnMore: 'Pelajari lebih lanjut',
    retryStatus: 'Status Percobaan Ulang',
    nextRetry: 'Percobaan ulang berikutnya',
    lastRetry: 'Percobaan terakhir',
    retryAttempts: 'Percobaan',
    retryNow: 'Coba Ulang Sekarang',
    cancelRetry: 'Batalkan Percobaan Ulang',
    retrying: 'Memproses...',
    scheduled: 'Dijadwalkan',
    pending: 'Menunggu',
    succeeded: 'Berhasil',
    failed: 'Gagal',
    cancelled: 'Dibatalkan',
    retryScheduled: 'Percobaan ulang otomatis dijadwalkan',
    noMoreRetries: 'Tidak ada percobaan ulang otomatis tersisa',
    manualRetryRequired: 'Silakan perbarui metode pembayaran',
    resolutionSteps: {
      payment_expiring: ['Buka Pengaturan > Metode Pembayaran', 'Tambah kartu baru atau perbarui yang ada', 'Atur sebagai metode pembayaran default'],
      payment_failed: ['Periksa kartu Anda memiliki saldo cukup', 'Verifikasi detail kartu sudah benar', 'Hubungi bank jika masalah berlanjut', 'Coba metode pembayaran lain'],
      subscription_expiring: ['Kunjungi halaman Premium untuk berlangganan ulang', 'Data dan kecocokan Anda dipertahankan', 'Berlangganan ulang kapan saja untuk memulihkan akses'],
      renewal_reminder: ['Tidak perlu tindakan - perpanjangan otomatis aktif', 'Untuk membatalkan, buka Pengaturan > Langganan', 'Kelola metode pembayaran di Pengaturan']
    }
  },
  ms: {
    proactiveAlerts: 'Notis Penting',
    dismiss: 'Tutup',
    dismissAll: 'Tutup Semua',
    loading: 'Menyemak pemberitahuan...',
    noAlerts: 'Tiada pemberitahuan pada masa ini',
    learnMore: 'Ketahui lebih lanjut',
    retryStatus: 'Status Cuba Semula',
    nextRetry: 'Cuba semula seterusnya',
    lastRetry: 'Percubaan terakhir',
    retryAttempts: 'Percubaan',
    retryNow: 'Cuba Semula Sekarang',
    cancelRetry: 'Batalkan Cuba Semula',
    retrying: 'Memproses...',
    scheduled: 'Dijadualkan',
    pending: 'Menunggu',
    succeeded: 'Berjaya',
    failed: 'Gagal',
    cancelled: 'Dibatalkan',
    retryScheduled: 'Cuba semula automatik dijadualkan',
    noMoreRetries: 'Tiada cuba semula automatik yang tinggal',
    manualRetryRequired: 'Sila kemas kini kaedah pembayaran',
    resolutionSteps: {
      payment_expiring: ['Pergi ke Tetapan > Kaedah Pembayaran', 'Tambah kad baharu atau kemas kini yang sedia ada', 'Tetapkan sebagai kaedah pembayaran lalai'],
      payment_failed: ['Semak kad anda mempunyai baki yang mencukupi', 'Sahkan butiran kad adalah betul', 'Hubungi bank anda jika masalah berterusan', 'Cuba kaedah pembayaran lain'],
      subscription_expiring: ['Lawati halaman Premium untuk melanggan semula', 'Data dan padanan anda dipelihara', 'Langgan semula bila-bila masa untuk memulihkan akses'],
      renewal_reminder: ['Tiada tindakan diperlukan - pembaharuan automatik aktif', 'Untuk membatalkan, pergi ke Tetapan > Langganan', 'Urus kaedah pembayaran dalam Tetapan']
    }
  }
};


const ALERT_ICONS: Record<string, React.FC<{ className?: string }>> = {
  payment_expiring: CreditCard,
  renewal_reminder: Clock,
  payment_failed: XCircle,
  subscription_expiring: Crown,
  subscription_expired: Crown
};

const ALERT_COLORS: Record<string, { bg: string; border: string; icon: string; text: string }> = {
  critical: { bg: 'bg-red-500/10', border: 'border-red-500/30', icon: 'text-red-400', text: 'text-red-300' },
  high: { bg: 'bg-orange-500/10', border: 'border-orange-500/30', icon: 'text-orange-400', text: 'text-orange-300' },
  medium: { bg: 'bg-yellow-500/10', border: 'border-yellow-500/30', icon: 'text-yellow-400', text: 'text-yellow-300' },
  low: { bg: 'bg-blue-500/10', border: 'border-blue-500/30', icon: 'text-blue-400', text: 'text-blue-300' }
};

const STATUS_COLORS: Record<string, string> = {
  scheduled: 'text-blue-400',
  pending: 'text-yellow-400',
  retrying: 'text-orange-400',
  succeeded: 'text-green-400',
  failed: 'text-red-400',
  cancelled: 'text-gray-400'
};

interface ProactiveAlertsProps {
  onAction?: (actionType: string, triggerType: string) => void;
  variant?: 'banner' | 'card' | 'inline';
  maxAlerts?: number;
}

const ProactiveAlerts: React.FC<ProactiveAlertsProps> = ({ onAction, variant = 'card', maxAlerts = 3 }) => {
  const { user } = useAuth();
  const { language: appLanguage } = useI18n();
  
  const supportedLanguages: SupportedLanguage[] = ['en', 'es', 'fr', 'de', 'ja', 'ko', 'zh', 'th', 'vi', 'hi', 'id', 'ms'];
  const language: SupportedLanguage = supportedLanguages.includes(appLanguage as SupportedLanguage) ? appLanguage as SupportedLanguage : 'en';
  const text = UI_TEXT[language];

  
  const [triggers, setTriggers] = useState<ProactiveTrigger[]>([]);
  const [loading, setLoading] = useState(true);
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  const checkTriggers = async () => {
    if (!user) return;
    
    setLoading(true);
    let triggersWithRetry: ProactiveTrigger[] = [];
    
    try {
      // Try to fetch proactive triggers - gracefully handle failures
      try {
        const { data, error } = await supabase.functions.invoke('check-proactive-triggers', {
          body: { userId: user.id, language }
        });
        if (!error && data?.triggers) {
          triggersWithRetry = data.triggers;
        }
      } catch (triggerErr) {
        // Edge function not available - silently continue
        console.log('Proactive triggers check unavailable');
      }

      // Try to fetch retry status - gracefully handle failures
      try {
        const { data: retryData } = await supabase.functions.invoke('process-payment-retry', {
          body: { action: 'status', userId: user.id }
        });

        if (retryData?.success && retryData.retries?.length > 0) {
          triggersWithRetry = triggersWithRetry.map((trigger: ProactiveTrigger) => {
            if (trigger.type === 'payment_failed') {
              const matchingRetry = retryData.retries.find((r: RetryInfo) => r.status !== 'succeeded' && r.status !== 'cancelled');
              if (matchingRetry) return { ...trigger, retryInfo: matchingRetry };
            }
            return trigger;
          });
        }
      } catch (retryErr) {
        // Retry status fetch failed - silently continue
        console.log('Retry status fetch unavailable');
      }
    } catch (err) {
      console.log('Proactive alerts check failed');
    } finally {
      setTriggers(triggersWithRetry);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      checkTriggers();
    } else {
      setLoading(false);
    }
  }, [user, language]);

  const dismissAlert = async (triggerType: string) => {
    setDismissedIds(prev => new Set([...prev, triggerType]));
    if (user) {
      try {
        await supabase.from('proactive_alerts').update({ dismissed_at: new Date().toISOString() })
          .eq('user_id', user.id).eq('alert_type', triggerType).is('dismissed_at', null);
      } catch (err) { /* ignore */ }
    }
  };

  const dismissAll = () => {
    const allTypes = triggers.map(t => t.type);
    setDismissedIds(new Set(allTypes));
  };

  const handleRetryNow = async (retryId: string) => {
    setRetryingId(retryId);
    try {
      await supabase.functions.invoke('process-payment-retry', { body: { action: 'retry_now', retryId } });
      await checkTriggers();
    } catch (err) { /* ignore */ }
    setRetryingId(null);
  };

  const handleCancelRetry = async (retryId: string) => {
    setCancellingId(retryId);
    try {
      await supabase.functions.invoke('process-payment-retry', { body: { action: 'cancel', retryId } });
      await checkTriggers();
    } catch (err) { /* ignore */ }
    setCancellingId(null);
  };

  const handleAction = (trigger: ProactiveTrigger) => {
    if (onAction) {
      onAction(trigger.actionType, trigger.type);
    } else {
      switch (trigger.actionType) {
        case 'update_payment':
        case 'fix_payment':
          window.dispatchEvent(new CustomEvent('openSupportChat', { detail: { category: 'billing' } }));
          break;
        case 'manage_subscription':
        case 'resubscribe':
          window.location.href = '/premium';
          break;
        case 'view_retry':
          setExpandedId(trigger.type);
          break;
        default:
          window.dispatchEvent(new CustomEvent('openSupportChat', { detail: { category: 'billing' } }));
      }
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const locales: Record<SupportedLanguage, string> = {
      en: 'en-US', es: 'es-ES', fr: 'fr-FR', de: 'de-DE', ja: 'ja-JP',
      ko: 'ko-KR', zh: 'zh-CN', th: 'th-TH', vi: 'vi-VN', hi: 'hi-IN', id: 'id-ID', ms: 'ms-MY'
    };
    return date.toLocaleDateString(locales[language] || 'en-US', { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  const visibleTriggers = triggers.filter(t => !dismissedIds.has(t.type)).slice(0, maxAlerts);


  if (loading) {
    return variant === 'inline' ? null : (
      <div className="flex items-center gap-2 text-gray-400 text-sm p-4">
        <RefreshCw className="w-4 h-4 animate-spin" />
        <span>{text.loading}</span>
      </div>
    );
  }

  if (visibleTriggers.length === 0) return null;

  const RetryStatusCard = ({ retryInfo, colors }: { retryInfo: RetryInfo; colors: typeof ALERT_COLORS.critical }) => {
    const progress = (retryInfo.retry_count / retryInfo.max_retries) * 100;
    const hasMoreRetries = retryInfo.retry_count < retryInfo.max_retries;
    const isProcessing = retryingId === retryInfo.id || retryInfo.status === 'retrying';

    return (
      <div className={`mt-3 p-3 rounded-lg ${colors.bg} border ${colors.border}`}>
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-medium text-gray-300">{text.retryStatus}</span>
          <span className={`text-xs font-medium ${STATUS_COLORS[retryInfo.status] || 'text-gray-400'}`}>
            {(text as any)[retryInfo.status] || retryInfo.status}
          </span>
        </div>
        <div className="mb-3">
          <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
            <span>{text.retryAttempts}</span>
            <span>{retryInfo.retry_count} / {retryInfo.max_retries}</span>
          </div>
          <div className="h-2 bg-charcoal-700 rounded-full overflow-hidden">
            <div className={`h-full transition-all duration-500 ${retryInfo.retry_count >= retryInfo.max_retries ? 'bg-red-500' : 'bg-blue-500'}`} style={{ width: `${progress}%` }} />
          </div>
        </div>
        {retryInfo.next_retry_at && hasMoreRetries && (
          <div className="flex items-center gap-2 text-xs text-gray-400 mb-2">
            <Calendar className="w-3 h-3" />
            <span>{text.nextRetry}: {formatDate(retryInfo.next_retry_at)}</span>
          </div>
        )}
        <div className={`text-xs mb-3 ${hasMoreRetries ? 'text-blue-400' : 'text-red-400'}`}>
          {hasMoreRetries ? (
            <div className="flex items-center gap-1"><RotateCcw className="w-3 h-3" /><span>{text.retryScheduled}</span></div>
          ) : (
            <div className="flex items-center gap-1"><AlertTriangle className="w-3 h-3" /><span>{text.noMoreRetries}</span></div>
          )}
        </div>
        {hasMoreRetries && retryInfo.status !== 'retrying' && (
          <div className="flex gap-2">
            <button onClick={() => handleRetryNow(retryInfo.id)} disabled={isProcessing}
              className="flex-1 py-1.5 px-3 text-xs font-medium rounded-lg bg-gold text-charcoal hover:bg-gold-400 disabled:opacity-50 transition-colors flex items-center justify-center gap-1">
              {isProcessing ? <Loader2 className="w-3 h-3 animate-spin" /> : <RotateCcw className="w-3 h-3" />}
              {isProcessing ? text.retrying : text.retryNow}
            </button>
            <button onClick={() => handleCancelRetry(retryInfo.id)} disabled={cancellingId === retryInfo.id}
              className="py-1.5 px-3 text-xs font-medium rounded-lg bg-charcoal-600 text-gray-300 hover:bg-charcoal-500 disabled:opacity-50 transition-colors">
              <X className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>
    );
  };

  if (variant === 'banner') {
    const topTrigger = visibleTriggers[0];
    const colors = ALERT_COLORS[topTrigger.priority];
    const Icon = ALERT_ICONS[topTrigger.type] || AlertTriangle;

    return (
      <div className={`${colors.bg} border-b ${colors.border} px-4 py-3`}>
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <Icon className={`w-5 h-5 ${colors.icon} flex-shrink-0`} />
            <p className={`text-sm ${colors.text} truncate`}>{topTrigger.message[language] || topTrigger.message['en']}</p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <button onClick={() => handleAction(topTrigger)} className={`px-3 py-1.5 text-sm font-medium rounded-lg ${colors.bg} ${colors.text} border ${colors.border}`}>
              {topTrigger.actionLabel[language] || topTrigger.actionLabel['en']}
            </button>
            <button onClick={() => dismissAlert(topTrigger.type)} className="p-1.5 text-gray-400 hover:text-white"><X className="w-4 h-4" /></button>
          </div>
        </div>
      </div>
    );
  }

  if (variant === 'inline') {
    return (
      <div className="space-y-2">
        {visibleTriggers.map((trigger) => {
          const colors = ALERT_COLORS[trigger.priority];
          const Icon = ALERT_ICONS[trigger.type] || AlertTriangle;
          return (
            <div key={trigger.type} className={`flex items-center gap-2 p-2 rounded-lg ${colors.bg} border ${colors.border}`}>
              <Icon className={`w-4 h-4 ${colors.icon} flex-shrink-0`} />
              <p className={`text-xs ${colors.text} flex-1 truncate`}>{trigger.message[language] || trigger.message['en']}</p>
              <button onClick={() => handleAction(trigger)} className={`text-xs ${colors.text} hover:underline flex-shrink-0`}>
                {trigger.actionLabel[language] || trigger.actionLabel['en']}
              </button>
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-gold" />
          <h3 className="text-sm font-medium text-white">{text.proactiveAlerts}</h3>
          <span className="px-1.5 py-0.5 text-xs bg-gold/20 text-gold rounded-full">{visibleTriggers.length}</span>
        </div>
        {visibleTriggers.length > 1 && (
          <button onClick={dismissAll} className="text-xs text-gray-500 hover:text-gray-300">{text.dismissAll}</button>
        )}
      </div>
      <div className="space-y-2">
        {visibleTriggers.map((trigger) => {
          const colors = ALERT_COLORS[trigger.priority];
          const Icon = ALERT_ICONS[trigger.type] || AlertTriangle;
          const isExpanded = expandedId === trigger.type;
          const steps = text.resolutionSteps[trigger.type] || [];

          return (
            <div key={trigger.type} className={`rounded-xl border ${colors.border} ${colors.bg} overflow-hidden`}>
              <div className="p-4">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg ${colors.bg} border ${colors.border}`}>
                    <Icon className={`w-5 h-5 ${colors.icon}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm ${colors.text} leading-relaxed`}>{trigger.message[language] || trigger.message['en']}</p>
                    {trigger.retryInfo && (
                      <div className="mt-2 flex items-center gap-2">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ${trigger.retryInfo.status === 'scheduled' ? 'bg-blue-500/20 text-blue-400' : 'bg-gray-500/20 text-gray-400'}`}>
                          {trigger.retryInfo.status === 'retrying' ? <Loader2 className="w-3 h-3 animate-spin" /> : <Calendar className="w-3 h-3" />}
                          {(text as any)[trigger.retryInfo.status] || trigger.retryInfo.status}
                        </span>
                      </div>
                    )}
                    {(steps.length > 0 || trigger.retryInfo) && (
                      <button onClick={() => setExpandedId(isExpanded ? null : trigger.type)} className="mt-2 text-xs text-gray-500 hover:text-gray-300 flex items-center gap-1">
                        <ChevronRight className={`w-3 h-3 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                        {text.learnMore}
                      </button>
                    )}
                    {isExpanded && (
                      <>
                        {trigger.retryInfo && <RetryStatusCard retryInfo={trigger.retryInfo} colors={colors} />}
                        {steps.length > 0 && (
                          <ul className="mt-3 space-y-1.5 text-xs text-gray-400">
                            {steps.map((step, idx) => (
                              <li key={idx} className="flex items-start gap-2">
                                <span className="w-4 h-4 rounded-full bg-charcoal-600 flex items-center justify-center flex-shrink-0 text-[10px] text-gray-500">{idx + 1}</span>
                                {step}
                              </li>
                            ))}
                          </ul>
                        )}
                      </>
                    )}
                  </div>
                  <button onClick={() => dismissAlert(trigger.type)} className="p-1 text-gray-500 hover:text-white flex-shrink-0"><X className="w-4 h-4" /></button>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <button onClick={() => handleAction(trigger)} className={`flex-1 py-2 px-4 text-sm font-medium rounded-lg ${trigger.priority === 'critical' || trigger.priority === 'high' ? 'bg-gold text-charcoal hover:bg-gold-400' : `${colors.bg} ${colors.text} border ${colors.border}`} transition-colors flex items-center justify-center gap-2`}>
                    {trigger.actionLabel[language] || trigger.actionLabel['en']}
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ProactiveAlerts;
