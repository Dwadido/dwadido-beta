import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePremium } from '@/contexts/PremiumContext';
import { supabase } from '@/lib/supabase';
import { 
  User, Shield, Bell, Eye, Lock, Database, Camera,
  ChevronRight, Save, Loader2, Check, AlertTriangle, ShieldOff, UserX, CheckCircle,
  Smartphone, MessageSquare, Heart, BadgeCheck, Crown, Image, Calendar, Video, CheckCheck,
  HelpCircle, MessageCircle, Wrench, Mail, RotateCcw, WifiOff, Clock, Timer, Phone
} from 'lucide-react';

import GDPRSettings from './GDPRSettings';
import EmailPreferences from './EmailPreferences';

import PaymentRetryStatus from './PaymentRetryStatus';
import OfflineNotificationSettings from './OfflineNotificationSettings';
import MatchExpirationSettings from './MatchExpirationSettings';
import MatchReminderSettings from './MatchReminderSettings';
import CrushCodeExpirationSettings from '@/components/dashboard/CrushCodeExpirationSettings';
import PhoneNumberSetup from './PhoneNumberSetup';






import ProactiveAlerts from '../support/ProactiveAlerts';
import PremiumGate, { usePremiumGate } from '@/components/premium/PremiumGate';
import NotificationPreferencesPanel from '@/components/notifications/NotificationPreferencesPanel';
import {

  isPushSupported,
  getNotificationPermission,
  requestNotificationPermission,
  subscribeToPush,
  unsubscribeFromPush,
  saveNotificationPreferences,
  getNotificationPreferences,
  NotificationPreferences,
  defaultNotificationPreferences,
} from '@/lib/notifications';
import { useNavigate } from 'react-router-dom';









interface BlockedUser {
  id: string;
  blocked_user_id: string;
  created_at: string;
  blocked_profile?: {
    display_name: string | null;
    avatar_url: string | null;
  };
}

const SettingsPanel: React.FC = () => {
  const { user, profile, updateProfile, signOut, refreshProfile } = useAuth();
  const { isPremium, features, daysRemaining, canUseFeature } = usePremium();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('profile');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);



  // Blocked users
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([]);
  const [loadingBlocked, setLoadingBlocked] = useState(false);

  // Notification settings
  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences>(defaultNotificationPreferences);
  const [pushPermission, setPushPermission] = useState<NotificationPermission>('default');
  const [loadingNotifications, setLoadingNotifications] = useState(false);

  // Privacy settings
  const [showOnlineStatus, setShowOnlineStatus] = useState(true);
  const [showLastSeen, setShowLastSeen] = useState(false);
  const [allowScreenshots, setAllowScreenshots] = useState(false);
  const [readReceiptsEnabled, setReadReceiptsEnabled] = useState(false);

  useEffect(() => {
    if (activeSection === 'blocked' && user) {
      fetchBlockedUsers();
    }
    if (activeSection === 'notifications' && user) {
      loadNotificationSettings();
    }
  }, [activeSection, user]);

  useEffect(() => {
    // Load read receipts setting from profile
    if (profile) {
      setReadReceiptsEnabled((profile as any).read_receipts_enabled || false);
    }
  }, [profile]);

  const loadNotificationSettings = async () => {
    if (!user) return;
    setLoadingNotifications(true);
    
    setPushPermission(getNotificationPermission());
    const prefs = await getNotificationPreferences(user.id);
    setNotificationPrefs(prefs);
    
    setLoadingNotifications(false);
  };

  const handleEnablePush = async () => {
    if (!user) return;
    setLoadingNotifications(true);
    
    const permission = await requestNotificationPermission();
    setPushPermission(permission);
    
    if (permission === 'granted') {
      await subscribeToPush(user.id);
      setNotificationPrefs({ ...notificationPrefs, push_enabled: true });
      await saveNotificationPreferences(user.id, { ...notificationPrefs, push_enabled: true });
    }
    
    setLoadingNotifications(false);
  };

  const handleDisablePush = async () => {
    if (!user) return;
    setLoadingNotifications(true);
    
    await unsubscribeFromPush(user.id);
    setNotificationPrefs({ ...notificationPrefs, push_enabled: false });
    await saveNotificationPreferences(user.id, { ...notificationPrefs, push_enabled: false });
    
    setLoadingNotifications(false);
  };

  const handleNotificationPrefChange = async (key: keyof NotificationPreferences, value: boolean) => {
    if (!user) return;
    
    const newPrefs = { ...notificationPrefs, [key]: value };
    setNotificationPrefs(newPrefs);
    await saveNotificationPreferences(user.id, newPrefs);
  };

  const handleReadReceiptsChange = async (enabled: boolean) => {
    if (!canUseFeature('readReceiptControl')) {
      navigate('/premium');
      return;
    }
    
    setReadReceiptsEnabled(enabled);
    await updateProfile({ read_receipts_enabled: enabled } as any);
  };

  const fetchBlockedUsers = async () => {
    if (!user) return;
    setLoadingBlocked(true);
    
    const { data } = await supabase
      .from('user_blocks')
      .select('id, blocked_user_id, created_at')
      .eq('blocker_id', user.id);

    if (data) {
      const blockedWithProfiles = await Promise.all(
        data.map(async (block) => {
          const { data: profile } = await supabase
            .from('profiles')
            .select('display_name, avatar_url')
            .eq('id', block.blocked_user_id)
            .single();
          return { ...block, blocked_profile: profile || undefined };
        })
      );
      setBlockedUsers(blockedWithProfiles);
    }
    setLoadingBlocked(false);
  };

  const handleUnblock = async (blockedUserId: string) => {
    const { error } = await supabase.functions.invoke('block-user', {
      body: { blocked_user_id: blockedUserId, action: 'unblock' }
    });

    if (!error) {
      setBlockedUsers(blockedUsers.filter(b => b.blocked_user_id !== blockedUserId));
    }
  };

  const handleSave = async () => {
    setSaving(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const sections = [
    { id: 'profile', name: 'Profile', icon: User },
    { id: 'phone', name: 'Phone Number', icon: Phone },
    { id: 'premium', name: 'Premium', icon: Crown, highlight: !isPremium },
    { id: 'privacy', name: 'Privacy', icon: Eye },

    { id: 'notifications', name: 'Notifications', icon: Bell },
    { id: 'email', name: 'Email Alerts', icon: Mail },
    { id: 'connection-reminders', name: 'Connection Reminders', icon: Heart },
    { id: 'match-expiration', name: 'Expiration Alerts', icon: Clock },
    { id: 'code-expiration', name: 'Code Reminders', icon: Timer },
    { id: 'offline', name: 'Offline Alerts', icon: WifiOff },
    { id: 'payment-retry', name: 'Payment Retries', icon: RotateCcw },
    { id: 'security', name: 'Security', icon: Shield },
    { id: 'blocked', name: 'Blocked Users', icon: ShieldOff },
    { id: 'gdpr', name: 'Your Data', icon: Database },
    { id: 'help', name: 'Help & Support', icon: HelpCircle },
    { id: 'danger', name: 'Danger Zone', icon: AlertTriangle }
  ];















  const Toggle = ({ enabled, onChange, disabled }: { enabled: boolean; onChange: () => void; disabled?: boolean }) => (
    <button
      onClick={onChange}
      disabled={disabled}
      className={`w-11 h-6 rounded-full transition-all ${
        enabled ? 'bg-gold' : 'bg-charcoal-500'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      <div className={`w-5 h-5 bg-white rounded-full shadow transform transition-transform ${
        enabled ? 'translate-x-5' : 'translate-x-0.5'
      }`} />
    </button>
  );

  return (
    <div className="min-h-screen bg-charcoal py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-white mb-8">Settings</h1>

        <div className="grid md:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="md:col-span-1">
            <nav className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
              {sections.map((section) => (
                <button
                  key={section.id}
                  onClick={() => setActiveSection(section.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-all ${
                    activeSection === section.id
                      ? 'bg-gold/10 text-gold border-l-4 border-gold'
                      : section.id === 'danger' 
                        ? 'text-red-400 hover:bg-red-500/10'
                        : section.highlight
                          ? 'text-gold hover:bg-gold/10'
                          : 'text-gray-400 hover:bg-charcoal-600 hover:text-white'
                  }`}
                >
                  <section.icon className="w-5 h-5" />
                  <span className="font-medium">{section.name}</span>
                  {section.id === 'premium' && isPremium && (
                    <span className="ml-auto px-1.5 py-0.5 bg-gold/20 text-gold text-xs rounded">Active</span>
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* Content */}
          {/* Content */}
          <div className="md:col-span-3">
            {activeSection === 'gdpr' ? (
              <GDPRSettings />
            ) : (
              <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 p-6">


                {activeSection === 'profile' && (
                  <div className="space-y-6">
                    <h2 className="text-xl font-semibold text-white">Profile Settings</h2>
                    <p className="text-gray-400">Manage your public profile information</p>

                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Display Name
                        </label>
                        <input
                          type="text"
                          defaultValue={profile?.display_name || ''}
                          className="w-full px-4 py-3 bg-charcoal-600 border border-charcoal-500 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Email
                        </label>
                        <input
                          type="email"
                          defaultValue={profile?.email || ''}
                          disabled
                          className="w-full px-4 py-3 bg-charcoal-800 border border-charcoal-600 rounded-xl text-gray-500"
                        />
                        <p className="text-xs text-gray-500 mt-1">Contact support to change your email</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Phone Number Setup - FREE feature */}
                {activeSection === 'phone' && (
                  <PhoneNumberSetup />
                )}


                {activeSection === 'premium' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h2 className="text-xl font-semibold text-white flex items-center gap-2">
                          <Crown className="w-6 h-6 text-gold" />
                          Premium
                        </h2>
                        <p className="text-gray-400">More control. More clarity. More intent.</p>
                      </div>
                      {isPremium && (
                        <span className="px-3 py-1 bg-gold/20 text-gold font-medium rounded-full">
                          Active
                        </span>
                      )}
                    </div>

                    {isPremium ? (
                      <>
                        {/* Premium Status */}
                        <div className="p-4 bg-gold/10 border border-gold/30 rounded-xl">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gold/20 rounded-full flex items-center justify-center">
                              <Crown className="w-5 h-5 text-gold" />
                            </div>
                            <div>
                              <p className="font-medium text-gold">Premium Active</p>
                              <p className="text-sm text-gray-400">
                                {daysRemaining !== null && `${daysRemaining} days remaining`}
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* Premium Features */}
                        <div className="space-y-3">
                          <h3 className="text-sm font-medium text-gray-300">Your Premium Features</h3>
                          
                          <div className="grid gap-3">
                            <div className="flex items-center gap-3 p-3 bg-charcoal-600 rounded-xl">
                              <div className="w-8 h-8 bg-gold/20 rounded-lg flex items-center justify-center">
                                <Lock className="w-4 h-4 text-gold" />
                              </div>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-white">Multiple Active Codes</p>
                                <p className="text-xs text-gray-400">Up to {features.maxActiveCodes} codes at once</p>
                              </div>
                              <Check className="w-5 h-5 text-gold" />
                            </div>

                            <div className="flex items-center gap-3 p-3 bg-charcoal-600 rounded-xl">
                              <div className="w-8 h-8 bg-gold/20 rounded-lg flex items-center justify-center">
                                <Calendar className="w-4 h-4 text-gold" />
                              </div>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-white">Extended Code Validity</p>
                                <p className="text-xs text-gray-400">Up to {features.codeValidityHours} hours</p>
                              </div>
                              <Check className="w-5 h-5 text-gold" />
                            </div>

                            <div className="flex items-center gap-3 p-3 bg-charcoal-600 rounded-xl">
                              <div className="w-8 h-8 bg-gold/20 rounded-lg flex items-center justify-center">
                                <Video className="w-4 h-4 text-gold" />
                              </div>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-white">Video Speed-Date</p>
                                <p className="text-xs text-gray-400">Video calls with mutual consent</p>
                              </div>
                              <Check className="w-5 h-5 text-gold" />
                            </div>

                            <div className="flex items-center gap-3 p-3 bg-charcoal-600 rounded-xl">
                              <div className="w-8 h-8 bg-gold/20 rounded-lg flex items-center justify-center">
                                <CheckCheck className="w-4 h-4 text-gold" />
                              </div>
                              <div className="flex-1">
                                <p className="text-sm font-medium text-white">Read Receipt Control</p>
                                <p className="text-xs text-gray-400">Toggle read receipts on/off</p>
                              </div>
                              <Check className="w-5 h-5 text-gold" />
                            </div>
                          </div>
                        </div>


                        {/* Billing Support Link */}
                        <div className="p-4 bg-charcoal-600 rounded-xl">
                          <div className="flex items-start gap-3">
                            <div className="w-10 h-10 bg-gold/10 rounded-xl flex items-center justify-center flex-shrink-0">
                              <HelpCircle className="w-5 h-5 text-gold" />
                            </div>
                            <div className="flex-1">
                              <p className="font-medium text-white">Need billing help?</p>
                              <p className="text-sm text-gray-400 mb-3">
                                Get help with payments, cancellations, refunds, or receipts.
                              </p>
                              <button
                                onClick={() => window.dispatchEvent(new CustomEvent('openSupportChat', { detail: { category: 'billing' } }))}
                                className="inline-flex items-center gap-2 px-3 py-1.5 bg-charcoal-500 hover:bg-charcoal-400 text-white text-sm rounded-lg transition-colors"
                              >
                                <MessageCircle className="w-4 h-4" />
                                Chat with Billing Support
                              </button>
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={() => navigate('/premium')}
                          className="w-full py-3 text-gray-400 hover:text-white font-medium rounded-xl transition-colors border border-charcoal-500 hover:border-charcoal-400"
                        >
                          Manage Subscription
                        </button>

                      </>
                    ) : (
                      <>
                        {/* Upgrade prompt */}
                        <div className="p-6 bg-gradient-to-br from-gold/10 to-transparent border border-gold/20 rounded-xl text-center">
                          <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Crown className="w-8 h-8 text-gold" />
                          </div>
                          <h3 className="text-lg font-semibold text-white mb-2">Upgrade to Premium</h3>
                          <p className="text-gray-400 mb-4">
                            Get more control over your connections with advanced features.
                          </p>
                          <ul className="text-left space-y-2 mb-6">
                            <li className="flex items-center gap-2 text-sm text-gray-300">
                              <Check className="w-4 h-4 text-gold" />
                              Up to 3 active codes at once
                            </li>
                            <li className="flex items-center gap-2 text-sm text-gray-300">
                              <Check className="w-4 h-4 text-gold" />
                              Extended 72-hour code validity
                            </li>
                            <li className="flex items-center gap-2 text-sm text-gray-300">
                              <Check className="w-4 h-4 text-gold" />
                              Advanced intent filters
                            </li>
                            <li className="flex items-center gap-2 text-sm text-gray-300">
                              <Check className="w-4 h-4 text-gold" />
                              Video speed-date access
                            </li>
                            <li className="flex items-center gap-2 text-sm text-gray-300">
                              <Check className="w-4 h-4 text-gold" />
                              Read receipt control
                            </li>
                          </ul>
                          <button
                            onClick={() => navigate('/premium')}
                            className="w-full py-3 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all shadow-gold"
                          >
                            View Premium Plans
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                )}

                {activeSection === 'privacy' && (
                  <div className="space-y-6">
                    <h2 className="text-xl font-semibold text-white">Privacy Settings</h2>
                    <p className="text-gray-400">Control what others can see about you</p>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between py-3 border-b border-charcoal-600">
                        <div>
                          <p className="font-medium text-white">Show online status</p>
                          <p className="text-sm text-gray-400">Let matches see when you're online</p>
                        </div>
                        <Toggle enabled={showOnlineStatus} onChange={() => setShowOnlineStatus(!showOnlineStatus)} />
                      </div>

                      <div className="flex items-center justify-between py-3 border-b border-charcoal-600">
                        <div>
                          <p className="font-medium text-white">Show last seen</p>
                          <p className="text-sm text-gray-400">Display when you were last active</p>
                        </div>
                        <Toggle enabled={showLastSeen} onChange={() => setShowLastSeen(!showLastSeen)} />
                      </div>

                      <div className="flex items-center justify-between py-3 border-b border-charcoal-600">
                        <div>
                          <p className="font-medium text-white">Allow screenshots</p>
                          <p className="text-sm text-gray-400">Let others screenshot your profile</p>
                        </div>
                        <Toggle enabled={allowScreenshots} onChange={() => setAllowScreenshots(!allowScreenshots)} />
                      </div>

                      {/* Read Receipts - Premium Feature with PremiumGate */}
                      <PremiumGate feature="readReceiptControl" compactLock>
                        <div className="flex items-center justify-between py-3">
                          <div className="flex items-center gap-2">
                            <div>
                              <p className="font-medium text-white flex items-center gap-2">
                                Read receipts
                                {!canUseFeature('readReceiptControl') && (
                                  <span className="px-1.5 py-0.5 bg-gold/20 text-gold text-xs rounded">Premium</span>
                                )}
                              </p>
                              <p className="text-sm text-gray-400">Show when you've read messages</p>
                            </div>
                          </div>
                          <Toggle 
                            enabled={readReceiptsEnabled} 
                            onChange={() => handleReadReceiptsChange(!readReceiptsEnabled)}
                          />
                        </div>
                      </PremiumGate>
                    </div>
                  </div>
                )}



                {activeSection === 'notifications' && (
                  <NotificationPreferencesPanel />
                )}



                {activeSection === 'security' && (
                  <div className="space-y-6">
                    <h2 className="text-xl font-semibold text-white">Security Settings</h2>
                    <p className="text-gray-400">Keep your account secure</p>

                    <div className="space-y-4">
                      <button className="w-full flex items-center justify-between p-4 bg-charcoal-600 rounded-xl hover:bg-charcoal-500 transition-all">
                        <div className="flex items-center gap-3">
                          <Lock className="w-5 h-5 text-gray-400" />
                          <div className="text-left">
                            <p className="font-medium text-white">Change password</p>
                            <p className="text-sm text-gray-400">Update your password regularly</p>
                          </div>
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-500" />
                      </button>

                      <button className="w-full flex items-center justify-between p-4 bg-charcoal-600 rounded-xl hover:bg-charcoal-500 transition-all">
                        <div className="flex items-center gap-3">
                          <Shield className="w-5 h-5 text-gray-400" />
                          <div className="text-left">
                            <p className="font-medium text-white">Two-factor authentication</p>
                            <p className="text-sm text-gray-400">Add an extra layer of security</p>
                          </div>
                        </div>
                        <span className="px-2 py-1 bg-gold/20 text-gold text-xs font-medium rounded-full">Coming soon</span>
                      </button>
                    </div>
                  </div>
                )}

                {activeSection === 'blocked' && (
                  <div className="space-y-6">
                    <h2 className="text-xl font-semibold text-white">Blocked Users</h2>
                    <p className="text-gray-400">Manage users you've blocked</p>

                    {loadingBlocked ? (
                      <div className="flex items-center justify-center py-12">
                        <Loader2 className="w-8 h-8 text-gold animate-spin" />
                      </div>
                    ) : blockedUsers.length === 0 ? (
                      <div className="text-center py-12 bg-charcoal-600 rounded-xl">
                        <UserX className="w-12 h-12 text-gray-500 mx-auto mb-3" />
                        <p className="text-gray-400">You haven't blocked anyone</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {blockedUsers.map((block) => (
                          <div 
                            key={block.id}
                            className="flex items-center justify-between p-4 bg-charcoal-600 rounded-xl"
                          >
                            <div className="flex items-center gap-3">
                              {block.blocked_profile?.avatar_url ? (
                                <img 
                                  src={block.blocked_profile.avatar_url} 
                                  alt="" 
                                  className="w-10 h-10 rounded-full object-cover"
                                />
                              ) : (
                                <div className="w-10 h-10 rounded-full bg-charcoal-500 flex items-center justify-center">
                                  <User className="w-5 h-5 text-gray-400" />
                                </div>
                              )}
                              <div>
                                <p className="font-medium text-white">
                                  {block.blocked_profile?.display_name || 'Anonymous User'}
                                </p>
                                <p className="text-xs text-gray-500">
                                  Blocked {new Date(block.created_at).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                            <button
                              onClick={() => handleUnblock(block.blocked_user_id)}
                              className="px-4 py-2 text-sm font-medium text-gold hover:bg-gold/10 rounded-lg transition-all"
                            >
                              Unblock
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}



                {activeSection === 'danger' && (
                  <div className="space-y-6">
                    <h2 className="text-xl font-semibold text-red-400">Danger Zone</h2>
                    <p className="text-gray-400">Irreversible actions for your account</p>

                    <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl">
                      <div className="flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5" />
                        <div>
                          <p className="font-medium text-red-400">Delete Account</p>
                          <p className="text-sm text-gray-400 mt-1">
                            For GDPR-compliant account deletion with data export options, 
                            please use the "Your Data" section in the sidebar.
                          </p>
                          <button
                            onClick={() => setActiveSection('gdpr')}
                            className="mt-4 px-4 py-2 bg-red-500 text-white font-medium rounded-xl hover:bg-red-600 transition-all"
                          >
                            Go to Your Data
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeSection === 'help' && (
                  <div className="space-y-6">
                    <h2 className="text-xl font-semibold text-white">Help & Support</h2>
                    <p className="text-gray-400">Get help with any issues or questions</p>

                    {/* AI Support Chat */}
                    <div className="p-4 bg-gold/10 border border-gold/30 rounded-xl">
                      <div className="flex items-start gap-3">
                        <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center flex-shrink-0">
                          <MessageCircle className="w-5 h-5 text-gold" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-white">AI Support Assistant</p>
                          <p className="text-sm text-gray-400 mb-3">
                            Get instant help 24/7 from our AI assistant. It can help with account issues, 
                            billing questions, technical problems, and more.
                          </p>
                          <button
                            onClick={() => window.dispatchEvent(new CustomEvent('openSupportChat'))}
                            className="inline-flex items-center gap-2 px-4 py-2 bg-gold text-charcoal font-medium rounded-xl hover:bg-gold-400 transition-colors"
                          >
                            <MessageCircle className="w-4 h-4" />
                            Start Chat
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Support Categories */}
                    <div className="space-y-3">
                      <h3 className="text-sm font-medium text-gray-300">Quick Help Topics</h3>
                      
                      <button
                        onClick={() => window.dispatchEvent(new CustomEvent('openSupportChat', { detail: { category: 'technical' } }))}
                        className="w-full flex items-center gap-3 p-4 bg-charcoal-600 rounded-xl hover:bg-charcoal-500 transition-all text-left"
                      >
                        <div className="w-10 h-10 bg-purple-500/20 rounded-xl flex items-center justify-center">
                          <Wrench className="w-5 h-5 text-purple-400" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-white">Technical Support</p>
                          <p className="text-sm text-gray-400">App crashes, loading issues, permissions</p>
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-500" />
                      </button>

                      <button
                        onClick={() => window.dispatchEvent(new CustomEvent('openSupportChat', { detail: { category: 'billing' } }))}
                        className="w-full flex items-center gap-3 p-4 bg-charcoal-600 rounded-xl hover:bg-charcoal-500 transition-all text-left"
                      >
                        <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center">
                          <Crown className="w-5 h-5 text-gold" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-white">Billing & Premium</p>
                          <p className="text-sm text-gray-400">Subscriptions, payments, refunds</p>
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-500" />
                      </button>

                      <button
                        onClick={() => {
                          window.dispatchEvent(new CustomEvent('openSupportChat'));
                          setTimeout(() => {
                            const event = new CustomEvent('sendSupportMessage', { detail: { message: 'I need help with safety or privacy settings' } });
                            window.dispatchEvent(event);
                          }, 500);
                        }}
                        className="w-full flex items-center gap-3 p-4 bg-charcoal-600 rounded-xl hover:bg-charcoal-500 transition-all text-left"
                      >
                        <div className="w-10 h-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                          <Shield className="w-5 h-5 text-blue-400" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-white">Safety & Privacy</p>
                          <p className="text-sm text-gray-400">Blocking, reporting, data protection</p>
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-500" />
                      </button>

                      <button
                        onClick={() => {
                          window.dispatchEvent(new CustomEvent('openSupportChat'));
                          setTimeout(() => {
                            const event = new CustomEvent('sendSupportMessage', { detail: { message: 'I have a question about Crush Codes' } });
                            window.dispatchEvent(event);
                          }, 500);
                        }}
                        className="w-full flex items-center gap-3 p-4 bg-charcoal-600 rounded-xl hover:bg-charcoal-500 transition-all text-left"
                      >
                        <div className="w-10 h-10 bg-pink-500/20 rounded-xl flex items-center justify-center">
                          <Heart className="w-5 h-5 text-pink-400" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-white">Crush Codes & Matching</p>
                          <p className="text-sm text-gray-400">How codes work, matching, chat</p>
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-500" />
                      </button>
                    </div>

                    {/* AI Disclosure */}
                    <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
                      <div className="flex items-start gap-3">
                        <HelpCircle className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <p className="text-sm text-blue-300">
                            Our support is powered by AI and available 24/7. The AI assistant can handle most 
                            questions instantly. For complex issues that require human review, the AI will 
                            escalate your request to our team.
                          </p>
                        </div>
                      </div>

                    </div>
                  </div>
                )}

                {activeSection === 'email' && (
                  <EmailPreferences />
                )}

                {activeSection === 'payment-retry' && (
                  <PaymentRetryStatus />
                )}

                {activeSection === 'offline' && (
                  <OfflineNotificationSettings />
                )}

                {activeSection === 'match-expiration' && (
                  <MatchExpirationSettings />
                )}

                {activeSection === 'connection-reminders' && (
                  <MatchReminderSettings />
                )}

                {activeSection === 'code-expiration' && (
                  <CrushCodeExpirationSettings />
                )}


                {/* Save button */}
                {!['danger', 'blocked', 'gdpr', 'notifications', 'premium', 'ai', 'help', 'email', 'payment-retry', 'offline', 'match-expiration', 'code-expiration', 'phone', 'connection-reminders'].includes(activeSection) && (


                  <div className="mt-8 pt-6 border-t border-charcoal-600">
                    <button
                      onClick={handleSave}
                      disabled={saving}
                      className="px-6 py-3 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all disabled:opacity-50 flex items-center gap-2 shadow-gold"
                    >
                      {saving ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : saved ? (
                        <>
                          <Check className="w-5 h-5" />
                          Saved!
                        </>
                      ) : (
                        <>
                          <Save className="w-5 h-5" />
                          Save Changes
                        </>
                      )}
                    </button>
                  </div>
                )}

              </div>
            )}
          </div>

        </div>
      </div>


    </div>
  );
};

export default SettingsPanel;
