/**
 * Dwadido Design Guidelines
 * 
 * ============================================================================
 * GLOBAL DWADIDO RULE (PRIMARY PRINCIPLE)
 * ============================================================================
 * 
 * Any feature that increases pressure, anxiety, comparison, or compulsive 
 * checking must be redesigned or removed.
 * 
 * Dwadido exists to support clarity and real-world connection, 
 * not to maximise time spent in-app.
 * 
 * Before implementing ANY feature, ask:
 * 1. Does this create pressure to act quickly? → REDESIGN
 * 2. Does this create anxiety about missing out? → REDESIGN
 * 3. Does this encourage comparison with others? → REMOVE
 * 4. Does this encourage compulsive checking? → REMOVE
 * 5. Does this keep users in-app longer than necessary? → REDESIGN
 * 
 * If a feature passes these questions, it supports Dwadido's mission.
 * If it fails any question, it must be redesigned or removed.
 * 
 * ============================================================================
 * PROHIBITED PATTERNS (Never use these)
 * ============================================================================
 * 
 * 1. URGENCY LANGUAGE:
 *    - "Hurry!", "Act now!", "Don't miss out!"
 *    - "Time is running out!", "Last chance!"
 *    - "Expires very soon!", "Quick, before it's gone!"
 *    - Countdown timers with escalating colors (red/orange warnings)
 *    - "You haven't replied" guilt prompts
 * 
 * 2. SCARCITY TACTICS:
 *    - "Only X left!", "Limited time!"
 *    - "X people are viewing this now"
 *    - Artificial deadlines designed to pressure action
 * 
 * 3. GAMIFICATION:
 *    - Points, streaks, badges for engagement
 *    - "You have X new matches" counts designed to trigger checking
 *    - Leaderboards or competitive elements
 *    - Reward systems for app usage
 * 
 * 4. ANXIETY-INDUCING UI:
 *    - Flashing animations (animate-pulse on status indicators or alerts)
 *    - Red/orange warning colors for non-critical information
 *    - Countdown timers with escalating urgency
 *    - Push notifications designed to create FOMO
 * 
 * 5. COMPARISON FEATURES:
 *    - Profile views or "who viewed you"
 *    - Activity tracking visible to others
 *    - Match statistics or success rates
 *    - Popularity indicators
 * 
 * 6. COMPULSIVE CHECKING TRIGGERS:
 *    - Unread counts prominently displayed
 *    - "New" badges that persist
 *    - Notification sounds for non-urgent updates
 *    - Real-time typing indicators
 * 
 * ============================================================================
 * APPROVED PATTERNS (Use these instead)
 * ============================================================================
 * 
 * 1. CALM INFORMATION:
 *    - "This link is available until [date]"
 *    - "Renewal available when you're ready"
 *    - "Take your time - there's no pressure"
 *    - Neutral colors (purple, blue, gold) for time-sensitive info
 *    - Static indicators instead of pulsing/flashing ones
 * 
 * 2. SUPPORTIVE LANGUAGE:
 *    - "When you're ready..."
 *    - "If it feels right..."
 *    - "No rush - this will be here when you need it"
 *    - Context-based nudges that explain WHY, not just WHEN
 * 
 * 3. USER AUTONOMY:
 *    - Optional features (user-controlled)
 *    - Low-frequency options (weekly, monthly)
 *    - Easy dismiss/snooze without guilt
 *    - Clear explanation of what happens if they don't act
 * 
 * 4. CLARITY-FOCUSED:
 *    - Explain the purpose, not create pressure
 *    - Guide toward offline action
 *    - Respect user's pace and decisions
 *    - Never manipulate through fear of missing out
 * 
 * ============================================================================
 * COMPONENT-SPECIFIC GUIDELINES
 * ============================================================================
 * 
 * NOTIFICATIONS:
 * - Use calm gold dot indicator, not red badge with count
 * - Format time as "Recently" not "Just now!"
 * - No "You have X unread" gamification
 * - Subtle, non-intrusive visual treatment
 * 
 * MATCH REMINDERS:
 * - Optional and user-controlled
 * - Low frequency (weekly/biweekly/monthly)
 * - Supportive, not pushy
 * - Encourage offline action, not app engagement
 * 
 * STATUS INDICATORS:
 * - Use static dots, not animate-pulse
 * - Calm colors (green for active, gray for inactive)
 * - No flashing or attention-grabbing animations
 * 
 * MEETING SPOT PICKER:
 * - Acts as a gentle assistant, not a decision-maker
 * - Never auto-books or locks locations
 * - Suggestions only appear AFTER a match exists
 * - Both users must opt in before suggestions appear
 * - Suggest 2-4 neutral, low-pressure public places
 * - Prioritize simplicity (coffee, walk, casual venue)
 * - Use shared interests lightly (not as a ranking factor)
 * - Never push expensive or high-effort dates
 * - Tone: Supportive and optional, never directive
 * - Example: "Based on your shared interests and location, a relaxed coffee 
 *   or a short walk nearby could be an easy first meet."
 * 
 * MATCH INSIGHT DETAILS (REQUIRED FOR EVERY MATCH):
 * - Purpose: Explain why the match exists, build trust through transparency,
 *   help users feel confident acting offline
 * - Rules:
 *   • NO scores, percentages, or rankings
 *   • Plain-language explanations ONLY
 *   • MUST always show insight (never return null/empty)
 * - Focus areas (in priority order):
 *   1. Intent alignment (PRIMARY) - Why your relationship goals align
 *   2. Communication & interaction style (SECONDARY) - How conversations may feel
 *   3. One relevant lifestyle or interest note (OPTIONAL) - Shared ground for first meet
 * - Tone: Warm, transparent, confidence-building
 * - Example: "This match exists because your relationship intentions align, 
 *   and your communication styles suggest conversations may feel natural. 
 *   You also both enjoy live music, which could make an easy first meet."
 * - The explanation is MORE IMPORTANT than the match itself
 * - Never use vague language like "You're compatible" without explaining WHY

 * 
 * CONNECTION HISTORY VIEW:
 * - Purpose: Help users reflect on what felt right, not optimize behavior
 * - Tone: Private, calm, and non-judgmental
 * - ALLOWED:
 *   • Simple timeline of past connections
 *   • Optional notes written by the user
 *   • Clear distinction between: Met in person, Chatted only, Closed/expired
 * - NOT ALLOWED:
 *   • Performance stats
 *   • Match counts
 *   • Response rate metrics
 *   • AI judgments or summaries
 * - Notes are private and only visible to the user who wrote them
 * - No gamification or optimization metrics
 * - Example intro: "This is your private space to look back on past connections.
 *   Add notes to remember what felt meaningful. There's no judgment here—just reflection."
 * 
 * TIME-LIMITED FEATURES:
 * - Show time remaining in calm, informational way
 * - No color escalation (red/orange/yellow warnings)
 * - No "Hurry!" or "Act fast!" language
 * - Explain what happens when time expires (calmly)
 * 
 * VERIFICATION/EXPIRATION:
 * - "Renewal available" not "Expiring soon!"
 * - Explain benefits of renewal, not consequences of expiration
 * - No countdown pressure
 * - User decides when to renew
 */




// Time formatting that avoids urgency
export const formatTimeCalm = (date: Date): string => {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  // Calm time formatting - no urgency
  if (diffMins < 5) return 'Recently';
  if (diffMins < 60) return `${diffMins} minutes ago`;
  if (diffHours < 24) return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
  if (diffDays < 7) return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
  
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric'
  });
};

// Format remaining time without urgency
export const formatRemainingTimeCalm = (
  hours: number, 
  minutes: number, 
  seconds: number
): string => {
  if (hours > 0) {
    return `${hours}h ${minutes}m remaining`;
  }
  if (minutes > 0) {
    return `${minutes}m ${seconds}s remaining`;
  }
  return `${seconds}s remaining`;
};

// Get calm status for time-sensitive features
export const getTimeStatus = (remainingMs: number): 'available' | 'expiring' | 'expired' => {
  if (remainingMs <= 0) return 'expired';
  // No "critical" or "warning" states - just "available" or "expiring"
  return 'available';
};

// Calm color scheme for time-sensitive UI (no red/orange urgency colors)
export const calmTimeColors = {
  available: {
    bg: 'bg-purple-500/20',
    border: 'border-purple-500/50',
    text: 'text-purple-400',
    icon: 'text-purple-400'
  },
  expiring: {
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/30',
    text: 'text-amber-400',
    icon: 'text-amber-400'
  },
  expired: {
    bg: 'bg-gray-500/20',
    border: 'border-gray-500/50',
    text: 'text-gray-400',
    icon: 'text-gray-400'
  }
};

// Approved notification messages
export const calmMessages = {
  timeLimited: {
    title: 'Time-Limited Link',
    subtitle: 'This link will be available until the time shown',
    expired: 'This link is no longer available',
    expiredSubtitle: 'You can request a new link if needed'
  },
  verification: {
    renewalAvailable: 'Renewal Available',
    renewalSubtitle: 'Renew your verification when you\'re ready',
    expired: 'Verification Expired',
    expiredSubtitle: 'Renew to restore your verified status'
  },
  match: {
    newConnection: 'New Connection',
    reminder: 'You have a connection waiting when you\'re ready',
    noRush: 'Take your time. There\'s no pressure to respond.'
  }
};

// Validate that a message doesn't contain prohibited patterns
export const validateCalmMessage = (message: string): boolean => {
  const prohibitedPatterns = [
    /hurry/i,
    /act now/i,
    /don't miss/i,
    /time is running out/i,
    /last chance/i,
    /expires? (very )?soon/i,
    /quick(ly)?[,!]/i,
    /before it's gone/i,
    /only \d+ left/i,
    /limited time/i,
    /you haven't replied/i,
  ];

  return !prohibitedPatterns.some(pattern => pattern.test(message));
};

/**
 * Audit a feature against the Global Dwadido Rule
 * Returns issues found and recommendations
 */
export interface FeatureAuditResult {
  passes: boolean;
  issues: string[];
  recommendations: string[];
}

export const auditFeature = (featureDescription: {
  name: string;
  hasUrgencyLanguage?: boolean;
  hasCountdownTimer?: boolean;
  hasFlashingAnimation?: boolean;
  hasComparisonMetrics?: boolean;
  hasUnreadCounts?: boolean;
  hasGamification?: boolean;
  encouragesCompulsiveChecking?: boolean;
  keepsUsersInApp?: boolean;
}): FeatureAuditResult => {
  const issues: string[] = [];
  const recommendations: string[] = [];

  if (featureDescription.hasUrgencyLanguage) {
    issues.push('Uses urgency language that creates pressure');
    recommendations.push('Replace with calm, informational language');
  }

  if (featureDescription.hasCountdownTimer) {
    issues.push('Countdown timer may create anxiety');
    recommendations.push('Show time remaining as calm text without escalating colors');
  }

  if (featureDescription.hasFlashingAnimation) {
    issues.push('Flashing animations (animate-pulse) create anxiety');
    recommendations.push('Use static indicators instead');
  }

  if (featureDescription.hasComparisonMetrics) {
    issues.push('Comparison metrics encourage unhealthy behavior');
    recommendations.push('Remove all comparison features');
  }

  if (featureDescription.hasUnreadCounts) {
    issues.push('Unread counts trigger compulsive checking');
    recommendations.push('Use subtle dot indicator instead of counts');
  }

  if (featureDescription.hasGamification) {
    issues.push('Gamification elements (streaks, badges, points) are prohibited');
    recommendations.push('Remove all gamification');
  }

  if (featureDescription.encouragesCompulsiveChecking) {
    issues.push('Feature encourages compulsive checking');
    recommendations.push('Redesign to reduce checking frequency');
  }

  if (featureDescription.keepsUsersInApp) {
    issues.push('Feature keeps users in-app longer than necessary');
    recommendations.push('Guide users toward offline action instead');
  }

  return {
    passes: issues.length === 0,
    issues,
    recommendations
  };
};

/**
 * Check if CSS classes contain prohibited patterns
 */
export const auditCSSClasses = (classes: string): string[] => {
  const issues: string[] = [];
  
  // Check for animate-pulse on non-loading elements
  if (classes.includes('animate-pulse') && !classes.includes('loading')) {
    issues.push('animate-pulse should only be used for loading states, not status indicators');
  }
  
  // Check for red/orange urgency colors
  if ((classes.includes('text-red-') || classes.includes('bg-red-')) && 
      !classes.includes('error') && !classes.includes('danger')) {
    issues.push('Red colors should only be used for actual errors, not urgency');
  }
  
  // Check for orange warning colors
  if ((classes.includes('text-orange-') || classes.includes('bg-orange-')) && 
      !classes.includes('warning')) {
    issues.push('Orange colors should only be used for warnings, not time pressure');
  }

  return issues;
};

export default {
  formatTimeCalm,
  formatRemainingTimeCalm,
  getTimeStatus,
  calmTimeColors,
  calmMessages,
  validateCalmMessage,
  auditFeature,
  auditCSSClasses
};
