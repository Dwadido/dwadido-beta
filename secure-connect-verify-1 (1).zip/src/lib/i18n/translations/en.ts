// English translations - Default language for Dwadido
// This file serves as the template for all other language files

export const en = {
  // Common
  common: {
    loading: 'Loading...',
    save: 'Save',
    saving: 'Saving...',
    cancel: 'Cancel',
    confirm: 'Confirm',
    delete: 'Delete',
    edit: 'Edit',
    back: 'Back',
    next: 'Next',
    done: 'Done',
    close: 'Close',
    search: 'Search',
    filter: 'Filter',
    clear: 'Clear',
    apply: 'Apply',
    yes: 'Yes',
    no: 'No',
    or: 'or',
    and: 'and',
    optional: 'Optional',
    required: 'Required',
    success: 'Success',
    error: 'Error',
    warning: 'Warning',
    info: 'Info',
  },

  // Onboarding
  onboarding: {
    genderTitle: 'Who would you like to meet?',
    genderDescription: 'Help us personalize your experience by telling us who you\'d like to see in your matches.',
    welcomeMessage: 'Welcome to Dwadido!',
    welcomeSubtext: 'This helps us show you the most relevant connections. You can change this anytime in your profile settings.',
    continue: 'Continue',
    privacyNote: 'Your preference is private and only used to filter your matches.',
  },

  // Navigation
  nav: {
    home: 'Home',
    dashboard: 'Dashboard',
    map: 'Map',
    matches: 'Matches',
    messages: 'Messages',
    settings: 'Settings',
    profile: 'Profile',
    signIn: 'Sign In',
    signUp: 'Sign Up',
    signOut: 'Sign Out',
    myCard: 'My Card',
    crushCode: 'Crush Code',
  },


  // Landing Page
  landing: {
    hero: {
      title: 'Dating That Starts in Real Life',
      subtitle: 'Exchange codes with people you meet. If they enter yours too, it\'s a match. Simple, private, and real.',
      cta: 'Get Started',
      secondaryCta: 'Learn More',
    },
    features: {
      title: 'Why Dwadido?',
      subtitle: 'A dating app that respects your privacy and encourages real connections',
      privacy: {
        title: 'Privacy First',
        description: 'No photos, no profiles visible to strangers. Your information stays private until you match.',
      },
      realConnections: {
        title: 'Real Connections',
        description: 'Meet someone in real life first, then connect digitally. No endless swiping.',
      },
      mutualInterest: {
        title: 'Mutual Interest',
        description: 'Both people must enter each other\'s code to match. No unwanted messages.',
      },
      safe: {
        title: 'Safe & Secure',
        description: 'Verified users, reporting tools, and safety features built in.',
      },
    },
    howItWorks: {
      title: 'How It Works',
      subtitle: 'Three simple steps to meaningful connections',
      step1: {
        title: 'Get Your Code',
        description: 'Sign up and receive your unique crush code to share.',
      },
      step2: {
        title: 'Meet & Exchange',
        description: 'Meet someone interesting and exchange codes with them.',
      },
      step3: {
        title: 'Match & Connect',
        description: 'If you both enter each other\'s codes, you\'re matched!',
      },
    },
    stats: {
      users: 'Active Users',
      matches: 'Successful Matches',
      countries: 'Countries',
      satisfaction: 'Satisfaction Rate',
    },
    testimonials: {
      title: 'Love Stories',
      subtitle: 'Real people, real connections',
    },
    cta: {
      title: 'Ready to Find Real Connection?',
      subtitle: 'Join thousands of people who are tired of superficial dating apps.',
      button: 'Start Your Journey',
    },
    faq: {
      title: 'Frequently Asked Questions',
      subtitle: 'Everything you need to know about Dwadido',
    },
  },

  // Dashboard
  dashboard: {
    welcome: 'Welcome back',
    noMatches: 'No matches yet',
    noMatchesDesc: 'Exchange crush codes with people you meet to start matching!',
    yourCode: 'Your Crush Code',
    shareCode: 'Share this code with someone you\'re interested in',
    enterCode: 'Enter a Code',
    enterCodePlaceholder: 'Enter their crush code',
    redeemCode: 'Redeem Code',
    matches: 'Your Matches',
    recentActivity: 'Recent Activity',
    pendingMatches: 'Pending',
    confirmedMatches: 'Confirmed',
    viewAll: 'View All',
  },

  // QR Code
  qr: {
    scanQrCode: 'Scan QR Code',
    showQrCode: 'Show QR Code',
    scanToConnect: 'Scan to connect',
    pointCamera: 'Point your camera at a Dwadido QR code',
    positionCode: 'Position the code within the frame',
    scannerNotSupported: 'QR scanning is not supported in this browser',
    enterManually: 'Enter Code Manually',
    scannableQrCode: 'Scannable QR Code',
    othersCanScan: 'Others can scan this QR code to enter your Crush Code instantly',

    copyQrCode: 'Copy QR Code',
    downloadQrCode: 'Download QR Code',
    qrCopied: 'QR code copied to clipboard',
    switchCamera: 'Switch Camera',
    toggleFlash: 'Toggle Flashlight',
    cameraError: 'Camera Error',
    cameraPermissionDenied: 'Camera permission denied. Please allow camera access to scan QR codes.',
    noCameraFound: 'No camera found on this device.',
    tryAgain: 'Try Again',
  },





  // Profile
  profile: {
    title: 'Your Profile',
    displayName: 'Display Name',
    displayNamePlaceholder: 'How should matches see you?',
    bio: 'About Me',
    bioPlaceholder: 'Tell your matches a bit about yourself...',
    age: 'Age',
    ageNotSpecified: 'Age not specified',
    gender: 'Gender',
    dateOfBirth: 'Date of Birth',
    dateOfBirthDescription: 'Your age will be shown on your profile. You must be 18 or older.',
    yourAge: 'Your Age',
    ageWillBeDisplayed: 'This will be displayed on your profile',
    ageSaved: 'Age saved successfully',
    mustBe18: 'You must be at least 18 years old to use this service',
    invalidDate: 'Please enter a valid date',

    genderOptions: {
      male: 'Male',
      female: 'Female',
      prefer_not_to_say: 'Prefer not to say',
      other: 'Other (not specified)',
    },
    showMe: 'Show Me',
    showMeDescription: 'Choose who you want to see in your matches',
    showMeOptions: {
      women: 'Women',
      men: 'Men',
      everyone: 'Everyone',
    },
    interestedIn: 'Interested In',
    lookingFor: 'Looking For',
    location: 'Location',
    country: 'Country',
    city: 'City',
    selectCountry: 'Select your country',
    selectCity: 'Select your city',
    timezone: 'Timezone',
    language: 'Preferred Language',
    visibility: 'Map Visibility',
    visibilityDesc: 'Allow others to see your approximate location on the map',
    verified: 'Verified',
    notVerified: 'Not Verified',
    getVerified: 'Get Verified',
    saveProfile: 'Save Profile',
    profileSaved: 'Profile saved successfully',
    interests: {
      women: 'Women',
      men: 'Men',
      everyone: 'Everyone',
      undisclosed: 'Prefer not to say',
    },
    lookingForOptions: {
      relationship: 'Relationship',
      casual: 'Casual Dating',
      friends: 'Friends',
      unsure: 'Not Sure Yet',
    },
  },





  // Match Filters
  filters: {
    title: 'Match Preferences',
    subtitle: 'Set your preferences to find compatible connections',
    genderPreference: 'Gender Preference',
    genderPreferenceDesc: 'Who would you like to see in your matches?',
    genderOptions: {
      women: 'Women',
      men: 'Men',
      everyone: 'Everyone',
    },
    ageRange: 'Age Range',
    ageRangeDesc: 'Set your preferred age range for matches',
    enableAgeFilter: 'Filter by age',
    anyAge: 'Any Age',
    quickSelect: 'Quick select',
    relationshipType: 'Relationship Type',
    relationshipTypeDesc: 'What kind of connection are you looking for?',
    distanceRange: 'Distance Range',
    distanceRangeDesc: 'How far are you willing to connect?',
    meetingPreference: 'Meeting Preference',
    meetingPreferenceDesc: 'How do you prefer to meet initially?',
    applyFilters: 'Apply Filters',
    resetFilters: 'Reset',
    filtersApplied: 'Filters applied',
    noPreference: 'No preference',
    relationshipTypes: {
      casual: 'Casual Dating',
      serious: 'Serious Relationship',
      friendship: 'Friendship First',
      open: 'Open to Anything',
    },
    distanceRanges: {
      nearby: 'Nearby (< 10 km)',
      local: 'Local (< 50 km)',
      regional: 'Regional (< 200 km)',
      anywhere: 'Anywhere',
    },
    meetingPreferences: {
      video_first: 'Video Call First',
      coffee_date: 'Coffee Date',
      activity_based: 'Activity Together',
    },
    // V1 REMOVED: Compatibility scoring labels - no scores, percentages, or rankings allowed
    // compatibilityHigh, compatibilityMedium, compatibilityLow, showCompatible removed
  },



  // Map
  map: {
    title: 'Privacy Map',
    subtitle: 'See who\'s nearby without revealing identities',
    showOnMap: 'Show me on map',
    hideFromMap: 'Hide from map',
    legend: 'Legend',
    interestedInWomen: 'Interested in women',
    interestedInMen: 'Interested in men',
    interestedInEveryone: 'Interested in everyone',
    undisclosed: 'Undisclosed',
    activeNow: 'Active now',
    recentlyActive: 'Recently active',
    olderActivity: 'Older activity',
    privacyNote: 'All locations are approximate. No personal information is shared.',
    noLocation: 'Location not set',
    setLocation: 'Set your location in profile settings to appear on the map.',
  },


  // Chat & Messaging
  chat: {
    title: 'Messages',
    typeMessage: 'Type a message...',
    send: 'Send',
    noMessages: 'No messages yet',
    startConversation: 'Start the conversation!',
    suggestMeeting: 'Suggest Meeting',
    meetingSuggestion: 'Meeting Suggestion',

    selectCountry: 'Select Country',
    selectCity: 'Select City',
    selectCategory: 'Select Category',

    proposedMeeting: 'has proposed a meeting',
    accept: 'Accept',
    decline: 'Decline',
    reschedule: 'Reschedule',
    viewOnMap: 'View on Map',
    videoCall: 'Video Call',
    startVideoCall: 'Start Video Call',
    endCall: 'End Call',
    categories: {
      cafe: 'Café',
      restaurant: 'Restaurant',
      bar: 'Bar',
      walk: 'Walk / Park',
    },
  },

  // Settings
  settings: {
    title: 'Settings',
    account: 'Account',
    privacy: 'Privacy & Safety',
    notifications: 'Notifications',
    language: 'Language & Region',
    appearance: 'Appearance',
    help: 'Help & Support',
    about: 'About',
    deleteAccount: 'Delete Account',
    deleteAccountWarning: 'This action cannot be undone. All your data will be permanently deleted.',
    exportData: 'Export My Data',
    exportDataDesc: 'Download a copy of all your data',
    blockedUsers: 'Blocked Users',
    reportUser: 'Report User',
    gdpr: {
      title: 'Data & Privacy (GDPR)',
      description: 'Manage your data and privacy settings',
      dataRetention: 'Data Retention',
      dataRetentionDesc: 'How long we keep your data',
      marketingConsent: 'Marketing Communications',
      marketingConsentDesc: 'Receive updates about new features and tips',
      analyticsConsent: 'Analytics',
      analyticsConsentDesc: 'Help us improve by sharing anonymous usage data',
    },
  },


  // Photo Privacy
  photos: {
    blurredPreview: 'Blurred Preview',
    requestToSee: 'Request to see photos',
    photosPrivate: 'Photos are private',
    photosMatchesOnly: 'Photos visible to matches',
    photosApprovalRequired: 'Photos require approval',
    requestSent: 'Photo request sent',
    requestPending: 'Request pending',
    requestApproved: 'Request approved',
    requestDeclined: 'Request declined',
    tapToRequest: 'Tap to request access',
    photoRequests: 'Photo Requests',
    noRequests: 'No pending requests',
    approveRequest: 'Approve',
    declineRequest: 'Decline',
    addMessage: 'Add a message (optional)',
    messagePlaceholder: "Hi! I'd love to see your photos...",
  },

  // Verification
  verification: {
    title: 'Verify Your Identity',
    subtitle: 'Get verified to build trust with your matches',
    ageVerification: 'Age Verification',
    ageVerificationDesc: 'Confirm you are 18 or older',
    photoVerification: 'Photo Verification',
    photoVerificationDesc: 'Take a selfie to verify your identity',
    takeSelfie: 'Take Selfie',
    retake: 'Retake',
    submit: 'Submit for Verification',
    pending: 'Verification Pending',
    approved: 'Verified',
    rejected: 'Verification Rejected',
    tryAgain: 'Try Again',
  },

  // Safety
  safety: {
    reportUser: 'Report User',
    reportReason: 'Reason for Report',
    reportReasons: {
      harassment: 'Harassment or bullying',
      spam: 'Spam or fake profile',
      inappropriate: 'Inappropriate content',
      underage: 'User appears underage',
      other: 'Other',
    },
    additionalDetails: 'Additional Details',
    blockUser: 'Block User',
    blockUserDesc: 'This user will no longer be able to contact you',
    unblockUser: 'Unblock User',
    reportSubmitted: 'Report submitted. Thank you for helping keep Dwadido safe.',
    userBlocked: 'User has been blocked',
  },

  // Errors
  errors: {
    generic: 'Something went wrong. Please try again.',
    network: 'Network error. Please check your connection.',
    unauthorized: 'Please sign in to continue.',
    notFound: 'Not found.',
    invalidCode: 'Invalid crush code. Please check and try again.',
    alreadyRedeemed: 'You\'ve already entered this code.',
    ownCode: 'You can\'t enter your own code!',
    codeExpired: 'This code has expired.',
  },

  // Success messages
  success: {
    codeSent: 'Code sent successfully!',
    codeRedeemed: 'Code redeemed! Waiting for them to enter yours.',
    itsAMatch: 'It\'s a Match! You can now chat.',
    profileUpdated: 'Profile updated successfully.',
    settingsSaved: 'Settings saved.',
    messageSent: 'Message sent.',
  },

  // Time
  time: {
    justNow: 'Just now',
    minutesAgo: '{count} minutes ago',
    hoursAgo: '{count} hours ago',
    daysAgo: '{count} days ago',
    weeksAgo: '{count} weeks ago',
  },

  // Footer
  footer: {
    about: 'About',
    privacy: 'Privacy Policy',
    terms: 'Terms of Service',
    contact: 'Contact',
    help: 'Help Center',
    safety: 'Safety Tips',
    copyright: '© {year} Dwadido. All rights reserved.',
    tagline: 'Dating that starts in real life.',
  },
};

export type TranslationKeys = typeof en;
