import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePremium } from '@/contexts/PremiumContext';
import { useI18n } from '@/contexts/I18nContext';
import { useNavigate, useLocation } from 'react-router-dom';
import { Menu, X, User, Settings, LogOut, ChevronDown, LayoutDashboard, Edit, Shield, MapPin, Globe, Crown, Bell } from 'lucide-react';


import NotificationBell from '../notifications/NotificationBell';

interface HeaderProps {
  onSignIn: () => void;
  onSignUp: () => void;
  transparent?: boolean;
  onEditProfile?: () => void;
}




// Dwadido Logo - Heart with gold checkmark
const DwadidoLogo = ({ className = "w-8 h-8" }: { className?: string }) => (
  <svg className={className} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Heart shape */}
    <path 
      d="M20 35L17.09 32.3C8.14 24.2 2 18.55 2 11.5C2 5.85 6.42 1.5 12 1.5C15.09 1.5 18.09 2.97 20 5.27C21.91 2.97 24.91 1.5 28 1.5C33.58 1.5 38 5.85 38 11.5C38 18.55 31.86 24.2 22.91 32.3L20 35Z" 
      fill="#1C1C1C"
      stroke="#C9A24D"
      strokeWidth="2"
    />
    {/* Gold checkmark */}
    <path 
      d="M14 19L18 23L26 15" 
      stroke="#C9A24D" 
      strokeWidth="3" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    />
  </svg>
);

const Header: React.FC<HeaderProps> = ({ onSignIn, onSignUp, transparent = false, onEditProfile }) => {
  const { user, profile, signOut } = useAuth();
  const { isPremium } = usePremium();
  const { t, language, setLanguage, supportedLanguages, activeLanguages } = useI18n();
  const navigate = useNavigate();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [langMenuOpen, setLangMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSignOut = async () => {
    await signOut();
    setUserMenuOpen(false);
    navigate('/');
  };

  const isLandingPage = location.pathname === '/';
  const headerBg = transparent && !scrolled && isLandingPage
    ? 'bg-transparent'
    : 'bg-charcoal/95 backdrop-blur-md border-b border-charcoal-600';

  const textColor = 'text-white';
  const linkColor = 'text-gray-400 hover:text-gold transition-colors';
  const activeLinkColor = 'text-gold';




  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${headerBg}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <a href="/" className="flex items-center gap-3" onClick={(e) => { e.preventDefault(); navigate('/'); }}>
            <DwadidoLogo className="w-10 h-10" />
            <span className={`text-xl font-semibold tracking-wide ${textColor}`}>Dwadido</span>
          </a>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-8">
            {isLandingPage ? (
              <>
                <a href="#features" className={`text-sm font-medium ${linkColor}`}>
                  {t('landing.features.title')}
                </a>
                <a href="#how-it-works" className={`text-sm font-medium ${linkColor}`}>
                  {t('landing.howItWorks.title')}
                </a>
                <a href="#faq" className={`text-sm font-medium ${linkColor}`}>
                  {t('landing.faq.title')}
                </a>
              </>

            ) : (
              <>
                <button
                  onClick={() => navigate('/dashboard')}
                  className={`text-sm font-medium transition-colors ${location.pathname === '/dashboard' ? activeLinkColor : linkColor}`}
                >
                  {t('nav.dashboard')}
                </button>
                <button
                  onClick={() => navigate('/map')}
                  className={`text-sm font-medium transition-colors flex items-center gap-1 ${location.pathname === '/map' ? activeLinkColor : linkColor}`}
                >
                  <MapPin className="w-4 h-4" />
                  {t('nav.map')}
                </button>
                <button
                  onClick={() => navigate('/premium')}
                  className={`text-sm font-medium transition-colors flex items-center gap-1 ${location.pathname === '/premium' ? activeLinkColor : 'text-gold hover:text-gold-400'}`}
                >
                  <Crown className="w-4 h-4" />
                  Premium
                  {isPremium && <span className="ml-1 w-1.5 h-1.5 bg-gold rounded-full" />}
                </button>
                <button
                  onClick={() => navigate('/settings')}
                  className={`text-sm font-medium transition-colors ${location.pathname === '/settings' ? activeLinkColor : linkColor}`}
                >
                  {t('nav.settings')}
                </button>
                {profile?.is_admin && (
                  <button
                    onClick={() => navigate('/admin')}
                    className={`text-sm font-medium transition-colors flex items-center gap-1 ${location.pathname === '/admin' ? activeLinkColor : linkColor}`}
                  >
                    <Shield className="w-4 h-4" />
                    Admin
                  </button>
                )}
              </>
            )}
          </nav>

          {/* Auth buttons & Language selector */}
          <div className="hidden md:flex items-center gap-4">
            {/* Language Selector */}
            <div className="relative">
              <button
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-charcoal-600 transition-all"
                title="Language"
              >
                <Globe className="w-4 h-4" />
                <span className="text-xs font-medium uppercase">{language}</span>
              </button>
              
              {langMenuOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setLangMenuOpen(false)} />
                  <div className="absolute right-0 top-10 z-20 w-48 bg-charcoal-700 rounded-xl shadow-lg border border-charcoal-600 py-2 max-h-64 overflow-y-auto">
                    {supportedLanguages.map((lang) => {
                      const isActive = activeLanguages.includes(lang.code);
                      const isSelected = language === lang.code;
                      
                      return (
                        <button
                          key={lang.code}
                          onClick={() => {
                            if (isActive) {
                              setLanguage(lang.code);
                              setLangMenuOpen(false);
                            }
                          }}
                          disabled={!isActive}
                          className={`w-full flex items-center justify-between px-4 py-2 text-sm transition-colors ${
                            isSelected
                              ? 'bg-gold/10 text-gold'
                              : isActive
                                ? 'text-gray-300 hover:bg-charcoal-600 hover:text-white'
                                : 'text-gray-500 cursor-not-allowed'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <span>{lang.nativeName}</span>
                            {!isActive && (
                              <span className="text-xs text-gray-500">(Soon)</span>
                            )}
                          </div>
                          {isSelected && (
                            <div className="w-2 h-2 bg-gold rounded-full" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </>
              )}
            </div>

            {/* Notification Bell - only show when logged in */}
            {user && <NotificationBell />}

            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className="flex items-center gap-2 px-3 py-2 rounded-xl transition-all hover:bg-charcoal-600"
                >

                  <div className="relative">
                    {profile?.avatar_url ? (
                      <img
                        src={profile.avatar_url}
                        alt={profile.display_name || 'User'}
                        className="w-8 h-8 rounded-full object-cover ring-2 ring-gold/30"
                      />
                    ) : (
                      <div className="w-8 h-8 bg-charcoal-600 rounded-full flex items-center justify-center ring-2 ring-gold/30">
                        <User className="w-4 h-4 text-gold" />
                      </div>
                    )}


                  </div>
                  <span className="font-medium text-white">
                    {profile?.display_name || 'User'}
                  </span>
                  {isPremium && (
                    <Crown className="w-4 h-4 text-gold" />
                  )}
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </button>



                {userMenuOpen && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setUserMenuOpen(false)} />

                    <div className="absolute right-0 top-12 z-20 w-48 bg-charcoal-700 rounded-xl shadow-lg border border-charcoal-600 py-2">
                      {/* User location display */}
                      {profile?.city && profile?.country && (
                        <div className="px-4 py-2 border-b border-charcoal-600">
                          <p className="text-xs text-gray-500">{t('profile.location')}</p>
                          <p className="text-sm text-gray-300">{profile.city}, {profile.country}</p>
                        </div>
                      )}
                      <button
                        onClick={() => { navigate('/dashboard'); setUserMenuOpen(false); }}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-gray-300 hover:bg-charcoal-600 hover:text-white transition-colors"
                      >
                        <LayoutDashboard className="w-4 h-4" />
                        {t('nav.dashboard')}
                      </button>
                      <button
                        onClick={() => { navigate('/map'); setUserMenuOpen(false); }}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-gray-300 hover:bg-charcoal-600 hover:text-white transition-colors"
                      >
                        <MapPin className="w-4 h-4" />
                        {t('map.title')}
                      </button>
                      <button
                        onClick={() => { navigate('/premium'); setUserMenuOpen(false); }}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-gold hover:bg-gold/10 transition-colors"
                      >
                        <Crown className="w-4 h-4" />
                        Premium
                        {isPremium && <span className="ml-auto text-xs bg-gold/20 px-1.5 py-0.5 rounded">Active</span>}
                      </button>
                      {onEditProfile && (
                        <button
                          onClick={() => { onEditProfile(); setUserMenuOpen(false); }}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-gray-300 hover:bg-charcoal-600 hover:text-white transition-colors"
                        >
                          <Edit className="w-4 h-4" />
                          {t('profile.title')}
                        </button>
                      )}
                      <button
                        onClick={() => { navigate('/settings'); setUserMenuOpen(false); }}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-gray-300 hover:bg-charcoal-600 hover:text-white transition-colors"
                      >
                        <Settings className="w-4 h-4" />
                        {t('nav.settings')}
                      </button>
                      {profile?.is_admin && (
                        <button
                          onClick={() => { navigate('/admin'); setUserMenuOpen(false); }}
                          className="w-full flex items-center gap-3 px-4 py-2.5 text-gold hover:bg-gold/10 transition-colors"
                        >
                          <Shield className="w-4 h-4" />
                          Admin Panel
                        </button>
                      )}
                      <hr className="my-2 border-charcoal-600" />
                      <button
                        onClick={handleSignOut}
                        className="w-full flex items-center gap-3 px-4 py-2.5 text-red-400 hover:bg-red-500/10 transition-colors"
                      >
                        <LogOut className="w-4 h-4" />
                        {t('nav.signOut')}
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <>
                <button
                  onClick={onSignIn}
                  className="px-4 py-2 text-sm font-medium text-gray-300 hover:text-white transition-colors"
                >
                  {t('nav.signIn')}
                </button>
                <button
                  onClick={onSignUp}
                  className="px-5 py-2.5 bg-gold text-charcoal text-sm font-semibold rounded-xl hover:bg-gold-400 transition-all shadow-gold"
                >
                  {t('landing.hero.cta')}
                </button>
              </>
            )}
          </div>


          {/* Mobile notification bell and menu button */}
          <div className="md:hidden flex items-center gap-2">
            {user && <NotificationBell />}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-white hover:bg-charcoal-600 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-charcoal-700 border-t border-charcoal-600">
          <div className="px-4 py-4 space-y-4">
            {/* Mobile Language Selector */}
            <div className="flex items-center justify-between py-2">
              <span className="text-gray-400 text-sm flex items-center gap-2">
                <Globe className="w-4 h-4" />
                {t('profile.language')}
              </span>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as any)}
                className="bg-charcoal-600 text-white text-sm rounded-lg px-2 py-1 border border-charcoal-500"
              >
                {supportedLanguages.filter(l => activeLanguages.includes(l.code)).map((lang) => (
                  <option key={lang.code} value={lang.code}>
                    {lang.nativeName}
                  </option>
                ))}
              </select>
            </div>
            
            <hr className="border-charcoal-600" />
            
            {isLandingPage ? (
              <>
                <a href="#features" className="block text-gray-300 hover:text-gold font-medium transition-colors">
                  {t('landing.features.title')}
                </a>
                <a href="#how-it-works" className="block text-gray-300 hover:text-gold font-medium transition-colors">
                  {t('landing.howItWorks.title')}
                </a>
                <a href="#faq" className="block text-gray-300 hover:text-gold font-medium transition-colors">
                  {t('landing.faq.title')}
                </a>
              </>

            ) : (
              <>
                <button
                  onClick={() => { navigate('/dashboard'); setMobileMenuOpen(false); }}
                  className="block text-gray-300 hover:text-gold font-medium transition-colors"
                >
                  {t('nav.dashboard')}
                </button>
                <button
                  onClick={() => { navigate('/map'); setMobileMenuOpen(false); }}
                  className="flex items-center gap-2 text-gray-300 hover:text-gold font-medium transition-colors"
                >
                  <MapPin className="w-4 h-4" />
                  {t('map.title')}
                </button>
                <button
                  onClick={() => { navigate('/premium'); setMobileMenuOpen(false); }}
                  className="flex items-center gap-2 text-gold font-medium"
                >
                  <Crown className="w-4 h-4" />
                  Premium
                  {isPremium && <span className="ml-1 text-xs bg-gold/20 px-1.5 py-0.5 rounded">Active</span>}
                </button>
                <button
                  onClick={() => { navigate('/settings'); setMobileMenuOpen(false); }}
                  className="block text-gray-300 hover:text-gold font-medium transition-colors"
                >
                  {t('nav.settings')}
                </button>
                {profile?.is_admin && (
                  <button
                    onClick={() => { navigate('/admin'); setMobileMenuOpen(false); }}
                    className="flex items-center gap-2 text-gold font-medium"
                  >
                    <Shield className="w-4 h-4" />
                    Admin Panel
                  </button>
                )}
              </>
            )}
            <hr className="border-charcoal-600" />
            {user ? (
              <button
                onClick={handleSignOut}
                className="block text-red-400 font-medium"
              >
                {t('nav.signOut')}
              </button>
            ) : (
              <div className="flex flex-col gap-3">
                <button
                  onClick={() => { onSignIn(); setMobileMenuOpen(false); }}
                  className="w-full py-2.5 text-gray-300 font-medium hover:text-white transition-colors"
                >
                  {t('nav.signIn')}
                </button>
                <button
                  onClick={() => { onSignUp(); setMobileMenuOpen(false); }}
                  className="w-full py-2.5 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all"
                >
                  {t('landing.hero.cta')}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
