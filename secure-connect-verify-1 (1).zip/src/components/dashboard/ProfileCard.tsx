import React, { useState, useEffect } from 'react';
import { useAuth, INTENT_LABELS, RELATIONSHIP_STATUS_LABELS } from '@/contexts/AuthContext';
import { User, Edit, Shield, Heart, Users, AlertCircle, Image, Eye, Loader2 } from 'lucide-react';
import PhotoRequestModal from '../profile/PhotoRequestModal';
import { supabase, getPublicPhotoUrl } from '@/lib/supabase';


interface ProfileCardProps {
  onEditProfile: () => void;
}

const ProfileCard: React.FC<ProfileCardProps> = ({ onEditProfile }) => {
  const { profile, user, isProfileLoading } = useAuth();
  const [showPhotoRequestsModal, setShowPhotoRequestsModal] = useState(false);
  const [pendingRequestsCount, setPendingRequestsCount] = useState(0);

  // Derive photo URL from profile — NO fetch, NO signed URL, NO user_photos table
  const primaryPhoto = getPublicPhotoUrl(profile?.primary_photo_path, profile?.primary_photo_updated_at);

  const isProfileIncomplete = !profile?.intent || !profile?.relationship_status;

  // Fetch pending photo requests count
  useEffect(() => {
    const fetchPendingRequests = async () => {
      if (!user) return;
      try {
        const { count } = await supabase
          .from('photo_requests')
          .select('*', { count: 'exact', head: true })
          .eq('target_id', user.id)
          .eq('status', 'pending');
        setPendingRequestsCount(count || 0);
      } catch {
        setPendingRequestsCount(0);
      }
    };
    fetchPendingRequests();
  }, [user]);

  // Determine what to show for avatar
  const showPhoto = primaryPhoto;

  // ── LOADING STATE: Show skeleton card while profile is being fetched ──
  // This prevents "Anonymous User" from flashing/displaying during fetch.
  if (!profile && isProfileLoading) {
    return (
      <div className="bg-[#141414] rounded-2xl border border-[#2a2a2a] overflow-hidden animate-pulse">
        {/* Header gradient skeleton */}
        <div className="h-20 bg-gradient-to-r from-[#1a1a1a] to-[#141414] relative">
          <div className="absolute inset-0 bg-[#C9A24D]/5" />
          <div className="absolute -bottom-10 left-1/2 -translate-x-1/2">
            <div className="w-20 h-20 rounded-full bg-[#1a1a1a] ring-4 ring-[#141414] flex items-center justify-center">
              <Loader2 className="w-8 h-8 text-[#C9A24D]/40 animate-spin" />
            </div>
          </div>
        </div>
        <div className="pt-12 pb-6 px-6">
          {/* Name skeleton */}
          <div className="text-center mb-4">
            <div className="h-6 w-32 bg-[#2a2a2a] rounded-lg mx-auto" />
          </div>
          {/* Intent skeleton */}
          <div className="mb-4 p-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl space-y-2">
            <div className="h-4 w-40 bg-[#2a2a2a] rounded" />
            <div className="h-4 w-28 bg-[#2a2a2a] rounded" />
          </div>
          {/* Button skeleton */}
          <div className="h-10 w-full bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl" />
        </div>
      </div>
    );
  }

  // ── DISPLAY NAME LOGIC ──
  // Never show "Anonymous User". Priority:
  // 1. profile.display_name (from DB)
  // 2. email prefix (from user.email)
  // 3. "Your Profile" (neutral fallback — not "Anonymous")
  const displayName = profile?.display_name 
    || (user?.email ? user.email.split('@')[0] : null)
    || 'Your Profile';

  return (
    <>
      <div className="bg-[#141414] rounded-2xl border border-[#2a2a2a] overflow-hidden">
        {/* Header gradient */}
        <div className="h-20 bg-gradient-to-r from-[#1a1a1a] to-[#141414] relative">
          <div className="absolute inset-0 bg-[#C9A24D]/5" />
          <div className="absolute -bottom-10 left-1/2 -translate-x-1/2">
            {showPhoto ? (
              <img
                src={primaryPhoto}
                alt={displayName}
                className="w-20 h-20 rounded-full object-cover ring-4 ring-[#141414]"
              />
            ) : profile?.avatar_url ? (
              <img
                src={profile.avatar_url}
                alt={displayName}
                className="w-20 h-20 rounded-full object-cover ring-4 ring-[#141414]"
              />
            ) : (
              <div className="w-20 h-20 rounded-full bg-[#1a1a1a] ring-4 ring-[#141414] flex items-center justify-center">
                <User className="w-10 h-10 text-[#C9A24D]" />
              </div>
            )}
          </div>
        </div>

        <div className="pt-12 pb-6 px-6">

          {/* Name — never shows "Anonymous User" */}
          <div className="text-center mb-4">
            <h3 className="text-xl font-semibold text-white">
              {displayName}
            </h3>
          </div>

          {/* Profile Incomplete Warning */}
          {isProfileIncomplete && (
            <div className="mb-4 p-3 bg-[#C9A24D]/10 border border-[#C9A24D]/30 rounded-xl">
              <div className="flex items-center gap-2 text-[#C9A24D] text-sm">
                <AlertCircle className="w-4 h-4" />
                <span className="font-medium">Profile Incomplete</span>
              </div>
              <p className="text-xs text-gray-400 mt-1">
                Set your intent and relationship status to complete your profile.
              </p>
            </div>
          )}

          {/* Intent & Relationship Status - Always Visible */}
          {(profile?.intent || profile?.relationship_status) && (
            <div className="mb-4 p-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl space-y-2">
              {profile?.intent && (
                <div className="flex items-center gap-2">
                  <Heart className="w-4 h-4 text-[#C9A24D]" />
                  <span className="text-gray-400 text-sm">Looking for:</span>
                  <span className="text-white text-sm font-medium">
                    {INTENT_LABELS[profile.intent]}
                  </span>
                </div>
              )}
              {profile?.relationship_status && (
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-[#C9A24D]" />
                  <span className="text-gray-400 text-sm">Status:</span>
                  <span className="text-white text-sm font-medium">
                    {RELATIONSHIP_STATUS_LABELS[profile.relationship_status]}
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Bio */}
          {profile?.bio && (
            <p className="text-gray-400 text-sm text-center mb-4 line-clamp-3">
              {profile.bio}
            </p>
          )}

          {/* Interest tags */}
          {profile?.interest_tags && profile.interest_tags.length > 0 && (
            <div className="flex flex-wrap justify-center gap-1.5 mb-4">
              {profile.interest_tags.slice(0, 5).map((tag, index) => (
                <span
                  key={index}
                  className="px-2.5 py-1 bg-[#C9A24D]/10 text-[#C9A24D] text-xs font-medium rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}

          {/* Photo visibility indicator - V1: No 'private' option */}
          <div className="flex items-center justify-center gap-2 text-gray-500 text-xs mb-4">
            {profile?.photo_visibility === 'matches_only' || !profile?.photo_visibility ? (
              <>
                <Eye className="w-4 h-4" />
                <span>Photos visible to matches</span>
              </>
            ) : profile?.photo_visibility === 'approved_only' ? (
              <>
                <Shield className="w-4 h-4" />
                <span>Photos require approval</span>
              </>
            ) : (
              // Fallback for legacy 'private' setting - migrate to matches_only display
              <>
                <Eye className="w-4 h-4" />
                <span>Photos visible to matches</span>
              </>
            )}
          </div>


          {/* Pending Photo Requests */}
          {pendingRequestsCount > 0 && (
            <button
              onClick={() => setShowPhotoRequestsModal(true)}
              className="w-full mb-2 py-2.5 bg-[#C9A24D]/10 hover:bg-[#C9A24D]/20 text-[#C9A24D] font-medium rounded-xl flex items-center justify-center gap-2 transition-all border border-[#C9A24D]/30"
            >
              <Image className="w-4 h-4" />
              {pendingRequestsCount} Photo Request{pendingRequestsCount > 1 ? 's' : ''}
            </button>
          )}

          {/* Action buttons */}
          <div className="space-y-2">
            <button
              onClick={onEditProfile}
              className="w-full py-2.5 bg-[#1a1a1a] hover:bg-[#2a2a2a] text-gray-300 font-medium rounded-xl flex items-center justify-center gap-2 transition-all border border-[#2a2a2a]"
            >
              <Edit className="w-4 h-4" />
              Edit Profile
            </button>
          </div>
        </div>
      </div>

      {/* Photo Requests Modal */}
      <PhotoRequestModal
        isOpen={showPhotoRequestsModal}
        onClose={() => {
          setShowPhotoRequestsModal(false);
          // Refresh count after closing
          if (user) {
            supabase
              .from('photo_requests')
              .select('*', { count: 'exact', head: true })
              .eq('target_id', user.id)
              .eq('status', 'pending')
              .then(({ count }) => setPendingRequestsCount(count || 0));
          }
        }}
        mode="manage"
      />
    </>
  );
};

export default ProfileCard;
