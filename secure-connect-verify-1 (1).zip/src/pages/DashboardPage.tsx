import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/layout/Header';
import Dashboard from '@/components/dashboard/Dashboard';
import AuthModal from '@/components/auth/AuthModal';
import ProactiveAlerts from '@/components/support/ProactiveAlerts';
import NotificationPermissionBanner from '@/components/notifications/NotificationPermissionBanner';
import { Ban, AlertTriangle, Mail } from 'lucide-react';
import usePresence from '@/hooks/usePresence';

const DashboardPage: React.FC = () => {
  const { user, profile, loading, error, clearError, signOut } = useAuth();
  const navigate = useNavigate();
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');

  // Initialize presence tracking for offline notifications
  usePresence({
    heartbeatInterval: 30000,
    onStatusChange: (isOnline) => {
      console.log('User presence changed:', isOnline ? 'online' : 'offline');
    }
  });

  useEffect(() => {
    if (!loading && !user) {
      navigate('/');
    }
  }, [user, loading, navigate]);

  const handleProactiveAction = (actionType: string, triggerType: string) => {
    switch (actionType) {
      case 'update_payment':
      case 'fix_payment':
        window.dispatchEvent(new CustomEvent('openSupportChat', { detail: { category: 'billing' } }));
        break;
      case 'manage_subscription':
      case 'resubscribe':
        navigate('/premium');
        break;
      default:
        window.dispatchEvent(new CustomEvent('openSupportChat', { detail: { category: 'billing' } }));
    }
  };

  const handleRetry = () => {
    clearError();
    window.location.reload();
  };

  if (error && user) {
    return (
      <div className="min-h-screen bg-charcoal">
        <Header
          onSignIn={() => { setAuthMode('signin'); setAuthModalOpen(true); }}
          onSignUp={() => { setAuthMode('signup'); setAuthModalOpen(true); }}
          transparent={false}
        />
        <div className="pt-24 flex items-center justify-center">
          <div className="text-center max-w-md mx-auto px-4">
            <div className="w-16 h-16 mx-auto mb-4 bg-charcoal-700 rounded-2xl flex items-center justify-center border border-yellow-500/30">
              <AlertTriangle className="w-8 h-8 text-yellow-400" />
            </div>
            <h2 className="text-xl font-semibold text-white mb-2">Something went wrong</h2>
            <p className="text-gray-400 mb-6">{error}</p>
            <button
              onClick={handleRetry}
              className="px-6 py-3 bg-gold text-charcoal font-medium rounded-lg hover:bg-gold-400 transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-charcoal">
        <div className="animate-spin w-8 h-8 border-4 border-gold border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  if (profile?.is_suspended) {
    return (
      <div className="min-h-screen bg-charcoal flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-charcoal-700 rounded-2xl shadow-xl p-8 text-center border border-charcoal-600">
          <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Ban className="w-8 h-8 text-red-500" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">Account Suspended</h1>
          <p className="text-gray-400 mb-6">
            Your account has been suspended due to a violation of our community guidelines.
          </p>
          {profile.suspended_reason && (
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 mb-6 text-left">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-red-400 text-sm">Reason for suspension:</p>
                  <p className="text-gray-300 text-sm mt-1">{profile.suspended_reason}</p>
                </div>
              </div>
            </div>
          )}
          {profile.suspended_at && (
            <p className="text-sm text-gray-500 mb-6">
              Suspended on {new Date(profile.suspended_at).toLocaleDateString()}
            </p>
          )}
          <div className="space-y-3">
            <a
              href="mailto:support@dwadido.com"
              className="flex items-center justify-center gap-2 w-full py-3 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all"
            >
              <Mail className="w-5 h-5" />
              Contact Support
            </a>
            <button
              onClick={async () => {
                await signOut();
                navigate('/');
              }}
              className="w-full py-3 bg-charcoal-600 text-gray-300 font-medium rounded-xl hover:bg-charcoal-500 transition-all"
            >
              Sign Out
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-6">
            If you believe this was a mistake, please contact our support team for assistance.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-charcoal">
      <Header
        onSignIn={() => { setAuthMode('signin'); setAuthModalOpen(true); }}
        onSignUp={() => { setAuthMode('signup'); setAuthModalOpen(true); }}
        transparent={false}
      />
      <div className="pt-16">
        <ProactiveAlerts 
          variant="banner" 
          onAction={handleProactiveAction}
        />
      </div>
      <div>
        <Dashboard />
      </div>
      <NotificationPermissionBanner variant="banner" />
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authMode}
      />
    </div>
  );
};

export default DashboardPage;
