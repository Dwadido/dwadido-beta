import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode, useRef } from 'react';
import { useAuth } from './AuthContext';
import {
  AppNotification,
  getNotifications,

  markAsRead,
  markAllAsRead,
  subscribeToNotifications,
  syncMissedNotifications,
  NotificationPreferences,
  getNotificationPreferences,
  saveNotificationPreferences,
  defaultNotificationPreferences,
  showLocalNotification,
  getNotificationPermission,
  isPushSupported,
  initializeNotifications,
  // ── NEW: Match-derived notification helpers ──
  getMatchDerivedNotifications,
  isDerivedNotificationId,
  markDerivedNotificationRead,
  markAllDerivedRead,
  dismissDerivedNotification,
  dismissAllDerivedNotifications,
} from '@/lib/notifications';
// sendEmailNotification and checkEmailPreference are available from '@/lib/emailNotifications'
// but not currently used in this context — kept as a note for future email notification integration.

import { withTimeout, withTimeoutFallback, TimeoutError } from '@/lib/utils';
import { supabase } from '@/lib/supabase';

// Timeout configuration
const DB_TIMEOUT_MS = 10000; // 10 seconds

// =============================================================================
// NOTIFICATION CONTEXT — HYBRID DB + MATCH-DERIVED APPROACH
// =============================================================================
//
// Root cause of "No updates yet" bug:
//   1. Edge functions (redeem-crush-code) do NOT insert notification rows.
//   2. Frontend createNotificationDirect() inserts fail silently (RLS blocks
//      cross-user inserts where user_id ≠ auth.uid(), and may block even
//      same-user inserts depending on policy configuration).
//   3. syncMissedNotifications also uses createNotificationDirect, so it
//      fails for the same reason.
//   4. Result: the `notifications` table stays empty → "No updates yet".
//
// Fix: HYBRID approach
//   - Still query the `notifications` table (it may have rows from successful
//     inserts or future edge function fixes).
//   - ALSO derive notifications from the `matches` table (the actual source
//     of truth for connections). These "derived" notifications have
//     deterministic IDs (match-derived-{matchId}) and use localStorage for
//     read/dismissed state.
//   - Merge both sources, deduplicating by match_id so DB rows take priority.
//   - This ensures users ALWAYS see updates for their connections regardless
//     of whether the notifications table has rows.
// =============================================================================


interface NotificationContextType {
  notifications: AppNotification[];
  unreadCount: number;
  loading: boolean;
  error: string | null;
  preferences: NotificationPreferences;
  permissionStatus: NotificationPermission;
  isSupported: boolean;
  fetchNotifications: (options?: { limit?: number; unreadOnly?: boolean }) => Promise<void>;
  markNotificationAsRead: (notificationId: string) => Promise<void>;
  markAllNotificationsAsRead: () => Promise<void>;
  updatePreferences: (prefs: Partial<NotificationPreferences>) => Promise<void>;
  refreshUnreadCount: () => Promise<void>;
  requestPermission: () => Promise<NotificationPermission>;
  deleteNotification: (notificationId: string) => Promise<void>;
  deleteAllNotifications: () => Promise<void>;
  clearError: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

interface NotificationProviderProps {
  children: ReactNode;
}

export const NotificationProvider: React.FC<NotificationProviderProps> = ({ children }) => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preferences, setPreferences] = useState<NotificationPreferences>(defaultNotificationPreferences);

  const [permissionStatus, setPermissionStatus] = useState<NotificationPermission>('default');
  const [isSupported] = useState(() => isPushSupported());
  
  // Track if component is mounted to prevent state updates after unmount
  const isMountedRef = useRef(true);

  const clearError = () => setError(null);

  // Update permission status
  useEffect(() => {
    if (isSupported) {
      setPermissionStatus(getNotificationPermission());
    }
  }, [isSupported]);

  // Initialize notifications and service worker - with abort handling and timeout
  useEffect(() => {
    if (!user?.id || !isSupported) return;
    
    let cancelled = false;
    
    const init = async () => {
      try {
        await withTimeout(
          initializeNotifications(user.id),
          DB_TIMEOUT_MS,
          'Initialize notifications'
        );
      } catch (err) {
        // Silently handle abort errors - they're expected during unmount
        if (err instanceof Error && err.name === 'AbortError') {
          return;
        }
        if (err instanceof TimeoutError) {
          console.warn('[Notifications] Initialization timed out, continuing without push');
          return;
        }
        console.error('Error initializing notifications:', err);
      }
    };
    
    if (!cancelled) {
      init();
    }
    
    return () => {
      cancelled = true;
    };
  }, [user?.id, isSupported]);

  // Request notification permission
  const requestPermission = useCallback(async (): Promise<NotificationPermission> => {
    if (!isSupported) return 'denied';

    try {
      const permission = await Notification.requestPermission();
      if (isMountedRef.current) {
        setPermissionStatus(permission);
      }
      return permission;
    } catch (err) {
      console.error('Error requesting permission:', err);
      return 'denied';
    }
  }, [isSupported]);

  // =========================================================================
  // FETCH NOTIFICATIONS — Hybrid DB + Match-Derived
  // =========================================================================
  // 1. Fetch from `notifications` table (may be empty)
  // 2. Fetch match-derived notifications (always has data if matches exist)
  // 3. Merge, deduplicating by match_id (DB rows take priority)
  // 4. Sort by created_at descending
  // =========================================================================
  const fetchNotifications = useCallback(async (options?: { limit?: number; unreadOnly?: boolean }) => {
    if (!user?.id) return;
    
    setLoading(true);
    try {
      // Fetch from BOTH sources in parallel
      const [dbNotifications, derivedNotifications] = await Promise.all([
        withTimeoutFallback(
          getNotifications(user.id, options),
          [] as AppNotification[],
          DB_TIMEOUT_MS,
          'Fetch DB notifications'
        ),
        getMatchDerivedNotifications(user.id).catch((err) => {
          console.warn('[Notifications] Failed to derive from matches:', err);
          return [] as AppNotification[];
        }),
      ]);

      // Build a set of match_ids that already have DB notification rows
      const dbMatchIds = new Set<string>();
      dbNotifications.forEach(n => {
        if (n.data?.match_id) {
          dbMatchIds.add(n.data.match_id);
        }
      });

      // Filter derived notifications: only keep those whose match_id
      // is NOT already covered by a DB notification row
      const uniqueDerived = derivedNotifications.filter(dn => {
        const matchId = dn.data?.match_id;
        return matchId && !dbMatchIds.has(matchId);
      });

      // Merge and sort by created_at descending
      const merged = [...dbNotifications, ...uniqueDerived].sort(
        (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      );

      // Apply unreadOnly filter if requested (derived notifications handle this via localStorage)
      const filtered = options?.unreadOnly
        ? merged.filter(n => !n.read)
        : merged;

      // Apply limit if requested
      const limited = options?.limit
        ? filtered.slice(0, options.limit)
        : filtered;

      if (isMountedRef.current) {
        setNotifications(limited);
        setUnreadCount(limited.filter(n => !n.read).length);
        setError(null);
      }
    } catch (err) {
      if (err instanceof Error && err.name === 'AbortError') {
        return;
      }
      if (err instanceof TimeoutError) {
        console.warn('[Notifications] Fetch timed out');
        if (isMountedRef.current) {
          setError('Loading notifications is taking longer than expected.');
        }
        return;
      }
      console.error('Error fetching notifications:', err);
    } finally {
      if (isMountedRef.current) {
        setLoading(false);
      }
    }
  }, [user?.id]);

  // =========================================================================
  // REFRESH UNREAD COUNT — computed from merged list
  // =========================================================================
  const refreshUnreadCount = useCallback(async () => {
    if (!user?.id) return;
    
    // Instead of querying DB count only, re-fetch the full list
    // This ensures derived notifications are included in the count
    await fetchNotifications({ limit: 50 });
  }, [user?.id, fetchNotifications]);

  // =========================================================================
  // MARK SINGLE NOTIFICATION AS READ — handles both DB and derived
  // =========================================================================
  const markNotificationAsRead = useCallback(async (notificationId: string) => {
    try {
      if (isDerivedNotificationId(notificationId)) {
        // Derived notification: update localStorage
        markDerivedNotificationRead(notificationId);
      } else {
        // DB notification: update in database
        try {
          await withTimeout(
            markAsRead([notificationId]),
            DB_TIMEOUT_MS,
            'Mark notification as read'
          );
        } catch (err) {
          if (err instanceof TimeoutError) {
            console.warn('[Notifications] Mark as read timed out');
          }
          // Still update UI optimistically
        }
      }

      // Update local state optimistically
      if (isMountedRef.current) {
        setNotifications(prev => 
          prev.map(n => n.id === notificationId ? { ...n, read: true } : n)
        );
        setUnreadCount(prev => Math.max(0, prev - 1));
      }
    } catch (err) {
      console.error('Error marking notification as read:', err);
    }
  }, []);

  // =========================================================================
  // MARK ALL NOTIFICATIONS AS READ — handles both DB and derived
  // =========================================================================
  const markAllNotificationsAsRead = useCallback(async () => {
    if (!user?.id) return;
    
    try {
      // Mark DB notifications as read
      try {
        await withTimeout(
          markAllAsRead(user.id),
          DB_TIMEOUT_MS,
          'Mark all notifications as read'
        );
      } catch (err) {
        if (err instanceof TimeoutError) {
          console.warn('[Notifications] Mark all as read timed out');
        }
        // Continue — still update derived + UI
      }

      // Mark all derived notifications as read in localStorage
      const derivedIds = notifications
        .filter(n => isDerivedNotificationId(n.id))
        .map(n => n.id);
      if (derivedIds.length > 0) {
        markAllDerivedRead(derivedIds);
      }

      // Update local state
      if (isMountedRef.current) {
        setNotifications(prev => prev.map(n => ({ ...n, read: true })));
        setUnreadCount(0);
      }
    } catch (err) {
      console.error('Error marking all notifications as read:', err);
    }
  }, [user?.id, notifications]);

  // =========================================================================
  // DELETE SINGLE NOTIFICATION — handles both DB and derived
  // =========================================================================
  const deleteNotification = useCallback(async (notificationId: string) => {
    try {
      if (isDerivedNotificationId(notificationId)) {
        // Derived notification: dismiss in localStorage
        dismissDerivedNotification(notificationId);
      } else {
        // DB notification: delete from database
        try {
          const deleteQuery = supabase
            .from('notifications')
            .delete()
            .eq('id', notificationId);

          await withTimeout(deleteQuery, DB_TIMEOUT_MS, 'Delete notification');
        } catch (err) {
          if (err instanceof TimeoutError) {
            console.warn('[Notifications] Delete timed out');
          }
          // Still remove from UI
        }
      }

      // Update local state
      if (isMountedRef.current) {
        const notification = notifications.find(n => n.id === notificationId);
        setNotifications(prev => prev.filter(n => n.id !== notificationId));
        if (notification && !notification.read) {
          setUnreadCount(prev => Math.max(0, prev - 1));
        }
      }
    } catch (err) {
      console.error('Error deleting notification:', err);
    }
  }, [notifications]);

  // =========================================================================
  // DELETE ALL NOTIFICATIONS — handles both DB and derived
  // =========================================================================
  const deleteAllNotifications = useCallback(async () => {
    if (!user?.id) return;

    try {
      // Delete DB notifications
      try {
        const deleteQuery = supabase
          .from('notifications')
          .delete()
          .eq('user_id', user.id);

        await withTimeout(deleteQuery, DB_TIMEOUT_MS, 'Delete all notifications');
      } catch (err) {
        if (err instanceof TimeoutError) {
          console.warn('[Notifications] Delete all timed out');
        }
        // Continue — still dismiss derived + clear UI
      }

      // Dismiss all derived notifications in localStorage
      const derivedIds = notifications
        .filter(n => isDerivedNotificationId(n.id))
        .map(n => n.id);
      if (derivedIds.length > 0) {
        dismissAllDerivedNotifications(derivedIds);
      }

      // Clear local state
      if (isMountedRef.current) {
        setNotifications([]);
        setUnreadCount(0);
      }
    } catch (err) {
      console.error('Error deleting all notifications:', err);
    }
  }, [user?.id, notifications]);

  // Update preferences
  const updatePreferences = useCallback(async (prefs: Partial<NotificationPreferences>) => {
    if (!user?.id) return;
    
    const newPrefs = { ...preferences, ...prefs };
    setPreferences(newPrefs);
    
    try {
      await withTimeout(
        saveNotificationPreferences(user.id, newPrefs),
        DB_TIMEOUT_MS,
        'Save notification preferences'
      );
    } catch (err) {
      if (err instanceof TimeoutError) {
        console.warn('[Notifications] Save preferences timed out - changes may not persist');
        return;
      }
      console.error('Error saving preferences:', err);
    }
  }, [user?.id, preferences]);

  // Load preferences on mount with timeout
  useEffect(() => {
    let cancelled = false;
    
    const loadPreferences = async () => {
      if (!user?.id) return;
      try {
        const prefs = await withTimeoutFallback(
          getNotificationPreferences(user.id),
          defaultNotificationPreferences,
          DB_TIMEOUT_MS,
          'Load notification preferences'
        );
        if (!cancelled && isMountedRef.current) {
          setPreferences(prefs);
        }
      } catch (err) {
        console.warn('[Notifications] Failed to load preferences, using defaults');
      }
    };
    
    loadPreferences();
    
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  // =========================================================================
  // INITIAL FETCH + REALTIME SUBSCRIPTION
  // =========================================================================
  useEffect(() => {
    if (!user?.id) {
      setNotifications([]);
      setUnreadCount(0);
      return;
    }

    let cancelled = false;

    const initialFetch = async () => {
      try {
        // Best-effort: try to sync missed notifications to the DB.
        // This may fail silently if RLS blocks inserts — that's OK because
        // getMatchDerivedNotifications provides the fallback.
        try {
          await syncMissedNotifications(user.id);
        } catch (syncErr) {
          console.warn('[Notifications] Sync missed notifications failed (non-fatal):', syncErr);
        }

        // Fetch merged notifications (DB + match-derived)
        await fetchNotifications({ limit: 50 });
      } catch (err) {
        if (err instanceof Error && err.name === 'AbortError') {
          return;
        }
      }
    };
    
    if (!cancelled) {
      initialFetch();
    }

    // Subscribe to real-time DB notifications (may not work if realtime
    // is not enabled for the notifications table, but harmless to try)
    const unsubscribe = subscribeToNotifications(user.id, (newNotification) => {
      if (cancelled || !isMountedRef.current) return;
      
      // Add to notifications list (avoid duplicates)
      setNotifications(prev => {
        if (prev.some(n => n.id === newNotification.id)) return prev;
        return [newNotification, ...prev];
      });
      setUnreadCount(prev => prev + 1);

      // Show local notification if permission granted and push enabled
      if (getNotificationPermission() === 'granted' && preferences.push_enabled) {
        const typeKey = newNotification.type as keyof NotificationPreferences;
        if (preferences[typeKey] !== false) {
          showLocalNotification(
            newNotification.title,
            newNotification.body,
            '/dwadido-icon.png',
            newNotification.type
          );
        }
      }
    });

    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, [user?.id, fetchNotifications, preferences]);


  // =========================================================================
  // PERIODIC FULL REFRESH (fallback for realtime)
  // =========================================================================
  // Polls every 30 seconds to pick up new matches/notifications.
  // This is the safety net that ensures updates appear even if:
  // - Realtime subscription is not working
  // - DB inserts failed but new matches were created
  // =========================================================================
  useEffect(() => {
    if (!user?.id) return;

    const interval = setInterval(() => {
      if (isMountedRef.current) {
        // Full refresh — not just count — so derived notifications are included
        fetchNotifications({ limit: 50 });
      }
    }, 30000); // Every 30 seconds

    return () => clearInterval(interval);
  }, [user?.id, fetchNotifications]);

  // Listen for permission changes
  useEffect(() => {
    if (!isSupported) return;

    const checkPermission = () => {
      if (isMountedRef.current) {
        setPermissionStatus(getNotificationPermission());
      }
    };

    const interval = setInterval(checkPermission, 5000);
    return () => clearInterval(interval);
  }, [isSupported]);

  // Track mounted state
  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        loading,
        error,
        preferences,
        permissionStatus,
        isSupported,
        fetchNotifications,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        updatePreferences,
        refreshUnreadCount,
        requestPermission,
        deleteNotification,
        deleteAllNotifications,
        clearError,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export default NotificationContext;
