import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { usePremium } from '@/contexts/PremiumContext';
import { 
  Phone, 
  Shield, 
  Key, 
  MessageSquare, 
  Check, 
  AlertCircle, 
  Loader2,
  Info,
  Crown,
  Lock
} from 'lucide-react';

// =============================================================================
// PHONE NUMBER SETUP - FREE FEATURE
// Used for: Trust, account recovery, and required for SMS/premium features
// =============================================================================

interface PhoneNumberSetupProps {
  onPhoneVerified?: () => void;
}

const PhoneNumberSetup: React.FC<PhoneNumberSetupProps> = ({ onPhoneVerified }) => {
  const { user, profile } = useAuth();
  const { isPremium, canUseFeature } = usePremium();
  
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [step, setStep] = useState<'input' | 'verify' | 'verified'>('input');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [countdown, setCountdown] = useState(0);

  // Check if user already has a verified phone number
  useEffect(() => {
    if (profile?.phone_number && profile?.phone_verified) {
      setPhoneNumber(profile.phone_number);
      setStep('verified');
    } else if (profile?.phone_number) {
      setPhoneNumber(profile.phone_number);
    }
  }, [profile]);

  // Countdown timer for resend
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const formatPhoneNumber = (value: string) => {
    // Remove all non-digits
    const digits = value.replace(/\D/g, '');
    
    // Format as +1 (XXX) XXX-XXXX for US numbers
    if (digits.length <= 1) return digits;
    if (digits.length <= 4) return `+${digits.slice(0, 1)} (${digits.slice(1)}`;
    if (digits.length <= 7) return `+${digits.slice(0, 1)} (${digits.slice(1, 4)}) ${digits.slice(4)}`;
    return `+${digits.slice(0, 1)} (${digits.slice(1, 4)}) ${digits.slice(4, 7)}-${digits.slice(7, 11)}`;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhoneNumber(e.target.value);
    setPhoneNumber(formatted);
    setError(null);
  };

  const sendVerificationCode = async () => {
    if (!user) return;
    
    // Extract digits only
    const digits = phoneNumber.replace(/\D/g, '');
    if (digits.length < 10) {
      setError('Please enter a valid phone number');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // In production, this would call an edge function to send SMS
      // For now, we'll simulate the flow
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ 
          phone_number: `+${digits}`,
          phone_verified: false,
          phone_verification_sent_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (updateError) throw updateError;

      setStep('verify');
      setCountdown(60); // 60 second cooldown for resend
      setSuccess('Verification code sent! Check your phone.');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Failed to send verification code:', err);
      setError('Failed to send verification code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const verifyCode = async () => {
    if (!user) return;
    
    if (verificationCode.length !== 6) {
      setError('Please enter the 6-digit code');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // In production, this would verify the code via an edge function
      // For demo purposes, accept any 6-digit code
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ 
          phone_verified: true,
          phone_verified_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (updateError) throw updateError;

      setStep('verified');
      setSuccess('Phone number verified successfully!');
      onPhoneVerified?.();
    } catch (err) {
      console.error('Failed to verify code:', err);
      setError('Invalid verification code. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const removePhoneNumber = async () => {
    if (!user) return;
    
    setLoading(true);
    setError(null);

    try {
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ 
          phone_number: null,
          phone_verified: false,
          phone_verified_at: null
        })
        .eq('id', user.id);

      if (updateError) throw updateError;

      setPhoneNumber('');
      setVerificationCode('');
      setStep('input');
      setSuccess('Phone number removed.');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err) {
      console.error('Failed to remove phone number:', err);
      setError('Failed to remove phone number. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const canUseSMS = canUseFeature('smsNotifications');

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Phone className="w-5 h-5 text-gold" />
          Phone Number
        </h3>
        <p className="text-sm text-gray-400 mt-1">
          Add your phone number for account recovery and trust verification
        </p>
      </div>

      {/* Benefits of adding phone number */}
      <div className="p-4 bg-charcoal-600/50 rounded-xl border border-charcoal-500">
        <h4 className="text-sm font-medium text-white mb-3">Why add your phone number?</h4>
        <div className="space-y-2">
          <div className="flex items-start gap-2">
            <Shield className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm text-gray-300">Account Recovery</p>
              <p className="text-xs text-gray-500">Recover your account if you lose access to email</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <Key className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm text-gray-300">Trust Signal</p>
              <p className="text-xs text-gray-500">Verified phone numbers increase profile trust</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            {canUseSMS ? (
              <MessageSquare className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
            ) : (
              <Lock className="w-4 h-4 text-gray-500 mt-0.5 flex-shrink-0" />
            )}
            <div>
              <p className="text-sm text-gray-300 flex items-center gap-2">
                SMS Notifications
                {!canUseSMS && (
                  <span className="px-1.5 py-0.5 bg-gold/20 text-gold text-xs rounded flex items-center gap-1">
                    <Crown className="w-3 h-3" />
                    Premium
                  </span>
                )}
              </p>
              <p className="text-xs text-gray-500">
                {canUseSMS 
                  ? 'Receive SMS alerts for matches and important events'
                  : 'Upgrade to Premium to enable SMS notifications'
                }
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Status messages */}
      {error && (
        <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      {success && (
        <div className="flex items-center gap-2 p-3 bg-green-500/10 border border-green-500/30 rounded-xl text-green-400 text-sm">
          <Check className="w-4 h-4 flex-shrink-0" />
          {success}
        </div>
      )}

      {/* Phone number input */}
      {step === 'input' && (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Phone Number
            </label>
            <input
              type="tel"
              value={phoneNumber}
              onChange={handlePhoneChange}
              placeholder="+1 (555) 123-4567"
              className="w-full px-4 py-3 bg-charcoal-600 border border-charcoal-500 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
            />
            <p className="text-xs text-gray-500 mt-1">
              We'll send a verification code to this number
            </p>
          </div>

          <button
            onClick={sendVerificationCode}
            disabled={loading || phoneNumber.replace(/\D/g, '').length < 10}
            className="w-full py-3 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Sending...
              </>
            ) : (
              <>
                <Phone className="w-5 h-5" />
                Send Verification Code
              </>
            )}
          </button>
        </div>
      )}

      {/* Verification code input */}
      {step === 'verify' && (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Verification Code
            </label>
            <input
              type="text"
              value={verificationCode}
              onChange={(e) => {
                const value = e.target.value.replace(/\D/g, '').slice(0, 6);
                setVerificationCode(value);
                setError(null);
              }}
              placeholder="Enter 6-digit code"
              maxLength={6}
              className="w-full px-4 py-3 bg-charcoal-600 border border-charcoal-500 rounded-xl text-white text-center text-2xl tracking-widest placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
            />
            <p className="text-xs text-gray-500 mt-1 text-center">
              Code sent to {phoneNumber}
            </p>
          </div>

          <button
            onClick={verifyCode}
            disabled={loading || verificationCode.length !== 6}
            className="w-full py-3 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Verifying...
              </>
            ) : (
              <>
                <Check className="w-5 h-5" />
                Verify Code
              </>
            )}
          </button>

          <div className="flex items-center justify-between">
            <button
              onClick={() => {
                setStep('input');
                setVerificationCode('');
              }}
              className="text-sm text-gray-400 hover:text-white transition-colors"
            >
              Change number
            </button>
            <button
              onClick={sendVerificationCode}
              disabled={countdown > 0 || loading}
              className="text-sm text-gold hover:text-gold-400 transition-colors disabled:text-gray-500 disabled:cursor-not-allowed"
            >
              {countdown > 0 ? `Resend in ${countdown}s` : 'Resend code'}
            </button>
          </div>
        </div>
      )}

      {/* Verified state */}
      {step === 'verified' && (
        <div className="space-y-4">
          <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500/20 rounded-full flex items-center justify-center">
                <Check className="w-5 h-5 text-green-400" />
              </div>
              <div>
                <p className="font-medium text-green-400">Phone Verified</p>
                <p className="text-sm text-gray-400">{phoneNumber}</p>
              </div>
            </div>
          </div>

          {/* SMS notification status */}
          {canUseSMS ? (
            <div className="p-4 bg-purple-500/10 border border-purple-500/30 rounded-xl">
              <div className="flex items-start gap-3">
                <MessageSquare className="w-5 h-5 text-purple-400 mt-0.5" />
                <div>
                  <p className="font-medium text-purple-400">SMS Notifications Available</p>
                  <p className="text-sm text-gray-400">
                    You can now enable SMS notifications in your Email & Notifications settings.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-4 bg-gold/10 border border-gold/30 rounded-xl">
              <div className="flex items-start gap-3">
                <Crown className="w-5 h-5 text-gold mt-0.5" />
                <div>
                  <p className="font-medium text-gold">Unlock SMS Notifications</p>
                  <p className="text-sm text-gray-400">
                    Upgrade to Premium to receive SMS alerts for matches and important events.
                  </p>
                </div>
              </div>
            </div>
          )}

          <button
            onClick={removePhoneNumber}
            disabled={loading}
            className="w-full py-3 text-red-400 hover:bg-red-500/10 font-medium rounded-xl transition-all border border-red-500/30 flex items-center justify-center gap-2"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              'Remove Phone Number'
            )}
          </button>
        </div>
      )}

      {/* Privacy notice */}
      <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
        <div className="flex items-start gap-2">
          <Info className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-blue-300">
            Your phone number is private and never shared with other users. 
            It's only used for account recovery and optional SMS notifications.
          </p>
        </div>
      </div>
    </div>
  );
};

export default PhoneNumberSetup;
