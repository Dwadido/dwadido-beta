import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { 
  RotateCcw, 
  Calendar, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Loader2,
  CreditCard,
  ChevronDown,
  ChevronUp,
  RefreshCw,
  X
} from 'lucide-react';

type SupportedLanguage = 'en' | 'es' | 'fr' | 'de';

interface RetryRecord {
  id: string;
  payment_intent_id: string;
  amount: number;
  currency: string;
  status: string;
  retry_count: number;
  max_retries: number;
  next_retry_at: string | null;
  last_retry_at: string | null;
  failure_reason: string | null;
  created_at: string;
  retry_history: Array<{
    event: string;
    timestamp: string;
    attempt?: number;
    error?: string;
    next_retry?: string;
  }>;
}

const UI_TEXT = {
  en: {
    title: 'Payment Retry Status',
    description: 'Track automatic payment retry attempts',
    noRetries: 'No active payment retries',
    noRetriesDesc: 'When a payment fails, automatic retries will appear here',
    status: 'Status',
    nextRetry: 'Next Retry',
    lastAttempt: 'Last Attempt',
    attempts: 'Attempts',
    amount: 'Amount',
    reason: 'Failure Reason',
    retryNow: 'Retry Now',
    cancel: 'Cancel Retries',
    viewHistory: 'View History',
    hideHistory: 'Hide History',
    retrying: 'Processing...',
    statusLabels: {
      pending: 'Pending',
      scheduled: 'Scheduled',
      retrying: 'Retrying',
      succeeded: 'Succeeded',
      failed: 'Failed',
      cancelled: 'Cancelled',
      manual_intervention: 'Manual Action Required'
    },
    historyEvents: {
      scheduled: 'Retry scheduled',
      success: 'Payment successful',
      failure: 'Retry failed',
      rescheduled: 'Rescheduled',
      cancelled: 'Cancelled by user'
    },
    smartScheduling: 'Smart Scheduling',
    smartSchedulingDesc: 'Retries are scheduled at optimal times based on payday patterns (1st, 15th of month) and weekdays for higher success rates.'
  },
  es: {
    title: 'Estado de Reintentos de Pago',
    description: 'Seguimiento de reintentos automáticos de pago',
    noRetries: 'No hay reintentos activos',
    noRetriesDesc: 'Cuando un pago falle, los reintentos automáticos aparecerán aquí',
    status: 'Estado',
    nextRetry: 'Próximo Reintento',
    lastAttempt: 'Último Intento',
    attempts: 'Intentos',
    amount: 'Monto',
    reason: 'Razón del Fallo',
    retryNow: 'Reintentar Ahora',
    cancel: 'Cancelar Reintentos',
    viewHistory: 'Ver Historial',
    hideHistory: 'Ocultar Historial',
    retrying: 'Procesando...',
    statusLabels: {
      pending: 'Pendiente',
      scheduled: 'Programado',
      retrying: 'Reintentando',
      succeeded: 'Exitoso',
      failed: 'Fallido',
      cancelled: 'Cancelado',
      manual_intervention: 'Acción Manual Requerida'
    },
    historyEvents: {
      scheduled: 'Reintento programado',
      success: 'Pago exitoso',
      failure: 'Reintento fallido',
      rescheduled: 'Reprogramado',
      cancelled: 'Cancelado por usuario'
    },
    smartScheduling: 'Programación Inteligente',
    smartSchedulingDesc: 'Los reintentos se programan en momentos óptimos basados en patrones de día de pago (1, 15 del mes) y días laborables para mayor éxito.'
  },
  fr: {
    title: 'Statut des Réessais de Paiement',
    description: 'Suivez les tentatives de réessai automatique',
    noRetries: 'Aucun réessai actif',
    noRetriesDesc: 'Lorsqu\'un paiement échoue, les réessais automatiques apparaîtront ici',
    status: 'Statut',
    nextRetry: 'Prochain Réessai',
    lastAttempt: 'Dernière Tentative',
    attempts: 'Tentatives',
    amount: 'Montant',
    reason: 'Raison de l\'Échec',
    retryNow: 'Réessayer Maintenant',
    cancel: 'Annuler les Réessais',
    viewHistory: 'Voir l\'Historique',
    hideHistory: 'Masquer l\'Historique',
    retrying: 'Traitement...',
    statusLabels: {
      pending: 'En attente',
      scheduled: 'Programmé',
      retrying: 'En cours',
      succeeded: 'Réussi',
      failed: 'Échoué',
      cancelled: 'Annulé',
      manual_intervention: 'Action Manuelle Requise'
    },
    historyEvents: {
      scheduled: 'Réessai programmé',
      success: 'Paiement réussi',
      failure: 'Réessai échoué',
      rescheduled: 'Reprogrammé',
      cancelled: 'Annulé par l\'utilisateur'
    },
    smartScheduling: 'Planification Intelligente',
    smartSchedulingDesc: 'Les réessais sont planifiés aux moments optimaux basés sur les jours de paie (1er, 15 du mois) et jours ouvrables pour un meilleur taux de réussite.'
  },
  de: {
    title: 'Zahlungswiederholungs-Status',
    description: 'Verfolgen Sie automatische Zahlungswiederholungen',
    noRetries: 'Keine aktiven Wiederholungen',
    noRetriesDesc: 'Bei fehlgeschlagenen Zahlungen erscheinen automatische Wiederholungen hier',
    status: 'Status',
    nextRetry: 'Nächste Wiederholung',
    lastAttempt: 'Letzter Versuch',
    attempts: 'Versuche',
    amount: 'Betrag',
    reason: 'Fehlergrund',
    retryNow: 'Jetzt Wiederholen',
    cancel: 'Wiederholungen Abbrechen',
    viewHistory: 'Verlauf Anzeigen',
    hideHistory: 'Verlauf Ausblenden',
    retrying: 'Verarbeitung...',
    statusLabels: {
      pending: 'Ausstehend',
      scheduled: 'Geplant',
      retrying: 'Wird wiederholt',
      succeeded: 'Erfolgreich',
      failed: 'Fehlgeschlagen',
      cancelled: 'Abgebrochen',
      manual_intervention: 'Manuelle Aktion Erforderlich'
    },
    historyEvents: {
      scheduled: 'Wiederholung geplant',
      success: 'Zahlung erfolgreich',
      failure: 'Wiederholung fehlgeschlagen',
      rescheduled: 'Neu geplant',
      cancelled: 'Vom Benutzer abgebrochen'
    },
    smartScheduling: 'Intelligente Planung',
    smartSchedulingDesc: 'Wiederholungen werden zu optimalen Zeiten basierend auf Gehaltstagen (1., 15. des Monats) und Werktagen für höhere Erfolgsraten geplant.'
  }
};

const STATUS_STYLES: Record<string, { bg: string; text: string; icon: React.FC<{ className?: string }> }> = {
  pending: { bg: 'bg-yellow-500/20', text: 'text-yellow-400', icon: Clock },
  scheduled: { bg: 'bg-blue-500/20', text: 'text-blue-400', icon: Calendar },
  retrying: { bg: 'bg-orange-500/20', text: 'text-orange-400', icon: RefreshCw },
  succeeded: { bg: 'bg-green-500/20', text: 'text-green-400', icon: CheckCircle },
  failed: { bg: 'bg-red-500/20', text: 'text-red-400', icon: XCircle },
  cancelled: { bg: 'bg-gray-500/20', text: 'text-gray-400', icon: X },
  manual_intervention: { bg: 'bg-purple-500/20', text: 'text-purple-400', icon: AlertTriangle }
};

const PaymentRetryStatus: React.FC = () => {
  const { user } = useAuth();
  const { language: appLanguage } = useI18n();
  
  const language: SupportedLanguage = ['en', 'es', 'fr', 'de'].includes(appLanguage) 
    ? appLanguage as SupportedLanguage 
    : 'en';
  
  const text = UI_TEXT[language];
  
  const [retries, setRetries] = useState<RetryRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [retryingId, setRetryingId] = useState<string | null>(null);
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      loadRetries();
    }
  }, [user]);

  const loadRetries = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('process-payment-retry', {
        body: { action: 'status', userId: user.id }
      });

      if (error) throw error;
      setRetries(data?.retries || []);
    } catch (err) {
      console.error('Failed to load retries:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRetryNow = async (retryId: string) => {
    setRetryingId(retryId);
    try {
      const { error } = await supabase.functions.invoke('process-payment-retry', {
        body: { action: 'retry_now', retryId }
      });

      if (error) throw error;
      await loadRetries();
    } catch (err) {
      console.error('Failed to trigger retry:', err);
    } finally {
      setRetryingId(null);
    }
  };

  const handleCancel = async (retryId: string) => {
    setCancellingId(retryId);
    try {
      const { error } = await supabase.functions.invoke('process-payment-retry', {
        body: { action: 'cancel', retryId }
      });

      if (error) throw error;
      await loadRetries();
    } catch (err) {
      console.error('Failed to cancel retry:', err);
    } finally {
      setCancellingId(null);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const locales: Record<string, string> = {
      en: 'en-US',
      es: 'es-ES',
      fr: 'fr-FR',
      de: 'de-DE'
    };
    return date.toLocaleDateString(locales[language], {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatAmount = (amount: number, currency: string) => {
    // Use European locale for EUR, otherwise default to appropriate locale
    const locale = currency.toUpperCase() === 'EUR' ? 'de-DE' : 'en-US';
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: currency.toUpperCase()
    }).format(amount / 100);
  };


  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 text-gold animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <RotateCcw className="w-5 h-5 text-gold" />
          {text.title}
        </h3>
        <p className="text-sm text-gray-400 mt-1">{text.description}</p>
      </div>

      {/* Smart scheduling info */}
      <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
        <h4 className="text-sm font-medium text-blue-300 flex items-center gap-2">
          <Calendar className="w-4 h-4" />
          {text.smartScheduling}
        </h4>
        <p className="text-xs text-blue-400/80 mt-1">
          {text.smartSchedulingDesc}
        </p>
      </div>

      {retries.length === 0 ? (
        <div className="text-center py-8 bg-charcoal-700/50 rounded-xl border border-charcoal-600">
          <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-3" />
          <p className="text-white font-medium">{text.noRetries}</p>
          <p className="text-sm text-gray-400 mt-1">{text.noRetriesDesc}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {retries.map((retry) => {
            const statusStyle = STATUS_STYLES[retry.status] || STATUS_STYLES.pending;
            const StatusIcon = statusStyle.icon;
            const isExpanded = expandedId === retry.id;
            const isActive = ['pending', 'scheduled', 'retrying'].includes(retry.status);
            const canRetry = isActive && retry.retry_count < retry.max_retries && retry.status !== 'retrying';

            return (
              <div 
                key={retry.id}
                className="bg-charcoal-700 rounded-xl border border-charcoal-600 overflow-hidden"
              >
                <div className="p-4">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${statusStyle.bg}`}>
                        <CreditCard className={`w-5 h-5 ${statusStyle.text}`} />
                      </div>
                      <div>
                        <p className="font-medium text-white">
                          {formatAmount(retry.amount, retry.currency)}
                        </p>
                        <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs ${statusStyle.bg} ${statusStyle.text}`}>
                          <StatusIcon className="w-3 h-3" />
                          {text.statusLabels[retry.status as keyof typeof text.statusLabels] || retry.status}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Progress */}
                  <div className="mb-3">
                    <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                      <span>{text.attempts}</span>
                      <span>{retry.retry_count} / {retry.max_retries}</span>
                    </div>
                    <div className="h-2 bg-charcoal-600 rounded-full overflow-hidden">
                      <div 
                        className={`h-full transition-all duration-500 ${
                          retry.retry_count >= retry.max_retries 
                            ? 'bg-red-500' 
                            : retry.retry_count >= retry.max_retries - 1 
                              ? 'bg-orange-500' 
                              : 'bg-blue-500'
                        }`}
                        style={{ width: `${(retry.retry_count / retry.max_retries) * 100}%` }}
                      />
                    </div>
                  </div>

                  {/* Info grid */}
                  <div className="grid grid-cols-2 gap-3 text-sm mb-3">
                    {retry.next_retry_at && isActive && (
                      <div>
                        <p className="text-xs text-gray-500">{text.nextRetry}</p>
                        <p className="text-gray-300">{formatDate(retry.next_retry_at)}</p>
                      </div>
                    )}
                    {retry.last_retry_at && (
                      <div>
                        <p className="text-xs text-gray-500">{text.lastAttempt}</p>
                        <p className="text-gray-300">{formatDate(retry.last_retry_at)}</p>
                      </div>
                    )}
                    {retry.failure_reason && (
                      <div className="col-span-2">
                        <p className="text-xs text-gray-500">{text.reason}</p>
                        <p className="text-red-400 text-xs">{retry.failure_reason}</p>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    {canRetry && (
                      <button
                        onClick={() => handleRetryNow(retry.id)}
                        disabled={retryingId === retry.id}
                        className="flex-1 py-2 px-3 text-sm font-medium rounded-lg bg-gold text-charcoal hover:bg-gold-400 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                      >
                        {retryingId === retry.id ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin" />
                            {text.retrying}
                          </>
                        ) : (
                          <>
                            <RotateCcw className="w-4 h-4" />
                            {text.retryNow}
                          </>
                        )}
                      </button>
                    )}
                    {isActive && (
                      <button
                        onClick={() => handleCancel(retry.id)}
                        disabled={cancellingId === retry.id}
                        className="py-2 px-3 text-sm font-medium rounded-lg bg-charcoal-600 text-gray-300 hover:bg-charcoal-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                      >
                        {cancellingId === retry.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <X className="w-4 h-4" />
                            {text.cancel}
                          </>
                        )}
                      </button>
                    )}
                    <button
                      onClick={() => setExpandedId(isExpanded ? null : retry.id)}
                      className="py-2 px-3 text-sm text-gray-400 hover:text-white transition-colors flex items-center gap-1"
                    >
                      {isExpanded ? (
                        <>
                          <ChevronUp className="w-4 h-4" />
                          {text.hideHistory}
                        </>
                      ) : (
                        <>
                          <ChevronDown className="w-4 h-4" />
                          {text.viewHistory}
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* History */}
                {isExpanded && retry.retry_history && retry.retry_history.length > 0 && (
                  <div className="border-t border-charcoal-600 p-4 bg-charcoal-800/50">
                    <div className="space-y-3">
                      {retry.retry_history.slice().reverse().map((event, idx) => (
                        <div key={idx} className="flex items-start gap-3">
                          <div className={`w-2 h-2 rounded-full mt-1.5 ${
                            event.event === 'success' ? 'bg-green-400' :
                            event.event === 'failure' ? 'bg-red-400' :
                            event.event === 'cancelled' ? 'bg-gray-400' :
                            'bg-blue-400'
                          }`} />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-gray-300">
                              {text.historyEvents[event.event as keyof typeof text.historyEvents] || event.event}
                              {event.attempt && ` #${event.attempt}`}
                            </p>
                            <p className="text-xs text-gray-500">
                              {formatDate(event.timestamp)}
                            </p>
                            {event.error && (
                              <p className="text-xs text-red-400 mt-1">{event.error}</p>
                            )}
                            {event.next_retry && (
                              <p className="text-xs text-blue-400 mt-1">
                                {text.nextRetry}: {formatDate(event.next_retry)}
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default PaymentRetryStatus;
