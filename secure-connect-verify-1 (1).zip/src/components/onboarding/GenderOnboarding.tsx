import React, { useState, useEffect } from 'react';
import { useAuth, GenderType, GENDER_LABELS } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { Heart, Users, User, Sparkles, Check, Loader2 } from 'lucide-react';

interface GenderOnboardingProps {
  isOpen: boolean;
  onComplete: () => void;
}

const GENDER_OPTIONS: { value: GenderType; icon: React.ReactNode; description: string }[] = [
  {
    value: 'women',
    icon: <User className="w-7 h-7" />,
    description: 'Show me women in my matches'
  },
  {
    value: 'men',
    icon: <User className="w-7 h-7" />,
    description: 'Show me men in my matches'
  },
  {
    value: 'everyone',
    icon: <Users className="w-7 h-7" />,
    description: 'Show me everyone in my matches'
  }
];

const GenderOnboarding: React.FC<GenderOnboardingProps> = ({ isOpen, onComplete }) => {
  const { updateProfile } = useAuth();
  const { t } = useI18n();
  const [selectedGender, setSelectedGender] = useState<GenderType | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Handle body scroll lock for iOS (same pattern as AuthModal)
  useEffect(() => {
    if (isOpen) {
      const scrollY = window.scrollY;
      document.body.style.position = 'fixed';
      document.body.style.top = `-${scrollY}px`;
      document.body.style.width = '100%';
    } else {
      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);
    }

    return () => {
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
    };
  }, [isOpen]);

  const handleSave = async () => {
    if (!selectedGender) return;

    setSaving(true);
    setError(null);

    try {
      const { error: updateError } = await updateProfile({
        gender: selectedGender,
        intent: 'dating',
      });
      
      if (updateError) {
        setError('Failed to save your preference. Please try again.');
        console.error('Error saving gender preference:', updateError);
      } else {
        onComplete();
      }
    } catch (err) {
      setError('An unexpected error occurred. Please try again.');
      console.error('Error in handleSave:', err);
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden"
      style={{ WebkitOverflowScrolling: 'touch' } as React.CSSProperties}
    >
      {/* Backdrop - no onClick since onboarding is mandatory */}
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" />

      {/* Scrollable content wrapper */}
      <div className="relative min-h-full flex items-center justify-center p-4 py-8">
        <div className="relative w-full max-w-md bg-[#1C1C1C] rounded-2xl shadow-2xl border border-[#2a2a2a] animate-in fade-in zoom-in duration-300">
          
          {/* Header */}
          <div className="px-6 pt-8 pb-4 text-center">
            <div className="mx-auto w-14 h-14 bg-gradient-to-br from-[#C9A24D]/20 to-[#C9A24D]/10 rounded-2xl flex items-center justify-center mb-4">
              <Heart className="w-7 h-7 text-[#C9A24D]" />
            </div>
            <h2 className="text-2xl font-bold text-white">
              {t('onboarding.genderTitle') || 'Who would you like to meet?'}
            </h2>
            <p className="text-gray-400 mt-2 text-sm">
              {t('onboarding.genderDescription') || 'Help us personalize your experience by telling us who you\'d like to see in your matches.'}
            </p>
          </div>

          {/* Body */}
          <div className="px-6 pb-6">
            {/* Welcome message */}
            <div className="bg-[#C9A24D]/10 border border-[#C9A24D]/20 rounded-xl p-3 mb-5">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-[#C9A24D] flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm text-[#C9A24D] font-medium">
                    {t('onboarding.welcomeMessage') || 'Welcome to Dwadido!'}
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    {t('onboarding.welcomeSubtext') || 'This helps us show you the most relevant connections. You can change this anytime in your profile settings.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Gender selection options */}
            <div className="space-y-3">
              {GENDER_OPTIONS.map((option) => (
                <button
                  key={option.value}
                  onClick={() => setSelectedGender(option.value)}
                  className={`w-full p-4 rounded-xl border-2 transition-all duration-200 flex items-center gap-4 ${
                    selectedGender === option.value
                      ? 'border-[#C9A24D] bg-[#C9A24D]/10 shadow-lg shadow-[#C9A24D]/10'
                      : 'border-[#2a2a2a] bg-[#1a1a1a] hover:border-[#3a3a3a] hover:bg-[#222]'
                  }`}
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${
                    selectedGender === option.value
                      ? 'bg-[#C9A24D]/20 text-[#C9A24D]'
                      : 'bg-[#2a2a2a] text-gray-400'
                  }`}>
                    {option.icon}
                  </div>
                  <div className="flex-1 text-left">
                    <p className={`font-semibold text-base ${
                      selectedGender === option.value ? 'text-[#C9A24D]' : 'text-white'
                    }`}>
                      {GENDER_LABELS[option.value]}
                    </p>
                    <p className="text-sm text-gray-400">
                      {option.description}
                    </p>
                  </div>
                  {selectedGender === option.value && (
                    <div className="w-7 h-7 bg-[#C9A24D] rounded-full flex items-center justify-center flex-shrink-0">
                      <Check className="w-4 h-4 text-[#141414]" />
                    </div>
                  )}
                </button>
              ))}
            </div>

            {/* Error message */}
            {error && (
              <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                <p className="text-sm text-red-400">{error}</p>
              </div>
            )}

            {/* Action button */}
            <div className="mt-6">
              <button
                onClick={handleSave}
                disabled={!selectedGender || saving}
                className="w-full py-4 bg-[#C9A24D] hover:bg-[#D4AF5B] text-[#141414] font-semibold text-lg rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(201,162,77,0.2)]"
              >
                {saving ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    {t('common.saving') || 'Saving...'}
                  </>
                ) : (
                  t('onboarding.continue') || 'Continue'
                )}
              </button>
              
              <p className="text-xs text-gray-500 text-center mt-4">
                {t('onboarding.privacyNote') || 'Your preference is private and only used to filter your matches.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GenderOnboarding;
