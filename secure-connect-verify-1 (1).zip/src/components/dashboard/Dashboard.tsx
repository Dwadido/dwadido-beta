// Dashboard — Build 2026-02-19T17:10:00Z-v5 (RLS fix: session refresh + diagnostic fallback query)


import React, { useState, useEffect, useRef, useCallback } from 'react';


import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useAuth, IntentType, RelationshipStatusType, GenderType } from '@/contexts/AuthContext';
import { DWADIDO_CODE_EXPIRY_HOURS, DWADIDO_CODE_EXPIRY_DAYS } from '@/lib/globalData';

import { useI18n } from '@/contexts/I18nContext';
import CrushCard from './CrushCard';
import CodeRedeemer from './CodeRedeemer';
import MatchCard from './MatchCard';
import ChatModal from './ChatModal';
import ProfileCard from './ProfileCard';



import ProfileEditor from '../profile/ProfileEditor';
import CrushCardScreen from './CrushCardScreen';
import CrushCodeAnalytics from './CrushCodeAnalytics';
import ConnectionHistoryView from './ConnectionHistoryView';
import ShareAndEarn from './ShareAndEarn';
import GenderOnboarding from '../onboarding/GenderOnboarding';
import PhotoRequirementGate from '../profile/PhotoRequirementGate';
import { Plus, Loader2, CreditCard, Users, Shield, RefreshCw, Heart, MapPin, AlertTriangle, WifiOff } from 'lucide-react';


/**
 * =============================================================================
 * DWADIDO DASHBOARD
 * =============================================================================
 * 
 * V1 Design Decisions:
 * - Profile Search Filters REMOVED - Dwadido is intent-led, not search-led
 * - Connections show all matches without filtering
 * - Focus on stability, trust, and simplicity
 * - No gamification, no engagement mechanics
 * - PHOTO REQUIREMENT: Users must have at least 1 real photo to view connections
 * 
 * Users should feel: Understood, Respected, In control
 * =============================================================================
 */

interface CrushCardData {
  id: string;
  code: string;
  status: string;
  expires_at: string;
  created_at: string;
}

interface MatchData {
  id: string;
  status: string;
  confirmed_at: string;
  user1_id: string;
  user2_id: string;
  other_user: {
    id: string;
    display_name: string | null;
    avatar_url: string | null;
    bio: string | null;
    interest_tags: string[];
    intent?: IntentType | null;
    relationship_status?: RelationshipStatusType | null;
    gender?: GenderType | null;
    date_of_birth?: string | null;
  };
}

const Dashboard: React.FC = () => {
  const { user, profile, refreshProfile, error: authError, retryProfile, clearError } = useAuth();

  const { t } = useI18n();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'cards' | 'connections'>('cards');
  const [cards, setCards] = useState<CrushCardData[]>([]);
  const [matches, setMatches] = useState<MatchData[]>([]);
  const [loading, setLoading] = useState(true);
  // ── Match count: only trust the count AFTER the first successful fetch ──
  const [matchCountReady, setMatchCountReady] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [generateError, setGenerateError] = useState<string | null>(null);
  const [selectedMatch, setSelectedMatch] = useState<MatchData | null>(null);
  const [profileEditorOpen, setProfileEditorOpen] = useState(false);
  const [showCrushCardScreen, setShowCrushCardScreen] = useState(false);
  const [showGenderOnboarding, setShowGenderOnboarding] = useState(false);

  // ── Cache: Preserve previous match profile data to prevent "Anonymous" flicker ──
  const matchProfileCacheRef = useRef<Map<string, MatchData['other_user']>>(new Map());


  // Check if user needs gender onboarding (NULL gender value)
  useEffect(() => {
    if (profile && profile.gender === null) {
      setShowGenderOnboarding(true);
    }
  }, [profile]);

  const handleGenderOnboardingComplete = async () => {
    setShowGenderOnboarding(false);
    await refreshProfile();
  };

  const fetchData = async () => {
    if (!user) return;
    setLoading(true);

    // Fetch cards
    const { data: cardsData } = await supabase
      .from('crush_cards')
      .select('*')
      .eq('creator_id', user.id)
      .order('created_at', { ascending: false });

    if (cardsData) {
      setCards(cardsData);
    }

    // ── Fetch matches — LOGGING for match count bug ──
    console.log('[Dashboard] Fetching matches for user:', user.id);
    const { data: matchesData, error: matchesError } = await supabase
      .from('matches')
      .select('*')
      .or(`user1_id.eq.${user.id},user2_id.eq.${user.id}`)
      .in('status', ['confirmed', 'active'])
      .order('confirmed_at', { ascending: false });

    if (matchesError) {
      console.error('[Dashboard] Matches query error:', {
        message: matchesError.message,
        code: matchesError.code,
        details: matchesError.details,
        hint: matchesError.hint,
      });
      setMatches([]);
      setMatchCountReady(true);
      setLoading(false);
      return;
    }

    // LOG: raw rows returned from DB (before client-side filter)
    console.log('[Dashboard] Raw matches from DB:', matchesData?.length ?? 0,
      matchesData?.map(m => ({
        id: m.id,
        user1: m.user1_id,
        user2: m.user2_id,
        status: m.status,
        mine: m.user1_id === user.id || m.user2_id === user.id,
      }))
    );

    // SAFETY: Client-side filter — belt-and-suspenders guard against RLS leak
    const myMatches = (matchesData || []).filter(
      (m) => m.user1_id === user.id || m.user2_id === user.id
    );

    // LOG: filtered count
    if (myMatches.length !== (matchesData || []).length) {
      console.warn('[Dashboard] CLIENT-SIDE FILTER REMOVED ROWS!',
        'raw:', (matchesData || []).length,
        'filtered:', myMatches.length,
        'leaked rows:', (matchesData || []).filter(m => m.user1_id !== user.id && m.user2_id !== user.id)
      );
    }

    if (myMatches.length > 0) {
      const matchesWithProfiles = await Promise.all(
        myMatches.map(async (match) => {
          const otherUserId = match.user1_id === user.id ? match.user2_id : match.user1_id;

          try {
            const { data: fetchedProfile, error: profileError } = await supabase
              .from('profiles')
              .select('id, display_name, avatar_url, bio, interest_tags, intent, relationship_status, gender, date_of_birth, communication_style, love_style, lifestyle_factors, city, values_causes')
              .eq('id', otherUserId)
              .single();

            if (profileError) {
              console.warn(`[Dashboard] Profile fetch failed for user ${otherUserId}:`, {
                message: profileError.message,
                code: profileError.code,
              });
              const cached = matchProfileCacheRef.current.get(otherUserId);
              if (cached) {
                return { ...match, other_user: cached };
              }
              return {
                ...match,
                other_user: {
                  id: otherUserId, display_name: null, avatar_url: null, bio: null,
                  interest_tags: [], gender: null, date_of_birth: null,
                  communication_style: null, love_style: null, lifestyle_factors: null,
                  city: null, values_causes: null
                }
              };
            }

            const otherUser = fetchedProfile || {
              id: otherUserId, display_name: null, avatar_url: null, bio: null,
              interest_tags: [], gender: null, date_of_birth: null,
              communication_style: null, love_style: null, lifestyle_factors: null,
              city: null, values_causes: null
            };

            matchProfileCacheRef.current.set(otherUserId, otherUser);
            return { ...match, other_user: otherUser };
          } catch (err) {
            console.error(`[Dashboard] Unexpected error fetching profile for ${otherUserId}:`, err);
            const cached = matchProfileCacheRef.current.get(otherUserId);
            if (cached) {
              return { ...match, other_user: cached };
            }
            return {
              ...match,
              other_user: {
                id: otherUserId, display_name: null, avatar_url: null, bio: null,
                interest_tags: [], gender: null, date_of_birth: null,
                communication_style: null, love_style: null, lifestyle_factors: null,
                city: null, values_causes: null
              }
            };
          }
        })
      );
      console.log('[Dashboard] Final match count after profile enrichment:', matchesWithProfiles.length);
      setMatches(matchesWithProfiles);
    } else {
      console.log('[Dashboard] No matches for this user — setting empty array');
      setMatches([]);
    }

    setMatchCountReady(true);
    setLoading(false);
  };



  useEffect(() => {
    // Reset match count readiness when user changes (e.g., sign-out → sign-in)
    setMatchCountReady(false);
    fetchData();
  }, [user]);

  // ── Client-side code generation ──
  function generateCrushCode(length = 6): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const arr = new Uint8Array(length);
    crypto.getRandomValues(arr);
    let code = '';
    for (let i = 0; i < length; i++) code += chars[arr[i] % chars.length];
    return code;
  }

  /**
   * Ensure the user's profile row exists before inserting a crush_card.
   * crush_cards.creator_id has FK → profiles.id, so the profile MUST exist.
   * Returns true if profile exists (or was just created), false on failure.
   */
  const ensureProfileExists = async (): Promise<boolean> => {
    if (!user) return false;

    // Fast path: check if profile already exists
    const { data: existing, error: selectErr } = await supabase
      .from('profiles')
      .select('id')
      .eq('id', user.id)
      .maybeSingle();

    if (selectErr) {
      console.error('[Dashboard] ensureProfileExists SELECT error:', selectErr.message, selectErr.code);
      // Don't fail — the INSERT might still work if the profile was just created
      return true;
    }

    if (existing) {
      return true; // Profile exists
    }

    // Profile doesn't exist — create it
    console.warn('[Dashboard] Profile not found for user', user.id, '— auto-creating before code generation');

    let authEmail = user.email || '';
    let authDisplayName = '';
    try {
      const { data: authData } = await supabase.auth.getUser();
      if (authData?.user) {
        authEmail = authData.user.email || authEmail;
        authDisplayName = authData.user.user_metadata?.display_name || '';
      }
    } catch (e) {
      console.warn('[Dashboard] Could not fetch auth user metadata:', e);
    }

    const displayName = authDisplayName || (authEmail ? authEmail.split('@')[0] : '') || 'User';

    const { error: insertErr } = await supabase
      .from('profiles')
      .insert({
        id: user.id,
        email: authEmail,
        display_name: displayName,
        intent: 'dating',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });

    if (insertErr) {
      // 23505 = unique violation — profile was created by another concurrent request (race condition)
      if (insertErr.code === '23505') {
        console.log('[Dashboard] Profile already exists (race condition) — proceeding');
        return true;
      }
      console.error('[Dashboard] Failed to auto-create profile:', insertErr.message, insertErr.code);
      return false;
    }

    console.log('[Dashboard] Auto-created profile for user:', user.id);
    // Refresh the AuthContext profile so the rest of the app sees it
    refreshProfile();
    return true;
  };

  const handleGenerateCard = async () => {
    if (!user) {
      console.error('[Dashboard] No user logged in');
      return;
    }
    
    setGenerating(true);
    setGenerateError(null);

    try {
      // ── CRITICAL: Ensure profile exists (FK constraint) ──
      console.log('[Dashboard] Ensuring profile exists before code generation...');
      const profileOk = await ensureProfileExists();
      if (!profileOk) {
        throw new Error('Could not verify your profile. Please refresh the page and try again.');
      }

      const expiresAt = new Date(Date.now() + DWADIDO_CODE_EXPIRY_HOURS * 60 * 60 * 1000).toISOString();

      let card: CrushCardData | null = null;
      let lastError: any = null;

      // Try up to 3 times in case of code collision
      for (let attempt = 0; attempt < 3; attempt++) {
        const code = generateCrushCode();
        console.log(`[Dashboard] Generating code (attempt ${attempt + 1}): ${code}, expires: ${expiresAt}`);

        const { data, error } = await supabase
          .from('crush_cards')
          .insert({
            creator_id: user.id,
            code,
            status: 'active',
            expires_at: expiresAt,
          })
          .select('id, code, status, expires_at, created_at')
          .single();

        if (error) {
          lastError = error;
          console.warn(`[Dashboard] Insert attempt ${attempt + 1} failed:`, {
            message: error.message,
            code: error.code,
            details: (error as any).details,
            hint: (error as any).hint,
          });
          if (error.code === '23505') continue; // unique collision — retry
          break;
        }

        if (data) {
          card = data as CrushCardData;
          break;
        }
      }

      if (!card) {
        const msg = lastError?.message || 'Failed to generate code.';
        console.error('[Dashboard] All code generation attempts failed:', lastError);
        throw new Error(msg);
      }

      console.log('[Dashboard] Code generated successfully:', card.code);
      setCards(prev => [card!, ...prev]);
      setGenerateError(null);

    } catch (err: any) {
      console.error('[Dashboard] Failed to generate card:', err);
      const msg = err?.message || 'Failed to generate code.';
      if (msg.includes('timed out') || msg.includes('timeout')) {
        setGenerateError('Code generation timed out. The server may be busy — please try again.');
      } else if (msg.includes('Free users') || msg.includes('free') || msg.includes('limit')) {
        setGenerateError(msg);
      } else if (msg.includes('Failed to fetch') || msg.includes('Load failed') || msg.includes('network')) {
        setGenerateError('Cannot reach the server. Please check your connection and try again.');
      } else if (msg.includes('violates row-level security') || msg.includes('row-level security')) {
        setGenerateError('Permission denied. Please sign out and sign back in, then try again.');
      } else if (msg.includes('violates foreign key') || msg.includes('foreign key')) {
        setGenerateError('Your profile is still being set up. Please refresh the page and try again in a moment.');
      } else {
        setGenerateError(msg);
      }
    } finally {
      setGenerating(false);
    }
  };


  const handleDeleteCard = async (cardId: string) => {
    setCards(cards.filter(c => c.id !== cardId));
  };

  const handleEndChat = async (matchId: string) => {
    setMatches(prev => prev.filter(m => m.id !== matchId));
    setSelectedMatch(null);
  };



  const activeCards = cards.filter(c => c.status === 'active' && new Date(c.expires_at) > new Date());
  const historyCards = cards.filter(c => c.status !== 'active' || new Date(c.expires_at) <= new Date());
  
  // V1: No filters - show all connections
  const activeConnections = matches;

  // ── BUG FIX (match count): Only show the real count after the first fetch completes.
  // Before that, show "..." to prevent a stale/phantom "1" from flashing.
  const displayMatchCount = matchCountReady ? activeConnections.length : '…';

  // ── BUG FIX: Scroll-preserving tab switch ──
  const handleTabChange = useCallback((tab: 'cards' | 'connections') => {
    if (tab === activeTab) return;
    const scrollY = window.scrollY;
    setActiveTab(tab);
    requestAnimationFrame(() => {
      window.scrollTo(0, scrollY);
    });
  }, [activeTab]);



  // Show Crush Card Screen if active
  if (showCrushCardScreen) {
    return (
      <CrushCardScreen 
        onBack={() => setShowCrushCardScreen(false)}
        onCodeGenerated={fetchData}
      />
    );
  }

  return (
    <div className="min-h-screen bg-charcoal py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">


        {/* ── Auth Error Banner ── */}
        {authError && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-2xl">
            <div className="flex items-start gap-3">
              {authError.includes('internet') || authError.includes('server') ? (
                <WifiOff className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              )}
              <div className="flex-1">
                <p className="text-red-400 font-medium text-sm">Connection Issue</p>
                <p className="text-sm text-red-300 mt-1">{authError}</p>
                <div className="flex items-center gap-3 mt-3">
                  <button
                    onClick={async () => {
                      clearError();
                      await retryProfile();
                    }}
                    className="flex items-center gap-2 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-300 rounded-lg text-sm font-medium transition-colors"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Retry
                  </button>
                  <button
                    onClick={clearError}
                    className="px-3 py-2 text-gray-400 hover:text-white text-sm transition-colors"
                  >
                    Dismiss
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}


        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">{t('nav.dashboard')}</h1>
            <p className="text-gray-400 mt-1">Manage your Crush Codes and connections</p>

          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/map')}
              className="flex items-center gap-2 px-4 py-2 bg-charcoal-700 hover:bg-charcoal-600 text-gray-300 hover:text-white font-medium rounded-xl transition-all border border-charcoal-600"
            >
              <MapPin className="w-4 h-4" />
              {t('nav.map')}
            </button>
            <button
              onClick={() => setShowCrushCardScreen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-gold hover:bg-gold-400 text-charcoal font-medium rounded-xl transition-all"
            >
              <Heart className="w-4 h-4" />
              {t('nav.myCard')}
            </button>
            <button
              onClick={fetchData}
              className="flex items-center gap-2 px-4 py-2 text-gray-400 hover:text-gold hover:bg-charcoal-700 rounded-xl transition-all"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar with Profile */}
           <div className="lg:col-span-1 space-y-6">
            <ProfileCard onEditProfile={() => setProfileEditorOpen(true)} />



            {/* Share & Earn - Referral Program */}
            <ShareAndEarn compact={true} />

            
            {/* How It Works */}
            <div className="bg-charcoal-700 rounded-2xl p-6 border border-charcoal-600">
              <h3 className="font-semibold text-white mb-4">How Dwadido Works</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gold/20 rounded-lg flex items-center justify-center">
                    <span className="text-xs font-bold text-gold">1</span>
                  </div>
                  <span className="text-sm text-gray-300">Generate a code</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gold/30 rounded-lg flex items-center justify-center">
                    <span className="text-xs font-bold text-gold">2</span>
                  </div>
                  <span className="text-sm text-gray-300">Share with someone</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gold/40 rounded-lg flex items-center justify-center">
                    <span className="text-xs font-bold text-gold">3</span>
                  </div>
                  <span className="text-sm text-gray-300">They accept, you connect</span>
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-4">
                Chats remain open until either person ends them. No time pressure.
              </p>
            </div>
          </div>

          {/* Main content */}
          <div className="lg:col-span-3">
            {/* Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
              <div className="bg-charcoal-700 rounded-2xl p-6 border border-charcoal-600">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gold/20 rounded-xl flex items-center justify-center">
                    <CreditCard className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">{activeCards.length}</p>
                    <p className="text-gray-400 text-sm">Active Codes</p>
                  </div>
                </div>
              </div>
              <div className="bg-charcoal-700 rounded-2xl p-6 border border-charcoal-600">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gold/20 rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">{displayMatchCount}</p>
                    <p className="text-gray-400 text-sm">Active Connections</p>
                  </div>
                </div>
              </div>
              <div className="bg-charcoal-700 rounded-2xl p-6 border border-charcoal-600">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gold/20 rounded-xl flex items-center justify-center">
                    <Shield className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">{cards.filter(c => c.status === 'redeemed').length}</p>
                    <p className="text-gray-400 text-sm">Verified Matches</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Crush Code Analytics - Collapsible Section */}
            <div className="mb-8">
              <CrushCodeAnalytics />
            </div>

            {/* Tabs */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex gap-2" role="tablist">
                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'cards'}
                  onClick={() => handleTabChange('cards')}
                  className={`px-6 py-3 rounded-xl font-medium transition-all ${
                    activeTab === 'cards'
                      ? 'bg-gold text-charcoal shadow-gold'
                      : 'bg-charcoal-700 text-gray-400 hover:bg-charcoal-600 hover:text-white border border-charcoal-600'
                  }`}
                >
                  Crush Codes
                </button>

                <button
                  type="button"
                  role="tab"
                  aria-selected={activeTab === 'connections'}
                  onClick={() => handleTabChange('connections')}
                  className={`px-6 py-3 rounded-xl font-medium transition-all ${
                    activeTab === 'connections'
                      ? 'bg-gold text-charcoal shadow-gold'
                      : 'bg-charcoal-700 text-gray-400 hover:bg-charcoal-600 hover:text-white border border-charcoal-600'
                  }`}
                >
                  {t('nav.matches')} ({displayMatchCount})
                </button>
              </div>
            </div>

            {/* Tab content */}
            <div className="min-h-[400px]">


            {loading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-8 h-8 text-gold animate-spin" />
              </div>
            ) : activeTab === 'cards' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Left: Generate & Active Cards */}
                <div className="space-y-6">
                  {/* Generate new card */}
                  <button
                    onClick={handleGenerateCard}
                    disabled={generating}
                    className="w-full py-6 bg-gold hover:bg-gold-400 text-charcoal rounded-2xl font-semibold shadow-gold transition-all disabled:opacity-50 flex items-center justify-center gap-3"
                  >
                    {generating ? (
                      <Loader2 className="w-6 h-6 animate-spin" />
                    ) : (
                      <Plus className="w-6 h-6" />
                    )}
                    {generating ? 'Generating...' : 'Generate New Crush Code'}
                  </button>


                  {/* Generate Error Feedback */}
                  {generateError && (
                    <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl">
                      <div className="flex items-start gap-3">
                        <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <p className="text-red-400 font-medium text-sm">Code Generation Failed</p>
                          <p className="text-sm text-red-300 mt-1">{generateError}</p>
                          <button
                            onClick={handleGenerateCard}
                            disabled={generating}
                            className="mt-2 flex items-center gap-2 px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-300 rounded-lg text-sm transition-colors disabled:opacity-50"
                          >
                            <RefreshCw className={`w-4 h-4 ${generating ? 'animate-spin' : ''}`} />
                            Try Again
                          </button>
                        </div>
                      </div>
                    </div>
                  )}


                  {/* Info */}
                  <div className="bg-gold/10 rounded-xl p-4 border border-gold/20">
                    <div className="flex items-center gap-2 text-gold font-medium mb-2">
                      <Heart className="w-5 h-5" />
                      Express Your Intent
                    </div>
                    <p className="text-sm text-gray-400">
                      Generate a code and share it with someone you want to connect with. Codes are valid for {DWADIDO_CODE_EXPIRY_DAYS} days.
                    </p>
                  </div>


                  {/* Active cards */}
                  {activeCards.length > 0 && (
                    <div>
                      <h2 className="text-lg font-semibold text-white mb-4">Active Codes</h2>
                      <div className="space-y-4">
                        {activeCards.map(card => (
                          <CrushCard key={card.id} card={card} />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* History */}
                  {historyCards.length > 0 && (
                    <div>
                      <h2 className="text-lg font-semibold text-white mb-4">History</h2>
                      <div className="space-y-4">
                        {historyCards.slice(0, 5).map(card => (
                          <CrushCard key={card.id} card={card} onDelete={handleDeleteCard} />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                {/* Right: Redeem code */}
                <div>
                  <CodeRedeemer
                    onSuccess={fetchData}
                    onGoToConnections={() => {
                      // V4: Navigate to connections tab + refresh data when user clicks "Go to Connections"
                      fetchData();
                      setActiveTab('connections');
                    }}
                  />

                  
                  {/* Info */}
                  <div className="mt-6 bg-gold/5 rounded-xl p-4 border border-gold/10">
                    <div className="flex items-center gap-2 text-gold font-medium mb-2">
                      <Shield className="w-5 h-5" />
                      Mutual Consent
                    </div>
                    <p className="text-sm text-gray-400">
                      Enter a code someone shared with you. You must explicitly accept to create a connection.
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              /* Connections Tab */
              <PhotoRequirementGate onOpenPhotoManager={() => setProfileEditorOpen(true)}>
                {activeConnections.length === 0 ? (
                  <div className="text-center py-20 bg-charcoal-700 rounded-2xl border border-charcoal-600">
                    <div className="w-20 h-20 mx-auto mb-4 bg-charcoal-600 rounded-full flex items-center justify-center">
                      <Users className="w-10 h-10 text-gray-500" />
                    </div>
                    <h3 className="text-xl font-semibold text-white mb-2">
                      {t('dashboard.noMatches')}
                    </h3>
                    <p className="text-gray-400 max-w-sm mx-auto">
                      {t('dashboard.noMatchesDesc')}
                    </p>
                  </div>
                ) : (
                  <>
                    {/* Info */}
                    <div className="mb-6 bg-gold/10 rounded-xl p-4 border border-gold/20">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-gold font-medium">
                          <Users className="w-5 h-5" />
                          Active Connections
                        </div>
                      </div>
                      <p className="text-sm text-gray-400 mt-2">
                        Your connections remain open until you choose to end them. Take your time getting to know each other.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {activeConnections.map(match => (
                        <MatchCard
                          key={match.id}
                          match={{
                            ...match,
                            stage: 3,
                            expires_at: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
                          }}
                          onOpenChat={() => setSelectedMatch(match)}
                        />
                      ))}
                    </div>

                    {/* Connection History */}
                    <div className="mt-8">
                      <ConnectionHistoryView compact={true} />
                    </div>
                  </>
                )}
              </PhotoRequirementGate>
            )}
            </div>{/* end min-h-[400px] tab content wrapper */}
          </div>

        </div>
      </div>


      {/* Chat Modal */}
      {selectedMatch && (
        <ChatModal
          isOpen={!!selectedMatch}
          onClose={() => setSelectedMatch(null)}
          matchId={selectedMatch.id}
          otherUser={selectedMatch.other_user}
          onChatEnded={handleEndChat}
        />
      )}

      {/* Profile Editor Modal */}
      <ProfileEditor
        isOpen={profileEditorOpen}
        onClose={() => setProfileEditorOpen(false)}
      />




      {/* Gender Onboarding Modal */}
      <GenderOnboarding
        isOpen={showGenderOnboarding}
        onComplete={handleGenderOnboardingComplete}
      />
    </div>
  );
};

export default Dashboard;
