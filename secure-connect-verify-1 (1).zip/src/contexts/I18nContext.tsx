// Internationalization Context for Dwadido
// Provides translation functions and language management throughout the app

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import {
  LanguageCode,
  TranslationKeys,
  getTranslations,
  formatTranslation,
  detectBrowserLanguage,
  SUPPORTED_LANGUAGES,
  ACTIVE_LANGUAGES,
  isRTL,
  LanguageInfo,
} from '@/lib/i18n';

interface I18nContextType {
  // Current language
  language: LanguageCode;
  
  // Set language
  setLanguage: (lang: LanguageCode) => void;
  
  // Translation function - t('key') or t('key', { var: 'value' })
  t: (key: string, variables?: Record<string, string | number>) => string;
  
  // Get raw translations object
  translations: TranslationKeys;
  
  // Language utilities
  isRTL: boolean;
  supportedLanguages: LanguageInfo[];
  activeLanguages: LanguageCode[];
  
  // Get language info
  getLanguageInfo: (code: LanguageCode) => LanguageInfo | undefined;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

const STORAGE_KEY = 'dwadido_language';

export const I18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize language from storage, user preference, or browser
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    if (typeof window === 'undefined') return 'en';
    
    // Check localStorage first
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored && ACTIVE_LANGUAGES.includes(stored as LanguageCode)) {
      return stored as LanguageCode;
    }
    
    // Fall back to browser detection
    return detectBrowserLanguage();
  });

  // Get translations for current language
  const translations = useMemo(() => getTranslations(language), [language]);

  // Set language and persist
  const setLanguage = useCallback((lang: LanguageCode) => {
    if (ACTIVE_LANGUAGES.includes(lang)) {
      setLanguageState(lang);
      localStorage.setItem(STORAGE_KEY, lang);
      
      // Update document direction for RTL languages
      document.documentElement.dir = isRTL(lang) ? 'rtl' : 'ltr';
      document.documentElement.lang = lang;
    }
  }, []);

  // Translation function
  const t = useCallback(
    (key: string, variables?: Record<string, string | number>): string => {
      return formatTranslation(translations, key, variables);
    },
    [translations]
  );

  // Get language info helper
  const getLanguageInfoHelper = useCallback((code: LanguageCode): LanguageInfo | undefined => {
    return SUPPORTED_LANGUAGES.find(lang => lang.code === code);
  }, []);

  // Set document language on mount and language change
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = isRTL(language) ? 'rtl' : 'ltr';
  }, [language]);

  const value: I18nContextType = {
    language,
    setLanguage,
    t,
    translations,
    isRTL: isRTL(language),
    supportedLanguages: SUPPORTED_LANGUAGES,
    activeLanguages: ACTIVE_LANGUAGES,
    getLanguageInfo: getLanguageInfoHelper,
  };

  return (
    <I18nContext.Provider value={value}>
      {children}
    </I18nContext.Provider>
  );
};

// Hook to use translations
export const useI18n = (): I18nContextType => {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
};

// Shorthand hook for just the translation function
export const useTranslation = () => {
  const { t, language } = useI18n();
  return { t, language };
};

export default I18nContext;
