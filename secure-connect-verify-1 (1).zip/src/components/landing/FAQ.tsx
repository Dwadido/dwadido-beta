import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

const faqs = [
  {
    question: 'What is Dwadido and how does it work?',
    answer: 'Dwadido is a verified-intent connection platform. You generate a unique code, share it with someone you want to connect with, and only when they enter your code does a connection form. This ensures both parties have explicitly consented to connect.'
  },
  {
    question: 'What are the 5 stages of connection?',
    answer: 'Stage 0: No connection exists. Stage 1: You generate and share a code (intent signal). Stage 2: The receiver enters and accepts the code (verification). Stage 3: A 17-day communication window opens. Stage 4: Connection closes via success, opt-out, or expiry. Stage 5: Outcome is recorded for safety and feedback.'
  },
  {
    question: 'Why is there a 17-day communication window?',
    answer: 'The 17-day window encourages meaningful connections that progress to real-world meetings. It prevents endless digital chatting and ensures connections either develop naturally or close gracefully. Either party can opt out at any time.'
  },
  {
    question: 'Can I opt out of a connection?',
    answer: 'Absolutely. Either user can opt out at any time during the 17-day window. When you opt out, all communication is immediately disabled and the connection closes. There\'s no pressure to continue any interaction you\'re not comfortable with.'
  },
  {
    question: 'Is Dwadido only for dating?',
    answer: 'No! While Dwadido works great for romantic connections, it\'s designed to be industry-agnostic. Use it for professional networking, events, customer engagement, secure business introductions, and any situation where verified mutual intent is valuable.'
  },
  {
    question: 'How do codes work?',
    answer: 'Each code is unique and one-time use. Codes expire after 48 hours if not redeemed. When someone enters your code, they must explicitly accept the connection. Only then does Stage 3 (the communication window) unlock.'
  },
  {
    question: 'What happens after the 17-day window?',
    answer: 'If both users confirm a successful real-world meeting, the connection closes positively. Otherwise, the connection automatically closes after 17 days. All interaction is disabled, and the outcome is recorded for platform integrity.'
  },
  {
    question: 'Is my data safe?',
    answer: 'Yes. We prioritize privacy and security. Your information stays private until you choose to share it. We use industry-standard encryption, and our controlled progression system ensures you\'re always in control of your connections.'
  }
];

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 bg-charcoal-800" id="faq">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold/10 rounded-full text-gold font-medium text-sm mb-6 border border-gold/20">
            <HelpCircle className="w-4 h-4" />
            FAQ
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Frequently asked questions
          </h2>
          <p className="text-lg text-gray-400">
            Everything you need to know about Dwadido and verified-intent connections.
          </p>
        </div>

        {/* FAQ items */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="border border-charcoal-600 rounded-2xl overflow-hidden bg-charcoal-700"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-charcoal-600 transition-colors"
              >
                <span className="font-semibold text-white pr-4">{faq.question}</span>
                <ChevronDown
                  className={`w-5 h-5 text-gold flex-shrink-0 transition-transform ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openIndex === index && (
                <div className="px-6 pb-6">
                  <p className="text-gray-400 leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact CTA */}
        <div className="mt-12 text-center p-8 bg-charcoal-700 rounded-2xl border border-charcoal-600">
          <h3 className="text-xl font-semibold text-white mb-2">Still have questions?</h3>
          <p className="text-gray-400 mb-4">Can't find the answer you're looking for? Our AI support assistant is here to help 24/7.</p>
          <button 
            onClick={() => {
              // Trigger the support chat to open by dispatching a custom event
              window.dispatchEvent(new CustomEvent('openSupportChat'));
            }}
            className="px-6 py-3 bg-gold text-charcoal font-medium rounded-xl hover:bg-gold-400 transition-colors shadow-gold"
          >
            Chat with Support
          </button>
        </div>

      </div>
    </section>
  );
};

export default FAQ;
