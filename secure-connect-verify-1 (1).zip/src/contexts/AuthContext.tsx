import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';

import { supabase, checkBackendConnectivity, isBackendReachable, SUPABASE_URL } from '@/lib/supabase';
import { User, Session } from '@supabase/supabase-js';
import { withTimeout, TimeoutError } from '@/lib/utils';
// V1: Welcome emails removed - no marketing/re-engagement emails

// ─── Timeout Configuration ──────────────────────────────────────────────
// Must be larger than resilientFetch's total worst-case (~28s) to avoid
// killing the operation before retries complete, but not so large that
// the user stares at a spinner for a minute.
const DB_TIMEOUT_MS = 30_000; // 30 seconds

// We no longer retry at the AuthContext level — resilientFetch already
// retries 2× with exponential backoff. Adding another retry layer on top
// just multiplies wait time without improving success rate.




// =============================================================================
// DWADIDO INTENT & PROFILE TYPES
// Aligned with AI Matching & Profile Design Instructions
// =============================================================================

// Relationship Intent (HIGHEST PRIORITY - HARD FILTER)
// Intent mismatch = no match | Intent alignment = match eligible
// Updated to align with Dwadido's core philosophy of intent-verified, offline-first connections
export type IntentType = 
  | 'friends_first'           // Friends First - standalone intent, valid intentional path
  | 'dating'                  // Dating - open to meeting new people
  | 'long_term_relationship'  // Long-Term Relationship - seeking committed relationship
  | 'lifetime_partner';       // Lifetime Partner / Marriage - looking for marriage

// Relationship Status
export type RelationshipStatusType = 'single' | 'separated' | 'divorced' | 'widowed';

// Gender type - "Show Me" / "Interested In" preference
export type GenderType = 'women' | 'men' | 'everyone';

// Communication Style (HIGH VALUE - AI INSIGHT, never hard filter)
export type CommunicationStyleType = 'direct' | 'thoughtful' | 'emotional' | null;

// Love Style (HIGH VALUE - AI INSIGHT, never hard filter)
export type LoveStyleType = 'quality_time' | 'words_of_affirmation' | 'acts_of_service' | 'physical_touch' | 'gifts' | null;

// Lifestyle Factors (MEDIUM PRIORITY - COMPATIBILITY GUARDRAILS, not hard filters)
export interface LifestyleFactors {
  smoking?: 'never' | 'occasionally' | 'regularly' | null;
  drinking?: 'never' | 'socially' | 'regularly' | null;
  family_plans?: 'want_children' | 'dont_want_children' | 'have_children' | 'open' | null;
  pets?: 'have_pets' | 'want_pets' | 'no_pets' | 'allergic' | null;
}

// Display labels for UI - Updated for Dwadido philosophy
// Intent is a HARD FILTER: Intent mismatch = no match | Intent alignment = match eligible
export const INTENT_LABELS: Record<IntentType, string> = {
  friends_first: 'Friends First',
  dating: 'Dating',
  long_term_relationship: 'Long-Term Relationship',
  lifetime_partner: 'Lifetime Partner / Marriage'
};


export const RELATIONSHIP_STATUS_LABELS: Record<RelationshipStatusType, string> = {
  single: 'Single',
  separated: 'Separated',
  divorced: 'Divorced',
  widowed: 'Widowed'
};

export const GENDER_LABELS: Record<GenderType, string> = {
  women: 'Women',
  men: 'Men',
  everyone: 'Everyone'
};

export const COMMUNICATION_STYLE_LABELS: Record<NonNullable<CommunicationStyleType>, string> = {
  direct: 'Direct',
  thoughtful: 'Thoughtful',
  emotional: 'Emotional'
};

export const LOVE_STYLE_LABELS: Record<NonNullable<LoveStyleType>, string> = {
  quality_time: 'Quality Time',
  words_of_affirmation: 'Words of Affirmation',
  acts_of_service: 'Acts of Service',
  physical_touch: 'Physical Touch',
  gifts: 'Receiving Gifts'
};

export const LIFESTYLE_LABELS = {
  smoking: {
    never: 'Non-smoker',
    occasionally: 'Social smoker',
    regularly: 'Regular smoker'
  },
  drinking: {
    never: 'Non-drinker',
    socially: 'Social drinker',
    regularly: 'Regular drinker'
  },
  family_plans: {
    want_children: 'Want children',
    dont_want_children: "Don't want children",
    have_children: 'Have children',
    open: 'Open to children'
  },
  pets: {
    have_pets: 'Have pets',
    want_pets: 'Want pets',
    no_pets: 'No pets',
    allergic: 'Allergic to pets'
  }
};


interface Profile {
  id: string;
  email: string;
  display_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  // Interests: Keep light & human (max 5-7, seed conversations, suggest dates)
  interest_tags: string[];
  privacy_settings: {
    show_bio_before_match: boolean;
    show_interests_before_match: boolean;
  };
  // RELATIONSHIP INTENT (HIGHEST PRIORITY - HARD FILTER)
  // Intent mismatch = no match | Intent alignment = match eligible
  // DB: NOT NULL, DEFAULT 'dating', CHECK (friends_first|dating|long_term_relationship|lifetime_partner)
  // ==========================================================================
  intent: IntentType;
  relationship_status: RelationshipStatusType | null;

  
  // ==========================================================================
  // COMMUNICATION & LOVE STYLE (HIGH VALUE - AI INSIGHT)
  // Used to predict compatibility, suggest tone, explain differences
  // NEVER used as hard filters, NEVER shown as scores
  // ==========================================================================
  communication_style: CommunicationStyleType;
  love_style: LoveStyleType;
  
  // ==========================================================================
  // LIFESTYLE FACTORS (MEDIUM PRIORITY - COMPATIBILITY GUARDRAILS)
  // No hard filtering unless user explicitly chooses
  // Used to lower match confidence slightly or trigger AI prompts
  // ==========================================================================
  lifestyle_factors: LifestyleFactors | null;
  
  // ==========================================================================
  // VALUES & CAUSES (OPTIONAL & USER-CONTROLLED)
  // Never required, never penalize users who skip
  // Only surface if both users opt in
  // ==========================================================================
  values_causes: string[] | null;
  
  // Gender field
  gender: GenderType | null;
  // Global-ready fields (Location: REAL-WORLD LOGIC ONLY - not for ranking)
  country: string | null;
  city: string | null;
  timezone: string | null;
  preferred_language: string | null;
  // Photo fields — public URL model (no signed URLs)
  primary_photo_path?: string | null;
  primary_photo_updated_at?: string | null;
  // Legacy field (kept for backward compat, not used for display)
  primary_photo_id?: string | null;
  photo_visibility?: 'private' | 'matches_only' | 'approved_only';

  // Admin flag
  is_admin?: boolean;

  date_of_birth?: string;
  // Suspension fields

  is_suspended?: boolean;
  suspended_at?: string;
  suspended_reason?: string;
  warning_count?: number;
  last_warning_at?: string;
  last_active_at?: string;
}







interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  loading: boolean;
  isProfileLoading: boolean;
  error: string | null;
  signUp: (email: string, password: string, displayName?: string) => Promise<{ error: Error | null }>;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ error: Error | null }>;
  updateProfile: (updates: Partial<Profile>) => Promise<{ error: Error | null }>;
  refreshProfile: () => Promise<void>;
  retryProfile: () => Promise<void>;
  clearError: () => void;
}


const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isProfileLoading, setIsProfileLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const clearError = () => setError(null);


  // ─── fetchProfile ─────────────────────────────────────────────────────
  // No retry loop here — resilientFetch already retries 2× with backoff.
  // Adding another retry layer just multiplies wait time.
  //
  // KEY FIX (v3): Never clear existing profile state during refresh.
  // If fetch fails, keep the previous profile data to prevent "Anonymous" flicker.
  //
  // KEY FIX (v4): When auto-creating a profile (PGRST116), get the real
  // auth user metadata via supabase.auth.getUser() instead of reading from
  // React state (which may be stale/null during initializeAuth).
  // This was the root cause of blank "Anonymous User" profiles being created.
  const fetchProfile = async (userId: string): Promise<boolean> => {
    setIsProfileLoading(true);
    try {
      const { data, error: queryError } = await withTimeout(
        supabase
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .single(),
        DB_TIMEOUT_MS,
        'Fetch profile'
      );
      
      if (queryError) {
        // Profile doesn't exist yet — auto-create it so .single() never returns 0 rows
        if (queryError.code === 'PGRST116') {
          console.warn('[Auth] Profile not found for user — auto-creating profile row');
          
          // ── CRITICAL FIX: Get real user metadata from the auth API ──
          // Do NOT read from `user` state — it may be null/stale when called
          // from initializeAuth (React state hasn't committed yet).
          let authEmail = '';
          let authDisplayName = '';
          try {
            const { data: authData } = await supabase.auth.getUser();
            if (authData?.user) {
              authEmail = authData.user.email || '';
              authDisplayName = authData.user.user_metadata?.display_name || '';
            }
          } catch (e) {
            console.warn('[Auth] Could not fetch auth user for metadata:', e);
          }
          
          // Build a meaningful display name from available data
          const displayName = authDisplayName 
            || (authEmail ? authEmail.split('@')[0] : '') 
            || 'User';
          
          console.log('[Auth] Auto-creating profile with:', { 
            userId, 
            email: authEmail ? '***@' + authEmail.split('@')[1] : '(none)', 
            displayName 
          });
          
          // Use INSERT (not upsert) since we know the row doesn't exist.
          const { data: newProfile, error: insertError } = await withTimeout(
            supabase
              .from('profiles')
              .insert({
                id: userId,
                email: authEmail,
                display_name: displayName,
                intent: 'dating',
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
              })
              .select()
              .single(),
            DB_TIMEOUT_MS,
            'Auto-create profile'
          );
          
          if (insertError) {
            console.error('[Auth] Failed to auto-create profile:', {
              message: insertError.message,
              code: insertError.code,
              details: insertError.details,
              hint: insertError.hint,
            });
            // Don't clear existing profile — keep previous data if any
            return false;
          }

          
          if (newProfile) {
            console.log('[Auth] Auto-created profile for user:', userId, 'display_name:', newProfile.display_name);
            setProfile(newProfile as Profile);
          }
          return true;
        }
        
        // Other query errors — log but DON'T clear existing profile
        console.error('[Auth] Error fetching profile:', {
          message: queryError.message,
          code: queryError.code,
          details: queryError.details,
          hint: queryError.hint,
        });
        return false;
      }
      
      if (data) {
        setProfile(data as Profile);
      }
      // NOTE: If data is null but no error, keep existing profile (defensive)
      return true;
    } catch (err) {
      // CRITICAL: Never clear profile on fetch failure — keep previous data
      if (err instanceof TimeoutError) {
        console.error('[Auth] Profile fetch timed out — keeping existing profile data');
        // Fast connectivity check (cached, won't block)
        const reachable = await checkBackendConnectivity();
        if (!reachable) {
          setError('Cannot reach the server. Please check your internet connection and try again.');
        } else {
          setError('Loading your profile is taking longer than expected. Please refresh the page.');
        }
      } else {
        console.error('[Auth] Unexpected error fetching profile (keeping existing data):', err);
      }
      return false;
    } finally {
      setIsProfileLoading(false);
    }
  };




  const refreshProfile = async () => {
    if (user) {
      await fetchProfile(user.id);
    }
  };

  useEffect(() => {
    let isMounted = true;

    const initializeAuth = async () => {
      try {
        // ── Fast-fail: check backend connectivity first ──
        // This is a quick HEAD request (5s timeout, cached 15s).
        // If the backend is down, we skip the slow auth flow entirely.
        const reachable = await checkBackendConnectivity();
        if (!reachable) {
          if (!isMounted) return;
          console.warn('[Auth] Backend unreachable on init — skipping auth flow');
          setError('Cannot reach the server. Please check your internet connection and refresh.');
          setLoading(false);
          return;
        }

        // Get session with timeout
        const { data: { session: currentSession } } = await withTimeout(
          supabase.auth.getSession(),
          DB_TIMEOUT_MS,
          'Get session'
        );
        
        if (!isMounted) return;
        
        setSession(currentSession);
        setUser(currentSession?.user ?? null);
        
        if (currentSession?.user) {
          const success = await fetchProfile(currentSession.user.id);
          if (!success && isMounted) {
            // Profile fetch failed but we still have auth - app can partially work
            console.warn('[Auth] Profile fetch failed, continuing with limited functionality');
          }
        }
      } catch (err) {
        if (!isMounted) return;
        
        if (err instanceof TimeoutError) {
          console.error('[Auth] Session initialization timed out');
          setError('Connection is slow. Please check your internet and refresh the page.');
        } else {
          console.error('[Auth] Error initializing auth:', err);
          setError('Failed to connect. Please refresh the page.');
        }
      } finally {
        if (isMounted) {
          setLoading(false);
        }
      }
    };

    initializeAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, newSession) => {
      if (!isMounted) return;
      
      console.log('[Auth] onAuthStateChange:', event, newSession?.user?.id ? 'has user' : 'no user');
      
      setSession(newSession);
      setUser(newSession?.user ?? null);
      
      if (newSession?.user) {
        // Don't block on profile fetch for auth state changes
        fetchProfile(newSession.user.id).catch(err => {
          console.error('[Auth] Error fetching profile on auth change:', err);
        });
        // V1: Welcome emails removed - no marketing/re-engagement emails
      } else if (event === 'SIGNED_OUT') {
        // CRITICAL FIX: Only clear profile on explicit SIGNED_OUT event.
        // During token refresh, onAuthStateChange may briefly fire with null session.
        // Clearing profile on every null session causes "Anonymous User" flicker.
        console.log('[Auth] User signed out — clearing profile');
        setProfile(null);
      } else {
        // Session is null but event is not SIGNED_OUT (e.g., TOKEN_REFRESHED edge case).
        // Keep existing profile to prevent flicker. If user truly signed out,
        // the SIGNED_OUT event will fire separately.
        console.warn('[Auth] Session null but event is not SIGNED_OUT:', event, '— keeping existing profile');
      }
      setLoading(false);
    });


    return () => {
      isMounted = false;
      subscription.unsubscribe();
    };
  }, []);

  // =========================================================================
  // DIAGNOSTIC TOOL — callable from browser console:
  //   window.__dwadido_diagnose()
  //
  // Runs comprehensive checks and returns a diagnostic report.
  // This helps Colin verify the environment without needing code changes.
  // =========================================================================
  useEffect(() => {
    (window as any).__dwadido_diagnose = async () => {
      const report: Record<string, any> = {
        timestamp: new Date().toISOString(),
        supabase_url: SUPABASE_URL,
        app_origin: window.location.origin,
      };

      // 1. Check session
      try {
        const { data: sessionData } = await supabase.auth.getSession();
        const sess = sessionData?.session;
        report.session = sess ? {
          user_id: sess.user?.id,
          user_email: sess.user?.email,
          user_aud: (sess.user as any)?.aud,
          expires_at: sess.expires_at ? new Date(sess.expires_at * 1000).toISOString() : null,
          token_first_20: sess.access_token?.substring(0, 20) + '...',
        } : 'NO SESSION';
      } catch (e: any) {
        report.session_error = e.message;
      }

      // 2. Check auth user (server-side verification)
      try {
        const { data: userData, error: userError } = await supabase.auth.getUser();
        if (userError) {
          report.auth_user = `ERROR: ${userError.message}`;
        } else if (userData?.user) {
          report.auth_user = {
            id: userData.user.id,
            email: userData.user.email,
            aud: (userData.user as any).aud,
            created_at: userData.user.created_at,
            role: (userData.user as any).role,
          };
        } else {
          report.auth_user = 'NO USER RETURNED';
        }
      } catch (e: any) {
        report.auth_user_error = e.message;
      }

      // 3. Check if profile exists
      const userId = report.session?.user_id || report.auth_user?.id;
      if (userId) {
        try {
          const { data: profileData, error: profileError } = await supabase
            .from('profiles')
            .select('id, email, display_name, updated_at, intent')
            .eq('id', userId)
            .maybeSingle();
          
          if (profileError) {
            report.profile = `ERROR: ${profileError.message} (code: ${profileError.code})`;
          } else if (profileData) {
            report.profile = {
              id: profileData.id,
              email: profileData.email,
              display_name: profileData.display_name,
              updated_at: profileData.updated_at,
              intent: profileData.intent,
              id_matches_auth: profileData.id === userId,
            };
          } else {
            report.profile = 'NOT FOUND — this user has no profile row!';
          }
        } catch (e: any) {
          report.profile_error = e.message;
        }

        // 4. Test UPDATE (dry run — update updated_at only)
        try {
          const { data: updateTest, error: updateTestError } = await supabase
            .from('profiles')
            .update({ updated_at: new Date().toISOString() })
            .eq('id', userId)
            .select('id')
            .maybeSingle();
          
          if (updateTestError) {
            report.update_test = `FAILED: ${updateTestError.message} (code: ${updateTestError.code})`;
          } else if (updateTest) {
            report.update_test = 'SUCCESS — UPDATE works';
          } else {
            report.update_test = 'NO ROWS AFFECTED — profile may not exist or RLS blocks it';
          }
        } catch (e: any) {
          report.update_test_error = e.message;
        }
      } else {
        report.profile = 'SKIPPED — no user ID available';
        report.update_test = 'SKIPPED — no user ID available';
      }

      // 5. React state snapshot
      report.react_state = {
        user_id: user?.id || null,
        user_email: user?.email || null,
        profile_id: profile?.id || null,
        profile_email: profile?.email || null,
        loading,
        isProfileLoading,
        error: error || null,
      };

      // Print report
      console.log('=== DWADIDO DIAGNOSTIC REPORT ===');
      console.log(JSON.stringify(report, null, 2));
      console.log('=== END DIAGNOSTIC REPORT ===');
      
      // Also return it so it shows in console
      return report;
    };

    console.log('[Dwadido] Diagnostic tool loaded. Run window.__dwadido_diagnose() in console for environment verification.');

    return () => {
      delete (window as any).__dwadido_diagnose;
    };
  }, [user, session, profile, loading, isProfileLoading, error]);




  const signUp = async (email: string, password: string, displayName?: string) => {
    try {
      const { error: signUpError } = await withTimeout(
        supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              display_name: displayName || email.split('@')[0]
            }
          }
        }),
        DB_TIMEOUT_MS,
        'Sign up'
      );
      return { error: signUpError as Error | null };
    } catch (err) {
      if (err instanceof TimeoutError) {
        return { error: new Error('Sign up timed out. Please try again.') };
      }
      return { error: err as Error };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { error: signInError } = await withTimeout(
        supabase.auth.signInWithPassword({
          email,
          password
        }),
        DB_TIMEOUT_MS,
        'Sign in'
      );
      return { error: signInError as Error | null };
    } catch (err) {
      if (err instanceof TimeoutError) {
        return { error: new Error('Sign in timed out. Please try again.') };
      }
      return { error: err as Error };
    }
  };

  const signOut = async () => {
    try {
      await withTimeout(
        supabase.auth.signOut(),
        DB_TIMEOUT_MS,
        'Sign out'
      );
      setProfile(null);
      setError(null);
    } catch (err) {
      // Even if signout times out, clear local state
      setProfile(null);
      setSession(null);
      setUser(null);
      console.error('[Auth] Sign out error:', err);
    }
  };

  const resetPassword = async (email: string) => {
    try {
      const { error: resetError } = await withTimeout(
        supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${window.location.origin}/reset-password`
        }),
        DB_TIMEOUT_MS,
        'Reset password'
      );
      return { error: resetError as Error | null };
    } catch (err) {
      if (err instanceof TimeoutError) {
        return { error: new Error('Password reset timed out. Please try again.') };
      }
      return { error: err as Error };
    }
  };

  // =========================================================================
  // VALID DB COLUMNS - whitelist to prevent "column does not exist" errors
  // These are the actual columns in the profiles table (47 columns)
  // =========================================================================
  const VALID_PROFILE_COLUMNS = new Set([
    'id', 'email', 'display_name', 'avatar_url', 'bio', 'interest_tags',
    'privacy_settings', 'created_at', 'updated_at', 'is_verified', 'is_admin',
    'date_of_birth', 'age_verified', 'verification_status', 'verification_submitted_at',
    'is_suspended', 'suspended_at', 'suspended_reason', 'warning_count',
    'last_warning_at', 'last_active_at', 'intent', 'relationship_status',
    'primary_photo_id', 'primary_photo_path', 'primary_photo_updated_at',
    'photo_visibility', 'show_avatar_only',
    'filter_relationship_type', 'filter_distance_range', 'filter_meeting_preference',
    'is_premium', 'premium_expires_at', 'read_receipts_enabled',
    'country', 'city', 'timezone', 'preferred_language', 'gender',
    'verified_at', 'verified_by', 'verification_expires_at',
    'verification_reminder_sent_at', 'previous_verification_count',
    'stripe_customer_id', 'stripe_subscription_id', 'subscription_status',
    'referred_by_code', 'referral_rewards_earned',
    'communication_style', 'love_style', 'lifestyle_factors', 'values_causes'
  ]);


  // =========================================================================
  // INTENT SAFETY: Default value must match DB CHECK constraint & NOT NULL
  // Allowed: 'friends_first' | 'dating' | 'long_term_relationship' | 'lifetime_partner'
  // =========================================================================
  const SAFE_DEFAULT_INTENT: IntentType = 'dating';

  const updateProfile = async (updates: Partial<Profile>) => {
    if (!user) return { error: new Error('Not authenticated') };
    
    // =====================================================================
    // DIAGNOSTIC LOGGING — helps debug FK constraint issues
    // =====================================================================
    console.log('=== [Profile Update] DIAGNOSTIC START ===');
    console.log('[Profile Update] Supabase URL:', SUPABASE_URL);
    console.log('[Profile Update] auth user.id:', user.id);
    console.log('[Profile Update] auth user.email:', user.email);
    console.log('[Profile Update] auth user.aud:', (user as any).aud);
    console.log('[Profile Update] session access_token (first 20 chars):', session?.access_token?.substring(0, 20) + '...');

    // Sanitize updates: only include fields that exist as DB columns
    const sanitizedUpdates: Record<string, any> = {};
    for (const [key, value] of Object.entries(updates)) {
      if (VALID_PROFILE_COLUMNS.has(key)) {
        sanitizedUpdates[key] = value;
      } else {
        console.warn(`[Profile Update] Skipping non-DB field: "${key}"`);
      }
    }
    
    // Remove fields that should not be set via client-side updates
    delete sanitizedUpdates['id'];
    delete sanitizedUpdates['created_at'];

    // =====================================================================
    // INTENT GUARD: Ensure intent is NEVER null/empty in the payload.
    // The DB column is NOT NULL DEFAULT 'dating' with a CHECK constraint.
    // =====================================================================
    if (sanitizedUpdates.intent === undefined || sanitizedUpdates.intent === null || sanitizedUpdates.intent === '') {
      const existingIntent = profile?.intent;
      const validIntents = ['friends_first', 'dating', 'long_term_relationship', 'lifetime_partner'];
      if (existingIntent && validIntents.includes(existingIntent)) {
        sanitizedUpdates.intent = existingIntent;
        console.log(`[Profile Update] Intent not in payload — preserved existing: "${existingIntent}"`);
      } else {
        sanitizedUpdates.intent = SAFE_DEFAULT_INTENT;
        console.log(`[Profile Update] Intent not in payload & no valid existing — set default: "${SAFE_DEFAULT_INTENT}"`);
      }
    } else {
      const validIntents = ['friends_first', 'dating', 'long_term_relationship', 'lifetime_partner'];
      if (!validIntents.includes(sanitizedUpdates.intent)) {
        console.error(`[Profile Update] INVALID intent value: "${sanitizedUpdates.intent}" — overriding to "${SAFE_DEFAULT_INTENT}"`);
        sanitizedUpdates.intent = SAFE_DEFAULT_INTENT;
      }
    }
    
    console.log('[Profile Update] Sanitized payload keys:', Object.keys(sanitizedUpdates).join(', '));
    
    try {
      // =====================================================================
      // STEP 1: PRE-FLIGHT CHECK — Does the profile row exist?
      // This SELECT tells us definitively whether to UPDATE or INSERT,
      // and provides diagnostic info if neither works.
      // =====================================================================
      console.log('[Profile Update] Step 1: Pre-flight SELECT to check profile exists...');
      const { data: existingProfile, error: selectError } = await withTimeout(
        supabase
          .from('profiles')
          .select('id, email, updated_at')
          .eq('id', user.id)
          .maybeSingle(),
        DB_TIMEOUT_MS,
        'Pre-flight profile check'
      );

      if (selectError) {
        console.error('[Profile Update] Pre-flight SELECT failed:', {
          message: selectError.message,
          code: selectError.code,
          details: selectError.details,
          hint: selectError.hint,
        });
        // Don't abort — try the UPDATE anyway, it might work
      } else {
        console.log('[Profile Update] Pre-flight result:', existingProfile ? `FOUND (id=${existingProfile.id}, email=${existingProfile.email})` : 'NOT FOUND');
      }

      // =====================================================================
      // STEP 2A: Profile EXISTS → UPDATE only (no INSERT fallback)
      // =====================================================================
      if (existingProfile) {
        console.log('[Profile Update] Step 2A: Profile exists — executing UPDATE...');
        const { data: updateData, error: updateError } = await withTimeout(
          supabase
            .from('profiles')
            .update({ 
              ...sanitizedUpdates, 
              updated_at: new Date().toISOString() 
            })
            .eq('id', user.id)
            .select()
            .single(),
          DB_TIMEOUT_MS,
          'Update profile'
        );
        
        if (updateError) {
          console.error('[Profile Update] UPDATE failed:', {
            message: updateError.message,
            code: updateError.code,
            details: updateError.details,
            hint: updateError.hint,
          });
          
          // If UPDATE itself returns FK violation, something is deeply wrong
          if (updateError.message?.includes('profiles_id_fkey')) {
            const diagMsg = `UPDATE triggered FK violation. This should not happen. ` +
              `Supabase URL: ${SUPABASE_URL}, user.id: ${user.id}, ` +
              `profile.id from SELECT: ${existingProfile.id}. ` +
              `The FK constraint may reference the wrong auth schema. ` +
              `Please check the database FK definition.`;
            console.error('[Profile Update] CRITICAL:', diagMsg);
            return { error: new Error(diagMsg) };
          }
          
          return { error: updateError as Error };
        }
        
        if (updateData) {
          console.log('[Profile Update] UPDATE success — updating local state');
          setProfile(updateData as Profile);
        } else {
          console.log('[Profile Update] UPDATE returned no data — re-fetching profile');
          await fetchProfile(user.id);
        }
        
        console.log('=== [Profile Update] DIAGNOSTIC END (success via UPDATE) ===');
        return { error: null };
      }

      // =====================================================================
      // STEP 2B: Profile does NOT exist → Verify auth user, then INSERT
      // =====================================================================
      console.log('[Profile Update] Step 2B: Profile NOT found — verifying auth user exists...');
      
      // Verify the auth user actually exists on THIS Supabase project
      let authUserVerified = false;
      let authUserData: any = null;
      try {
        const { data: getUserData, error: getUserError } = await supabase.auth.getUser();
        if (getUserError) {
          console.error('[Profile Update] auth.getUser() error:', getUserError.message);
        } else if (getUserData?.user) {
          authUserData = getUserData.user;
          authUserVerified = true;
          console.log('[Profile Update] Auth user verified:', {
            id: authUserData.id,
            email: authUserData.email,
            aud: authUserData.aud,
            created_at: authUserData.created_at,
          });
          
          // CRITICAL CHECK: Does the auth user ID match what we're using?
          if (authUserData.id !== user.id) {
            const mismatchMsg = `CRITICAL: auth.getUser().id (${authUserData.id}) !== user.id (${user.id}). ` +
              `The session token may be from a different Supabase project. ` +
              `Supabase URL: ${SUPABASE_URL}`;
            console.error('[Profile Update]', mismatchMsg);
            return { error: new Error(mismatchMsg) };
          }
        } else {
          console.error('[Profile Update] auth.getUser() returned no user — session may be invalid');
        }
      } catch (e) {
        console.error('[Profile Update] auth.getUser() threw:', e);
      }

      if (!authUserVerified) {
        const noAuthMsg = `Cannot create profile: auth user verification failed. ` +
          `This usually means the session token is invalid or from a different Supabase project. ` +
          `Supabase URL: ${SUPABASE_URL}, user.id: ${user.id}. ` +
          `Please sign out and sign in again.`;
        console.error('[Profile Update]', noAuthMsg);
        return { error: new Error(noAuthMsg) };
      }

      // Auth user verified — safe to INSERT
      console.log('[Profile Update] Auth user verified — executing INSERT...');
      const { data: insertData, error: insertError } = await withTimeout(
        supabase
          .from('profiles')
          .insert({
            id: user.id,
            email: user.email || '',
            ...sanitizedUpdates,
            updated_at: new Date().toISOString(),
            created_at: new Date().toISOString(),
          })
          .select()
          .single(),
        DB_TIMEOUT_MS,
        'Insert profile'
      );
      
      if (insertError) {
        console.error('[Profile Update] INSERT failed:', {
          message: insertError.message,
          code: insertError.code,
          details: insertError.details,
          hint: insertError.hint,
        });
        
        // Provide detailed diagnostic for FK violation
        if (insertError.message?.includes('profiles_id_fkey')) {
          const fkDiagMsg = `INSERT failed with FK violation (profiles_id_fkey). ` +
            `This means user.id "${user.id}" does NOT exist in the auth.users table ` +
            `that the profiles FK references. ` +
            `LIKELY CAUSE: The FK constraint references a different auth schema than ` +
            `the one this session was created on. ` +
            `Supabase URL: ${SUPABASE_URL}. ` +
            `Auth user verified: ${authUserVerified}, auth user id: ${authUserData?.id}. ` +
            `ACTION NEEDED: Run this SQL to check FK target: ` +
            `SELECT pg_get_constraintdef(oid) FROM pg_constraint WHERE conname = 'profiles_id_fkey';`;
          console.error('[Profile Update] FK DIAGNOSTIC:', fkDiagMsg);
          return { error: new Error(fkDiagMsg) };
        }
        
        return { error: insertError as Error };
      }
      
      if (insertData) {
        console.log('[Profile Update] INSERT success');
        setProfile(insertData as Profile);
      }
      
      console.log('=== [Profile Update] DIAGNOSTIC END (success via INSERT) ===');
      return { error: null };
    } catch (err) {
      if (err instanceof TimeoutError) {
        console.error('[Profile Update] Timed out');
        return { error: new Error('Profile update timed out. Please try again.') };
      }
      console.error('[Profile Update] Unexpected error:', err);
      return { error: err as Error };
    }
  };




  // retryProfile: clears error and retries profile fetch (for dashboard retry button)
  const retryProfile = async () => {
    if (user) {
      setError(null);
      setLoading(true);
      const success = await fetchProfile(user.id);
      if (!success) {
        console.warn('[Auth] retryProfile failed');
      }
      setLoading(false);
    }
  };


  return (
    <AuthContext.Provider value={{
      user,
      session,
      profile,
      loading,
      isProfileLoading,
      error,
      signUp,
      signIn,
      signOut,
      resetPassword,
      updateProfile,
      refreshProfile,
      retryProfile,
      clearError
    }}>
      {children}
    </AuthContext.Provider>
  );
};



export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
