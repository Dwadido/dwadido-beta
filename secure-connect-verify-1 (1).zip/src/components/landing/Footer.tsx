import React from 'react';
import { Twitter, Instagram, Linkedin, Github, Globe } from 'lucide-react';
import { useI18n } from '@/contexts/I18nContext';

// Dwadido Logo - Heart with gold checkmark
const DwadidoLogo = ({ className = "w-8 h-8" }: { className?: string }) => (
  <svg className={className} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path 
      d="M20 35L17.09 32.3C8.14 24.2 2 18.55 2 11.5C2 5.85 6.42 1.5 12 1.5C15.09 1.5 18.09 2.97 20 5.27C21.91 2.97 24.91 1.5 28 1.5C33.58 1.5 38 5.85 38 11.5C38 18.55 31.86 24.2 22.91 32.3L20 35Z" 
      fill="#1C1C1C"
      stroke="#C9A24D"
      strokeWidth="2"
    />
    <path 
      d="M14 19L18 23L26 15" 
      stroke="#C9A24D" 
      strokeWidth="3" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    />
  </svg>
);

const Footer: React.FC = () => {
  const { t, language, setLanguage, supportedLanguages, activeLanguages } = useI18n();
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    product: [
      { name: t('landing.features.title'), href: '#features' },
      { name: t('landing.howItWorks.title'), href: '#how-it-works' },
      { name: 'Pricing', href: '#pricing' },
      { name: t('landing.faq.title'), href: '#faq' }
    ],
    company: [
      { name: t('footer.about'), href: '#about' },
      { name: 'Careers', href: '#careers' },
      { name: 'Blog', href: '#blog' },
      { name: 'Press', href: '#press' }
    ],
    legal: [
      { name: t('footer.privacy'), href: '#privacy' },
      { name: t('footer.terms'), href: '#terms' },
      { name: 'Cookie Policy', href: '#cookies' },
      { name: 'GDPR', href: '#gdpr' }
    ],
    support: [
      { name: t('footer.help'), href: '#help' },
      { name: t('footer.contact'), href: '#contact' },
      { name: t('footer.safety'), href: '#safety' },
      { name: 'Community', href: '#community' }
    ]
  };

  return (
    <footer className="bg-charcoal-800 text-white border-t border-charcoal-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-8 mb-12">
          {/* Brand */}
          <div className="col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <DwadidoLogo className="w-10 h-10" />
              <span className="text-xl font-semibold tracking-wide">Dwadido</span>
            </div>
            <p className="text-gray-400 mb-6 max-w-xs">
              {t('footer.tagline')} Building trust-first connections through verified mutual intent.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-10 h-10 bg-charcoal-700 rounded-full flex items-center justify-center hover:bg-gold/20 hover:text-gold transition-all border border-charcoal-600">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-charcoal-700 rounded-full flex items-center justify-center hover:bg-gold/20 hover:text-gold transition-all border border-charcoal-600">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-charcoal-700 rounded-full flex items-center justify-center hover:bg-gold/20 hover:text-gold transition-all border border-charcoal-600">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 bg-charcoal-700 rounded-full flex items-center justify-center hover:bg-gold/20 hover:text-gold transition-all border border-charcoal-600">
                <Github className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h3 className="font-semibold mb-4 text-gold">Product</h3>
            <ul className="space-y-3">
              {footerLinks.product.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="text-gray-400 hover:text-white transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4 text-gold">Company</h3>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="text-gray-400 hover:text-white transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4 text-gold">Legal</h3>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="text-gray-400 hover:text-white transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4 text-gold">Support</h3>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.name}>
                  <a href={link.href} className="text-gray-400 hover:text-white transition-colors">
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Language selector & Bottom bar */}
        <div className="pt-8 border-t border-charcoal-600">
          {/* Language Selector */}
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-6">
            <div className="flex items-center gap-3">
              <Globe className="w-5 h-5 text-gray-400" />
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as any)}
                className="bg-charcoal-700 text-gray-300 text-sm rounded-lg px-3 py-2 border border-charcoal-600 focus:outline-none focus:ring-2 focus:ring-gold/50"
              >
                {supportedLanguages.map((lang) => {
                  const isActive = activeLanguages.includes(lang.code);
                  return (
                    <option 
                      key={lang.code} 
                      value={lang.code}
                      disabled={!isActive}
                    >
                      {lang.nativeName} {!isActive ? '(Coming Soon)' : ''}
                    </option>
                  );
                })}
              </select>
            </div>
            
            <div className="flex items-center gap-6 text-sm text-gray-400">
              <a href="#" className="hover:text-gold transition-colors">{t('footer.privacy')}</a>
              <a href="#" className="hover:text-gold transition-colors">{t('footer.terms')}</a>
              <a href="#" className="hover:text-gold transition-colors">Cookies</a>
            </div>
          </div>

          {/* Copyright */}
          <div className="text-center">
            <p className="text-gray-500 text-sm">
              {t('footer.copyright', { year: currentYear.toString() })}
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
