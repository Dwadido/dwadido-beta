import React from 'react';
import { ArrowRight, Shield, CheckCircle, Lock, Clock, Globe } from 'lucide-react';
import { useI18n } from '@/contexts/I18nContext';

interface HeroProps {
  onGetStarted: () => void;
  heroImage: string;
}

// Dwadido Logo - Heart with gold checkmark
const DwadidoLogo = ({ className = "w-8 h-8" }: { className?: string }) => (
  <svg className={className} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path 
      d="M20 35L17.09 32.3C8.14 24.2 2 18.55 2 11.5C2 5.85 6.42 1.5 12 1.5C15.09 1.5 18.09 2.97 20 5.27C21.91 2.97 24.91 1.5 28 1.5C33.58 1.5 38 5.85 38 11.5C38 18.55 31.86 24.2 22.91 32.3L20 35Z" 
      fill="#1C1C1C"
      stroke="#C9A24D"
      strokeWidth="2"
    />
    <path 
      d="M14 19L18 23L26 15" 
      stroke="#C9A24D" 
      strokeWidth="3" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    />
  </svg>
);

const Hero: React.FC<HeroProps> = ({ onGetStarted, heroImage }) => {
  const { t } = useI18n();
  
  return (
    <section className="relative min-h-[100svh] overflow-hidden bg-charcoal">
      {/* Subtle gradient overlay */}

      <div className="absolute inset-0 bg-gradient-to-br from-charcoal via-charcoal-700 to-charcoal" />
      
      {/* Subtle animated elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gold/3 rounded-full blur-3xl" />
      </div>

      {/* Subtle grid pattern */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0wIDBoNjB2NjBIMHoiLz48cGF0aCBkPSJNMzAgMzBtLTEgMGExIDEgMCAxIDAgMiAwYTEgMSAwIDEgMCAtMiAwIiBmaWxsPSJyZ2JhKDIwMSwxNjIsNzcsMC4wNSkiLz48L2c+PC9zdmc+')] opacity-60" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
          {/* Left content */}
          <div className="text-center lg:text-left">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-charcoal-700 backdrop-blur-sm rounded-full border border-charcoal-600 mb-8">
              <span className="w-2 h-2 bg-gold rounded-full animate-pulse-gold" />
              <span className="text-gray-300 text-sm font-medium">Verified Intent Connections</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
              {t('landing.hero.title')}
              <span className="block text-gradient-gold">
                both sides say yes
              </span>
            </h1>

            {/* Subheadline */}
            <p className="text-lg sm:text-xl text-gray-400 mb-8 max-w-xl mx-auto lg:mx-0">
              {t('landing.hero.subtitle')}
            </p>

            {/* CTA buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-12">
              <button
                onClick={onGetStarted}
                className="group px-8 py-4 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all shadow-gold flex items-center justify-center gap-2"
              >
                {t('landing.hero.cta')}
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="px-8 py-4 bg-charcoal-700 backdrop-blur-sm text-white font-semibold rounded-xl border border-charcoal-600 hover:border-gold/50 hover:bg-charcoal-600 transition-all flex items-center justify-center gap-2">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                </svg>
                {t('landing.hero.secondaryCta')}
              </button>
            </div>

            {/* Trust indicators */}
            <div className="flex flex-wrap gap-6 justify-center lg:justify-start text-gray-500 text-sm">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-gold" />
                <span>Zero unwanted contact</span>
              </div>
              <div className="flex items-center gap-2">
                <Lock className="w-5 h-5 text-gold" />
                <span>Controlled progression</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-gold" />
                <span>Global community</span>
              </div>
            </div>
          </div>

          {/* Right content - Hero image/card */}
          <div className="relative hidden lg:block">
            <div className="relative">
              {/* Floating card mockup */}
              <div className="absolute -top-8 -left-8 w-72 bg-charcoal-700 rounded-2xl shadow-2xl p-6 transform -rotate-6 z-10 border border-charcoal-600">
                <div className="h-2 bg-gradient-to-r from-gold to-gold-400 rounded-full mb-4" />
                <div className="font-mono text-2xl font-bold text-center tracking-[0.3em] text-white mb-4">
                  DWD-X7K9
                </div>
                <div className="flex items-center justify-center gap-2 text-gold text-sm font-medium">
                  <CheckCircle className="w-4 h-4" />
                  Ready to share
                </div>
              </div>

              {/* Main image */}
              <div className="relative z-0 rounded-2xl overflow-hidden shadow-2xl border border-charcoal-600">
                <img
                  src={heroImage}
                  alt="Connection visualization"
                  className="w-full h-auto"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 to-transparent" />
              </div>

              {/* Stage indicator */}
              <div className="absolute -bottom-4 -right-4 bg-charcoal-700 rounded-2xl shadow-2xl p-4 transform rotate-3 z-10 border border-charcoal-600">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gold/20 rounded-full flex items-center justify-center">
                    <svg className="w-6 h-6 text-gold" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                  <div>
                    <p className="font-semibold text-white">Verified Match!</p>
                    <p className="text-sm text-gray-400">Stage 3 unlocked</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Wave divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 120L60 105C120 90 240 60 360 45C480 30 600 30 720 37.5C840 45 960 60 1080 67.5C1200 75 1320 75 1380 75L1440 75V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z" fill="#141414"/>
        </svg>
      </div>
    </section>
  );
};

export default Hero;
