/**
 * Image Quality Checker for Verification Selfies
 * 
 * Performs client-side pre-screening of selfie images to ensure quality standards:
 * - Sufficient brightness
 * - Minimum resolution
 * - Blur detection
 * - Face detection (basic skin tone and region analysis)
 */

export interface QualityCheckResult {
  passed: boolean;
  brightness: {
    passed: boolean;
    score: number; // 0-100
    message: string;
  };
  resolution: {
    passed: boolean;
    width: number;
    height: number;
    message: string;
  };
  blur: {
    passed: boolean;
    score: number; // 0-100, higher is sharper
    message: string;
  };
  faceDetection: {
    passed: boolean;
    confidence: number; // 0-100
    message: string;
  };
  overallMessage: string;
}

// Minimum requirements
const MIN_WIDTH = 320;
const MIN_HEIGHT = 240;
const MIN_BRIGHTNESS = 30; // 0-100 scale
const MAX_BRIGHTNESS = 95; // Avoid overexposed images
const MIN_SHARPNESS = 20; // 0-100 scale
const MIN_FACE_CONFIDENCE = 40; // 0-100 scale

/**
 * Analyze image brightness by calculating average luminance
 */
function analyzeBrightness(imageData: ImageData): { score: number; passed: boolean; message: string } {
  const data = imageData.data;
  let totalLuminance = 0;
  const pixelCount = data.length / 4;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    // Calculate relative luminance using standard coefficients
    const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
    totalLuminance += luminance;
  }

  const avgLuminance = totalLuminance / pixelCount;
  const score = Math.round((avgLuminance / 255) * 100);

  let passed = true;
  let message = 'Good lighting';

  if (score < MIN_BRIGHTNESS) {
    passed = false;
    message = 'Image is too dark. Please move to a brighter area or turn on more lights.';
  } else if (score > MAX_BRIGHTNESS) {
    passed = false;
    message = 'Image is overexposed. Please reduce lighting or move away from direct light.';
  }

  return { score, passed, message };
}

/**
 * Check if image meets minimum resolution requirements
 */
function checkResolution(width: number, height: number): { passed: boolean; message: string } {
  const passed = width >= MIN_WIDTH && height >= MIN_HEIGHT;
  let message = `Resolution: ${width}x${height}`;

  if (!passed) {
    message = `Image resolution too low (${width}x${height}). Minimum required: ${MIN_WIDTH}x${MIN_HEIGHT}`;
  }

  return { passed, message };
}

/**
 * Detect blur using Laplacian variance
 * Higher variance = sharper image
 */
function detectBlur(imageData: ImageData, width: number, height: number): { score: number; passed: boolean; message: string } {
  const data = imageData.data;
  
  // Convert to grayscale for edge detection
  const grayscale: number[] = [];
  for (let i = 0; i < data.length; i += 4) {
    const gray = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
    grayscale.push(gray);
  }

  // Apply Laplacian kernel for edge detection
  // Kernel: [0, 1, 0]
  //         [1, -4, 1]
  //         [0, 1, 0]
  let variance = 0;
  let count = 0;
  const laplacianValues: number[] = [];

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const idx = y * width + x;
      const laplacian = 
        grayscale[idx - width] +
        grayscale[idx - 1] +
        grayscale[idx + 1] +
        grayscale[idx + width] -
        4 * grayscale[idx];
      
      laplacianValues.push(laplacian);
      count++;
    }
  }

  // Calculate variance of Laplacian
  const mean = laplacianValues.reduce((a, b) => a + b, 0) / count;
  variance = laplacianValues.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / count;

  // Normalize to 0-100 scale (typical variance ranges from 0 to ~5000 for sharp images)
  const normalizedScore = Math.min(100, Math.round((variance / 50)));
  
  const passed = normalizedScore >= MIN_SHARPNESS;
  let message = 'Image is sharp and clear';

  if (!passed) {
    message = 'Image appears blurry. Please hold your device steady and ensure good focus.';
  }

  return { score: normalizedScore, passed, message };
}

/**
 * Basic face detection using skin tone analysis and region detection
 * This is a simplified approach - production would use a proper face detection API
 */
function detectFace(imageData: ImageData, width: number, height: number): { confidence: number; passed: boolean; message: string } {
  const data = imageData.data;
  
  // Skin tone detection using YCbCr color space
  let skinPixelCount = 0;
  const skinRegions: { x: number; y: number }[] = [];
  
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];

      // Convert RGB to YCbCr
      const Y = 0.299 * r + 0.587 * g + 0.114 * b;
      const Cb = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b;
      const Cr = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;

      // Skin tone detection thresholds (works for various skin tones)
      const isSkinTone = (
        (Cb >= 77 && Cb <= 127) &&
        (Cr >= 133 && Cr <= 173) &&
        (Y >= 80)
      );

      // Alternative RGB-based skin detection for broader coverage
      const isRGBSkin = (
        r > 95 && g > 40 && b > 20 &&
        Math.max(r, g, b) - Math.min(r, g, b) > 15 &&
        Math.abs(r - g) > 15 && r > g && r > b
      );

      if (isSkinTone || isRGBSkin) {
        skinPixelCount++;
        skinRegions.push({ x, y });
      }
    }
  }

  const totalPixels = width * height;
  const skinPercentage = (skinPixelCount / totalPixels) * 100;

  // Check if skin pixels are concentrated in the expected face region (upper-center of image)
  const centerX = width / 2;
  const upperY = height * 0.4; // Face should be in upper 40% of image
  
  let faceRegionPixels = 0;
  const faceRegionWidth = width * 0.6;
  const faceRegionHeight = height * 0.5;

  for (const point of skinRegions) {
    const inHorizontalRange = Math.abs(point.x - centerX) < faceRegionWidth / 2;
    const inVerticalRange = point.y < upperY + faceRegionHeight / 2;
    
    if (inHorizontalRange && inVerticalRange) {
      faceRegionPixels++;
    }
  }

  const faceRegionPercentage = skinRegions.length > 0 
    ? (faceRegionPixels / skinRegions.length) * 100 
    : 0;

  // Calculate confidence based on:
  // 1. Overall skin percentage (should be 5-40% for a selfie)
  // 2. Concentration in face region
  let confidence = 0;

  if (skinPercentage >= 5 && skinPercentage <= 50) {
    // Good skin percentage range
    confidence += 40;
    
    // Bonus for concentration in face region
    if (faceRegionPercentage > 30) {
      confidence += Math.min(40, faceRegionPercentage * 0.8);
    }
    
    // Bonus for reasonable skin coverage
    if (skinPercentage >= 10 && skinPercentage <= 35) {
      confidence += 20;
    }
  } else if (skinPercentage > 0) {
    confidence = Math.min(30, skinPercentage * 2);
  }

  confidence = Math.min(100, Math.round(confidence));
  const passed = confidence >= MIN_FACE_CONFIDENCE;

  let message = 'Face detected';
  if (!passed) {
    if (skinPercentage < 5) {
      message = 'No face detected. Please position your face clearly in the frame.';
    } else if (faceRegionPercentage < 30) {
      message = 'Face not centered. Please position your face in the center of the frame.';
    } else {
      message = 'Face not clearly visible. Please ensure good lighting and face the camera directly.';
    }
  }

  return { confidence, passed, message };
}

/**
 * Load an image from a data URL and return image data for analysis
 */
function loadImageData(imageDataUrl: string): Promise<{ imageData: ImageData; width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        reject(new Error('Could not get canvas context'));
        return;
      }

      // Use a reasonable size for analysis (downscale large images)
      const maxSize = 640;
      let width = img.width;
      let height = img.height;

      if (width > maxSize || height > maxSize) {
        if (width > height) {
          height = Math.round((height / width) * maxSize);
          width = maxSize;
        } else {
          width = Math.round((width / height) * maxSize);
          height = maxSize;
        }
      }

      canvas.width = width;
      canvas.height = height;
      ctx.drawImage(img, 0, 0, width, height);

      const imageData = ctx.getImageData(0, 0, width, height);
      resolve({ imageData, width, height });
    };

    img.onerror = () => {
      reject(new Error('Failed to load image'));
    };

    img.src = imageDataUrl;
  });
}

/**
 * Main function to check image quality
 */
export async function checkImageQuality(imageDataUrl: string): Promise<QualityCheckResult> {
  try {
    const { imageData, width, height } = await loadImageData(imageDataUrl);

    // Get original image dimensions for resolution check
    const img = new Image();
    await new Promise<void>((resolve) => {
      img.onload = () => resolve();
      img.src = imageDataUrl;
    });

    const brightness = analyzeBrightness(imageData);
    const resolution = {
      ...checkResolution(img.width, img.height),
      width: img.width,
      height: img.height,
    };
    const blur = detectBlur(imageData, width, height);
    const faceDetection = detectFace(imageData, width, height);

    const allPassed = brightness.passed && resolution.passed && blur.passed && faceDetection.passed;

    let overallMessage = 'All quality checks passed! Your photo is ready for submission.';
    
    if (!allPassed) {
      const issues: string[] = [];
      if (!brightness.passed) issues.push('lighting');
      if (!resolution.passed) issues.push('resolution');
      if (!blur.passed) issues.push('focus');
      if (!faceDetection.passed) issues.push('face visibility');
      
      overallMessage = `Please fix the following issues: ${issues.join(', ')}.`;
    }

    return {
      passed: allPassed,
      brightness,
      resolution,
      blur,
      faceDetection,
      overallMessage,
    };
  } catch (error) {
    console.error('Image quality check error:', error);
    return {
      passed: false,
      brightness: { passed: false, score: 0, message: 'Could not analyze brightness' },
      resolution: { passed: false, width: 0, height: 0, message: 'Could not check resolution' },
      blur: { passed: false, score: 0, message: 'Could not detect blur' },
      faceDetection: { passed: false, confidence: 0, message: 'Could not detect face' },
      overallMessage: 'Failed to analyze image. Please try again with a different photo.',
    };
  }
}

/**
 * Real-time quality check for video stream (lighter version)
 * Used during camera preview for live feedback
 */
export function checkVideoFrameQuality(
  video: HTMLVideoElement,
  canvas: HTMLCanvasElement
): { brightness: number; hasFace: boolean; isSharp: boolean } {
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return { brightness: 50, hasFace: false, isSharp: false };
  }

  const width = Math.min(320, video.videoWidth);
  const height = Math.min(240, video.videoHeight);
  
  canvas.width = width;
  canvas.height = height;
  
  // Mirror the video for selfie view
  ctx.translate(width, 0);
  ctx.scale(-1, 1);
  ctx.drawImage(video, 0, 0, width, height);
  ctx.setTransform(1, 0, 0, 1, 0, 0); // Reset transform

  const imageData = ctx.getImageData(0, 0, width, height);

  // Quick brightness check
  const brightnessResult = analyzeBrightness(imageData);
  
  // Quick face detection
  const faceResult = detectFace(imageData, width, height);
  
  // Quick blur check (simplified)
  const blurResult = detectBlur(imageData, width, height);

  return {
    brightness: brightnessResult.score,
    hasFace: faceResult.confidence >= MIN_FACE_CONFIDENCE,
    isSharp: blurResult.score >= MIN_SHARPNESS,
  };
}
