import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { 
  MapPin, 
  Eye, 
  EyeOff, 
  RefreshCw, 
  Info, 
  Navigation,
  Shield,
  Users,
  Loader2,
  ChevronLeft,
  Settings,
  Circle
} from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

interface Marker {
  latitude: number;
  longitude: number;
  color: 'blue' | 'pink' | 'grey';
  recency: 'active' | 'recent' | 'older';
}


interface LocationSettings {
  is_visible: boolean;
  interested_in: string[];
  updated_at: string;
}

interface PrivacyMapProps {
  onBack?: () => void;
}

const PrivacyMap: React.FC<PrivacyMapProps> = ({ onBack }) => {
  const { user } = useAuth();
  const [markers, setMarkers] = useState<Marker[]>([]);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationSettings, setLocationSettings] = useState<LocationSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [interestedIn, setInterestedIn] = useState<string[]>([]);
  const [savingSettings, setSavingSettings] = useState(false);

  // Map viewport state
  const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({ lat: 40.7128, lng: -74.0060 }); // Default NYC
  const [mapZoom, setMapZoom] = useState(12);

  // Get color for marker - only blue (women), pink (men), or grey (undisclosed)
  const getMarkerColorClass = (color: string) => {
    switch (color) {
      case 'blue': return 'bg-blue-500';
      case 'pink': return 'bg-pink-500';
      default: return 'bg-gray-400';
    }
  };


  // Get opacity based on recency
  const getRecencyOpacity = (recency: string) => {
    switch (recency) {
      case 'active': return 'opacity-100';
      case 'recent': return 'opacity-70';
      default: return 'opacity-40';
    }
  };

  // Fetch user's location settings
  const fetchLocationSettings = useCallback(async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase.functions.invoke('map-locations', {
        body: { action: 'get_my_location' }
      });

      if (!error && data?.location) {
        setLocationSettings(data.location);
        setInterestedIn(data.location.interested_in || []);
      }
    } catch (err) {
      console.error('Error fetching location settings:', err);
    }
  }, [user]);

  // Fetch nearby markers
  const fetchNearbyMarkers = useCallback(async (lat: number, lng: number) => {
    setRefreshing(true);
    try {
      const { data, error } = await supabase.functions.invoke('map-locations', {
        body: { 
          action: 'get_nearby',
          latitude: lat,
          longitude: lng,
          radius_km: 15
        }
      });

      if (!error && data?.markers) {
        setMarkers(data.markers);
      }
    } catch (err) {
      console.error('Error fetching markers:', err);
    }
    setRefreshing(false);
  }, []);

  // Get user's current location
  const getCurrentLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setLocationError('Geolocation is not supported by your browser');
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setUserLocation({ lat: latitude, lng: longitude });
        setMapCenter({ lat: latitude, lng: longitude });
        setLocationError(null);
        fetchNearbyMarkers(latitude, longitude);
        setLoading(false);
      },
      (error) => {
        console.error('Geolocation error:', error);
        setLocationError('Unable to get your location. Please enable location services.');
        setLoading(false);
        // Still fetch markers for default location
        fetchNearbyMarkers(mapCenter.lat, mapCenter.lng);
      },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 }
    );
  }, [fetchNearbyMarkers, mapCenter.lat, mapCenter.lng]);

  // Initialize
  useEffect(() => {
    fetchLocationSettings();
    getCurrentLocation();
  }, [fetchLocationSettings, getCurrentLocation]);

  // Update location on server
  const updateLocation = async (visible: boolean) => {
    if (!user) return;

    setSavingSettings(true);
    try {
      // Allow visibility toggle even without geolocation
      // If no userLocation, send without coordinates (edge function handles this)
      const body: Record<string, any> = {
        action: 'update_location',
        is_visible: visible,
        interested_in: interestedIn
      };
      
      // Only include coordinates if we have them
      if (userLocation) {
        body.latitude = userLocation.lat;
        body.longitude = userLocation.lng;
      }

      const { data, error } = await supabase.functions.invoke('map-locations', {
        body
      });

      if (!error && data?.success) {
        setLocationSettings(prev => prev ? 
          { ...prev, is_visible: visible, interested_in: interestedIn } : 
          { is_visible: visible, interested_in: interestedIn, updated_at: new Date().toISOString() }
        );
      } else if (error) {
        console.error('[PrivacyMap] Error updating location:', error);
        // Still update local state optimistically for UI responsiveness
        setLocationSettings(prev => prev ? 
          { ...prev, is_visible: visible } : 
          { is_visible: visible, interested_in: interestedIn, updated_at: new Date().toISOString() }
        );
      }
    } catch (err) {
      console.error('[PrivacyMap] Error updating location:', err);
      // Optimistic update - toggle the UI even if the server call fails
      setLocationSettings(prev => prev ? 
        { ...prev, is_visible: visible } : 
        { is_visible: visible, interested_in: interestedIn, updated_at: new Date().toISOString() }
      );
    }
    setSavingSettings(false);
  };

  // Toggle visibility
  const toggleVisibility = async () => {
    const newVisibility = !locationSettings?.is_visible;
    await updateLocation(newVisibility);
  };

  // Save preferences
  const savePreferences = async () => {
    await updateLocation(locationSettings?.is_visible ?? false);
    setSettingsOpen(false);
  };



  // Handle interested_in checkbox change
  const handleInterestedInChange = (value: string, checked: boolean) => {
    if (checked) {
      setInterestedIn(prev => [...prev, value]);
    } else {
      setInterestedIn(prev => prev.filter(v => v !== value));
    }
  };

  // Convert lat/lng to pixel position on map
  const latLngToPixel = (lat: number, lng: number, centerLat: number, centerLng: number, zoom: number, mapWidth: number, mapHeight: number) => {
    const scale = Math.pow(2, zoom);
    const worldCoordCenter = {
      x: (centerLng + 180) / 360 * 256 * scale,
      y: (1 - Math.log(Math.tan(centerLat * Math.PI / 180) + 1 / Math.cos(centerLat * Math.PI / 180)) / Math.PI) / 2 * 256 * scale
    };
    const worldCoord = {
      x: (lng + 180) / 360 * 256 * scale,
      y: (1 - Math.log(Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)) / Math.PI) / 2 * 256 * scale
    };
    return {
      x: mapWidth / 2 + (worldCoord.x - worldCoordCenter.x),
      y: mapHeight / 2 + (worldCoord.y - worldCoordCenter.y)
    };
  };

  // Render map with markers
  const renderMap = () => {
    const mapWidth = 800;
    const mapHeight = 600;

    return (
      <div className="relative w-full h-full bg-charcoal-800 rounded-xl overflow-hidden" style={{ minHeight: '500px' }}>
        {/* Map background - simplified grid representation */}
        <div className="absolute inset-0 bg-gradient-to-br from-charcoal-700 to-charcoal-800">
          {/* Grid lines for visual effect */}
          <svg className="absolute inset-0 w-full h-full opacity-10">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-gold" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>

        {/* Markers container */}
        <div className="absolute inset-0">
          {markers.map((marker, index) => {
            const pos = latLngToPixel(
              marker.latitude,
              marker.longitude,
              mapCenter.lat,
              mapCenter.lng,
              mapZoom,
              mapWidth,
              mapHeight
            );

            // Only render if within bounds
            if (pos.x < 0 || pos.x > mapWidth || pos.y < 0 || pos.y > mapHeight) {
              return null;
            }

            return (
              <div
                key={index}
                className={`absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 ${getRecencyOpacity(marker.recency)}`}
                style={{ left: `${(pos.x / mapWidth) * 100}%`, top: `${(pos.y / mapHeight) * 100}%` }}
              >
                <div className={`w-4 h-4 rounded-full ${getMarkerColorClass(marker.color)} shadow-lg ring-2 ring-white/20`} />
              </div>
            );
          })}

          {/* User's location marker */}
          {userLocation && (
            <div
              className="absolute transform -translate-x-1/2 -translate-y-1/2"
              style={{ left: '50%', top: '50%' }}
            >
              <div className="relative">
                <div className="w-6 h-6 rounded-full bg-gold shadow-gold animate-pulse" />
                <div className="absolute inset-0 w-6 h-6 rounded-full bg-gold/30 animate-ping" />
              </div>
            </div>
          )}
        </div>

        {/* Map controls */}
        <div className="absolute bottom-4 right-4 flex flex-col gap-2">
          <button
            onClick={() => setMapZoom(prev => Math.min(prev + 1, 18))}
            className="w-10 h-10 bg-charcoal-700 hover:bg-charcoal-600 rounded-lg flex items-center justify-center text-white border border-charcoal-600"
          >
            +
          </button>
          <button
            onClick={() => setMapZoom(prev => Math.max(prev - 1, 8))}
            className="w-10 h-10 bg-charcoal-700 hover:bg-charcoal-600 rounded-lg flex items-center justify-center text-white border border-charcoal-600"
          >
            -
          </button>
        </div>

        {/* Center on user button */}
        {userLocation && (
          <button
            onClick={() => setMapCenter(userLocation)}
            className="absolute bottom-4 left-4 px-4 py-2 bg-charcoal-700 hover:bg-charcoal-600 rounded-lg flex items-center gap-2 text-white border border-charcoal-600"
          >
            <Navigation className="w-4 h-4" />
            Center
          </button>
        )}

        {/* Marker count */}
        <div className="absolute top-4 left-4 px-4 py-2 bg-charcoal-700/90 backdrop-blur rounded-lg border border-charcoal-600">
          <div className="flex items-center gap-2 text-white">
            <Users className="w-4 h-4 text-gold" />
            <span className="text-sm">{markers.length} nearby</span>
          </div>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-charcoal flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-gold animate-spin mx-auto mb-4" />
          <p className="text-gray-400">Loading map...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-charcoal">
      {/* Header */}
      <div className="bg-charcoal-800 border-b border-charcoal-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {onBack && (
                <button
                  onClick={onBack}
                  className="p-2 hover:bg-charcoal-700 rounded-lg transition-colors"
                >
                  <ChevronLeft className="w-5 h-5 text-gray-400" />
                </button>
              )}
              <div>
                <h1 className="text-xl font-bold text-white flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-gold" />
                  Privacy Map
                </h1>
                <p className="text-sm text-gray-400">Anonymous nearby users</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setInfoOpen(true)}
                className="p-2 hover:bg-charcoal-700 rounded-lg transition-colors"
              >
                <Info className="w-5 h-5 text-gray-400" />
              </button>
              <button
                onClick={() => setSettingsOpen(true)}
                className="p-2 hover:bg-charcoal-700 rounded-lg transition-colors"
              >
                <Settings className="w-5 h-5 text-gray-400" />
              </button>
              <button
                onClick={() => userLocation && fetchNearbyMarkers(userLocation.lat, userLocation.lng)}
                disabled={refreshing}
                className="p-2 hover:bg-charcoal-700 rounded-lg transition-colors"
              >
                <RefreshCw className={`w-5 h-5 text-gray-400 ${refreshing ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Visibility toggle card */}
        <div className="bg-charcoal-700 rounded-xl p-4 mb-6 border border-charcoal-600">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {locationSettings?.is_visible ? (
                <Eye className="w-5 h-5 text-gold" />
              ) : (
                <EyeOff className="w-5 h-5 text-gray-500" />
              )}
              <div>
                <p className="text-white font-medium">
                  {locationSettings?.is_visible ? 'You are visible on the map' : 'You are hidden from the map'}
                </p>
                <p className="text-sm text-gray-400">
                  {locationSettings?.is_visible 
                    ? 'Others can see your approximate location' 
                    : 'Toggle to appear as an anonymous marker'}
                </p>
              </div>
            </div>
            <Switch
              checked={locationSettings?.is_visible ?? false}
              onCheckedChange={toggleVisibility}
              disabled={savingSettings}
            />
          </div>
        </div>


        {locationError && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 mb-6">
            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-red-400" />
              <div>
                <p className="text-red-400 font-medium">Location unavailable</p>
                <p className="text-sm text-red-400/70">{locationError}</p>
              </div>
              <button
                onClick={getCurrentLocation}
                className="ml-auto px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg text-sm"
              >
                Retry
              </button>
            </div>
          </div>
        )}

        {/* Map */}
        <div className="bg-charcoal-700 rounded-xl overflow-hidden border border-charcoal-600">
          {renderMap()}
        </div>

        {/* Legend */}
        <div className="mt-6 bg-charcoal-700 rounded-xl p-4 border border-charcoal-600">
          <h3 className="text-white font-medium mb-3">Marker Colors</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-blue-500" />
              <span className="text-sm text-gray-300">Interested in women</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-pink-500" />
              <span className="text-sm text-gray-300">Interested in men</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-gray-400" />
              <span className="text-sm text-gray-300">Undisclosed</span>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-charcoal-600">
            <h4 className="text-white font-medium mb-2">Marker Brightness</h4>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-gold opacity-100" />
                <span className="text-sm text-gray-300">Active (last hour)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-gold opacity-70" />
                <span className="text-sm text-gray-300">Recent (last day)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-gold opacity-40" />
                <span className="text-sm text-gray-300">Older</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Settings Dialog */}
      <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
        <DialogContent className="bg-charcoal-800 border-charcoal-700 text-white">
          <DialogHeader>
            <DialogTitle>Map Preferences</DialogTitle>
            <DialogDescription className="text-gray-400">
              Configure how you appear on the map
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
          <div>
              <Label className="text-white mb-3 block">I'm interested in</Label>
              <p className="text-xs text-gray-500 mb-3">
                Select one option to determine your marker color. Selecting both will show as undisclosed (grey).
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="women"
                    checked={interestedIn.includes('women')}
                    onCheckedChange={(checked) => handleInterestedInChange('women', checked as boolean)}
                  />
                  <Label htmlFor="women" className="text-gray-300 cursor-pointer">Women</Label>
                  <div className="w-3 h-3 rounded-full bg-blue-500 ml-auto" />
                </div>
                <div className="flex items-center gap-3">
                  <Checkbox
                    id="men"
                    checked={interestedIn.includes('men')}
                    onCheckedChange={(checked) => handleInterestedInChange('men', checked as boolean)}
                  />
                  <Label htmlFor="men" className="text-gray-300 cursor-pointer">Men</Label>
                  <div className="w-3 h-3 rounded-full bg-pink-500 ml-auto" />
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-3">
                Leave both unchecked for grey (undisclosed) marker.
              </p>
            </div>




            <div className="bg-charcoal-700 rounded-lg p-4">
              <div className="flex items-center gap-2 text-gold mb-2">
                <Shield className="w-4 h-4" />
                <span className="font-medium">Privacy Note</span>
              </div>
              <p className="text-sm text-gray-400">
                Your exact location is never shared. We add a random offset of 0.5-2km 
                to protect your privacy. Only anonymous markers are visible to others.
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={() => setSettingsOpen(false)}
              className="flex-1 border-charcoal-600 text-gray-300 hover:bg-charcoal-700"
            >
              Cancel
            </Button>
            <Button
              onClick={savePreferences}
              disabled={savingSettings}
              className="flex-1 bg-gold hover:bg-gold-400 text-charcoal"
            >
              {savingSettings ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Save'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Info Dialog */}
      <Dialog open={infoOpen} onOpenChange={setInfoOpen}>
        <DialogContent className="bg-charcoal-800 border-charcoal-700 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-gold" />
              Privacy-First Map
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-gold/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Circle className="w-4 h-4 text-gold" />
                </div>
                <div>
                  <p className="text-white font-medium">Anonymous Markers Only</p>
                  <p className="text-sm text-gray-400">
                    You only see round markers. No names, photos, or profiles are visible.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-gold/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-4 h-4 text-gold" />
                </div>
                <div>
                  <p className="text-white font-medium">Fuzzed Locations</p>
                  <p className="text-sm text-gray-400">
                    All locations are offset by 0.5-2km. Your exact position is never shown.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-gold/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Eye className="w-4 h-4 text-gold" />
                </div>
                <div>
                  <p className="text-white font-medium">Opt-In Visibility</p>
                  <p className="text-sm text-gray-400">
                    You must explicitly enable visibility to appear on the map.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-gold/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Users className="w-4 h-4 text-gold" />
                </div>
                <div>
                  <p className="text-white font-medium">Color-Coded Preferences</p>
                  <p className="text-sm text-gray-400">
                    Marker colors indicate general preferences, not identities.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gold/10 rounded-lg p-4 border border-gold/20">
              <p className="text-sm text-gold">
                The map is designed for awareness, not tracking. Use Crush Codes to connect with people you meet in real life.

              </p>
            </div>
          </div>

          <Button
            onClick={() => setInfoOpen(false)}
            className="w-full bg-gold hover:bg-gold-400 text-charcoal"
          >
            Got it
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PrivacyMap;
