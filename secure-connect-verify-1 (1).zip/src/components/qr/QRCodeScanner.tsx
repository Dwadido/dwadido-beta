import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Camera, X, Loader2, AlertCircle, SwitchCamera, Flashlight, Keyboard } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface QRCodeScannerProps {
  onScan: (code: string) => void;
  onClose: () => void;
  isOpen: boolean;
  // Optional: context for anonymous analytics (no user tracking)
  scanContext?: 'event' | 'cafe' | 'personal' | 'printed_card' | 'digital_share' | 'unknown';
}

/**
 * Privacy-First QR Code Scanner
 * 
 * Analytics recorded are:
 * - AGGREGATE only (no individual tracking)
 * - ANONYMOUS (no user IDs)
 * - Used for product decisions, NOT matching or scoring
 */
const QRCodeScanner: React.FC<QRCodeScannerProps> = ({ onScan, onClose, isOpen, scanContext = 'unknown' }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationRef = useRef<number | null>(null);
  const scanStartTimeRef = useRef<number | null>(null);
  
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [torchOn, setTorchOn] = useState(false);
  const [hasTorch, setHasTorch] = useState(false);
  const [scannerSupported, setScannerSupported] = useState(true);
  const [cameraSupported, setCameraSupported] = useState(true);

  // Check if BarcodeDetector is available
  const barcodeDetectorRef = useRef<any>(null);

  /**
   * Privacy-First Analytics Recording
   * 
   * Records ONLY aggregate, anonymous data:
   * - Device category (mobile/desktop/tablet)
   * - Scan context (event/cafe/personal/etc)
   * - Outcome (success/failure)
   * - Average time to redemption
   * 
   * Does NOT record:
   * - User IDs
   * - Precise timestamps
   * - Individual behavioral data
   */
  const recordAnonymousScan = useCallback(async (
    outcome: 'scan_only' | 'redemption_success' | 'redemption_failed' | 'technical_error',
    scanToRedemptionSeconds?: number
  ) => {
    try {
      // Detect device category from user agent (no individual tracking)
      const userAgent = navigator.userAgent.toLowerCase();
      let deviceCategory: 'mobile' | 'desktop' | 'tablet' | 'unknown' = 'unknown';
      
      if (/tablet|ipad|playbook|silk/i.test(userAgent)) {
        deviceCategory = 'tablet';
      } else if (/mobile|iphone|ipod|android|blackberry|opera mini|iemobile/i.test(userAgent)) {
        deviceCategory = 'mobile';
      } else if (/windows|macintosh|linux/i.test(userAgent)) {
        deviceCategory = 'desktop';
      }

      // Get country code from browser locale (privacy-preserving, no precise location)
      const locale = navigator.language || 'en-US';
      const regionCountry = locale.split('-')[1]?.toUpperCase() || null;

      await supabase.functions.invoke('record-qr-scan', {
        body: {
          scan_context: scanContext,
          device_category: deviceCategory,
          region_country: regionCountry,
          outcome,
          scan_to_redemption_seconds: scanToRedemptionSeconds
        }
      });
    } catch (err) {
      // Silently fail - analytics should never block user experience
      console.debug('Analytics recording failed (non-blocking):', err);
    }
  }, [scanContext]);



  useEffect(() => {
    // Check for BarcodeDetector support
    if ('BarcodeDetector' in window) {
      // @ts-ignore - BarcodeDetector is not in TypeScript types yet
      barcodeDetectorRef.current = new window.BarcodeDetector({ formats: ['qr_code'] });
    } else {
      setScannerSupported(false);
    }

    // Check if camera is supported
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraSupported(false);
    }
  }, []);

  const startCamera = useCallback(async () => {
    // Check if camera is supported first
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setLoading(false);
      setCameraSupported(false);
      setError('Camera is not supported in this browser or context. Please use a modern browser with HTTPS.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Stop any existing stream
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }

      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      setHasPermission(true);

      // Check for torch capability
      const track = stream.getVideoTracks()[0];
      const capabilities = track.getCapabilities?.() as any;
      setHasTorch(capabilities?.torch === true);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      setLoading(false);
      startScanning();
    } catch (err: any) {
      console.error('Camera error:', err);
      setLoading(false);
      
      // Handle various error types
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setHasPermission(false);
        setError('Camera permission was denied. Please allow camera access in your browser settings to scan QR codes.');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setError('No camera found on this device.');
      } else if (err.name === 'NotReadableError' || err.name === 'TrackStartError') {
        setError('Camera is already in use by another application. Please close other apps using the camera.');
      } else if (err.name === 'OverconstrainedError') {
        setError('Camera does not meet the required constraints. Trying with basic settings...');
        // Try with basic constraints
        try {
          const basicStream = await navigator.mediaDevices.getUserMedia({ video: true });
          streamRef.current = basicStream;
          setHasPermission(true);
          if (videoRef.current) {
            videoRef.current.srcObject = basicStream;
            await videoRef.current.play();
          }
          setLoading(false);
          setError(null);
          startScanning();
        } catch (basicErr) {
          setError('Failed to access camera with basic settings.');
        }
      } else if (err.name === 'SecurityError') {
        setError('Camera access is blocked due to security restrictions. Please ensure you are using HTTPS.');
      } else if (err.message?.includes('denied') || err.message?.includes('not allowed')) {
        setHasPermission(false);
        setError('Camera permission was denied. Please allow camera access to scan QR codes.');
      } else {
        setError(`Failed to access camera: ${err.message || 'Unknown error'}. Please try again or enter the code manually.`);
      }
    }
  }, [facingMode]);

  const startScanning = useCallback(() => {
    if (!barcodeDetectorRef.current || !videoRef.current || !canvasRef.current) return;

    // Record scan start time for analytics (aggregate average only)
    scanStartTimeRef.current = Date.now();

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const scan = async () => {
      if (video.readyState !== video.HAVE_ENOUGH_DATA) {
        animationRef.current = requestAnimationFrame(scan);
        return;
      }

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0);

      try {
        const barcodes = await barcodeDetectorRef.current.detect(canvas);
        
        if (barcodes.length > 0) {
          const code = barcodes[0].rawValue;
          
          // Validate it looks like a Dwadido code (6 alphanumeric characters)
          const cleanCode = code.toUpperCase().replace(/[^A-Z0-9]/g, '');
          if (cleanCode.length === 6) {
            // Calculate time from scan start (for aggregate average, not individual tracking)
            const scanDuration = scanStartTimeRef.current 
              ? Math.round((Date.now() - scanStartTimeRef.current) / 1000)
              : undefined;
            
            // Record anonymous scan success (aggregate only)
            recordAnonymousScan('redemption_success', scanDuration);
            
            // Success - stop scanning and return the code
            stopCamera();
            onScan(cleanCode);
            return;
          }
        }
      } catch (err) {
        // Scanning error - continue trying
      }

      animationRef.current = requestAnimationFrame(scan);
    };

    animationRef.current = requestAnimationFrame(scan);
  }, [onScan, recordAnonymousScan]);



  const stopCamera = useCallback(() => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    }
    
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
  }, []);

  const toggleCamera = useCallback(() => {
    setFacingMode(prev => prev === 'environment' ? 'user' : 'environment');
  }, []);

  const toggleTorch = useCallback(async () => {
    if (!streamRef.current) return;
    
    const track = streamRef.current.getVideoTracks()[0];
    try {
      await track.applyConstraints({
        // @ts-ignore - torch is not in TypeScript types
        advanced: [{ torch: !torchOn }]
      });
      setTorchOn(!torchOn);
    } catch (err) {
      console.error('Failed to toggle torch:', err);
    }
  }, [torchOn]);

  useEffect(() => {
    if (isOpen && cameraSupported) {
      startCamera();
    } else if (!isOpen) {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isOpen, cameraSupported]);

  // Restart camera when facing mode changes
  useEffect(() => {
    if (isOpen && hasPermission && cameraSupported) {
      startCamera();
    }
  }, [facingMode]);

  const handleClose = () => {
    stopCamera();
    onClose();
  };

  const handleManualEntry = () => {
    stopCamera();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 bg-charcoal/80 backdrop-blur-sm">
        <h2 className="text-white font-semibold text-lg">Scan QR Code</h2>
        <button
          onClick={handleClose}
          className="p-2 text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-xl transition-all"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Scanner Area */}
      <div className="flex-1 relative flex items-center justify-center overflow-hidden">
        {loading && cameraSupported && (
          <div className="absolute inset-0 flex items-center justify-center bg-charcoal z-10">
            <div className="text-center">
              <Loader2 className="w-12 h-12 text-gold animate-spin mx-auto mb-4" />
              <p className="text-gray-400">Starting camera...</p>
              <p className="text-gray-500 text-sm mt-2">Please allow camera access when prompted</p>
            </div>
          </div>
        )}

        {(error || !cameraSupported) && (
          <div className="absolute inset-0 flex items-center justify-center bg-charcoal z-10 p-6">
            <div className="text-center max-w-sm">
              <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-8 h-8 text-red-400" />
              </div>
              <h3 className="text-white font-semibold mb-2">
                {!cameraSupported ? 'Camera Not Available' : 'Camera Error'}
              </h3>
              <p className="text-gray-400 text-sm mb-6">
                {!cameraSupported 
                  ? 'Camera access is not available in this browser or context. Please use a modern browser with HTTPS, or enter the code manually.'
                  : error
                }
              </p>
              <div className="space-y-3">
                {cameraSupported && hasPermission !== false && (
                  <button
                    onClick={startCamera}
                    className="w-full py-3 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all"
                  >
                    Try Again
                  </button>
                )}
                {hasPermission === false && (
                  <div className="p-4 bg-charcoal-700 rounded-xl text-left mb-4">
                    <p className="text-white text-sm font-medium mb-2">To enable camera:</p>
                    <ol className="text-gray-400 text-xs space-y-1 list-decimal list-inside">
                      <li>Click the lock/info icon in your browser's address bar</li>
                      <li>Find "Camera" in the permissions</li>
                      <li>Change it to "Allow"</li>
                      <li>Refresh the page and try again</li>
                    </ol>
                  </div>
                )}
                <button
                  onClick={handleManualEntry}
                  className="w-full py-3 bg-charcoal-700 text-white font-medium rounded-xl hover:bg-charcoal-600 transition-all flex items-center justify-center gap-2"
                >
                  <Keyboard className="w-5 h-5" />
                  Enter Code Manually
                </button>
              </div>
            </div>
          </div>
        )}

        {!scannerSupported && cameraSupported && !error && (
          <div className="absolute inset-0 flex items-center justify-center bg-charcoal z-10 p-6">
            <div className="text-center max-w-sm">
              <div className="w-16 h-16 bg-yellow-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-8 h-8 text-yellow-400" />
              </div>
              <h3 className="text-white font-semibold mb-2">Scanner Not Supported</h3>
              <p className="text-gray-400 text-sm mb-6">
                QR code scanning is not supported in this browser. Please use Chrome, Edge, or Safari, or enter the code manually.
              </p>
              <button
                onClick={handleManualEntry}
                className="w-full py-3 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all flex items-center justify-center gap-2"
              >
                <Keyboard className="w-5 h-5" />
                Enter Code Manually
              </button>
            </div>
          </div>
        )}

        {/* Video Feed */}
        <video
          ref={videoRef}
          className="absolute inset-0 w-full h-full object-cover"
          playsInline
          muted
        />
        
        {/* Hidden canvas for processing */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Scanning Overlay */}
        {!loading && !error && scannerSupported && cameraSupported && (
          <>
            {/* Darkened corners */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute inset-0 bg-black/50" />
              <div 
                className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-transparent"
                style={{
                  boxShadow: '0 0 0 9999px rgba(0, 0, 0, 0.5)'
                }}
              />
            </div>

            {/* Scanning Frame */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 pointer-events-none">
              {/* Corner decorations */}
              <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-gold rounded-tl-lg" />
              <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-gold rounded-tr-lg" />
              <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-gold rounded-bl-lg" />
              <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-gold rounded-br-lg" />
              
              {/* Scanning line animation */}
              <div className="absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-transparent via-gold to-transparent animate-scan" />
            </div>

            {/* Instructions */}
            <div className="absolute bottom-32 left-0 right-0 text-center">
              <p className="text-white text-sm font-medium mb-1">
                Point camera at QR code
              </p>
              <p className="text-gray-400 text-xs">
                Position the code within the frame
              </p>
            </div>
          </>
        )}
      </div>

      {/* Controls */}
      {!loading && !error && scannerSupported && cameraSupported && (
        <div className="p-6 bg-charcoal/80 backdrop-blur-sm">
          <div className="flex items-center justify-center gap-4 mb-4">
            <button
              onClick={toggleCamera}
              className="p-4 bg-charcoal-700 hover:bg-charcoal-600 text-white rounded-full transition-all"
              title="Switch Camera"
            >
              <SwitchCamera className="w-6 h-6" />
            </button>
            
            {hasTorch && (
              <button
                onClick={toggleTorch}
                className={`p-4 rounded-full transition-all ${
                  torchOn 
                    ? 'bg-gold text-charcoal' 
                    : 'bg-charcoal-700 hover:bg-charcoal-600 text-white'
                }`}
                title="Toggle Flashlight"
              >
                <Flashlight className="w-6 h-6" />
              </button>
            )}
          </div>
          
          <button
            onClick={handleManualEntry}
            className="w-full py-3 bg-charcoal-700 text-white font-medium rounded-xl hover:bg-charcoal-600 transition-all flex items-center justify-center gap-2"
          >
            <Keyboard className="w-5 h-5" />
            Enter Code Manually
          </button>
        </div>
      )}

      {/* Custom CSS for scanning animation */}
      <style>{`
        @keyframes scan {
          0%, 100% { top: 0; }
          50% { top: calc(100% - 2px); }
        }
        .animate-scan {
          animation: scan 2s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default QRCodeScanner;
