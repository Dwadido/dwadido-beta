import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { X, ShieldOff, Loader2, CheckCircle } from 'lucide-react';

interface BlockUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  userName?: string;
  onBlocked?: () => void;
}

const BlockUserModal: React.FC<BlockUserModalProps> = ({
  isOpen,
  onClose,
  userId,
  userName,
  onBlocked
}) => {
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  // Handle body scroll lock for iOS
  useEffect(() => {
    if (isOpen) {
      const scrollY = window.scrollY;
      document.body.style.position = 'fixed';
      document.body.style.top = `-${scrollY}px`;
      document.body.style.width = '100%';
    } else {
      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);
    }

    return () => {
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
    };
  }, [isOpen]);

  const handleBlock = async () => {
    setSubmitting(true);
    setError('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke('block-user', {
        body: {
          blocked_user_id: userId,
          action: 'block'
        }
      });

      if (fnError) throw fnError;
      if (data.error) throw new Error(data.error);

      setSubmitted(true);
      onBlocked?.();
      setTimeout(() => {
        onClose();
        setSubmitted(false);
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to block user');
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden" style={{ WebkitOverflowScrolling: 'touch' }}>
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      
      {/* Subtle gold ambient glow */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#C9A24D]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#C9A24D]/5 rounded-full blur-3xl" />
      </div>
      
      <div className="relative min-h-full flex items-center justify-center p-4 py-8">
        <div className="relative bg-[#141414] rounded-2xl w-full max-w-md shadow-2xl border border-[#C9A24D]/20">
          {submitted ? (
            <div className="p-8 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-[#C9A24D]/10 rounded-full flex items-center justify-center border border-[#C9A24D]/30">
                <CheckCircle className="w-8 h-8 text-[#C9A24D]" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">User Blocked</h3>
              <p className="text-gray-400">
                {userName || 'This user'} has been blocked. They won't be able to contact you anymore.
              </p>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between p-6 border-b border-[#1a1a1a]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#C9A24D]/10 rounded-xl flex items-center justify-center border border-[#C9A24D]/30">
                    <ShieldOff className="w-5 h-5 text-[#C9A24D]" />
                  </div>
                  <h2 className="text-lg font-bold text-white">Block User</h2>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-[#1a1a1a] rounded-xl transition-colors text-gray-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                <div className="text-center">
                  <p className="text-white font-medium mb-2">
                    Are you sure you want to block {userName || 'this user'}?
                  </p>
                  <p className="text-gray-500 text-sm">
                    When you block someone:
                  </p>
                  <ul className="mt-3 text-sm text-gray-400 space-y-2 text-left bg-[#1a1a1a] rounded-xl p-4 border border-[#252525]">
                    <li className="flex items-start gap-2">
                      <span className="text-[#C9A24D] mt-0.5">•</span>
                      They won't be able to send you messages
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#C9A24D] mt-0.5">•</span>
                      Any active connections will be ended
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#C9A24D] mt-0.5">•</span>
                      They won't know they've been blocked
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#C9A24D] mt-0.5">•</span>
                      You can unblock them later from Settings
                    </li>
                  </ul>
                </div>

                {error && (
                  <div className="p-3 bg-red-900/20 border border-red-500/30 rounded-xl text-red-400 text-sm">
                    {error}
                  </div>
                )}

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 py-3 bg-[#1a1a1a] text-gray-300 font-medium rounded-xl hover:bg-[#252525] transition-all border border-[#252525]"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleBlock}
                    disabled={submitting}
                    className="flex-1 py-3 bg-[#C9A24D] text-[#141414] font-semibold rounded-xl hover:bg-[#D4AF5B] transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-[#C9A24D]/20"
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Blocking...
                      </>
                    ) : (
                      'Block User'
                    )}
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default BlockUserModal;
