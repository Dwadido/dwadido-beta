import React, { useState } from 'react';
import { AlertTriangle, Info, X, Shield, ChevronRight } from 'lucide-react';

export interface SafetyAlert {
  messageId: string;
  alertType: 'scam' | 'manipulation' | 'pressure' | 'personal_info' | 'external_link' | 'inappropriate';
  shortInsight: string;
  detailedExplanation: string;
  confidence: 'low' | 'medium' | 'high';
}

interface SafetyAlertBannerProps {
  alert: SafetyAlert;
  onDismiss: (messageId: string) => void;
}

const alertTypeLabels: Record<SafetyAlert['alertType'], string> = {
  scam: 'Potential Scam',
  manipulation: 'Manipulation Pattern',
  pressure: 'Pressure Tactics',
  personal_info: 'Personal Info Request',
  external_link: 'External Link',
  inappropriate: 'Inappropriate Content'
};

const alertTypeColors: Record<SafetyAlert['alertType'], { bg: string; border: string; text: string; icon: string }> = {
  scam: { bg: 'bg-red-500/10', border: 'border-red-500/20', text: 'text-red-400', icon: 'text-red-400' },
  manipulation: { bg: 'bg-amber-500/10', border: 'border-amber-500/20', text: 'text-amber-400', icon: 'text-amber-400' },
  pressure: { bg: 'bg-orange-500/10', border: 'border-orange-500/20', text: 'text-orange-400', icon: 'text-orange-400' },
  personal_info: { bg: 'bg-yellow-500/10', border: 'border-yellow-500/20', text: 'text-yellow-400', icon: 'text-yellow-400' },
  external_link: { bg: 'bg-blue-500/10', border: 'border-blue-500/20', text: 'text-blue-400', icon: 'text-blue-400' },
  inappropriate: { bg: 'bg-purple-500/10', border: 'border-purple-500/20', text: 'text-purple-400', icon: 'text-purple-400' }
};

const SafetyAlertBanner: React.FC<SafetyAlertBannerProps> = ({ alert, onDismiss }) => {
  const [showDetails, setShowDetails] = useState(false);
  const colors = alertTypeColors[alert.alertType];

  return (
    <>
      {/* Main Alert Banner */}
      <div className={`mx-2 mb-2 rounded-xl ${colors.bg} border ${colors.border} overflow-hidden animate-in fade-in slide-in-from-top-2 duration-300`}>
        <div className="px-3 py-2.5">
          <div className="flex items-start gap-2.5">
            {/* Icon */}
            <div className={`flex-shrink-0 mt-0.5 ${colors.icon}`}>
              <AlertTriangle className="w-4 h-4" />
            </div>
            
            {/* Content */}
            <div className="flex-1 min-w-0">
              {/* Type Label */}
              <div className="flex items-center gap-2 mb-1">
                <span className={`text-xs font-medium ${colors.text}`}>
                  {alertTypeLabels[alert.alertType]}
                </span>
                {alert.confidence === 'high' && (
                  <span className="text-[10px] px-1.5 py-0.5 bg-white/10 rounded text-gray-400">
                    High confidence
                  </span>
                )}
              </div>
              
              {/* Insight */}
              <p className="text-sm text-gray-300 leading-snug">
                {alert.shortInsight}
              </p>
              
              {/* Actions */}
              <div className="flex items-center gap-3 mt-2">
                <button
                  onClick={() => setShowDetails(true)}
                  className={`text-xs font-medium ${colors.text} hover:underline flex items-center gap-1 transition-all`}
                >
                  <Info className="w-3 h-3" />
                  Learn more
                </button>
                <button
                  onClick={() => onDismiss(alert.messageId)}
                  className="text-xs text-gray-500 hover:text-gray-400 transition-all"
                >
                  Dismiss
                </button>
              </div>
            </div>
            
            {/* Close Button */}
            <button
              onClick={() => onDismiss(alert.messageId)}
              className="flex-shrink-0 p-1 text-gray-500 hover:text-gray-400 hover:bg-white/5 rounded transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
        
        {/* AI Disclaimer */}
        <div className="px-3 py-1.5 bg-black/20 border-t border-white/5">
          <p className="text-[10px] text-gray-500 flex items-center gap-1">
            <Shield className="w-3 h-3" />
            AI insight only — you decide what action to take
          </p>
        </div>
      </div>

      {/* Learn More Modal */}
      {showDetails && (
        <div className="fixed inset-0 z-[60] overflow-y-auto overflow-x-hidden">
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm" 
            onClick={() => setShowDetails(false)} 
          />
          
          <div className="relative min-h-full flex items-center justify-center p-4">
            <div className="relative w-full max-w-md bg-[#141414] rounded-2xl shadow-2xl overflow-hidden border border-[#2a2a2a] animate-in fade-in zoom-in-95 duration-200">
              {/* Header */}
              <div className={`px-5 py-4 ${colors.bg} border-b ${colors.border}`}>
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full ${colors.bg} border ${colors.border} flex items-center justify-center`}>
                    <AlertTriangle className={`w-5 h-5 ${colors.icon}`} />
                  </div>
                  <div>
                    <h3 className={`font-semibold ${colors.text}`}>
                      {alertTypeLabels[alert.alertType]}
                    </h3>
                    <p className="text-xs text-gray-400">Safety Insight</p>
                  </div>
                </div>
              </div>
              
              {/* Content */}
              <div className="p-5 space-y-4">
                {/* What was detected */}
                <div>
                  <h4 className="text-sm font-medium text-white mb-2">What was detected</h4>
                  <p className="text-sm text-gray-300 leading-relaxed">
                    {alert.shortInsight}
                  </p>
                </div>
                
                {/* Why this was flagged */}
                <div>
                  <h4 className="text-sm font-medium text-white mb-2">Why this was flagged</h4>
                  <p className="text-sm text-gray-400 leading-relaxed">
                    {alert.detailedExplanation}
                  </p>
                </div>
                
                {/* What you can do */}
                <div className="bg-[#1a1a1a] rounded-xl p-4 border border-[#2a2a2a]">
                  <h4 className="text-sm font-medium text-white mb-3 flex items-center gap-2">
                    <Shield className="w-4 h-4 text-[#C9A24D]" />
                    What you can do
                  </h4>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2 text-sm text-gray-400">
                      <ChevronRight className="w-4 h-4 text-gray-500 flex-shrink-0 mt-0.5" />
                      <span>Trust your instincts — if something feels off, it might be</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm text-gray-400">
                      <ChevronRight className="w-4 h-4 text-gray-500 flex-shrink-0 mt-0.5" />
                      <span>Take your time before sharing personal information</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm text-gray-400">
                      <ChevronRight className="w-4 h-4 text-gray-500 flex-shrink-0 mt-0.5" />
                      <span>You can report or block this user if needed</span>
                    </li>
                    <li className="flex items-start gap-2 text-sm text-gray-400">
                      <ChevronRight className="w-4 h-4 text-gray-500 flex-shrink-0 mt-0.5" />
                      <span>This alert may be a false positive — context matters</span>
                    </li>
                  </ul>
                </div>
                
                {/* Confidence indicator */}
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500">AI Confidence Level</span>
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1">
                      <div className={`w-2 h-2 rounded-full ${
                        alert.confidence === 'low' || alert.confidence === 'medium' || alert.confidence === 'high' 
                          ? colors.text.replace('text-', 'bg-') 
                          : 'bg-gray-600'
                      }`} />
                      <div className={`w-2 h-2 rounded-full ${
                        alert.confidence === 'medium' || alert.confidence === 'high' 
                          ? colors.text.replace('text-', 'bg-') 
                          : 'bg-gray-600'
                      }`} />
                      <div className={`w-2 h-2 rounded-full ${
                        alert.confidence === 'high' 
                          ? colors.text.replace('text-', 'bg-') 
                          : 'bg-gray-600'
                      }`} />
                    </div>
                    <span className={`capitalize ${colors.text}`}>{alert.confidence}</span>
                  </div>
                </div>
              </div>
              
              {/* Footer */}
              <div className="px-5 py-4 bg-[#0d0d0d] border-t border-[#2a2a2a]">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-gray-500 flex items-center gap-1">
                    <Shield className="w-3 h-3" />
                    AI provides insights only — you decide
                  </p>
                  <button
                    onClick={() => setShowDetails(false)}
                    className="px-4 py-2 bg-[#2a2a2a] hover:bg-[#333] text-white text-sm rounded-lg transition-all"
                  >
                    Got it
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default SafetyAlertBanner;
