import React, { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import {
  WebRTCManager,
  ConnectionState,
  NetworkStats,
  checkWebRTCSupport,
} from '@/lib/webrtc';
import {
  X,
  Video,
  VideoOff,
  Mic,
  MicOff,
  PhoneOff,
  Clock,
  User,
  Loader2,
  AlertCircle,
  Timer,
  WifiOff,
  Signal,
  SignalLow,
  SignalMedium,
  SignalHigh,
  RefreshCw,
  Monitor,
} from 'lucide-react';

interface VideoCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  matchId: string;
  callId: string | null;
  otherUser: {
    id: string;
    display_name: string | null;
    avatar_url: string | null;
  };
  isIncoming?: boolean;
  onCallEnded?: () => void;
}

type CallStatus = 'pending' | 'accepted' | 'declined' | 'active' | 'ended' | 'expired';

interface CallData {
  id: string;
  match_id: string;
  initiator_id: string;
  recipient_id: string;
  status: CallStatus;
  initiator_consent: boolean;
  recipient_consent: boolean;
  duration_minutes: number;
  started_at: string | null;
  ended_at: string | null;
  ended_by: string | null;
  end_reason: string | null;
}

const VideoCallModal: React.FC<VideoCallModalProps> = ({
  isOpen,
  onClose,
  matchId,
  callId,
  otherUser,
  isIncoming = false,
  onCallEnded
}) => {
  const { user } = useAuth();
  const [call, setCall] = useState<CallData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [timeRemaining, setTimeRemaining] = useState<number>(0);
  const [callEnding, setCallEnding] = useState(false);
  const [showEndConfirm, setShowEndConfirm] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  
  // WebRTC state
  const [connectionState, setConnectionState] = useState<ConnectionState>('new');
  const [networkStats, setNetworkStats] = useState<NetworkStats | null>(null);
  const [webrtcSupported, setWebrtcSupported] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const webrtcManagerRef = useRef<WebRTCManager | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const pollRef = useRef<NodeJS.Timeout | null>(null);
  const originalVideoTrackRef = useRef<MediaStreamTrack | null>(null);

  // Check WebRTC support on mount
  useEffect(() => {
    const support = checkWebRTCSupport();
    setWebrtcSupported(support.supported);
    if (!support.supported) {
      setError(`WebRTC not supported. Missing: ${support.missingFeatures.join(', ')}`);
    }
  }, []);

  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Get timer color based on remaining time
  const getTimerColor = () => {
    if (timeRemaining <= 30) return 'text-red-400';
    if (timeRemaining <= 60) return 'text-amber-400';
    return 'text-white';
  };

  // Get network quality icon and color
  const getNetworkQualityDisplay = () => {
    if (!networkStats) return { icon: Signal, color: 'text-gray-500', label: 'Checking...' };
    
    switch (networkStats.quality) {
      case 'excellent':
        return { icon: SignalHigh, color: 'text-green-400', label: 'Excellent' };
      case 'good':
        return { icon: SignalMedium, color: 'text-green-400', label: 'Good' };
      case 'fair':
        return { icon: SignalLow, color: 'text-amber-400', label: 'Fair' };
      case 'poor':
        return { icon: WifiOff, color: 'text-red-400', label: 'Poor' };
      default:
        return { icon: Signal, color: 'text-gray-500', label: 'Unknown' };
    }
  };

  // Get connection state display
  const getConnectionStateDisplay = () => {
    switch (connectionState) {
      case 'new':
        return { color: 'text-gray-400', label: 'Initializing...', pulse: false };
      case 'connecting':
        return { color: 'text-amber-400', label: 'Connecting...', pulse: true };
      case 'connected':
        return { color: 'text-green-400', label: 'Connected', pulse: true };
      case 'disconnected':
        return { color: 'text-amber-400', label: 'Disconnected', pulse: false };
      case 'reconnecting':
        return { color: 'text-amber-400', label: 'Reconnecting...', pulse: true };
      case 'failed':
        return { color: 'text-red-400', label: 'Connection Failed', pulse: false };
      case 'closed':
        return { color: 'text-gray-400', label: 'Closed', pulse: false };
      default:
        return { color: 'text-gray-400', label: 'Unknown', pulse: false };
    }
  };

  // Initialize camera
  const initializeCamera = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: 'user',
        },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        }
      });
      localStreamRef.current = stream;
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }
      
      // Store original video track for screen sharing toggle
      originalVideoTrackRef.current = stream.getVideoTracks()[0];
      
      return stream;
    } catch (err) {
      console.error('Failed to access camera:', err);
      setError('Unable to access camera/microphone. Please check permissions.');
      return null;
    }
  }, []);

  // Initialize WebRTC connection (STUN-only, no TURN required)
  const initializeWebRTC = useCallback(async (callData: CallData) => {
    if (!user || !localStreamRef.current) return;

    const isInitiator = callData.initiator_id === user.id;
    
    // Create WebRTC manager (uses free STUN servers for NAT traversal)
    webrtcManagerRef.current = new WebRTCManager(
      callData.id,
      user.id,
      otherUser.id,
      isInitiator,
      {
        onRemoteStream: (stream) => {
          console.log('Received remote stream');
          if (remoteVideoRef.current) {
            remoteVideoRef.current.srcObject = stream;
          }
        },
        onConnectionStateChange: (state) => {
          console.log('Connection state changed:', state);
          setConnectionState(state);
        },
        onNetworkQualityChange: (stats) => {
          setNetworkStats(stats);
        },
        onError: (error) => {
          console.error('WebRTC error:', error);
          setError(error.message);
        },
        onIceCandidate: (candidate) => {
          console.log('ICE candidate generated');
        },
      }
    );

    // Initialize the connection
    await webrtcManagerRef.current.initialize(localStreamRef.current);
  }, [user, otherUser.id]);


  // Stop camera and WebRTC
  const stopCamera = useCallback(() => {
    // Close WebRTC connection
    if (webrtcManagerRef.current) {
      webrtcManagerRef.current.close();
      webrtcManagerRef.current = null;
    }

    // Stop local stream
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = null;
    }

    // Clear video elements
    if (localVideoRef.current) {
      localVideoRef.current.srcObject = null;
    }
    if (remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = null;
    }

    originalVideoTrackRef.current = null;
    setConnectionState('closed');
    setNetworkStats(null);
  }, []);

  // Toggle camera
  const toggleCamera = () => {
    if (localStreamRef.current) {
      const videoTrack = localStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setCameraOn(videoTrack.enabled);
        webrtcManagerRef.current?.toggleVideo(videoTrack.enabled);
      }
    }
  };

  // Toggle microphone
  const toggleMic = () => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setMicOn(audioTrack.enabled);
        webrtcManagerRef.current?.toggleAudio(audioTrack.enabled);
      }
    }
  };

  // Toggle screen sharing
  const toggleScreenShare = async () => {
    if (!webrtcManagerRef.current || !localStreamRef.current) return;

    try {
      if (isScreenSharing) {
        // Switch back to camera
        if (originalVideoTrackRef.current) {
          await webrtcManagerRef.current.replaceVideoTrack(originalVideoTrackRef.current);
          localStreamRef.current.removeTrack(localStreamRef.current.getVideoTracks()[0]);
          localStreamRef.current.addTrack(originalVideoTrackRef.current);
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = localStreamRef.current;
          }
        }
        setIsScreenSharing(false);
      } else {
        // Start screen sharing
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: { cursor: 'always' },
          audio: false,
        });
        
        const screenTrack = screenStream.getVideoTracks()[0];
        
        // Handle when user stops sharing via browser UI
        screenTrack.onended = () => {
          toggleScreenShare();
        };
        
        await webrtcManagerRef.current.replaceVideoTrack(screenTrack);
        localStreamRef.current.removeTrack(localStreamRef.current.getVideoTracks()[0]);
        localStreamRef.current.addTrack(screenTrack);
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = localStreamRef.current;
        }
        setIsScreenSharing(true);
      }
    } catch (err) {
      console.error('Screen sharing error:', err);
      setError('Failed to share screen');
    }
  };

  // Fetch call data
  const fetchCall = useCallback(async () => {
    if (!callId) return;
    
    try {
      const { data, error: fetchError } = await supabase.functions.invoke('video-call', {
        body: { action: 'get_call', call_id: callId }
      });

      if (fetchError) throw fetchError;
      if (data?.call) {
        setCall(data.call);
        
        // If call became active, start timer
        if (data.call.status === 'active' && data.call.started_at) {
          const startTime = new Date(data.call.started_at).getTime();
          const durationMs = data.call.duration_minutes * 60 * 1000;
          const endTime = startTime + durationMs;
          const remaining = Math.max(0, Math.floor((endTime - Date.now()) / 1000));
          setTimeRemaining(remaining);
        }
        
        // If call ended, close modal
        if (data.call.status === 'ended' || data.call.status === 'declined') {
          stopCamera();
          onCallEnded?.();
          onClose();
        }
      }
    } catch (err) {
      console.error('Error fetching call:', err);
    }
  }, [callId, onClose, onCallEnded, stopCamera]);

  // Accept call
  const acceptCall = async () => {
    if (!callId) return;
    
    setLoading(true);
    try {
      // Initialize camera first
      const stream = await initializeCamera();
      if (!stream) {
        setLoading(false);
        return;
      }

      const { data, error: acceptError } = await supabase.functions.invoke('video-call', {
        body: { action: 'accept', call_id: callId }
      });

      if (acceptError) throw acceptError;
      if (data?.call) {
        setCall(data.call);
        // Initialize WebRTC after accepting
        await initializeWebRTC(data.call);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to accept call');
    } finally {
      setLoading(false);
    }
  };

  // Decline call
  const declineCall = async () => {
    if (!callId) return;
    
    try {
      await supabase.functions.invoke('video-call', {
        body: { action: 'decline', call_id: callId }
      });
      stopCamera();
      onCallEnded?.();
      onClose();
    } catch (err) {
      console.error('Error declining call:', err);
    }
  };

  // End call
  const endCall = async () => {
    if (!callId) return;
    
    setCallEnding(true);
    try {
      await supabase.functions.invoke('video-call', {
        body: { action: 'end', call_id: callId }
      });
      stopCamera();
      onCallEnded?.();
      onClose();
    } catch (err) {
      console.error('Error ending call:', err);
    } finally {
      setCallEnding(false);
    }
  };

  // Complete call (timer finished)
  const completeCall = useCallback(async () => {
    if (!callId) return;
    
    try {
      await supabase.functions.invoke('video-call', {
        body: { action: 'complete', call_id: callId }
      });
      stopCamera();
      onCallEnded?.();
      onClose();
    } catch (err) {
      console.error('Error completing call:', err);
    }
  }, [callId, onClose, onCallEnded, stopCamera]);

  // Initial load
  useEffect(() => {
    if (!isOpen || !callId) return;
    
    setLoading(true);
    setError(null);
    
    const init = async () => {
      await fetchCall();
      setLoading(false);
    };
    
    init();
    
    // Poll for call status updates (fallback for realtime)
    pollRef.current = setInterval(fetchCall, 3000);
    
    return () => {
      if (pollRef.current) {
        clearInterval(pollRef.current);
      }
    };
  }, [isOpen, callId, fetchCall]);

  // Initialize camera and WebRTC when call is active
  useEffect(() => {
    if (call?.status === 'active' && !webrtcManagerRef.current && user) {
      const setup = async () => {
        const stream = await initializeCamera();
        if (stream) {
          await initializeWebRTC(call);
        }
      };
      setup();
    }
  }, [call?.status, user, initializeCamera, initializeWebRTC, call]);

  // Timer countdown
  useEffect(() => {
    if (call?.status === 'active' && timeRemaining > 0) {
      timerRef.current = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            completeCall();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [call?.status, timeRemaining, completeCall]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
      if (timerRef.current) clearInterval(timerRef.current);
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [stopCamera]);

  // Handle body scroll lock
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  // WebRTC not supported
  if (!webrtcSupported) {
    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 backdrop-blur-sm">
        <div className="w-full max-w-sm mx-4 bg-[#141414] rounded-2xl border border-[#2a2a2a] overflow-hidden p-8 text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-red-500/10 rounded-full flex items-center justify-center border border-red-500/20">
            <AlertCircle className="w-8 h-8 text-red-400" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">Video Calling Not Supported</h3>
          <p className="text-gray-400 text-sm mb-6">
            Your browser doesn't support video calling. Please try using a modern browser like Chrome, Firefox, or Safari.
          </p>
          <button
            onClick={onClose}
            className="px-6 py-3 bg-[#2a2a2a] hover:bg-[#333] text-white rounded-xl transition-all"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  // Incoming call - waiting for user to accept
  if (isIncoming && call?.status === 'pending') {
    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 backdrop-blur-sm">
        <div className="w-full max-w-sm mx-4 bg-[#141414] rounded-2xl border border-[#2a2a2a] overflow-hidden">
          <div className="p-8 text-center">
            {/* Caller Avatar */}
            <div className="relative mx-auto w-24 h-24 mb-6">
              <div className="absolute inset-0 bg-[#C9A24D]/20 rounded-full animate-ping" />
              {otherUser.avatar_url ? (
                <img
                  src={otherUser.avatar_url}
                  alt={otherUser.display_name || 'Caller'}
                  className="relative w-24 h-24 rounded-full object-cover ring-4 ring-[#C9A24D]/30"
                />
              ) : (
                <div className="relative w-24 h-24 rounded-full bg-[#1a1a1a] flex items-center justify-center ring-4 ring-[#C9A24D]/30">
                  <User className="w-12 h-12 text-[#C9A24D]" />
                </div>
              )}
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 bg-[#C9A24D] rounded-full">
                <Video className="w-4 h-4 text-[#141414]" />
              </div>
            </div>

            <h3 className="text-xl font-semibold text-white mb-2">
              Incoming Video Call
            </h3>
            <p className="text-gray-400 mb-2">
              {otherUser.display_name || 'Someone'} wants to video chat
            </p>
            <div className="flex items-center justify-center gap-2 text-[#C9A24D] text-sm mb-8">
              <Timer className="w-4 h-4" />
              <span>{call?.duration_minutes || 5} minute speed date</span>
            </div>

            {/* Accept/Decline Buttons */}
            <div className="flex gap-4 justify-center">
              <button
                onClick={declineCall}
                className="w-16 h-16 bg-red-500/20 hover:bg-red-500/30 rounded-full flex items-center justify-center transition-all border border-red-500/30"
              >
                <PhoneOff className="w-7 h-7 text-red-400" />
              </button>
              <button
                onClick={acceptCall}
                disabled={loading}
                className="w-16 h-16 bg-green-500/20 hover:bg-green-500/30 rounded-full flex items-center justify-center transition-all border border-green-500/30 disabled:opacity-50"
              >
                {loading ? (
                  <Loader2 className="w-7 h-7 text-green-400 animate-spin" />
                ) : (
                  <Video className="w-7 h-7 text-green-400" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Outgoing call - waiting for other user to accept
  if (!isIncoming && call?.status === 'pending') {
    return (
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 backdrop-blur-sm">
        <div className="w-full max-w-sm mx-4 bg-[#141414] rounded-2xl border border-[#2a2a2a] overflow-hidden">
          <div className="p-8 text-center">
            {/* Recipient Avatar */}
            <div className="relative mx-auto w-24 h-24 mb-6">
              <div className="absolute inset-0 bg-[#C9A24D]/20 rounded-full animate-pulse" />
              {otherUser.avatar_url ? (
                <img
                  src={otherUser.avatar_url}
                  alt={otherUser.display_name || 'User'}
                  className="relative w-24 h-24 rounded-full object-cover ring-4 ring-[#C9A24D]/30"
                />
              ) : (
                <div className="relative w-24 h-24 rounded-full bg-[#1a1a1a] flex items-center justify-center ring-4 ring-[#C9A24D]/30">
                  <User className="w-12 h-12 text-[#C9A24D]" />
                </div>
              )}
            </div>

            <h3 className="text-xl font-semibold text-white mb-2">
              Calling {otherUser.display_name || 'User'}...
            </h3>
            <p className="text-gray-400 mb-2">
              Waiting for them to accept
            </p>
            <div className="flex items-center justify-center gap-2 text-[#C9A24D] text-sm mb-8">
              <Timer className="w-4 h-4" />
              <span>{call?.duration_minutes || 5} minute speed date</span>
            </div>

            <div className="flex items-center justify-center gap-2 text-gray-500 mb-8">
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Ringing...</span>
            </div>

            {/* Cancel Button */}
            <button
              onClick={declineCall}
              className="w-16 h-16 mx-auto bg-red-500/20 hover:bg-red-500/30 rounded-full flex items-center justify-center transition-all border border-red-500/30"
            >
              <PhoneOff className="w-7 h-7 text-red-400" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  const connectionDisplay = getConnectionStateDisplay();
  const networkDisplay = getNetworkQualityDisplay();
  const NetworkIcon = networkDisplay.icon;

  // Active call
  return (
    <div className="fixed inset-0 z-[60] bg-black">
      {/* Timer Bar */}
      <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/80 to-transparent p-4">
        <div className="flex items-center justify-between max-w-4xl mx-auto">
          <div className="flex items-center gap-3">
            {otherUser.avatar_url ? (
              <img
                src={otherUser.avatar_url}
                alt={otherUser.display_name || 'User'}
                className="w-10 h-10 rounded-full object-cover ring-2 ring-[#C9A24D]/30"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-[#1a1a1a] flex items-center justify-center ring-2 ring-[#C9A24D]/30">
                <User className="w-5 h-5 text-[#C9A24D]" />
              </div>
            )}
            <div>
              <p className="text-white font-medium">{otherUser.display_name || 'User'}</p>
              <p className={`text-xs flex items-center gap-1 ${connectionDisplay.color}`}>
                {connectionDisplay.pulse && (
                  <span className={`w-2 h-2 rounded-full animate-pulse ${
                    connectionState === 'connected' ? 'bg-green-400' : 'bg-amber-400'
                  }`} />
                )}
                {connectionState === 'reconnecting' && (
                  <RefreshCw className="w-3 h-3 animate-spin" />
                )}
                {connectionDisplay.label}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Network Quality Indicator */}
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`flex items-center gap-2 px-3 py-1.5 bg-[#1a1a1a]/80 rounded-full border border-[#2a2a2a] ${networkDisplay.color}`}
              title={networkStats ? `Latency: ${networkStats.latency}ms, Packet Loss: ${networkStats.packetLoss}%` : 'Checking network...'}
            >
              <NetworkIcon className="w-4 h-4" />
              <span className="text-xs hidden sm:inline">{networkDisplay.label}</span>
            </button>

            {/* Timer */}
            <div className={`flex items-center gap-2 px-4 py-2 bg-[#1a1a1a]/80 rounded-full border border-[#2a2a2a] ${getTimerColor()}`}>
              <Clock className="w-5 h-5" />
              <span className="font-mono text-lg font-semibold">{formatTime(timeRemaining)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Network Stats Panel */}
      {showSettings && networkStats && (
        <div className="absolute top-20 right-4 z-20 bg-[#1a1a1a]/95 border border-[#2a2a2a] rounded-xl p-4 w-64">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-white font-medium text-sm">Network Stats</h4>
            <button onClick={() => setShowSettings(false)} className="text-gray-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Quality</span>
              <span className={networkDisplay.color}>{networkDisplay.label}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Latency</span>
              <span className="text-white">{networkStats.latency}ms</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Packet Loss</span>
              <span className="text-white">{networkStats.packetLoss}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Jitter</span>
              <span className="text-white">{networkStats.jitter}ms</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Bitrate</span>
              <span className="text-white">{networkStats.bitrate} kbps</span>
            </div>
          </div>
        </div>
      )}

      {/* Video Feeds */}
      <div className="absolute inset-0 flex items-center justify-center">
        {/* Remote Video */}
        <div className="w-full h-full bg-[#0d0d0d] flex items-center justify-center">
          <video
            ref={remoteVideoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />
          
          {/* Fallback when no remote stream */}
          {connectionState !== 'connected' && (
            <div className="absolute inset-0 flex items-center justify-center bg-[#0d0d0d]">
              {otherUser.avatar_url ? (
                <div className="text-center">
                  <img
                    src={otherUser.avatar_url}
                    alt={otherUser.display_name || 'User'}
                    className="w-32 h-32 rounded-full object-cover mx-auto mb-4 ring-4 ring-[#C9A24D]/30"
                  />
                  <p className="text-gray-400">
                    {otherUser.display_name}
                  </p>
                  <p className={`text-sm mt-1 ${connectionDisplay.color}`}>
                    {connectionDisplay.label}
                  </p>
                </div>
              ) : (
                <div className="text-center">
                  <div className="w-32 h-32 rounded-full bg-[#1a1a1a] flex items-center justify-center mx-auto mb-4 ring-4 ring-[#C9A24D]/30">
                    <User className="w-16 h-16 text-[#C9A24D]" />
                  </div>
                  <p className="text-gray-400">{otherUser.display_name || 'User'}</p>
                  <p className={`text-sm mt-1 ${connectionDisplay.color}`}>
                    {connectionDisplay.label}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Local Video (Picture-in-Picture) */}
        <div className="absolute bottom-28 right-4 w-32 h-44 sm:w-40 sm:h-56 bg-[#1a1a1a] rounded-xl overflow-hidden border-2 border-[#2a2a2a] shadow-xl">
          {cameraOn ? (
            <video
              ref={localVideoRef}
              autoPlay
              muted
              playsInline
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <div className="text-center">
                <VideoOff className="w-8 h-8 text-gray-500 mx-auto mb-2" />
                <p className="text-gray-500 text-xs">Camera off</p>
              </div>
            </div>
          )}
          <div className="absolute bottom-2 left-2 flex items-center gap-1">
            <span className="px-2 py-1 bg-black/60 rounded text-xs text-white">
              {isScreenSharing ? 'Screen' : 'You'}
            </span>
            {!micOn && (
              <span className="p-1 bg-red-500/80 rounded">
                <MicOff className="w-3 h-3 text-white" />
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Controls Bar */}
      <div className="absolute bottom-0 left-0 right-0 z-10 bg-gradient-to-t from-black/80 to-transparent p-6">
        <div className="flex items-center justify-center gap-3 sm:gap-4 max-w-md mx-auto">
          {/* Mic Toggle */}
          <button
            onClick={toggleMic}
            className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center transition-all ${
              micOn 
                ? 'bg-[#2a2a2a] hover:bg-[#333] text-white' 
                : 'bg-red-500/20 text-red-400 border border-red-500/30'
            }`}
            title={micOn ? 'Mute microphone' : 'Unmute microphone'}
          >
            {micOn ? <Mic className="w-5 h-5 sm:w-6 sm:h-6" /> : <MicOff className="w-5 h-5 sm:w-6 sm:h-6" />}
          </button>

          {/* Camera Toggle */}
          <button
            onClick={toggleCamera}
            className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center transition-all ${
              cameraOn 
                ? 'bg-[#2a2a2a] hover:bg-[#333] text-white' 
                : 'bg-red-500/20 text-red-400 border border-red-500/30'
            }`}
            title={cameraOn ? 'Turn off camera' : 'Turn on camera'}
          >
            {cameraOn ? <Video className="w-5 h-5 sm:w-6 sm:h-6" /> : <VideoOff className="w-5 h-5 sm:w-6 sm:h-6" />}
          </button>

          {/* Screen Share Toggle */}
          <button
            onClick={toggleScreenShare}
            className={`w-12 h-12 sm:w-14 sm:h-14 rounded-full flex items-center justify-center transition-all ${
              isScreenSharing 
                ? 'bg-[#C9A24D]/20 text-[#C9A24D] border border-[#C9A24D]/30' 
                : 'bg-[#2a2a2a] hover:bg-[#333] text-white'
            }`}
            title={isScreenSharing ? 'Stop sharing' : 'Share screen'}
          >
            <Monitor className="w-5 h-5 sm:w-6 sm:h-6" />
          </button>

          {/* End Call */}
          <button
            onClick={() => setShowEndConfirm(true)}
            disabled={callEnding}
            className="w-14 h-14 sm:w-16 sm:h-16 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center transition-all disabled:opacity-50"
            title="End call"
          >
            {callEnding ? (
              <Loader2 className="w-6 h-6 sm:w-7 sm:h-7 text-white animate-spin" />
            ) : (
              <PhoneOff className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
            )}
          </button>
        </div>

        {/* Time Warning */}
        {timeRemaining <= 60 && timeRemaining > 0 && (
          <div className="text-center mt-4">
            <p className="text-amber-400 text-sm flex items-center justify-center gap-2">
              <AlertCircle className="w-4 h-4" />
              {timeRemaining <= 30 ? 'Call ending soon!' : 'Less than 1 minute remaining'}
            </p>
          </div>
        )}
      </div>

      {/* End Call Confirmation */}
      {showEndConfirm && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-sm mx-4 bg-[#141414] rounded-2xl border border-[#2a2a2a] p-6">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-red-500/10 rounded-full flex items-center justify-center border border-red-500/20">
                <PhoneOff className="w-8 h-8 text-red-400" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">End Call?</h3>
              <p className="text-gray-400 text-sm mb-6">
                Are you sure you want to end this video call?
              </p>
              
              <div className="flex gap-3">
                <button
                  onClick={() => setShowEndConfirm(false)}
                  className="flex-1 py-3 bg-[#2a2a2a] hover:bg-[#333] text-white rounded-xl transition-all"
                >
                  Continue Call
                </button>
                <button
                  onClick={endCall}
                  disabled={callEnding}
                  className="flex-1 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {callEnding ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    'End Call'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Error Display */}
      {error && (
        <div className="absolute top-20 left-4 right-4 z-20">
          <div className="max-w-md mx-auto bg-red-500/10 border border-red-500/30 rounded-xl p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-red-400 font-medium">Error</p>
              <p className="text-red-300 text-sm">{error}</p>
            </div>
            <button
              onClick={() => setError(null)}
              className="text-red-400 hover:text-red-300"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Connection Failed Overlay */}
      {connectionState === 'failed' && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/90 backdrop-blur-sm">
          <div className="w-full max-w-sm mx-4 bg-[#141414] rounded-2xl border border-[#2a2a2a] p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-red-500/10 rounded-full flex items-center justify-center border border-red-500/20">
              <WifiOff className="w-8 h-8 text-red-400" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">Connection Failed</h3>
            <p className="text-gray-400 text-sm mb-6">
              Unable to establish a stable connection. This could be due to network issues or firewall restrictions.
            </p>
            <div className="flex gap-3">
              <button
                onClick={endCall}
                className="flex-1 py-3 bg-[#2a2a2a] hover:bg-[#333] text-white rounded-xl transition-all"
              >
                End Call
              </button>
              <button
                onClick={async () => {
                  setConnectionState('new');
                  if (call) {
                    stopCamera();
                    const stream = await initializeCamera();
                    if (stream) {
                      await initializeWebRTC(call);
                    }
                  }
                }}
                className="flex-1 py-3 bg-[#C9A24D] hover:bg-[#B8913C] text-[#141414] rounded-xl transition-all flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-5 h-5" />
                Retry
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoCallModal;
