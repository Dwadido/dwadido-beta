import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

import { DWADIDO_CODE_EXPIRY_HOURS, DWADIDO_CODE_EXPIRY_DAYS } from '@/lib/globalData';

import { useAuth } from '@/contexts/AuthContext';

import { usePremium } from '@/contexts/PremiumContext';
import { 
  Heart, 
  Copy, 
  Share2, 
  QrCode, 
  Clock, 
  CheckCircle, 
  Plus, 
  Loader2,
  ArrowLeft,
  Sparkles,
  Users,
  Shield,
  Crown,
  AlertCircle,
  X,
  Lock,
  RefreshCw,
  Calendar,
  Layers,
  BarChart3,
  Infinity,
  AlertTriangle
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import QRCodeGenerator from '@/components/qr/QRCodeGenerator';
import CrushCodeShare from './CrushCodeShare';
import CodeExpirationPicker from './CodeExpirationPicker';
import BulkCodeGenerator from './BulkCodeGenerator';
import FreemiumUpsell, { UpsellTrigger } from './FreemiumUpsell';
import CrushCodeAnalytics from './CrushCodeAnalytics';

interface ShareStats {
  total: number;
  twitter: number;
  facebook: number;
  whatsapp: number;
  email: number;
  link_copies: number;
  time_limited: number;
}

interface CrushCardData {
  id: string;
  code: string;
  status: string;
  expires_at: string;
  created_at: string;
  code_expires_at?: string;
  extension_count?: number;
  is_single_use?: boolean;
  use_count?: number;
  max_uses?: number;
  total_shares?: number;
  twitter_shares?: number;
  facebook_shares?: number;
  whatsapp_shares?: number;
  email_shares?: number;
  link_copies?: number;
  time_limited_shares?: number;
}

interface CrushCardScreenProps {
  onBack: () => void;
  onCodeGenerated?: () => void;
}

const CrushCardScreen: React.FC<CrushCardScreenProps> = ({ onBack, onCodeGenerated }) => {
  const { user } = useAuth();
  const { isPremium, canUseFeature } = usePremium();
  const navigate = useNavigate();
  const [activeCards, setActiveCards] = useState<CrushCardData[]>([]);
  const [expiredCards, setExpiredCards] = useState<CrushCardData[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [showQR, setShowQR] = useState<string | null>(null);
  const [showShareModal, setShowShareModal] = useState<string | null>(null);
  const [shareStats, setShareStats] = useState<Record<string, ShareStats>>({});
  const [error, setError] = useState<string | null>(null);
  const [expiryHours, setExpiryHours] = useState(DWADIDO_CODE_EXPIRY_HOURS);

  const [codeExpiresAt, setCodeExpiresAt] = useState<Date | null>(null);
  const [extending, setExtending] = useState<string | null>(null);
  const [showExpirationPicker, setShowExpirationPicker] = useState(false);
  const [showBulkGenerator, setShowBulkGenerator] = useState(false);
  const [lifetimeCodeCount, setLifetimeCodeCount] = useState(0);
  
  // Upsell modal state
  const [upsellModal, setUpsellModal] = useState<{
    isOpen: boolean;
    trigger: UpsellTrigger;
    expiredCode?: string;
  }>({ isOpen: false, trigger: 'code_limit' });

  useEffect(() => {
    fetchActiveCards();
    fetchLifetimeCount();
  }, [user]);

  const fetchLifetimeCount = async () => {
    if (!user) return;
    
    try {
      // Get from user_analytics
      const { data: analytics } = await supabase
        .from('user_analytics')
        .select('lifetime_codes_created, total_codes_generated')
        .eq('user_id', user.id)
        .single();
      
      if (analytics) {
        setLifetimeCodeCount(analytics.lifetime_codes_created || analytics.total_codes_generated || 0);
      } else {
        // Fallback: count all cards
        const { count } = await supabase
          .from('crush_cards')
          .select('id', { count: 'exact', head: true })
          .eq('creator_id', user.id);
        
        setLifetimeCodeCount(count || 0);
      }
    } catch (err) {
      console.error('Error fetching lifetime count:', err);
    }
  };

  const fetchActiveCards = async () => {
    if (!user) return;
    setLoading(true);

    // Fetch active cards
    const { data: activeData } = await supabase
      .from('crush_cards')
      .select('*')
      .eq('creator_id', user.id)
      .eq('status', 'active')
      .gt('expires_at', new Date().toISOString())
      .order('created_at', { ascending: false });

    // Fetch recently expired cards (for renewal option)
    const { data: expiredData } = await supabase
      .from('crush_cards')
      .select('*')
      .eq('creator_id', user.id)
      .or('status.eq.expired,status.eq.redeemed')
      .order('created_at', { ascending: false })
      .limit(5);

    if (activeData) {
      setActiveCards(activeData);
      const stats: Record<string, ShareStats> = {};
      activeData.forEach(card => {
        stats[card.id] = {
          total: card.total_shares || 0,
          twitter: card.twitter_shares || 0,
          facebook: card.facebook_shares || 0,
          whatsapp: card.whatsapp_shares || 0,
          email: card.email_shares || 0,
          link_copies: card.link_copies || 0,
          time_limited: card.time_limited_shares || 0
        };
      });
      setShareStats(stats);
    }

    if (expiredData) {
      setExpiredCards(expiredData);
    }

    setLoading(false);
  };

  // ── Client-side code generation (bypasses broken edge function URL parsing) ──
  function generateCrushCode(length = 6): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const arr = new Uint8Array(length);
    crypto.getRandomValues(arr);
    let code = '';
    for (let i = 0; i < length; i++) code += chars[arr[i] % chars.length];
    return code;
  }

  const handleGenerateCard = async () => {
    if (!user) return;
    
    setGenerating(true);
    setError(null);

    // ── CRITICAL: Ensure profile exists (crush_cards.creator_id FK → profiles.id) ──
    try {
      const { data: profileExists } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', user.id)
        .maybeSingle();

      if (!profileExists) {
        console.warn('[CrushCardScreen] Profile missing — auto-creating before code generation');
        let authEmail = user.email || '';
        let authDisplayName = '';
        try {
          const { data: authData } = await supabase.auth.getUser();
          if (authData?.user) {
            authEmail = authData.user.email || authEmail;
            authDisplayName = authData.user.user_metadata?.display_name || '';
          }
        } catch (e) { /* ignore */ }
        const displayName = authDisplayName || (authEmail ? authEmail.split('@')[0] : '') || 'User';
        const { error: insertErr } = await supabase
          .from('profiles')
          .insert({ id: user.id, email: authEmail, display_name: displayName, intent: 'dating', created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
        if (insertErr && insertErr.code !== '23505') {
          console.error('[CrushCardScreen] Failed to auto-create profile:', insertErr.message);
          setError('Could not verify your profile. Please refresh and try again.');
          setGenerating(false);
          return;
        }
      }
    } catch (e) {
      console.warn('[CrushCardScreen] Profile check failed, proceeding anyway:', e);
    }

    const expiresAt = new Date(Date.now() + expiryHours * 60 * 60 * 1000).toISOString();


    try {
      let card: CrushCardData | null = null;
      let lastError: any = null;

      // Build the insert row
      const insertRow: Record<string, any> = {
        creator_id: user.id,
        code: '', // will be set in the loop
        status: 'active',
        expires_at: expiresAt,
      };

      // Premium code_expires_at
      if (codeExpiresAt && isPremium) {
        insertRow.code_expires_at = codeExpiresAt.toISOString();
      }

      // Try up to 3 times in case of code collision (unique constraint violation)
      for (let attempt = 0; attempt < 3; attempt++) {
        const code = generateCrushCode();
        insertRow.code = code;
        console.log(`[CrushCardScreen] Generating code (attempt ${attempt + 1}): ${code}`);

        const { data, error: insertError } = await supabase
          .from('crush_cards')
          .insert(insertRow)
          .select('id, code, status, expires_at, created_at, code_expires_at, extension_count, is_single_use, use_count, max_uses')
          .single();

        if (insertError) {
          lastError = insertError;
          console.warn(`[CrushCardScreen] Insert attempt ${attempt + 1} failed:`, insertError.message, insertError.code);
          if (insertError.code === '23505') continue; // collision — retry
          break;
        }

        if (data) {
          card = data as CrushCardData;
          break;
        }
      }

      if (!card) {
        const msg = lastError?.message || 'Failed to generate code.';
        console.error('[CrushCardScreen] All code generation attempts failed:', lastError);
        throw new Error(msg);
      }

      // Success — update local state
      setActiveCards(prev => [card!, ...prev]);
      setShareStats(prev => ({
        ...prev,
        [card!.id]: { total: 0, twitter: 0, facebook: 0, whatsapp: 0, email: 0, link_copies: 0, time_limited: 0 }
      }));
      setLifetimeCodeCount(prev => prev + 1);
      setCodeExpiresAt(null);
      setShowExpirationPicker(false);
      onCodeGenerated?.();

    } catch (err: any) {
      console.error('[CrushCardScreen] Failed to generate card:', err);
      const msg = err?.message || 'Failed to generate card.';
      if (msg.includes('timed out') || msg.includes('timeout')) {
        setError('Code generation timed out. The server may be busy — please try again.');
      } else if (msg.includes('Failed to fetch') || msg.includes('Load failed') || msg.includes('network')) {
        setError('Cannot reach the server. Please check your connection and try again.');
      } else if (msg.includes('violates row-level security') || msg.includes('row-level security')) {
        setError('Permission denied. Please sign out and sign back in, then try again.');
      } else if (msg.includes('violates foreign key') || msg.includes('foreign key')) {
        setError('Your profile is still being set up. Please refresh the page and try again in a moment.');
      } else {
        setError(msg);
      }
    } finally {
      setGenerating(false);
    }
  };


  const handleExtendCode = async (cardId: string) => {

    if (!user) return;
    
    // Premium-only feature
    if (!canUseFeature('codeRenewal')) {
      const card = [...activeCards, ...expiredCards].find(c => c.id === cardId);
      setUpsellModal({ 
        isOpen: true, 
        trigger: 'renewal',
        expiredCode: card?.code 
      });
      return;
    }
    
    setExtending(cardId);
    try {
      const card = [...activeCards, ...expiredCards].find(c => c.id === cardId);
      if (!card) return;
      
      const currentExpiry = card.code_expires_at ? new Date(card.code_expires_at) : new Date(card.expires_at);
      const newExpiry = new Date(Math.max(currentExpiry.getTime(), Date.now()) + 24 * 60 * 60 * 1000);
      
      const updateData: any = { 
        code_expires_at: newExpiry.toISOString(),
        extension_count: (card.extension_count || 0) + 1
      };
      
      // If card was expired, reactivate it
      if (card.status === 'expired') {
        updateData.status = 'active';
        updateData.expires_at = new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString();
      }
      
      const { error } = await supabase
        .from('crush_cards')
        .update(updateData)
        .eq('id', cardId)
        .eq('creator_id', user.id);
      
      if (error) throw error;
      
      // Refresh cards
      await fetchActiveCards();
    } catch (err: any) {
      console.error('Failed to extend code:', err);
      setError('Failed to extend code. Please try again.');
    } finally {
      setExtending(null);
    }
  };

  const handleCopyCode = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(code);
      setTimeout(() => setCopied(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const handleShareTracked = (cardId: string, stats: ShareStats) => {
    setShareStats(prev => ({ ...prev, [cardId]: stats }));
  };

  const handleShare = (card: CrushCardData) => {
    setShowShareModal(card.id);
  };

  const handleBulkGenerate = () => {
    if (!canUseFeature('bulkGeneration')) {
      setUpsellModal({ isOpen: true, trigger: 'bulk' });
      return;
    }
    setShowBulkGenerator(true);
  };

  const handleViewAnalytics = () => {
    if (!canUseFeature('codeAnalytics')) {
      setUpsellModal({ isOpen: true, trigger: 'analytics' });
      return;
    }
    // Analytics is shown inline for premium users
  };

  const getTimeRemaining = (expiresAt: string) => {
    const expires = new Date(expiresAt);
    const now = new Date();
    const diff = expires.getTime() - now.getTime();
    
    if (diff <= 0) return 'Expired';
    
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 24) {
      return `${Math.floor(hours / 24)}d ${hours % 24}h remaining`;
    }
    return `${hours}h ${minutes}m remaining`;
  };

  // NOTE: Free user lifetime limit REMOVED for MVP/demo.
  // Free users can now always generate codes.
  const canGenerateFree = !isPremium; // was: !isPremium && lifetimeCodeCount === 0
  // Premium user: can always generate
  const canGeneratePremium = isPremium;
  const canGenerateMore = canGenerateFree || canGeneratePremium;


  if (loading) {
    return (
      <div className="min-h-screen bg-charcoal flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-gold animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-charcoal">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-charcoal/95 backdrop-blur-sm border-b border-charcoal-600">
        <div className="max-w-lg mx-auto px-4 py-4 flex items-center gap-4">
          <button
            onClick={onBack}
            className="p-2 text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-xl transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold text-white">Your Crush Cards</h1>

            <p className="text-sm text-gray-400">
              {isPremium ? (
                <span className="flex items-center gap-1">
                  <Infinity className="w-3 h-3" /> Unlimited codes
                </span>
              ) : (
                `${lifetimeCodeCount} code${lifetimeCodeCount !== 1 ? 's' : ''} created`
              )}
            </p>
          </div>

          {isPremium && (
            <span className="px-2 py-1 bg-gold/20 text-gold text-xs font-medium rounded-full flex items-center gap-1">
              <Crown className="w-3 h-3" />
              Premium
            </span>
          )}
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 py-8">
        {/* Free User Info Banner */}
        {!isPremium && (
          <div className="mb-6 p-4 bg-gradient-to-r from-charcoal-700 to-charcoal-800 rounded-xl border border-charcoal-600">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-gold/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <Heart className="w-5 h-5 text-gold" />
              </div>
              <div className="flex-1">
                <p className="text-xs text-gray-400 mt-1">
                  Create Crush Codes and share them to connect with people you like.
                </p>

                <button
                  onClick={() => navigate('/premium')}
                  className="mt-2 text-gold text-xs font-medium hover:underline flex items-center gap-1"
                >
                  <Crown className="w-3 h-3" />
                  Upgrade to Premium for analytics, bulk generation & more
                </button>
              </div>
            </div>
          </div>
        )}


        {/* Premium Quick Actions */}
        {isPremium && (
          <div className="mb-6 grid grid-cols-2 gap-3">
            <button
              onClick={handleBulkGenerate}
              className="p-4 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl border border-charcoal-600 transition-all text-left"
            >
              <Layers className="w-5 h-5 text-purple-400 mb-2" />
              <p className="text-sm font-medium text-white">Bulk Generate</p>
              <p className="text-xs text-gray-400">Create multiple codes</p>
            </button>
            <button
              onClick={() => {/* Analytics shown inline */}}
              className="p-4 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl border border-charcoal-600 transition-all text-left"
            >
              <BarChart3 className="w-5 h-5 text-green-400 mb-2" />
              <p className="text-sm font-medium text-white">Analytics</p>
              <p className="text-xs text-gray-400">View code stats</p>
            </button>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-xl flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          </div>
        )}

        {/* Active Cards */}
        {activeCards.length > 0 && (
          <div className="space-y-4 mb-8">
            {activeCards.map((card) => (
              <div key={card.id} className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-gold/10 via-gold/20 to-gold/10 blur-2xl opacity-50" />
                
                <div className="relative bg-gradient-to-br from-charcoal-700 via-charcoal-800 to-charcoal-700 rounded-2xl p-6 border border-gold/30">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Heart className="w-5 h-5 text-gold" fill="currentColor" />
                      <span className="text-gold font-medium text-sm">Crush Card</span>
                      {card.is_single_use && (
                        <span className="px-1.5 py-0.5 bg-orange-500/20 text-orange-400 text-[10px] font-medium rounded">
                          Single-use
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5 px-2 py-1 bg-green-500/10 rounded-full border border-green-500/20">
                      <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                      <span className="text-xs text-green-400 font-medium">Active</span>
                    </div>
                  </div>


                  {/* Code Display */}
                  <div className="bg-charcoal-900 rounded-xl p-4 mb-4 border border-charcoal-600">
                    <p className="text-3xl font-mono font-bold text-white tracking-[0.2em] text-center">
                      {card.code}
                    </p>
                  </div>

                  {/* Timer & Usage */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-gold" />
                      <span className="text-gold text-sm font-medium">{getTimeRemaining(card.expires_at)}</span>
                    </div>
                    {card.is_single_use && (
                      <span className="text-xs text-gray-400">
                        {card.use_count || 0}/{card.max_uses || 1} uses
                      </span>
                    )}
                  </div>

                  {/* Extend Button (Premium only) */}
                  {isPremium && (
                    <button
                      onClick={() => handleExtendCode(card.id)}
                      disabled={extending === card.id}
                      className="w-full mb-4 py-2 bg-charcoal-600 hover:bg-charcoal-500 text-gray-300 rounded-lg transition-all flex items-center justify-center gap-2 text-sm"
                    >
                      {extending === card.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          <RefreshCw className="w-4 h-4" />
                          Extend +24h
                        </>
                      )}
                    </button>
                  )}

                  {/* Free user extend button (locked) */}
                  {!isPremium && (
                    <button
                      onClick={() => handleExtendCode(card.id)}
                      className="w-full mb-4 py-2 bg-charcoal-600 hover:bg-charcoal-500 text-gray-400 rounded-lg transition-all flex items-center justify-center gap-2 text-sm"
                    >
                      <Lock className="w-4 h-4" />
                      Extend Code
                      <Crown className="w-4 h-4 text-gold" />
                    </button>
                  )}

                  {/* Action Buttons */}
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => handleCopyCode(card.code)}
                      className="flex items-center justify-center gap-1.5 py-2.5 bg-charcoal-600 hover:bg-charcoal-500 text-white rounded-lg transition-all text-sm"
                    >
                      {copied === card.code ? (
                        <>
                          <CheckCircle className="w-4 h-4 text-green-400" />
                          <span>Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                    <button
                      onClick={() => handleShare(card)}
                      className="flex items-center justify-center gap-1.5 py-2.5 bg-gold hover:bg-gold-400 text-charcoal font-medium rounded-lg transition-all text-sm"
                    >
                      <Share2 className="w-4 h-4" />
                      <span>Share</span>
                    </button>
                    <button
                      onClick={() => setShowQR(showQR === card.id ? null : card.id)}
                      className="flex items-center justify-center gap-1.5 py-2.5 bg-charcoal-600 hover:bg-charcoal-500 text-white rounded-lg transition-all text-sm"
                    >
                      <QrCode className="w-4 h-4" />
                      <span>QR</span>
                    </button>
                  </div>

                  {/* QR Code Display */}
                  {showQR === card.id && (
                    <div className="mt-4 pt-4 border-t border-charcoal-600">
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-sm text-gray-400">Scannable QR Code</span>
                        <button
                          onClick={() => setShowQR(null)}
                          className="p-1 text-gray-500 hover:text-white transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <QRCodeGenerator 
                        value={card.code} 
                        size={180}
                        showActions={isPremium}
                      />
                      {!isPremium && (
                        <p className="text-center text-gray-500 text-xs mt-3">
                          <Lock className="w-3 h-3 inline mr-1" />
                          QR printing available with Premium
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Expired Cards (Premium can renew) */}
        {expiredCards.length > 0 && (
          <div className="mb-8">
            <h3 className="text-sm font-medium text-gray-400 mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Expired / Used Codes
            </h3>
            <div className="space-y-2">
              {expiredCards.slice(0, 3).map((card) => (
                <div
                  key={card.id}
                  className="flex items-center justify-between p-3 bg-charcoal-700/50 rounded-xl border border-charcoal-600"
                >
                  <div>
                    <p className="font-mono font-bold text-gray-400">{card.code}</p>
                    <p className="text-xs text-gray-500">
                      {card.status === 'redeemed' ? 'Redeemed' : 'Expired'}
                    </p>
                  </div>
                  {card.status === 'expired' && (
                    <button
                      onClick={() => handleExtendCode(card.id)}
                      disabled={extending === card.id}
                      className={`px-3 py-1.5 text-sm font-medium rounded-lg flex items-center gap-1 transition-colors ${
                        isPremium
                          ? 'bg-gold/20 text-gold hover:bg-gold/30'
                          : 'bg-charcoal-600 text-gray-400'
                      }`}
                    >
                      {extending === card.id ? (
                        <Loader2 className="w-3 h-3 animate-spin" />
                      ) : (
                        <>
                          {!isPremium && <Lock className="w-3 h-3" />}
                          <RefreshCw className="w-3 h-3" />
                          Renew
                          {!isPremium && <Crown className="w-3 h-3 text-gold" />}
                        </>
                      )}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Generate New Code Section */}
        {canGenerateMore ? (
          <div className="bg-charcoal-700 rounded-2xl p-6 border border-charcoal-600">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
              <Plus className="w-5 h-5 text-gold" />
              Generate New Code
            </h3>


            {/* Expiry Hours Selector */}
            <div className="mb-4">
              <label className="block text-sm text-gray-400 mb-2">Code Validity</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { hours: DWADIDO_CODE_EXPIRY_HOURS, label: `${DWADIDO_CODE_EXPIRY_DAYS}d` },
                  { hours: DWADIDO_CODE_EXPIRY_HOURS + 168, label: `${DWADIDO_CODE_EXPIRY_DAYS + 7}d` },
                  { hours: DWADIDO_CODE_EXPIRY_HOURS + 336, label: `${DWADIDO_CODE_EXPIRY_DAYS + 14}d` },
                ].map(({ hours, label }) => {
                  const isDisabled = !isPremium && hours > DWADIDO_CODE_EXPIRY_HOURS;
                  
                  return (
                    <button
                      key={hours}
                      onClick={() => !isDisabled && setExpiryHours(hours)}
                      disabled={isDisabled}
                      className={`py-2 px-3 rounded-lg text-sm font-medium transition-all relative ${
                        expiryHours === hours
                          ? 'bg-gold text-charcoal'
                          : isDisabled
                            ? 'bg-charcoal-600 text-gray-500 cursor-not-allowed'
                            : 'bg-charcoal-600 text-gray-300 hover:bg-charcoal-500'
                      }`}
                    >
                      {label}
                      {isDisabled && (
                        <Lock className="w-3 h-3 absolute top-1 right-1 text-gray-500" />
                      )}
                    </button>
                  );
                })}
              </div>
              {!isPremium && (
                <p className="text-xs text-gray-500 mt-2 flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  Free codes are valid for {DWADIDO_CODE_EXPIRY_DAYS} days
                </p>
              )}

            </div>

            {/* Code Expiration Picker (Premium only) */}
            {isPremium && (
              <div className="mb-4 border-t border-charcoal-600 pt-4">
                <button
                  onClick={() => setShowExpirationPicker(!showExpirationPicker)}
                  className="w-full flex items-center justify-between p-3 bg-charcoal-600 hover:bg-charcoal-500 rounded-lg transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-orange-400" />
                    <span className="text-sm text-gray-300">
                      {codeExpiresAt 
                        ? `Expires: ${codeExpiresAt.toLocaleDateString()}`
                        : 'Set Code Expiration (Optional)'
                      }
                    </span>
                  </div>
                  <X 
                    className={`w-4 h-4 text-gray-400 transition-transform ${showExpirationPicker ? 'rotate-45' : 'rotate-0'}`} 
                  />
                </button>
                
                {showExpirationPicker && (
                  <div className="mt-3 p-4 bg-charcoal-800 rounded-lg border border-charcoal-600">
                    <CodeExpirationPicker
                      value={codeExpiresAt}
                      onChange={setCodeExpiresAt}
                      maxDays={90}
                      isPremium={true}
                    />
                  </div>
                )}
              </div>
            )}

            <button
              onClick={handleGenerateCard}
              disabled={generating}
              className="w-full py-4 bg-gold hover:bg-gold-400 text-charcoal font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shadow-gold"
            >
              {generating ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <Plus className="w-5 h-5" />
                  Generate Code

                </>
              )}
            </button>
          </div>
        ) : (
          <div className="bg-charcoal-700 rounded-2xl p-6 border border-charcoal-600 text-center">
            <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-6 h-6 text-gold" />
            </div>
            <h3 className="text-lg font-semibold text-white mb-2">You've Used Your Free Code</h3>
            <p className="text-gray-400 text-sm mb-4">
              Free users get one Crush Code to experience a real connection. 
              Ready for unlimited codes?
            </p>
            <button
              onClick={() => navigate('/premium')}
              className="px-6 py-3 bg-gradient-to-r from-gold to-gold-400 text-charcoal font-bold rounded-xl hover:from-gold-400 hover:to-gold transition-all flex items-center gap-2 mx-auto shadow-lg shadow-gold/20"
            >
              <Crown className="w-5 h-5" />
              Upgrade to Premium
            </button>
            <p className="text-xs text-gray-500 mt-3">
              Unlimited codes • Analytics • Bulk generation • Code renewal
            </p>
          </div>
        )}

        {/* Analytics Section (Premium only) */}
        {isPremium && (
          <div className="mt-8">
            <CrushCodeAnalytics />
          </div>
        )}

        {/* Analytics Upsell for Free Users */}
        {!isPremium && activeCards.length > 0 && (
          <div className="mt-8">
            <button
              onClick={handleViewAnalytics}
              className="w-full p-4 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl border border-charcoal-600 transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-500/10 rounded-xl flex items-center justify-center">
                  <BarChart3 className="w-5 h-5 text-green-400" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-medium text-white flex items-center gap-2">
                    Code Analytics
                    <Lock className="w-3 h-3 text-gray-500" />
                  </p>
                  <p className="text-xs text-gray-400">Track scans, shares & conversions</p>
                </div>
                <Crown className="w-5 h-5 text-gold" />
              </div>
            </button>
          </div>
        )}

        {/* How It Works (for new users) */}
        {activeCards.length === 0 && lifetimeCodeCount === 0 && (
          <div className="mt-8 space-y-4">
            <h2 className="text-lg font-semibold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-gold" />
              How Crush Cards Work
            </h2>

            <div className="bg-charcoal-700 rounded-2xl p-5 border border-charcoal-600 space-y-4">
              <div className="flex gap-4">
                <div className="w-10 h-10 bg-gold/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Heart className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <p className="text-white font-medium">Express your interest</p>
                  <p className="text-sm text-gray-400 mt-1">
                    Share your code with someone you'd like to connect with.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-10 h-10 bg-gold/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Users className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <p className="text-white font-medium">Mutual consent required</p>
                  <p className="text-sm text-gray-400 mt-1">
                    They must accept your code before any chat can begin.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-10 h-10 bg-gold/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Shield className="w-5 h-5 text-gold" />
                </div>
                <div>
                  <p className="text-white font-medium">Privacy protected</p>
                  <p className="text-sm text-gray-400 mt-1">
                    Your details stay private until you choose to share them.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Share Modals */}
      {activeCards.map((card) => (
        <CrushCodeShare
          key={card.id}
          isOpen={showShareModal === card.id}
          onClose={() => setShowShareModal(null)}
          code={card.code}
          codeId={card.id}
          initialStats={shareStats[card.id]}
          onShareTracked={(stats) => handleShareTracked(card.id, stats)}
        />
      ))}

      {/* Bulk Generator Modal (Premium) */}
      {isPremium && (
        <BulkCodeGenerator
          isOpen={showBulkGenerator}
          onClose={() => setShowBulkGenerator(false)}
          onCodesGenerated={(codes) => {
            fetchActiveCards();
            setLifetimeCodeCount(prev => prev + codes.length);
          }}
        />
      )}

      {/* Freemium Upsell Modal */}
      <FreemiumUpsell
        isOpen={upsellModal.isOpen}
        onClose={() => setUpsellModal({ ...upsellModal, isOpen: false })}
        trigger={upsellModal.trigger}
        expiredCode={upsellModal.expiredCode}
      />
    </div>
  );
};

export default CrushCardScreen;
