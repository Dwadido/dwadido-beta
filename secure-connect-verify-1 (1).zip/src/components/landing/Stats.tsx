import React from 'react';
import { Shield, Lock, Clock, CheckCircle } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Verified Intent',
    description: 'Both parties must confirm interest before any connection is made'
  },
  {
    icon: CheckCircle,
    title: 'Mutual Consent',
    description: 'No unwanted messages or contact—ever'
  },
  {
    icon: Lock,
    title: 'Controlled Progression',
    description: 'Information revealed gradually through trust stages'
  },
  {
    icon: Clock,
    title: '17-Day Window',
    description: 'Secure timeframe encourages meaningful real-world connections'
  }
];

const Stats: React.FC = () => {
  return (
    <section className="py-20 bg-charcoal-800 border-y border-charcoal-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-white mb-4">
            Built on <span className="text-gold">Verified Intent</span>
          </h2>
          <p className="text-gray-400">
            A fundamentally different approach to connection—where trust comes first.
          </p>
        </div>

        {/* Feature cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-charcoal-700 rounded-xl p-6 border border-charcoal-600 hover:border-gold/30 transition-all duration-300"
            >
              <div className="w-12 h-12 mb-4 bg-gold/10 rounded-xl flex items-center justify-center border border-gold/20">
                <feature.icon className="w-6 h-6 text-gold" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-400 text-sm leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;
