
import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'

// Build version — forces rebuild/redeploy on Deploypad
const BUILD_VERSION = '2026-02-19T16:44:00Z-v3-cache-bust';
console.log(`[Dwadido] Build: ${BUILD_VERSION}`);

// ─── Aggressive Service Worker Update ───────────────────────────────────
// Forces the new SW to activate immediately, purging stale cached JS bundles.
// This fixes iPhone Safari caching old builds that have broken Supabase URLs.
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').then((registration) => {
    console.log('[SW] Registered, scope:', registration.scope);

    // Force update check on every page load
    registration.update().catch(() => {});

    // When a new SW is found, tell it to skip waiting immediately
    registration.addEventListener('updatefound', () => {
      const newWorker = registration.installing;
      if (newWorker) {
        newWorker.addEventListener('statechange', () => {
          if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
            console.log('[SW] New version installed — activating immediately');
            newWorker.postMessage({ type: 'SKIP_WAITING' });
          }
        });
      }
    });

    // When the new SW takes control, reload to get fresh assets
    let refreshing = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (!refreshing) {
        refreshing = true;
        console.log('[SW] New controller active — reloading for fresh assets');
        window.location.reload();
      }
    });
  }).catch((err) => {
    console.warn('[SW] Registration failed:', err);
  });
}

// Global handler for unhandled promise rejections
window.addEventListener('unhandledrejection', (event) => {
  if (event.reason?.name === 'AbortError') {
    event.preventDefault();
    return;
  }
  if (event.reason?.message?.includes('WebSocket') || 
      event.reason?.message?.includes('connection') ||
      event.reason?.message?.includes('channel')) {
    event.preventDefault();
    return;
  }
  console.warn('Unhandled promise rejection:', event.reason);
});

createRoot(document.getElementById("root")!).render(<App />);
