import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { 
  Heart, 
  Loader2,
  Check,
  AlertCircle,
  Info,
  Calendar,
  Coffee,
  Sparkles
} from 'lucide-react';

/**
 * DWADIDO DESIGN PHILOSOPHY - MATCH REMINDERS
 * 
 * Match reminders must be:
 * - Optional (user-controlled)
 * - Low-frequency
 * - Supportive, not pushy
 * 
 * Rules:
 * - No "You haven't replied" guilt prompts
 * - No countdown timers
 * - No engagement pressure
 * 
 * Allowed reminder style:
 * Gentle, context-based nudges that encourage clarity or offline action.
 * 
 * Example:
 * "You matched with someone whose intentions align with yours. 
 *  If it feels right, this could be a good time to suggest meeting."
 * 
 * Reminders should respect user autonomy and never create pressure.
 */

type SupportedLanguage = 'en' | 'es' | 'fr' | 'de';

interface MatchReminderPrefs {
  match_reminders_enabled: boolean;
  reminder_frequency: 'weekly' | 'biweekly' | 'monthly' | 'none';
  reminder_style: 'gentle' | 'minimal';
  encourage_offline_meetings: boolean;
}

// UI translations - calm, supportive language
const UI_TEXT = {
  en: {
    title: 'Connection Reminders',
    description: 'Gentle, optional reminders about your connections. You\'re always in control.',
    
    mainToggle: 'Enable Reminders',
    mainToggleDesc: 'Receive occasional, supportive reminders about your connections',
    
    frequencyTitle: 'How Often',
    frequencyDesc: 'Choose a pace that feels comfortable for you',
    
    frequencies: {
      weekly: 'Once a week',
      biweekly: 'Every two weeks',
      monthly: 'Once a month',
      none: 'Only when I ask'
    },
    
    styleTitle: 'Reminder Style',
    styleDesc: 'How would you like reminders to feel?',
    
    styles: {
      gentle: {
        name: 'Gentle & Supportive',
        desc: 'Warm reminders with context about why you connected'
      },
      minimal: {
        name: 'Minimal',
        desc: 'Simple, brief reminders without extra details'
      }
    },
    
    offlineToggle: 'Encourage In-Person Meetings',
    offlineToggleDesc: 'Include gentle suggestions for meeting offline when it feels right',
    
    exampleTitle: 'Example Reminder',
    exampleGentle: 'You matched with someone whose intentions align with yours. If it feels right, this could be a good time to suggest meeting.',
    exampleMinimal: 'You have a connection you haven\'t chatted with recently.',
    
    saving: 'Saving...',
    saved: 'Preferences saved',
    error: 'Failed to save preferences',
    
    philosophy: 'These reminders are designed to support you, not pressure you. Take your time with every connection.',
    
    noGuilt: 'We\'ll never say "You haven\'t replied" or use countdown timers. Your pace is your own.'
  },
  es: {
    title: 'Recordatorios de Conexión',
    description: 'Recordatorios suaves y opcionales sobre tus conexiones. Siempre tienes el control.',
    
    mainToggle: 'Activar Recordatorios',
    mainToggleDesc: 'Recibir recordatorios ocasionales y de apoyo sobre tus conexiones',
    
    frequencyTitle: 'Con Qué Frecuencia',
    frequencyDesc: 'Elige un ritmo que te resulte cómodo',
    
    frequencies: {
      weekly: 'Una vez por semana',
      biweekly: 'Cada dos semanas',
      monthly: 'Una vez al mes',
      none: 'Solo cuando lo pida'
    },
    
    styleTitle: 'Estilo de Recordatorio',
    styleDesc: '¿Cómo te gustaría que se sientan los recordatorios?',
    
    styles: {
      gentle: {
        name: 'Suave y de Apoyo',
        desc: 'Recordatorios cálidos con contexto sobre por qué conectaron'
      },
      minimal: {
        name: 'Mínimo',
        desc: 'Recordatorios simples y breves sin detalles extra'
      }
    },
    
    offlineToggle: 'Fomentar Encuentros en Persona',
    offlineToggleDesc: 'Incluir sugerencias suaves para reunirse cuando se sienta bien',
    
    exampleTitle: 'Ejemplo de Recordatorio',
    exampleGentle: 'Conectaste con alguien cuyas intenciones coinciden con las tuyas. Si se siente bien, este podría ser un buen momento para sugerir un encuentro.',
    exampleMinimal: 'Tienes una conexión con la que no has conversado recientemente.',
    
    saving: 'Guardando...',
    saved: 'Preferencias guardadas',
    error: 'Error al guardar preferencias',
    
    philosophy: 'Estos recordatorios están diseñados para apoyarte, no presionarte. Tómate tu tiempo con cada conexión.',
    
    noGuilt: 'Nunca diremos "No has respondido" ni usaremos temporizadores. Tu ritmo es tuyo.'
  },
  fr: {
    title: 'Rappels de Connexion',
    description: 'Rappels doux et optionnels sur vos connexions. Vous gardez toujours le contrôle.',
    
    mainToggle: 'Activer les Rappels',
    mainToggleDesc: 'Recevoir des rappels occasionnels et bienveillants sur vos connexions',
    
    frequencyTitle: 'À Quelle Fréquence',
    frequencyDesc: 'Choisissez un rythme qui vous convient',
    
    frequencies: {
      weekly: 'Une fois par semaine',
      biweekly: 'Toutes les deux semaines',
      monthly: 'Une fois par mois',
      none: 'Seulement quand je demande'
    },
    
    styleTitle: 'Style de Rappel',
    styleDesc: 'Comment aimeriez-vous que les rappels se présentent?',
    
    styles: {
      gentle: {
        name: 'Doux et Bienveillant',
        desc: 'Rappels chaleureux avec contexte sur pourquoi vous avez connecté'
      },
      minimal: {
        name: 'Minimal',
        desc: 'Rappels simples et brefs sans détails supplémentaires'
      }
    },
    
    offlineToggle: 'Encourager les Rencontres en Personne',
    offlineToggleDesc: 'Inclure des suggestions douces pour se rencontrer quand cela semble approprié',
    
    exampleTitle: 'Exemple de Rappel',
    exampleGentle: 'Vous avez connecté avec quelqu\'un dont les intentions correspondent aux vôtres. Si cela vous semble bien, ce pourrait être un bon moment pour suggérer une rencontre.',
    exampleMinimal: 'Vous avez une connexion avec laquelle vous n\'avez pas discuté récemment.',
    
    saving: 'Enregistrement...',
    saved: 'Préférences enregistrées',
    error: 'Échec de l\'enregistrement',
    
    philosophy: 'Ces rappels sont conçus pour vous soutenir, pas vous presser. Prenez votre temps avec chaque connexion.',
    
    noGuilt: 'Nous ne dirons jamais "Vous n\'avez pas répondu" et n\'utiliserons pas de compte à rebours. Votre rythme est le vôtre.'
  },
  de: {
    title: 'Verbindungs-Erinnerungen',
    description: 'Sanfte, optionale Erinnerungen an deine Verbindungen. Du behältst immer die Kontrolle.',
    
    mainToggle: 'Erinnerungen aktivieren',
    mainToggleDesc: 'Gelegentliche, unterstützende Erinnerungen an deine Verbindungen erhalten',
    
    frequencyTitle: 'Wie Oft',
    frequencyDesc: 'Wähle ein Tempo, das sich für dich gut anfühlt',
    
    frequencies: {
      weekly: 'Einmal pro Woche',
      biweekly: 'Alle zwei Wochen',
      monthly: 'Einmal im Monat',
      none: 'Nur wenn ich frage'
    },
    
    styleTitle: 'Erinnerungs-Stil',
    styleDesc: 'Wie sollen sich die Erinnerungen anfühlen?',
    
    styles: {
      gentle: {
        name: 'Sanft & Unterstützend',
        desc: 'Warme Erinnerungen mit Kontext, warum ihr verbunden seid'
      },
      minimal: {
        name: 'Minimal',
        desc: 'Einfache, kurze Erinnerungen ohne zusätzliche Details'
      }
    },
    
    offlineToggle: 'Persönliche Treffen fördern',
    offlineToggleDesc: 'Sanfte Vorschläge für persönliche Treffen einbeziehen, wenn es sich richtig anfühlt',
    
    exampleTitle: 'Beispiel-Erinnerung',
    exampleGentle: 'Du hast dich mit jemandem verbunden, dessen Absichten mit deinen übereinstimmen. Wenn es sich richtig anfühlt, könnte dies ein guter Zeitpunkt sein, ein Treffen vorzuschlagen.',
    exampleMinimal: 'Du hast eine Verbindung, mit der du kürzlich nicht gechattet hast.',
    
    saving: 'Speichern...',
    saved: 'Einstellungen gespeichert',
    error: 'Speichern fehlgeschlagen',
    
    philosophy: 'Diese Erinnerungen sollen dich unterstützen, nicht unter Druck setzen. Nimm dir Zeit mit jeder Verbindung.',
    
    noGuilt: 'Wir werden nie sagen "Du hast nicht geantwortet" oder Countdowns verwenden. Dein Tempo ist dein eigenes.'
  }
};

const MatchReminderSettings: React.FC = () => {
  const { user } = useAuth();
  const { language: appLanguage } = useI18n();
  
  const language: SupportedLanguage = ['en', 'es', 'fr', 'de'].includes(appLanguage) 
    ? appLanguage as SupportedLanguage 
    : 'en';
  
  const text = UI_TEXT[language];
  
  const [preferences, setPreferences] = useState<MatchReminderPrefs>({
    match_reminders_enabled: false,
    reminder_frequency: 'biweekly',
    reminder_style: 'gentle',
    encourage_offline_meetings: true
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      loadPreferences();
    }
  }, [user]);

  const loadPreferences = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('email_preferences')
        .select('match_reminders_enabled, reminder_frequency, reminder_style, encourage_offline_meetings')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setPreferences({
          match_reminders_enabled: data.match_reminders_enabled ?? false,
          reminder_frequency: data.reminder_frequency ?? 'biweekly',
          reminder_style: data.reminder_style ?? 'gentle',
          encourage_offline_meetings: data.encourage_offline_meetings ?? true
        });
      }
    } catch (err) {
      console.error('Failed to load match reminder preferences:', err);
    } finally {
      setLoading(false);
    }
  };

  const updatePreference = async (key: keyof MatchReminderPrefs, value: boolean | string) => {
    if (!user) return;

    const newPrefs = { ...preferences, [key]: value };
    setPreferences(newPrefs);
    setSaving(true);
    setError(null);

    try {
      const { error } = await supabase
        .from('email_preferences')
        .upsert({ 
          user_id: user.id,
          [key]: value, 
          updated_at: new Date().toISOString() 
        }, {
          onConflict: 'user_id'
        });

      if (error) throw error;

      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      console.error('Failed to update preference:', err);
      setError(text.error);
      setPreferences(preferences);
    } finally {
      setSaving(false);
    }
  };

  const Toggle = ({ 
    enabled, 
    onChange, 
    disabled 
  }: { 
    enabled: boolean; 
    onChange: () => void; 
    disabled?: boolean 
  }) => (
    <button
      onClick={onChange}
      disabled={disabled}
      className={`w-11 h-6 rounded-full transition-all ${
        enabled ? 'bg-gold' : 'bg-charcoal-500'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      <div className={`w-5 h-5 bg-white rounded-full shadow transform transition-transform ${
        enabled ? 'translate-x-5' : 'translate-x-0.5'
      }`} />
    </button>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 text-gold animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Heart className="w-5 h-5 text-gold" />
          {text.title}
        </h3>
        <p className="text-sm text-gray-400 mt-1">{text.description}</p>
      </div>

      {/* Status indicator */}
      {(saving || saved || error) && (
        <div className={`flex items-center gap-2 text-sm ${
          error ? 'text-amber-400' : saved ? 'text-green-400' : 'text-gray-400'
        }`}>
          {saving && <Loader2 className="w-4 h-4 animate-spin" />}
          {saved && <Check className="w-4 h-4" />}
          {error && <AlertCircle className="w-4 h-4" />}
          <span>{saving ? text.saving : saved ? text.saved : error}</span>
        </div>
      )}

      {/* Philosophy note - calm, supportive */}
      <div className="p-4 bg-gold/5 border border-gold/10 rounded-xl">
        <div className="flex items-start gap-3">
          <Sparkles className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm text-gray-300">{text.philosophy}</p>
            <p className="text-xs text-gray-500 mt-2">{text.noGuilt}</p>
          </div>
        </div>
      </div>

      {/* Main toggle */}
      <div className="p-4 bg-charcoal-600 rounded-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              preferences.match_reminders_enabled ? 'bg-gold/20' : 'bg-charcoal-500'
            }`}>
              <Heart className={`w-5 h-5 ${
                preferences.match_reminders_enabled ? 'text-gold' : 'text-gray-400'
              }`} />
            </div>
            <div>
              <p className="font-medium text-white">{text.mainToggle}</p>
              <p className="text-sm text-gray-400">{text.mainToggleDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.match_reminders_enabled} 
            onChange={() => updatePreference('match_reminders_enabled', !preferences.match_reminders_enabled)}
            disabled={saving}
          />
        </div>
      </div>

      {/* Options - only show when enabled */}
      <div className={`space-y-6 ${!preferences.match_reminders_enabled ? 'opacity-50 pointer-events-none' : ''}`}>
        
        {/* Frequency selection */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-4 h-4 text-gold" />
            <h4 className="text-sm font-semibold text-gold uppercase tracking-wide">{text.frequencyTitle}</h4>
          </div>
          <p className="text-xs text-gray-500 mb-4">{text.frequencyDesc}</p>
          
          <div className="grid grid-cols-2 gap-3">
            {(['weekly', 'biweekly', 'monthly', 'none'] as const).map((freq) => (
              <button
                key={freq}
                onClick={() => updatePreference('reminder_frequency', freq)}
                disabled={saving || !preferences.match_reminders_enabled}
                className={`p-3 rounded-xl border transition-all text-left ${
                  preferences.reminder_frequency === freq
                    ? 'bg-gold/20 border-gold/40 text-white'
                    : 'bg-charcoal-700 border-charcoal-600 text-gray-400 hover:border-charcoal-500'
                }`}
              >
                <span className="text-sm font-medium">{text.frequencies[freq]}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Style selection */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-gold" />
            <h4 className="text-sm font-semibold text-gold uppercase tracking-wide">{text.styleTitle}</h4>
          </div>
          <p className="text-xs text-gray-500 mb-4">{text.styleDesc}</p>
          
          <div className="space-y-3">
            {(['gentle', 'minimal'] as const).map((style) => (
              <button
                key={style}
                onClick={() => updatePreference('reminder_style', style)}
                disabled={saving || !preferences.match_reminders_enabled}
                className={`w-full p-4 rounded-xl border transition-all text-left ${
                  preferences.reminder_style === style
                    ? 'bg-gold/20 border-gold/40'
                    : 'bg-charcoal-700 border-charcoal-600 hover:border-charcoal-500'
                }`}
              >
                <p className={`font-medium ${preferences.reminder_style === style ? 'text-white' : 'text-gray-300'}`}>
                  {text.styles[style].name}
                </p>
                <p className="text-sm text-gray-500 mt-1">{text.styles[style].desc}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Offline meetings toggle */}
        <div className="p-4 bg-charcoal-700 rounded-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                preferences.encourage_offline_meetings ? 'bg-gold/20' : 'bg-charcoal-500'
              }`}>
                <Coffee className={`w-5 h-5 ${
                  preferences.encourage_offline_meetings ? 'text-gold' : 'text-gray-400'
                }`} />
              </div>
              <div>
                <p className="font-medium text-white">{text.offlineToggle}</p>
                <p className="text-sm text-gray-400">{text.offlineToggleDesc}</p>
              </div>
            </div>
            <Toggle 
              enabled={preferences.encourage_offline_meetings} 
              onChange={() => updatePreference('encourage_offline_meetings', !preferences.encourage_offline_meetings)}
              disabled={saving || !preferences.match_reminders_enabled}
            />
          </div>
        </div>

        {/* Example reminder preview */}
        <div className="p-4 bg-charcoal-700/50 rounded-xl border border-charcoal-600">
          <div className="flex items-center gap-2 mb-3">
            <Info className="w-4 h-4 text-gray-400" />
            <h4 className="text-sm font-medium text-gray-300">{text.exampleTitle}</h4>
          </div>
          <div className="p-4 bg-charcoal-800 rounded-lg border border-charcoal-600">
            <p className="text-sm text-gray-300 italic leading-relaxed">
              "{preferences.reminder_style === 'gentle' ? text.exampleGentle : text.exampleMinimal}"
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MatchReminderSettings;
