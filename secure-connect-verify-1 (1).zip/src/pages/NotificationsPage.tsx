import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Bell, Heart, MessageSquare, Camera, Calendar, BadgeCheck, 
  CheckCheck, Filter, Trash2, ArrowLeft, Settings, User, X, AlertCircle
} from 'lucide-react';
import { useNotifications } from '@/contexts/NotificationContext';
import { useAuth } from '@/contexts/AuthContext';
import { AppNotification, NotificationType } from '@/lib/notifications';
import NotificationPermissionBanner from '@/components/notifications/NotificationPermissionBanner';

// =============================================================================
// DWADIDO NOTIFICATIONS PAGE
// 
// Design Philosophy (from Dwadido AI Matching Instructions):
// - Match alerts must be minimal, calm, and non-addictive
// - NO flashing animations, NO red badges, NO gamification
// - NO urgency language like "Don't miss out!" or "Act now!"
// - Calm, non-urgent time formatting
// 
// Users should feel: Understood, Respected, In control
// =============================================================================

type FilterType = 'all' | 'unread' | 'connections' | 'messages' | 'other';

const NotificationsPage: React.FC = () => {
  const { user } = useAuth();
  const { 
    notifications, 
    unreadCount, 
    loading,
    error,
    clearError,
    fetchNotifications, 
    markNotificationAsRead, 
    markAllNotificationsAsRead,
    deleteNotification,
    deleteAllNotifications,
    permissionStatus,
    isSupported,
  } = useNotifications();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<FilterType>('all');
  const [selectedNotifications, setSelectedNotifications] = useState<Set<string>>(new Set());
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    fetchNotifications({ limit: 100 });
  }, [user, fetchNotifications, navigate]);

  const handleRetry = () => {
    clearError();
    fetchNotifications({ limit: 100 });
  };


  // Calm, non-urgent icon colors (gold instead of pink/red)
  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'new_match':
      case 'mutual_match':
        // Using gold instead of pink for calm, non-urgent feel
        return <Heart className="w-5 h-5 text-[#C9A24D]" />;
      case 'new_message':
        return <MessageSquare className="w-5 h-5 text-blue-400" />;
      case 'crush_code_redeemed':
        return <Heart className="w-5 h-5 text-[#C9A24D]" />;
      case 'photo_request':
      case 'photo_request_response':
        return <Camera className="w-5 h-5 text-purple-400" />;
      case 'meeting_suggestion':
      case 'meeting_response':
        return <Calendar className="w-5 h-5 text-green-400" />;
      case 'verification_update':
        return <BadgeCheck className="w-5 h-5 text-[#C9A24D]" />;
      default:
        return <Bell className="w-5 h-5 text-gray-400" />;
    }
  };

  const getNotificationCategory = (type: string): 'connections' | 'messages' | 'other' => {
    if (['new_match', 'mutual_match', 'crush_code_redeemed'].includes(type)) {
      return 'connections';
    }
    if (type === 'new_message') {
      return 'messages';
    }
    return 'other';
  };

  // Calm, non-urgent time formatting (no "Just now!" urgency)
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    // Calm time formatting - no urgency
    if (diffMins < 5) return 'Recently';
    if (diffMins < 60) return `${diffMins} minutes ago`;
    if (diffHours < 24) return `${diffHours} hours ago`;
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
    });
  };

  const filteredNotifications = notifications.filter(n => {
    if (filter === 'all') return true;
    if (filter === 'unread') return !n.read;
    return getNotificationCategory(n.type) === filter;
  });
  const handleNotificationClick = async (notification: AppNotification) => {
    if (!notification.read) {
      await markNotificationAsRead(notification.id);
    }
    
    const url = notification.data?.url || '/dashboard';
    navigate(url);
  };


  const handleDeleteSelected = async () => {
    if (selectedNotifications.size === 0) return;
    
    // Delete selected notifications one by one
    for (const id of selectedNotifications) {
      await deleteNotification(id);
    }
    setSelectedNotifications(new Set());
    setShowDeleteConfirm(false);
  };

  const handleDeleteAll = async () => {
    await deleteAllNotifications();
    setShowDeleteConfirm(false);
  };

  const toggleSelectAll = () => {
    if (selectedNotifications.size === filteredNotifications.length) {
      setSelectedNotifications(new Set());
    } else {
      setSelectedNotifications(new Set(filteredNotifications.map(n => n.id)));
    }
  };

  const toggleSelectNotification = (id: string) => {
    const newSelected = new Set(selectedNotifications);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedNotifications(newSelected);
  };

  // Group notifications by date
  const groupedNotifications = filteredNotifications.reduce((groups, notification) => {
    const date = new Date(notification.created_at);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    let groupKey: string;
    if (date.toDateString() === today.toDateString()) {
      groupKey = 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      groupKey = 'Yesterday';
    } else if (date > new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)) {
      groupKey = 'This Week';
    } else if (date > new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000)) {
      groupKey = 'This Month';
    } else {
      groupKey = 'Earlier';
    }

    if (!groups[groupKey]) {
      groups[groupKey] = [];
    }
    groups[groupKey].push(notification);
    return groups;
  }, {} as Record<string, AppNotification[]>);

  // Calm filter labels (no gamification language)
  const filterButtons: { key: FilterType; label: string; icon: React.ReactNode }[] = [
    { key: 'all', label: 'All', icon: <Bell className="w-4 h-4" /> },
    { key: 'unread', label: 'Unread', icon: <span className="w-2 h-2 bg-[#C9A24D] rounded-full" /> },
    { key: 'connections', label: 'Connections', icon: <Heart className="w-4 h-4" /> },
    { key: 'messages', label: 'Messages', icon: <MessageSquare className="w-4 h-4" /> },
    { key: 'other', label: 'Other', icon: <Filter className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-charcoal pt-20 pb-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        {/* Header - calm, no gamification */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(-1)}
              className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-charcoal-600 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-white">Updates</h1>
              {/* Calm status - no "All caught up!" gamification */}
              <p className="text-sm text-gray-400">
                {unreadCount > 0 ? `${unreadCount} unread` : 'No new updates'}
              </p>
            </div>
          </div>
          
          <button
            onClick={() => navigate('/settings')}
            className="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-charcoal-600 transition-colors"
            title="Notification Settings"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>

        {/* Error Banner - shows when notification fetch times out */}
        {error && (
          <div className="mb-6 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-xl">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium text-yellow-300">Connection issue</p>
                <p className="text-sm text-yellow-400/70 mt-1">{error}</p>
              </div>
              <button
                onClick={handleRetry}
                className="px-3 py-1.5 text-sm bg-yellow-500/20 text-yellow-300 rounded-lg hover:bg-yellow-500/30 transition-colors"
              >
                Retry
              </button>
            </div>
          </div>
        )}

        {/* Permission Banner - inline variant */}
        {isSupported && permissionStatus === 'default' && (
          <div className="mb-6">
            <NotificationPermissionBanner variant="inline" showOnlyOnce={false} />
          </div>
        )}

        {/* Permission Denied Warning - calm tone */}
        {isSupported && permissionStatus === 'denied' && (
          <div className="mb-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-amber-300">Browser notifications disabled</p>
                <p className="text-sm text-amber-400/70 mt-1">
                  To receive updates when you're not on this page, you can enable notifications in your browser settings.
                </p>
              </div>
            </div>
          </div>
        )}


        {/* Filter Tabs */}
        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
          {filterButtons.map(({ key, label, icon }) => (
            <button
              key={key}
              onClick={() => setFilter(key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                filter === key
                  ? 'bg-[#C9A24D] text-charcoal'
                  : 'bg-charcoal-700 text-gray-400 hover:text-white hover:bg-charcoal-600'
              }`}
            >
              {icon}
              {label}
              {/* Show count only for unread, subtle styling */}
              {key === 'unread' && unreadCount > 0 && (
                <span className={`px-1.5 py-0.5 text-xs rounded-full ${
                  filter === key ? 'bg-charcoal/20 text-charcoal' : 'bg-[#C9A24D]/20 text-[#C9A24D]'
                }`}>
                  {unreadCount}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Action Bar */}
        {filteredNotifications.length > 0 && (
          <div className="flex items-center justify-between mb-4 p-3 bg-charcoal-700 rounded-xl">
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={selectedNotifications.size === filteredNotifications.length && filteredNotifications.length > 0}
                  onChange={toggleSelectAll}
                  className="w-4 h-4 rounded border-charcoal-500 text-[#C9A24D] focus:ring-[#C9A24D] focus:ring-offset-charcoal-700"
                />
                <span className="text-sm text-gray-400">
                  {selectedNotifications.size > 0 
                    ? `${selectedNotifications.size} selected`
                    : 'Select all'
                  }
                </span>
              </label>
            </div>
            
            <div className="flex items-center gap-2">
              {selectedNotifications.size > 0 && (
                <button
                  onClick={() => setShowDeleteConfirm(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  Delete
                </button>
              )}
              {unreadCount > 0 && (
                <button
                  onClick={markAllNotificationsAsRead}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-[#C9A24D] hover:text-[#d4af5a] hover:bg-[#C9A24D]/10 rounded-lg transition-colors"
                >
                  <CheckCheck className="w-4 h-4" />
                  Mark read
                </button>
              )}
            </div>
          </div>
        )}

        {/* Notifications List */}
        {loading && notifications.length === 0 ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-[#C9A24D] border-t-transparent rounded-full animate-spin" />
          </div>
        ) : filteredNotifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 px-4">
            <div className="w-16 h-16 bg-charcoal-700 rounded-full flex items-center justify-center mb-4">
              <Bell className="w-8 h-8 text-gray-500" />
            </div>
            {/* Calm empty state - no gamification */}
            <h3 className="text-lg font-medium text-white mb-2">
              {filter === 'unread' ? 'No unread updates' : 'No updates yet'}
            </h3>
            <p className="text-gray-400 text-center max-w-sm">
              {filter === 'unread' 
                ? "You're up to date. New updates will appear here when they arrive."
                : "New connections and messages will appear here."
              }
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedNotifications).map(([group, groupNotifications]) => (
              <div key={group}>
                <h3 className="text-sm font-medium text-gray-500 mb-3 px-1">{group}</h3>
                <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden divide-y divide-charcoal-600">
                  {groupNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`flex items-start gap-3 p-4 transition-colors group ${
                        !notification.read ? 'bg-[#C9A24D]/5' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <input
                        type="checkbox"
                        checked={selectedNotifications.has(notification.id)}
                        onChange={() => toggleSelectNotification(notification.id)}
                        className="mt-1 w-4 h-4 rounded border-charcoal-500 text-[#C9A24D] focus:ring-[#C9A24D] focus:ring-offset-charcoal-700"
                      />

                      {/* Icon - calm colors */}
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                        !notification.read ? 'bg-[#C9A24D]/10' : 'bg-charcoal-600'
                      }`}>
                        {getNotificationIcon(notification.type)}
                      </div>

                      {/* Content */}
                      <button
                        onClick={() => handleNotificationClick(notification)}
                        className="flex-1 text-left min-w-0"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p className={`text-sm font-medium ${!notification.read ? 'text-white' : 'text-gray-300'}`}>
                            {notification.title}
                          </p>
                          {/* Subtle unread indicator - no flashing */}
                          {!notification.read && (
                            <span className="w-2 h-2 bg-[#C9A24D] rounded-full flex-shrink-0 mt-1.5" />
                          )}
                        </div>
                        <p className="text-sm text-gray-400 mt-0.5 line-clamp-2">
                          {notification.body}
                        </p>
                        <p className="text-xs text-gray-500 mt-1.5">
                          {formatDate(notification.created_at)}
                        </p>
                      </button>

                      {/* Delete button - appears on hover */}
                      <button
                        onClick={() => deleteNotification(notification.id)}
                        className="p-1.5 rounded-lg text-gray-500 hover:text-red-400 hover:bg-red-500/10 transition-colors opacity-0 group-hover:opacity-100"
                        title="Delete"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Delete All Button */}
        {notifications.length > 0 && (
          <div className="mt-8 pt-6 border-t border-charcoal-700">
            <button
              onClick={() => setShowDeleteConfirm(true)}
              className="w-full py-3 text-gray-400 hover:text-red-400 font-medium rounded-xl border border-charcoal-600 hover:border-red-500/30 hover:bg-red-500/5 transition-colors"
            >
              Clear all updates
            </button>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-charcoal-700 border border-charcoal-600 rounded-2xl p-6 max-w-sm w-full shadow-2xl">
            <div className="text-center">
              <div className="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trash2 className="w-6 h-6 text-red-400" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">Clear updates?</h3>
              <p className="text-gray-400 text-sm mb-6">
                {selectedNotifications.size > 0 
                  ? `This will remove ${selectedNotifications.size} selected update${selectedNotifications.size > 1 ? 's' : ''}.`
                  : 'This will remove all updates. This cannot be undone.'
                }
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 py-2.5 bg-charcoal-600 text-gray-300 font-medium rounded-xl hover:bg-charcoal-500 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={selectedNotifications.size > 0 ? handleDeleteSelected : handleDeleteAll}
                  className="flex-1 py-2.5 bg-red-500 text-white font-medium rounded-xl hover:bg-red-600 transition-colors"
                >
                  Clear
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationsPage;
