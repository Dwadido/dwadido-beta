// CodeRedeemer — Build 2026-02-19T16:52:00Z-v4 (already-connected navigation fix)

import React, { useState, useRef } from 'react';
import { previewRedeemCode, confirmRedeemCode } from '@/lib/redeemCode';
import { createMatchNotifications } from '@/lib/notifications';


import { useAuth } from '@/contexts/AuthContext';
import { useNotifications } from '@/contexts/NotificationContext';

import { Loader2, Check, X, Sparkles, Shield, Heart, Users, AlertCircle, ArrowRight, QrCode, Camera } from 'lucide-react';
import { IntentType, RelationshipStatusType, INTENT_LABELS, RELATIONSHIP_STATUS_LABELS } from '@/contexts/AuthContext';
import QRCodeScanner from '@/components/qr/QRCodeScanner';

interface MatchedUserPreview {
  id: string;
  display_name: string | null;
  avatar_url: string | null;
  intent: IntentType | null;
  relationship_status: RelationshipStatusType | null;

}

interface CodeRedeemerProps {
  onSuccess?: (match: any) => void;
  onGoToConnections?: () => void; // V4: navigate to connections tab
}

const CodeRedeemer: React.FC<CodeRedeemerProps> = ({ onSuccess, onGoToConnections }) => {
  const { user, profile } = useAuth();
  const { fetchNotifications } = useNotifications();

  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [errorCode, setErrorCode] = useState('');
  const [success, setSuccess] = useState(false);

  const [matchedUser, setMatchedUser] = useState<MatchedUserPreview | null>(null);
  const [previewUser, setPreviewUser] = useState<MatchedUserPreview | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [pendingCode, setPendingCode] = useState('');
  const [showScanner, setShowScanner] = useState(false);
  // V4: existing match info for ALREADY_CONNECTED navigation
  const [existingMatchId, setExistingMatchId] = useState<string | null>(null);
  const [existingMatchStatus, setExistingMatchStatus] = useState<string | null>(null);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const handleChange = (index: number, value: string) => {
    const char = value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (char.length > 1) return;

    const newCode = [...code];
    newCode[index] = char;
    setCode(newCode);
    setError('');
    setExistingMatchId(null);
    setExistingMatchStatus(null);

    // Auto-focus next input
    if (char && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    // Auto-validate when complete (but don't submit yet)
    if (char && index === 5 && newCode.every(c => c)) {
      handleValidate(newCode.join(''));
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
    const newCode = [...code];
    for (let i = 0; i < pasted.length; i++) {
      newCode[i] = pasted[i];
    }
    setCode(newCode);
    
    if (pasted.length === 6) {
      handleValidate(pasted);
    } else {
      inputRefs.current[Math.min(pasted.length, 5)]?.focus();
    }
  };

  // Handle QR code scan result
  const handleQRScan = (scannedCode: string) => {
    setShowScanner(false);
    
    // Fill in the code inputs
    const newCode = scannedCode.split('').slice(0, 6);
    while (newCode.length < 6) newCode.push('');
    setCode(newCode);
    
    // Validate the scanned code
    if (scannedCode.length === 6) {
      handleValidate(scannedCode);
    }
  };

  // First step: Validate code and show user preview
  const handleValidate = async (fullCode: string) => {
    if (fullCode.length !== 6) return;
    if (!user?.id) {
      setError('You must be signed in to redeem a code.');
      return;
    }
    
    setLoading(true);
    setError('');
    setErrorCode('');
    setExistingMatchId(null);
    setExistingMatchStatus(null);

    try {
      const normalizedCode = fullCode.toUpperCase();
      console.log('[CodeRedeemer] Validating code:', normalizedCode, 'user_id:', user.id);
      
      // ── Direct DB call ──
      const result = await previewRedeemCode(normalizedCode, user.id);

      console.log('[CodeRedeemer] Validate response:', result);

      if (!result.success) {
        const err = new Error(result.error || 'Validation failed');
        (err as any).code = result.code;
        (err as any).existingMatchId = result.existingMatchId;
        (err as any).existingMatchStatus = result.existingMatchStatus;
        throw err;
      }

      setPreviewUser(result.previewUser as MatchedUserPreview || null);
      setPendingCode(normalizedCode);
      setShowConfirmation(true);
    } catch (err: any) {
      console.error('[CodeRedeemer] Validation error:', err);
      const code = err.code || '';
      setErrorCode(code);
      
      // V4: Capture existing match details for navigation
      if (err.existingMatchId) {
        setExistingMatchId(err.existingMatchId);
        setExistingMatchStatus(err.existingMatchStatus || null);
      }
      
      if (code === 'NOT_FOUND') {
        setError('Code not found. Please double-check and try again.');
      } else if (code === 'EXPIRED') {
        setError('This code has expired. Ask the sender for a new one.');
      } else if (code === 'OWN_CODE' || code === 'SELF_REDEEM') {
        setError('You cannot redeem your own code.');
      } else if (code === 'ALREADY_CONNECTED' || code === 'ALREADY_MATCHED') {
        setError('You already have an active connection with this person.');
      } else if (code === 'ALREADY_REDEEMED') {
        setError('This code has already been used.');
      } else if (code === 'RATE_LIMITED') {
        setError('Too many attempts. Please wait a moment before trying again.');
      } else if (code === 'MATCH_DAILY_LIMIT') {
        setError('You\'ve reached the maximum new connections per day. Please try again tomorrow.');
      } else if (code === 'MATCH_DAILY_LIMIT_CREATOR') {
        setError('The other person has reached their daily connection limit. Please try again later.');
      } else if (err.message?.includes('timed out')) {
        setError('The server is taking too long. Please tap Retry.');
      } else {
        setError(err.message || 'Invalid or expired code');
      }
    } finally {
      setLoading(false);
    }

  };





  // Second step: Confirm and complete the connection
  const handleConfirmConnection = async () => {
    if (!user?.id) {
      setError('You must be signed in.');
      return;
    }

    setLoading(true);
    setError('');
    setExistingMatchId(null);
    setExistingMatchStatus(null);

    try {
      // ── Direct DB call ──
      const result = await confirmRedeemCode(pendingCode, user.id);

      console.log('[CodeRedeemer] Confirm response:', result);

      if (!result.success) {
        const err = new Error(result.error || 'Failed to confirm connection');
        (err as any).code = result.code;
        (err as any).existingMatchId = result.existingMatchId;
        (err as any).existingMatchStatus = result.existingMatchStatus;
        throw err;
      }

      const finalMatchedUser = (result.matchedUser || previewUser) as MatchedUserPreview;
      setSuccess(true);
      setMatchedUser(finalMatchedUser);
      setShowConfirmation(false);
      onSuccess?.(result);

      // ─── CREATE NOTIFICATIONS FOR BOTH USERS ───────────────────────
      if (user.id && finalMatchedUser?.id) {
        const matchId = result.matchId || result.match?.id || '';
        const redeemerId = user.id;
        const creatorId = finalMatchedUser.id;
        const redeemerName = profile?.display_name || null;
        const creatorName = finalMatchedUser.display_name || null;

        createMatchNotifications(redeemerId, creatorId, redeemerName, creatorName, matchId)
          .then(() => {
            console.log('[CodeRedeemer] Match notifications created for both users');
            fetchNotifications({ limit: 50 });
          })
          .catch((err) => {
            console.warn('[CodeRedeemer] Failed to create match notifications:', err);
          });
      }
    } catch (err: any) {
      console.error('[CodeRedeemer] Confirm connection error:', err);
      const errCode = err.code || '';
      
      // V4: Capture existing match details
      if (err.existingMatchId) {
        setExistingMatchId(err.existingMatchId);
        setExistingMatchStatus(err.existingMatchStatus || null);
      }
      
      if (errCode === 'ALREADY_CONNECTED' || errCode === 'ALREADY_MATCHED') {
        setError('You already have an active connection with this person.');
      } else if (errCode === 'RATE_LIMITED') {
        setError('Too many attempts. Please wait a moment before trying again.');
      } else if (errCode === 'MATCH_DAILY_LIMIT') {
        setError('You\'ve reached the maximum new connections per day. Please try again tomorrow.');
      } else if (errCode === 'MATCH_DAILY_LIMIT_CREATOR') {
        setError('The other person has reached their daily connection limit. Please try again later.');
      } else {
        setError(err.message || 'Failed to confirm connection');
      }
      setShowConfirmation(false);
    } finally {
      setLoading(false);
    }

  };



  const handleCancelConnection = () => {
    setShowConfirmation(false);
    setPreviewUser(null);
    setPendingCode('');
    setCode(['', '', '', '', '', '']);
    inputRefs.current[0]?.focus();
  };


  const resetForm = () => {
    setCode(['', '', '', '', '', '']);
    setSuccess(false);
    setMatchedUser(null);
    setPreviewUser(null);
    setShowConfirmation(false);
    setPendingCode('');
    setError('');
    setExistingMatchId(null);
    setExistingMatchStatus(null);
    inputRefs.current[0]?.focus();
  };

  // Success state
  if (success && matchedUser) {
    return (
      <div className="bg-[#141414] rounded-2xl p-8 text-center border border-[#C9A24D]/30">
        <div className="w-20 h-20 mx-auto mb-4 bg-[#C9A24D] rounded-full flex items-center justify-center animate-bounce">
          <Sparkles className="w-10 h-10 text-[#141414]" />
        </div>
        <h3 className="text-2xl font-bold text-white mb-2">Connection Verified!</h3>
        <p className="text-gray-400 mb-4">
          You're now connected with <span className="font-semibold text-white">{matchedUser.display_name || 'Someone special'}</span>
        </p>
        
        {/* Show matched user's intent */}
        {(matchedUser.intent || matchedUser.relationship_status) && (
          <div className="mb-4 p-4 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl">
            <div className="flex flex-col gap-2">
              {matchedUser.intent && (
                <div className="flex items-center justify-center gap-2">
                  <Heart className="w-4 h-4 text-[#C9A24D]" />
                  <span className="text-gray-400 text-sm">Looking for:</span>
                  <span className="text-white text-sm font-medium">
                    {INTENT_LABELS[matchedUser.intent]}
                  </span>
                </div>
              )}
              {matchedUser.relationship_status && (
                <div className="flex items-center justify-center gap-2">
                  <Users className="w-4 h-4 text-[#C9A24D]" />
                  <span className="text-gray-400 text-sm">Status:</span>
                  <span className="text-white text-sm font-medium">
                    {RELATIONSHIP_STATUS_LABELS[matchedUser.relationship_status]}
                  </span>
                </div>
              )}
            </div>
          </div>
        )}

        <div className="flex items-center justify-center gap-2 text-[#C9A24D] text-sm mb-4">
          <Shield className="w-4 h-4" />
          <span>Chat is now open - take your time</span>
        </div>
        
        <div className="flex flex-col gap-2">
          {/* V4: Go to Connections button */}
          {onGoToConnections && (
            <button
              onClick={() => {
                resetForm();
                onGoToConnections();
              }}
              className="px-6 py-3 bg-[#C9A24D] text-[#141414] font-semibold rounded-xl hover:bg-[#d4af5a] transition-all flex items-center justify-center gap-2"
            >
              <Users className="w-5 h-5" />
              Go to Connections
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={resetForm}
            className="px-6 py-2 bg-[#1a1a1a] text-[#C9A24D] font-medium rounded-xl border border-[#C9A24D]/30 hover:bg-[#C9A24D]/10 transition-all"
          >
            Enter another code
          </button>
        </div>
      </div>
    );
  }

  // Confirmation state - Show user preview before connecting
  if (showConfirmation && previewUser) {
    return (
      <div className="bg-[#141414] rounded-2xl border border-[#2a2a2a] p-6">
        <h3 className="text-lg font-semibold text-white mb-2 text-center">Confirm Connection</h3>
        <p className="text-gray-500 text-sm mb-6 text-center">
          Review this person's profile before connecting
        </p>

        {/* User Preview Card */}
        <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-5 mb-6">
          <div className="flex items-center gap-4 mb-4">
            {previewUser.avatar_url ? (
              <img
                src={previewUser.avatar_url}
                alt={previewUser.display_name || 'User'}
                className="w-16 h-16 rounded-full object-cover ring-2 ring-[#C9A24D]/30"
              />
            ) : (
              <div className="w-16 h-16 rounded-full bg-[#C9A24D]/20 flex items-center justify-center border border-[#C9A24D]/30">
                <span className="text-2xl text-[#C9A24D] font-bold">
                  {(previewUser.display_name || 'A')[0].toUpperCase()}
                </span>
              </div>
            )}
            <div>
              <h4 className="text-white font-semibold text-lg">
                {previewUser.display_name || 'Anonymous'}
              </h4>
            </div>
          </div>


          {/* Intent & Relationship Status - Critical for Verified Intent */}
          <div className="space-y-3 p-4 bg-[#141414] rounded-xl border border-[#C9A24D]/20">
            <div className="flex items-center gap-2 text-[#C9A24D] text-sm font-medium mb-2">
              <AlertCircle className="w-4 h-4" />
              Verified Intent
            </div>
            
            {previewUser.intent ? (
              <div className="flex items-center gap-3">
                <Heart className="w-5 h-5 text-[#C9A24D]" />
                <div>
                  <span className="text-gray-400 text-sm">Looking for:</span>
                  <p className="text-white font-medium">{INTENT_LABELS[previewUser.intent as IntentType]}</p>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3 text-gray-500">
                <Heart className="w-5 h-5" />
                <span className="text-sm">Intent not specified</span>
              </div>
            )}
            
            {previewUser.relationship_status ? (
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-[#C9A24D]" />
                <div>
                  <span className="text-gray-400 text-sm">Relationship status:</span>
                  <p className="text-white font-medium">{RELATIONSHIP_STATUS_LABELS[previewUser.relationship_status as RelationshipStatusType]}</p>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-3 text-gray-500">
                <Users className="w-5 h-5" />
                <span className="text-sm">Status not specified</span>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={handleConfirmConnection}
            disabled={loading}
            className="w-full py-3 bg-[#C9A24D] text-[#141414] font-semibold rounded-xl hover:bg-[#d4af5a] transition-all flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(201,162,77,0.3)] disabled:opacity-50"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <Check className="w-5 h-5" />
                Confirm Connection
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
          <button
            onClick={handleCancelConnection}
            disabled={loading}
            className="w-full py-3 bg-[#1a1a1a] text-gray-400 font-medium rounded-xl border border-[#2a2a2a] hover:bg-[#2a2a2a] transition-all"
          >
            Cancel
          </button>
        </div>

        <p className="text-center text-gray-500 text-xs mt-4">
          By confirming, a chat will open. You can end it anytime.
        </p>
      </div>
    );
  }

  // Default: Code entry state
  return (
    <>
      <div className="bg-[#141414] rounded-2xl border border-[#2a2a2a] p-6">
        <h3 className="text-lg font-semibold text-white mb-2">Enter a Crush Code</h3>

        <p className="text-gray-500 text-sm mb-6">
          Someone shared their code with you? Enter it below or scan their QR code.
        </p>

        <div className="flex justify-center gap-2 mb-4" onPaste={handlePaste}>
          {code.map((char, index) => (
            <input
              key={index}
              ref={(el) => (inputRefs.current[index] = el)}
              type="text"
              value={char}
              onChange={(e) => handleChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              disabled={loading}
              className="w-12 h-14 text-center text-2xl font-mono font-bold bg-[#1a1a1a] border-2 border-[#2a2a2a] text-white rounded-xl focus:outline-none focus:border-[#C9A24D] focus:ring-2 focus:ring-[#C9A24D]/20 transition-all disabled:opacity-50 uppercase"
              maxLength={1}
            />
          ))}
        </div>

        {/* Scan QR Button */}
        <button
          onClick={() => setShowScanner(true)}
          disabled={loading}
          className="w-full py-3 mb-4 bg-[#1a1a1a] text-white font-medium rounded-xl border border-[#2a2a2a] hover:bg-[#2a2a2a] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          <QrCode className="w-5 h-5 text-[#C9A24D]" />
          <span>Scan QR Code</span>
          <Camera className="w-4 h-4 text-gray-500" />
        </button>

        {loading && (
          <div className="flex items-center justify-center gap-2 text-[#C9A24D] py-2">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Verifying code...</span>
          </div>
        )}

        {error && (
          <div className="py-2">
            <div className="flex items-center justify-center gap-2 text-red-400 bg-red-500/10 rounded-xl border border-red-500/20 p-3">
              <X className="w-5 h-5 flex-shrink-0" />
              <span className="text-sm">{error}</span>
            </div>
            
            {/* V4: "Go to Connections" button when ALREADY_CONNECTED */}
            {(errorCode === 'ALREADY_CONNECTED' || errorCode === 'ALREADY_MATCHED') && onGoToConnections && (
              <button
                onClick={() => {
                  resetForm();
                  onGoToConnections();
                }}
                className="w-full mt-3 py-3 bg-[#C9A24D]/10 text-[#C9A24D] font-medium rounded-xl border border-[#C9A24D]/30 hover:bg-[#C9A24D]/20 transition-all flex items-center justify-center gap-2"
              >
                <Users className="w-5 h-5" />
                Go to Connections
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
            
            {/* V4: Debug info for existing match (helps with support) */}
            {existingMatchId && (
              <p className="text-xs text-gray-600 text-center mt-2">
                Match: {existingMatchId.substring(0, 8)}… (status: {existingMatchStatus || 'unknown'})
              </p>
            )}
          </div>
        )}

        <p className="text-center text-gray-500 text-xs mt-4">
          Codes are case-insensitive and valid for 17 days
        </p>

        <p className="text-center text-gray-500 text-xs">
          By entering this code, you'll see the person's verified intent before connecting. 
          A chat will open upon confirmation - you can end it anytime.
        </p>
      </div>


      {/* QR Code Scanner Modal */}
      <QRCodeScanner
        isOpen={showScanner}
        onClose={() => setShowScanner(false)}
        onScan={handleQRScan}
      />
    </>
  );
};

export default CodeRedeemer;
