import React from 'react';
import { Shield, Lock, Clock, Ban, Globe, Fingerprint, Sparkles } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Zero Unwanted Contact',
    description: 'No messages, no interactions until both parties verify intent through unique codes.'
  },
  {
    icon: Lock,
    title: 'Verified Intent Only',
    description: 'Connections require explicit acceptance. No bots, no fake profiles, no spam.'
  },
  {
    icon: Clock,
    title: '17-Day Secure Window',
    description: 'Time-bounded communication ensures connections progress or close naturally.'
  },
  {
    icon: Ban,
    title: 'Easy Opt-Out',
    description: 'Either user can end the connection at any time. No pressure, no persistence.'
  },
  {
    icon: Globe,
    title: 'Industry Agnostic',
    description: 'Beyond dating: professional networking, events, customer engagement, secure introductions.'
  },
  {
    icon: Fingerprint,
    title: 'Outcome Recording',
    description: 'System records outcomes for safety metrics and continuous platform improvement.'
  }
];

const Features: React.FC = () => {
  return (
    <section className="py-24 bg-charcoal">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold/10 rounded-full text-gold font-medium text-sm mb-6 border border-gold/20">
            <Sparkles className="w-4 h-4" />
            Verified Intent Platform
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Built for trust, designed for
            <span className="text-gold"> meaningful connections</span>
          </h2>
          <p className="text-lg text-gray-400">
            Every feature ensures safe, consensual, and genuine interactions through controlled progression stages.
          </p>
        </div>

        {/* Features grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group bg-charcoal-700 rounded-2xl p-8 border border-charcoal-600 hover:border-gold/30 transition-all duration-300"
            >
              <div className="w-14 h-14 bg-gold/10 rounded-xl flex items-center justify-center mb-6 group-hover:bg-gold/20 transition-colors border border-gold/20">
                <feature.icon className="w-7 h-7 text-gold" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-3">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
