import React, { useState, useRef, useCallback } from 'react';
import { invokeEdgeFunction } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { usePremium } from '@/contexts/PremiumContext';

import {
  Gift,
  Copy,
  Check,
  Users,
  Award,
  Share2,
  Loader2,
  ChevronDown,
  ChevronUp,
  Crown,
  Sparkles,
  WifiOff,
  RefreshCw,
  AlertCircle
} from 'lucide-react';

// ─── Client-side timeout for referral stats ─────────────────────────────
// 12s is generous for a warm function but won't leave the user hanging 30s.
// If the edge function is cold-starting, 12s should still be enough.
// If it isn't, the user sees a friendly retry button — not a frozen panel.
const STATS_TIMEOUT_MS = 12_000;

// SessionStorage key for caching stats (survives tab refresh)
const CACHE_KEY = 'dwadido_referral_stats';
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

interface ReferralStats {
  referralCode: string | null;
  referralLink: string | null;
  totalSignups: number;
  successfulConversions: number;
  pendingRewards: number;
  appliedRewards: number;
  totalMonthsEarned: number;
  conversions: Array<{
    convertedAt: string;
    rewardApplied: boolean;
    rewardMonths: number;
  }>;
}

interface CachedStats {
  stats: ReferralStats;
  timestamp: number;
}

interface ShareAndEarnProps {
  compact?: boolean;
}

// ─── Cache helpers ──────────────────────────────────────────────────────
function readCache(): ReferralStats | null {
  try {
    const raw = sessionStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const cached: CachedStats = JSON.parse(raw);
    if (Date.now() - cached.timestamp > CACHE_TTL_MS) {
      sessionStorage.removeItem(CACHE_KEY);
      return null;
    }
    return cached.stats;
  } catch {
    return null;
  }
}

function writeCache(stats: ReferralStats): void {
  try {
    const cached: CachedStats = { stats, timestamp: Date.now() };
    sessionStorage.setItem(CACHE_KEY, JSON.stringify(cached));
  } catch {
    // sessionStorage full or unavailable — ignore
  }
}

const ShareAndEarn: React.FC<ShareAndEarnProps> = ({ compact = false }) => {
  const { user } = useAuth();
  const { isPremium } = usePremium();

  // ── State ──────────────────────────────────────────────────────────
  // CRITICAL: loading starts FALSE — component renders instantly, never blocks dashboard
  const [stats, setStats] = useState<ReferralStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(!compact);
  const [error, setError] = useState<string | null>(null);
  const [isOffline, setIsOffline] = useState(false);
  const [hasFetchedOnce, setHasFetchedOnce] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  // AbortController ref so we can cancel in-flight requests
  const abortRef = useRef<AbortController | null>(null);

  // ── Fetch referral stats (lazy — only called on expand or retry) ──
  const fetchReferralStats = useCallback(async (isRetry = false) => {
    if (!user) return;

    // Cancel any in-flight request
    if (abortRef.current) {
      abortRef.current.abort();
    }

    // Check cache first (instant)
    const cached = readCache();
    if (cached && !isRetry) {
      setStats(cached);
      setHasFetchedOnce(true);
      setError(null);
      setIsOffline(false);
      // Still refresh in background (stale-while-revalidate)
      refreshInBackground();
      return;
    }

    setLoading(true);
    setError(null);
    setIsOffline(false);

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      // Use the new signal + timeoutMs options on invokeEdgeFunction
      // This ensures the actual fetch is cancelled after 12s, not 30s
      const { data, error: fnError } = await invokeEdgeFunction(
        'referral-get-stats',
        {},
        undefined,
        { timeoutMs: STATS_TIMEOUT_MS, signal: controller.signal }
      );

      // Check if this request was cancelled by a newer one
      if (controller.signal.aborted) return;

      if (fnError) throw fnError;

      setStats(data);
      setHasFetchedOnce(true);
      setRetryCount(0);
      if (data) writeCache(data);
    } catch (err: any) {
      // Don't update state if request was cancelled by a newer one
      if (controller.signal.aborted && abortRef.current !== controller) return;

      console.error('[ShareAndEarn] Error fetching referral stats:', err);

      const msg = err?.message || '';
      if (msg.includes('timed out') || msg.includes('timeout') || msg.includes('abort')) {
        setError('Stats took too long to load. Tap retry when ready.');
      } else if (msg.includes('cancelled')) {
        // Request was cancelled — don't show error
        return;
      } else if (msg.includes('Failed to send') || msg.includes('Load failed') || msg.includes('Failed to fetch')) {
        setIsOffline(true);
        setError('Cannot reach the server. Check your connection.');
      } else {
        setError('Could not load referral stats.');
      }
      setRetryCount(prev => prev + 1);
    } finally {
      setLoading(false);
    }
  }, [user]);

  // Background refresh — doesn't show loading state, silently updates cache
  const refreshInBackground = useCallback(async () => {
    if (!user) return;
    try {
      const { data, error: fnError } = await invokeEdgeFunction(
        'referral-get-stats',
        {},
        undefined,
        { timeoutMs: STATS_TIMEOUT_MS }
      );
      if (!fnError && data) {
        setStats(data);
        writeCache(data);
      }
    } catch {
      // Silent — cached data is already showing
    }
  }, [user]);

  // ── Handle expand (triggers lazy fetch) ────────────────────────────
  const handleExpand = useCallback(() => {
    setExpanded(true);
    if (!hasFetchedOnce && !loading) {
      fetchReferralStats();
    }
  }, [hasFetchedOnce, loading, fetchReferralStats]);

  const handleCollapse = useCallback(() => {
    setExpanded(false);
  }, []);

  // ── Generate referral code ─────────────────────────────────────────
  const generateReferralCode = async () => {
    try {
      setGenerating(true);
      setError(null);

      const { error: fnError } = await invokeEdgeFunction(
        'referral-generate-code',
        {},
        undefined,
        { timeoutMs: STATS_TIMEOUT_MS }
      );

      if (fnError) throw fnError;

      // Refresh stats to get the new code
      await fetchReferralStats(true);
    } catch (err: any) {
      console.error('[ShareAndEarn] Error generating referral code:', err);
      const msg = err?.message || '';
      if (msg.includes('timed out') || msg.includes('timeout')) {
        setError('Request timed out. Please try again.');
      } else {
        setError(err.message || 'Failed to generate referral code');
      }
    } finally {
      setGenerating(false);
    }
  };

  // ── Clipboard ──────────────────────────────────────────────────────
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const shareReferralLink = async () => {
    if (!stats?.referralLink) return;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join Dwadido Premium',
          text: 'Sign up for Dwadido using my referral link and we both get rewarded!',
          url: stats.referralLink
        });
      } catch {
        copyToClipboard(stats.referralLink);
      }
    } else {
      copyToClipboard(stats.referralLink);
    }
  };

  // ═══════════════════════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════════════════════

  // ── Collapsed compact view (renders INSTANTLY — no fetch needed) ───
  if (compact && !expanded) {
    return (
      <div className="bg-gradient-to-br from-gold/10 to-gold/5 rounded-2xl p-4 border border-gold/20">
        <button
          onClick={handleExpand}
          className="w-full flex items-center justify-between"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center">
              <Gift className="w-5 h-5 text-gold" />
            </div>
            <div className="text-left">
              <h3 className="font-semibold text-white text-sm">Share & Earn</h3>
              <p className="text-xs text-gray-400">
                {stats ? `${stats.totalMonthsEarned} months earned` : 'Tap to view'}
              </p>
            </div>
          </div>
          <ChevronDown className="w-5 h-5 text-gray-400" />
        </button>
      </div>
    );
  }

  // ── Loading skeleton (compact, non-blocking) ──────────────────────
  // Only shown INSIDE the expanded panel, never blocks the dashboard
  const LoadingSkeleton = () => (
    <div className="space-y-4 animate-pulse">
      <div className="bg-charcoal-700/50 rounded-xl p-4">
        <div className="h-3 bg-charcoal-600 rounded w-32 mb-3" />
        <div className="flex items-center gap-2">
          <div className="flex-1 h-12 bg-charcoal-600 rounded-lg" />
          <div className="w-12 h-12 bg-charcoal-600 rounded-lg" />
        </div>
      </div>
      <div className="grid grid-cols-3 gap-3">
        {[1, 2, 3].map(i => (
          <div key={i} className="bg-charcoal-700 rounded-xl p-4">
            <div className="w-10 h-10 mx-auto mb-2 bg-charcoal-600 rounded-lg" />
            <div className="h-6 bg-charcoal-600 rounded w-8 mx-auto mb-1" />
            <div className="h-2 bg-charcoal-600 rounded w-12 mx-auto" />
          </div>
        ))}
      </div>
    </div>
  );

  // ── Error state (inline, with retry — never blocks dashboard) ─────
  const ErrorFallback = () => (
    <div className="flex flex-col items-center justify-center py-6 text-center">
      {isOffline ? (
        <WifiOff className="w-8 h-8 text-gray-500 mb-3" />
      ) : (
        <AlertCircle className="w-8 h-8 text-gray-500 mb-3" />
      )}
      <p className="text-sm text-gray-400 mb-1">{error}</p>
      {retryCount > 1 && (
        <p className="text-xs text-gray-500 mb-3">
          Tried {retryCount} time{retryCount > 1 ? 's' : ''}. The server may be slow right now.
        </p>
      )}
      <button
        onClick={() => fetchReferralStats(true)}
        disabled={loading}
        className="flex items-center gap-2 px-4 py-2 bg-gold/20 hover:bg-gold/30 text-gold rounded-lg text-sm transition-colors disabled:opacity-50"
      >
        {loading ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <RefreshCw className="w-4 h-4" />
        )}
        Try Again
      </button>
    </div>
  );

  // ── Full expanded view ────────────────────────────────────────────
  return (
    <div className="bg-gradient-to-br from-gold/10 to-gold/5 rounded-2xl border border-gold/20 overflow-hidden">
      {/* Header */}
      <div className="p-6 pb-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gold/20 rounded-xl flex items-center justify-center">
              <Gift className="w-6 h-6 text-gold" />
            </div>
            <div>
              <h3 className="font-bold text-white text-lg">Share & Earn</h3>
              <p className="text-sm text-gray-400">Invite friends, get free Premium</p>
            </div>
          </div>
          {compact && (
            <button
              onClick={handleCollapse}
              className="p-2 hover:bg-charcoal-600 rounded-lg transition-colors"
            >
              <ChevronUp className="w-5 h-5 text-gray-400" />
            </button>
          )}
        </div>

        {/* How it works */}
        <div className="bg-charcoal-700/50 rounded-xl p-4 mb-4">
          <div className="flex items-center gap-2 text-gold font-medium mb-2">
            <Sparkles className="w-4 h-4" />
            How it works
          </div>
          <ol className="text-sm text-gray-300 space-y-1">
            <li className="flex items-start gap-2">
              <span className="text-gold font-bold">1.</span>
              Share your unique referral link
            </li>
            <li className="flex items-start gap-2">
              <span className="text-gold font-bold">2.</span>
              Friend signs up and subscribes to Premium
            </li>
            <li className="flex items-start gap-2">
              <span className="text-gold font-bold">3.</span>
              You get 1 free month of Premium added!
            </li>
          </ol>
        </div>

        {/* Inline error banner (non-blocking — shows above content when we have stale data) */}
        {error && stats && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 mb-4">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0" />
              <p className="text-sm text-amber-300 flex-1">{error}</p>
              <button
                onClick={() => fetchReferralStats(true)}
                disabled={loading}
                className="text-xs text-amber-400 hover:text-amber-300 underline flex-shrink-0"
              >
                Retry
              </button>
            </div>
          </div>
        )}

        {/* ── Content: Loading / Error / Stats ─────────────────────── */}
        {loading && !stats ? (
          // Loading skeleton — only shown if we have NO cached data
          <LoadingSkeleton />
        ) : error && !stats ? (
          // Error with no data — show retry fallback
          <ErrorFallback />
        ) : stats?.referralCode ? (
          // ── Has referral code — show full stats ──
          <div className="space-y-4">
            {/* Referral Code Display */}
            <div className="bg-charcoal-700 rounded-xl p-4">
              <label className="text-xs text-gray-400 uppercase tracking-wider mb-2 block">
                Your Referral Code
              </label>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-charcoal-800 rounded-lg px-4 py-3 font-mono text-lg text-gold font-bold tracking-wider">
                  {stats.referralCode}
                </div>
                <button
                  onClick={() => copyToClipboard(stats.referralCode!)}
                  className="p-3 bg-gold/20 hover:bg-gold/30 rounded-lg transition-colors"
                  title="Copy code"
                >
                  {copied ? (
                    <Check className="w-5 h-5 text-green-400" />
                  ) : (
                    <Copy className="w-5 h-5 text-gold" />
                  )}
                </button>
              </div>
            </div>

            {/* Referral Link */}
            <div className="bg-charcoal-700 rounded-xl p-4">
              <label className="text-xs text-gray-400 uppercase tracking-wider mb-2 block">
                Your Referral Link
              </label>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-charcoal-800 rounded-lg px-4 py-3 text-sm text-gray-300 truncate">
                  {stats.referralLink}
                </div>
                <button
                  onClick={shareReferralLink}
                  className="p-3 bg-gold hover:bg-gold-400 rounded-lg transition-colors"
                  title="Share link"
                >
                  <Share2 className="w-5 h-5 text-charcoal" />
                </button>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-charcoal-700 rounded-xl p-4 text-center">
                <div className="w-10 h-10 mx-auto mb-2 bg-blue-500/20 rounded-lg flex items-center justify-center">
                  <Users className="w-5 h-5 text-blue-400" />
                </div>
                <p className="text-2xl font-bold text-white">{stats.totalSignups}</p>
                <p className="text-xs text-gray-400">Signups</p>
              </div>
              <div className="bg-charcoal-700 rounded-xl p-4 text-center">
                <div className="w-10 h-10 mx-auto mb-2 bg-green-500/20 rounded-lg flex items-center justify-center">
                  <Crown className="w-5 h-5 text-green-400" />
                </div>
                <p className="text-2xl font-bold text-white">{stats.successfulConversions}</p>
                <p className="text-xs text-gray-400">Conversions</p>
              </div>
              <div className="bg-charcoal-700 rounded-xl p-4 text-center">
                <div className="w-10 h-10 mx-auto mb-2 bg-gold/20 rounded-lg flex items-center justify-center">
                  <Award className="w-5 h-5 text-gold" />
                </div>
                <p className="text-2xl font-bold text-white">{stats.totalMonthsEarned}</p>
                <p className="text-xs text-gray-400">Months Earned</p>
              </div>
            </div>

            {/* Loading overlay for background refresh */}
            {loading && stats && (
              <div className="flex items-center justify-center gap-2 py-2">
                <Loader2 className="w-3 h-3 text-gray-500 animate-spin" />
                <span className="text-xs text-gray-500">Refreshing...</span>
              </div>
            )}

            {/* Pending Rewards */}
            {stats.pendingRewards > 0 && (
              <div className="bg-gold/10 border border-gold/30 rounded-xl p-4">
                <div className="flex items-center gap-2 text-gold font-medium">
                  <Sparkles className="w-5 h-5" />
                  {stats.pendingRewards} reward{stats.pendingRewards > 1 ? 's' : ''} pending!
                </div>
                <p className="text-sm text-gray-400 mt-1">
                  Your free months will be added to your subscription soon.
                </p>
              </div>
            )}

            {/* Recent Conversions */}
            {stats.conversions.length > 0 && (
              <div className="bg-charcoal-700 rounded-xl p-4">
                <h4 className="font-medium text-white mb-3">Recent Rewards</h4>
                <div className="space-y-2">
                  {stats.conversions.slice(0, 5).map((conversion, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between py-2 border-b border-charcoal-600 last:border-0"
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${conversion.rewardApplied ? 'bg-green-400' : 'bg-yellow-400'}`} />
                        <span className="text-sm text-gray-300">
                          +{conversion.rewardMonths} month{conversion.rewardMonths > 1 ? 's' : ''}
                        </span>
                      </div>
                      <span className="text-xs text-gray-500">
                        {new Date(conversion.convertedAt).toLocaleDateString()}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : !loading ? (
          /* No referral code yet — Generate Code Button */
          <div className="text-center py-4">
            <p className="text-gray-400 mb-4">
              Generate your unique referral code to start earning free Premium months!
            </p>
            <button
              onClick={generateReferralCode}
              disabled={generating}
              className="px-6 py-3 bg-gold hover:bg-gold-400 text-charcoal font-semibold rounded-xl transition-all disabled:opacity-50 flex items-center gap-2 mx-auto"
            >
              {generating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Gift className="w-5 h-5" />
                  Get My Referral Code
                </>
              )}
            </button>
          </div>
        ) : null}
      </div>

      {/* Footer */}
      <div className="bg-charcoal-800/50 px-6 py-3 border-t border-charcoal-600">
        <p className="text-xs text-gray-500 text-center">
          Rewards are added automatically when your referrals subscribe to Premium.
        </p>
      </div>
    </div>
  );
};

export default ShareAndEarn;
