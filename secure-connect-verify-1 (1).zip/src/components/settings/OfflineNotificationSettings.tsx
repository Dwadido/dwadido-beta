import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useI18n } from '@/contexts/I18nContext';
import { 
  Wifi,
  WifiOff,
  Clock,
  Layers,
  Mail,
  Loader2,
  Check,
  AlertCircle,
  Info,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

type SupportedLanguage = 'en' | 'es' | 'fr' | 'de';

interface OfflineNotificationPrefs {
  offline_notification_enabled: boolean;
  offline_notification_delay: number;
  batch_notifications: boolean;
  max_emails_per_day: number;
}

interface PendingNotification {
  id: string;
  sender_name: string;
  scheduled_for: string;
  status: string;
}

const UI_TEXT = {
  en: {
    title: 'Offline Notifications',
    description: 'Get email notifications for messages received while you\'re offline',
    enableToggle: 'Offline Message Alerts',
    enableToggleDesc: 'Receive email when you have unread messages while offline',
    delayLabel: 'Notification Delay',
    delayDesc: 'Wait time before sending email (gives you time to come back online)',
    batchLabel: 'Batch Notifications',
    batchDesc: 'Combine multiple messages into a single email to reduce inbox clutter',
    maxEmailsLabel: 'Daily Email Limit',
    maxEmailsDesc: 'Maximum number of notification emails per day',
    pendingSection: 'Pending Notifications',
    pendingSectionDesc: 'Messages waiting to be sent as email notifications',
    noPending: 'No pending notifications',
    scheduledFor: 'Scheduled for',
    cancelAll: 'Cancel All',
    howItWorks: 'How it works',
    howItWorksText: 'When you receive a message while offline, we wait for the configured delay before sending an email. If you come back online during this time, the notification is cancelled. Multiple messages from the same person are batched together.',
    minutes: 'minutes',
    emails: 'emails',
    saving: 'Saving...',
    saved: 'Saved',
    error: 'Error saving'
  },
  es: {
    title: 'Notificaciones Sin Conexión',
    description: 'Recibe notificaciones por email de mensajes cuando estés desconectado',
    enableToggle: 'Alertas de Mensajes Sin Conexión',
    enableToggleDesc: 'Recibir email cuando tengas mensajes sin leer mientras estás desconectado',
    delayLabel: 'Retraso de Notificación',
    delayDesc: 'Tiempo de espera antes de enviar el email (te da tiempo para volver a conectarte)',
    batchLabel: 'Agrupar Notificaciones',
    batchDesc: 'Combinar múltiples mensajes en un solo email para reducir el desorden',
    maxEmailsLabel: 'Límite Diario de Emails',
    maxEmailsDesc: 'Número máximo de emails de notificación por día',
    pendingSection: 'Notificaciones Pendientes',
    pendingSectionDesc: 'Mensajes esperando ser enviados como notificaciones por email',
    noPending: 'No hay notificaciones pendientes',
    scheduledFor: 'Programado para',
    cancelAll: 'Cancelar Todo',
    howItWorks: 'Cómo funciona',
    howItWorksText: 'Cuando recibes un mensaje mientras estás desconectado, esperamos el retraso configurado antes de enviar un email. Si vuelves a conectarte durante este tiempo, la notificación se cancela. Múltiples mensajes de la misma persona se agrupan.',
    minutes: 'minutos',
    emails: 'emails',
    saving: 'Guardando...',
    saved: 'Guardado',
    error: 'Error al guardar'
  },
  fr: {
    title: 'Notifications Hors Ligne',
    description: 'Recevez des notifications par email pour les messages reçus hors ligne',
    enableToggle: 'Alertes Messages Hors Ligne',
    enableToggleDesc: 'Recevoir un email quand vous avez des messages non lus hors ligne',
    delayLabel: 'Délai de Notification',
    delayDesc: 'Temps d\'attente avant d\'envoyer l\'email (vous laisse le temps de revenir en ligne)',
    batchLabel: 'Regrouper les Notifications',
    batchDesc: 'Combiner plusieurs messages en un seul email pour réduire l\'encombrement',
    maxEmailsLabel: 'Limite Quotidienne d\'Emails',
    maxEmailsDesc: 'Nombre maximum d\'emails de notification par jour',
    pendingSection: 'Notifications en Attente',
    pendingSectionDesc: 'Messages en attente d\'être envoyés par email',
    noPending: 'Aucune notification en attente',
    scheduledFor: 'Prévu pour',
    cancelAll: 'Tout Annuler',
    howItWorks: 'Comment ça marche',
    howItWorksText: 'Quand vous recevez un message hors ligne, nous attendons le délai configuré avant d\'envoyer un email. Si vous revenez en ligne pendant ce temps, la notification est annulée. Les messages multiples de la même personne sont regroupés.',
    minutes: 'minutes',
    emails: 'emails',
    saving: 'Enregistrement...',
    saved: 'Enregistré',
    error: 'Erreur de sauvegarde'
  },
  de: {
    title: 'Offline-Benachrichtigungen',
    description: 'Erhalte E-Mail-Benachrichtigungen für Nachrichten, die du offline erhältst',
    enableToggle: 'Offline-Nachrichtenalarme',
    enableToggleDesc: 'E-Mail erhalten, wenn du ungelesene Nachrichten hast, während du offline bist',
    delayLabel: 'Benachrichtigungsverzögerung',
    delayDesc: 'Wartezeit vor dem Senden der E-Mail (gibt dir Zeit, wieder online zu kommen)',
    batchLabel: 'Benachrichtigungen Bündeln',
    batchDesc: 'Mehrere Nachrichten in einer E-Mail zusammenfassen',
    maxEmailsLabel: 'Tägliches E-Mail-Limit',
    maxEmailsDesc: 'Maximale Anzahl von Benachrichtigungs-E-Mails pro Tag',
    pendingSection: 'Ausstehende Benachrichtigungen',
    pendingSectionDesc: 'Nachrichten, die als E-Mail-Benachrichtigungen gesendet werden',
    noPending: 'Keine ausstehenden Benachrichtigungen',
    scheduledFor: 'Geplant für',
    cancelAll: 'Alle Abbrechen',
    howItWorks: 'So funktioniert es',
    howItWorksText: 'Wenn du eine Nachricht erhältst, während du offline bist, warten wir die konfigurierte Verzögerung ab, bevor wir eine E-Mail senden. Wenn du während dieser Zeit wieder online kommst, wird die Benachrichtigung abgebrochen. Mehrere Nachrichten von derselben Person werden gebündelt.',
    minutes: 'Minuten',
    emails: 'E-Mails',
    saving: 'Speichern...',
    saved: 'Gespeichert',
    error: 'Fehler beim Speichern'
  }
};

const DELAY_OPTIONS = [
  { value: 5, label: '5' },
  { value: 15, label: '15' },
  { value: 30, label: '30' },
  { value: 60, label: '60' },
  { value: 120, label: '120' }
];

const MAX_EMAILS_OPTIONS = [
  { value: 3, label: '3' },
  { value: 5, label: '5' },
  { value: 10, label: '10' },
  { value: 20, label: '20' },
  { value: 50, label: '50' }
];

const OfflineNotificationSettings: React.FC = () => {
  const { user } = useAuth();
  const { language: appLanguage } = useI18n();
  
  const language: SupportedLanguage = ['en', 'es', 'fr', 'de'].includes(appLanguage) 
    ? appLanguage as SupportedLanguage 
    : 'en';
  
  const text = UI_TEXT[language];
  
  const [preferences, setPreferences] = useState<OfflineNotificationPrefs>({
    offline_notification_enabled: true,
    offline_notification_delay: 30,
    batch_notifications: true,
    max_emails_per_day: 10
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pendingNotifications, setPendingNotifications] = useState<PendingNotification[]>([]);
  const [showPending, setShowPending] = useState(false);
  const [showHowItWorks, setShowHowItWorks] = useState(false);

  useEffect(() => {
    if (user) {
      loadPreferences();
      loadPendingNotifications();
    }
  }, [user]);

  const loadPreferences = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('email_preferences')
        .select('offline_notification_enabled, offline_notification_delay, batch_notifications, max_emails_per_day')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!error && data) {
        setPreferences({
          offline_notification_enabled: data.offline_notification_enabled ?? true,
          offline_notification_delay: data.offline_notification_delay ?? 30,
          batch_notifications: data.batch_notifications ?? true,
          max_emails_per_day: data.max_emails_per_day ?? 10
        });
      }
    } catch (err) {
      console.error('Failed to load offline notification preferences:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadPendingNotifications = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('pending_message_notifications')
        .select('id, sender_name, scheduled_for, status')
        .eq('recipient_id', user.id)
        .eq('status', 'pending')
        .order('scheduled_for', { ascending: true })
        .limit(10);

      if (!error && data) {
        setPendingNotifications(data);
      }
    } catch (err) {
      console.error('Failed to load pending notifications:', err);
    }
  };

  const updatePreference = async (key: keyof OfflineNotificationPrefs, value: boolean | number) => {
    if (!user) return;

    const newPrefs = { ...preferences, [key]: value };
    setPreferences(newPrefs);
    setSaving(true);
    setError(null);

    try {
      const { error } = await supabase
        .from('email_preferences')
        .update({ [key]: value, updated_at: new Date().toISOString() })
        .eq('user_id', user.id);

      if (error) throw error;

      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (err) {
      console.error('Failed to update preference:', err);
      setError(text.error);
      setPreferences(preferences);
    } finally {
      setSaving(false);
    }
  };

  const cancelAllPending = async () => {
    if (!user) return;
    
    try {
      await supabase.functions.invoke('process-offline-notifications', {
        body: {
          action: 'cancel',
          userId: user.id
        }
      });
      
      setPendingNotifications([]);
    } catch (err) {
      console.error('Failed to cancel pending notifications:', err);
    }
  };

  const Toggle = ({ 
    enabled, 
    onChange, 
    disabled 
  }: { 
    enabled: boolean; 
    onChange: () => void; 
    disabled?: boolean 
  }) => (
    <button
      onClick={onChange}
      disabled={disabled}
      className={`w-11 h-6 rounded-full transition-all ${
        enabled ? 'bg-gold' : 'bg-charcoal-500'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      <div className={`w-5 h-5 bg-white rounded-full shadow transform transition-transform ${
        enabled ? 'translate-x-5' : 'translate-x-0.5'
      }`} />
    </button>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 text-gold animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <WifiOff className="w-5 h-5 text-gold" />
          {text.title}
        </h3>
        <p className="text-sm text-gray-400 mt-1">{text.description}</p>
      </div>

      {/* Status indicator */}
      {(saving || saved || error) && (
        <div className={`flex items-center gap-2 text-sm ${
          error ? 'text-red-400' : saved ? 'text-green-400' : 'text-gray-400'
        }`}>
          {saving && <Loader2 className="w-4 h-4 animate-spin" />}
          {saved && <Check className="w-4 h-4" />}
          {error && <AlertCircle className="w-4 h-4" />}
          <span>{saving ? text.saving : saved ? text.saved : error}</span>
        </div>
      )}

      {/* Enable Toggle */}
      <div className="p-4 bg-charcoal-600 rounded-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              preferences.offline_notification_enabled ? 'bg-gold/20' : 'bg-charcoal-500'
            }`}>
              <Mail className={`w-5 h-5 ${
                preferences.offline_notification_enabled ? 'text-gold' : 'text-gray-400'
              }`} />
            </div>
            <div>
              <p className="font-medium text-white">{text.enableToggle}</p>
              <p className="text-sm text-gray-400">{text.enableToggleDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.offline_notification_enabled} 
            onChange={() => updatePreference('offline_notification_enabled', !preferences.offline_notification_enabled)}
            disabled={saving}
          />
        </div>
      </div>

      {/* Settings (only shown when enabled) */}
      <div className={`space-y-4 ${!preferences.offline_notification_enabled ? 'opacity-50 pointer-events-none' : ''}`}>
        
        {/* Notification Delay */}
        <div className="p-4 bg-charcoal-700/50 rounded-xl">
          <div className="flex items-center gap-3 mb-3">
            <Clock className="w-5 h-5 text-blue-400" />
            <div>
              <p className="font-medium text-white">{text.delayLabel}</p>
              <p className="text-sm text-gray-400">{text.delayDesc}</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {DELAY_OPTIONS.map((option) => (
              <button
                key={option.value}
                onClick={() => updatePreference('offline_notification_delay', option.value)}
                disabled={saving}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  preferences.offline_notification_delay === option.value
                    ? 'bg-gold text-charcoal-900'
                    : 'bg-charcoal-600 text-gray-300 hover:bg-charcoal-500'
                }`}
              >
                {option.label} {text.minutes}
              </button>
            ))}
          </div>
        </div>

        {/* Batch Notifications */}
        <div className="flex items-center justify-between p-4 bg-charcoal-700/50 rounded-xl">
          <div className="flex items-center gap-3">
            <Layers className="w-5 h-5 text-purple-400" />
            <div>
              <p className="font-medium text-white">{text.batchLabel}</p>
              <p className="text-sm text-gray-400">{text.batchDesc}</p>
            </div>
          </div>
          <Toggle 
            enabled={preferences.batch_notifications} 
            onChange={() => updatePreference('batch_notifications', !preferences.batch_notifications)}
            disabled={saving}
          />
        </div>

        {/* Max Emails Per Day */}
        <div className="p-4 bg-charcoal-700/50 rounded-xl">
          <div className="flex items-center gap-3 mb-3">
            <Mail className="w-5 h-5 text-amber-400" />
            <div>
              <p className="font-medium text-white">{text.maxEmailsLabel}</p>
              <p className="text-sm text-gray-400">{text.maxEmailsDesc}</p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            {MAX_EMAILS_OPTIONS.map((option) => (
              <button
                key={option.value}
                onClick={() => updatePreference('max_emails_per_day', option.value)}
                disabled={saving}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  preferences.max_emails_per_day === option.value
                    ? 'bg-gold text-charcoal-900'
                    : 'bg-charcoal-600 text-gray-300 hover:bg-charcoal-500'
                }`}
              >
                {option.label} {text.emails}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Pending Notifications */}
      {pendingNotifications.length > 0 && (
        <div className="p-4 bg-charcoal-700/50 rounded-xl">
          <button
            onClick={() => setShowPending(!showPending)}
            className="flex items-center justify-between w-full"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center">
                <Clock className="w-4 h-4 text-amber-400" />
              </div>
              <div className="text-left">
                <p className="font-medium text-white">{text.pendingSection}</p>
                <p className="text-sm text-gray-400">{text.pendingSectionDesc}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs bg-amber-500/20 text-amber-400 px-2 py-1 rounded-full">
                {pendingNotifications.length}
              </span>
              {showPending ? (
                <ChevronUp className="w-5 h-5 text-gray-400" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-400" />
              )}
            </div>
          </button>
          
          {showPending && (
            <div className="mt-4 space-y-2">
              {pendingNotifications.map((notification) => (
                <div 
                  key={notification.id}
                  className="flex items-center justify-between p-3 bg-charcoal-600 rounded-lg"
                >
                  <div>
                    <p className="text-sm text-white">{notification.sender_name}</p>
                    <p className="text-xs text-gray-500">
                      {text.scheduledFor}: {new Date(notification.scheduled_for).toLocaleTimeString()}
                    </p>
                  </div>
                  {/* Static dot instead of animate-pulse for calm, non-addictive design (Dwadido Global Rule) */}
                  <div className="w-2 h-2 rounded-full bg-amber-400" />
                </div>

              ))}
              
              <button
                onClick={cancelAllPending}
                className="w-full mt-2 px-4 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-colors"
              >
                {text.cancelAll}
              </button>
            </div>
          )}
        </div>
      )}

      {/* How It Works */}
      <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
        <button
          onClick={() => setShowHowItWorks(!showHowItWorks)}
          className="flex items-center gap-2 w-full"
        >
          <Info className="w-4 h-4 text-blue-400" />
          <span className="text-sm font-medium text-blue-300">{text.howItWorks}</span>
          {showHowItWorks ? (
            <ChevronUp className="w-4 h-4 text-blue-400 ml-auto" />
          ) : (
            <ChevronDown className="w-4 h-4 text-blue-400 ml-auto" />
          )}
        </button>
        
        {showHowItWorks && (
          <p className="text-xs text-blue-300/80 mt-3 leading-relaxed">
            {text.howItWorksText}
          </p>
        )}
      </div>
    </div>
  );
};

export default OfflineNotificationSettings;
