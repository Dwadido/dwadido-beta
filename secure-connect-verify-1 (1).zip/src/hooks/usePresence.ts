import { useEffect, useRef, useCallback } from 'react';
import { supabase, SUPABASE_URL, SUPABASE_ANON_KEY } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';


interface PresenceOptions {
  heartbeatInterval?: number; // How often to send heartbeat (ms)
  offlineThreshold?: number; // How long before considered offline (ms)
  onStatusChange?: (isOnline: boolean) => void;
}

const DEFAULT_HEARTBEAT_INTERVAL = 30000; // 30 seconds
const DEFAULT_OFFLINE_THRESHOLD = 60000; // 1 minute

export function usePresence(options: PresenceOptions = {}) {
  const { user } = useAuth();
  const {
    heartbeatInterval = DEFAULT_HEARTBEAT_INTERVAL,
    offlineThreshold = DEFAULT_OFFLINE_THRESHOLD,
    onStatusChange
  } = options;

  const heartbeatRef = useRef<NodeJS.Timeout | null>(null);
  const isOnlineRef = useRef<boolean>(true);
  const presenceExistsRef = useRef<boolean | null>(null);

  // Update presence in database - with resilient error handling
  const updatePresence = useCallback(async (isOnline: boolean) => {
    if (!user) return;

    const presenceData = {
      user_id: user.id,
      is_online: isOnline,
      last_seen_at: new Date().toISOString(),
      last_activity_at: new Date().toISOString(),
      device_info: {
        userAgent: navigator.userAgent,
        platform: navigator.platform,
        language: navigator.language,
        screenWidth: window.screen.width,
        screenHeight: window.screen.height
      },
      updated_at: new Date().toISOString()
    };

    try {
      // If we already know presence exists, just update
      if (presenceExistsRef.current === true) {
        const { error } = await supabase
          .from('user_presence')
          .update({
            is_online: presenceData.is_online,
            last_seen_at: presenceData.last_seen_at,
            last_activity_at: presenceData.last_activity_at,
            device_info: presenceData.device_info,
            updated_at: presenceData.updated_at
          })
          .eq('user_id', user.id);

        if (error && error.code !== '23505') {
          // If update fails, try insert on next call
          presenceExistsRef.current = null;
        }
      } else if (presenceExistsRef.current === false) {
        // We know it doesn't exist, insert
        const { error } = await supabase
          .from('user_presence')
          .insert(presenceData);

        if (!error || error.code === '23505') {
          // Success or duplicate - record exists now
          presenceExistsRef.current = true;
        }
      } else {
        // Unknown state - try to check first, but handle errors gracefully
        try {
          const { data: existingData, error: selectError } = await supabase
            .from('user_presence')
            .select('id')
            .eq('user_id', user.id)
            .maybeSingle();

          if (selectError) {
            // Select failed - try direct insert as fallback
            const { error: insertError } = await supabase
              .from('user_presence')
              .insert(presenceData);

            if (!insertError) {
              presenceExistsRef.current = true;
            } else if (insertError.code === '23505') {
              // Duplicate key - record exists, try update
              presenceExistsRef.current = true;
              await supabase
                .from('user_presence')
                .update({
                  is_online: presenceData.is_online,
                  last_seen_at: presenceData.last_seen_at,
                  last_activity_at: presenceData.last_activity_at,
                  device_info: presenceData.device_info,
                  updated_at: presenceData.updated_at
                })
                .eq('user_id', user.id);
            }
            // Silently fail - presence is non-critical
            return;
          }

          if (existingData) {
            presenceExistsRef.current = true;
            const { error } = await supabase
              .from('user_presence')
              .update({
                is_online: presenceData.is_online,
                last_seen_at: presenceData.last_seen_at,
                last_activity_at: presenceData.last_activity_at,
                device_info: presenceData.device_info,
                updated_at: presenceData.updated_at
              })
              .eq('user_id', user.id);

            // Silently handle errors
            if (error) {
              presenceExistsRef.current = null;
            }
          } else {
            presenceExistsRef.current = false;
            const { error } = await supabase
              .from('user_presence')
              .insert(presenceData);

            if (!error || error.code === '23505') {
              presenceExistsRef.current = true;
            }
          }
        } catch {
          // Silently fail - presence tracking is non-critical
        }
      }

      // If going online, cancel any pending notifications
      if (isOnline && !isOnlineRef.current) {
        await cancelPendingNotifications();
      }

      isOnlineRef.current = isOnline;
      onStatusChange?.(isOnline);
    } catch {
      // Silently fail - presence tracking should not break the app
    }
  }, [user, onStatusChange]);


  // Cancel pending notifications when user comes online
  const cancelPendingNotifications = useCallback(async () => {
    if (!user) return;

    try {
      await supabase.functions.invoke('process-offline-notifications', {
        body: {
          action: 'cancel',
          userId: user.id
        }
      });
    } catch {
      // Silently fail
    }
  }, [user]);

  // Send heartbeat
  const sendHeartbeat = useCallback(async () => {
    if (!user) return;

    try {
      await supabase
        .from('user_presence')
        .update({
          last_activity_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('user_id', user.id);
    } catch {
      // Silently fail
    }
  }, [user]);

  // Set user as offline
  const setOffline = useCallback(async () => {
    await updatePresence(false);
  }, [updatePresence]);

  // Set user as online
  const setOnline = useCallback(async () => {
    await updatePresence(true);
  }, [updatePresence]);

  // Initialize presence tracking
  useEffect(() => {
    if (!user) return;

    // Reset presence state for new user
    presenceExistsRef.current = null;

    // Set online when component mounts
    updatePresence(true);

    // Start heartbeat
    heartbeatRef.current = setInterval(sendHeartbeat, heartbeatInterval);

    // Handle visibility change (tab switch)
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        updatePresence(true);
      }
    };

    // Handle before unload (page close/refresh)
    const handleBeforeUnload = () => {
      // Use sendBeacon for reliable offline notification
      const data = JSON.stringify({
        user_id: user.id,
        is_online: false,
        last_seen_at: new Date().toISOString()
      });
      
      navigator.sendBeacon?.(
        `${SUPABASE_URL}/rest/v1/user_presence?user_id=eq.${user.id}`,
        data
      );
    };


    // Handle online/offline events
    const handleOnline = () => updatePresence(true);
    const handleOffline = () => updatePresence(false);

    // Handle user activity - debounced
    let activityTimeout: NodeJS.Timeout | null = null;
    const handleActivity = () => {
      if (activityTimeout) return;
      
      activityTimeout = setTimeout(() => {
        activityTimeout = null;
        if (!isOnlineRef.current) {
          updatePresence(true);
        }
      }, 1000);
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleBeforeUnload);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // Track user activity
    window.addEventListener('mousemove', handleActivity, { passive: true });
    window.addEventListener('keydown', handleActivity, { passive: true });
    window.addEventListener('click', handleActivity, { passive: true });
    window.addEventListener('scroll', handleActivity, { passive: true });
    window.addEventListener('touchstart', handleActivity, { passive: true });

    return () => {
      // Clear heartbeat
      if (heartbeatRef.current) {
        clearInterval(heartbeatRef.current);
      }

      // Clear activity timeout
      if (activityTimeout) {
        clearTimeout(activityTimeout);
      }

      // Set offline on unmount
      updatePresence(false);

      // Remove event listeners
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('keydown', handleActivity);
      window.removeEventListener('click', handleActivity);
      window.removeEventListener('scroll', handleActivity);
      window.removeEventListener('touchstart', handleActivity);
    };
  }, [user, heartbeatInterval, updatePresence, sendHeartbeat]);

  return {
    setOnline,
    setOffline,
    sendHeartbeat
  };
}

// Queue a message notification for offline user
export async function queueOfflineNotification(
  recipientId: string,
  senderId: string,
  senderName: string,
  messagePreview?: string,
  messageId?: string,
  chatUrl?: string
): Promise<{ success: boolean; queued: boolean; reason?: string }> {
  try {
    const { data, error } = await supabase.functions.invoke('process-offline-notifications', {
      body: {
        action: 'queue',
        userId: recipientId,
        senderId,
        senderName,
        messagePreview,
        messageId,
        chatUrl
      }
    });

    if (error) {
      return { success: false, queued: false, reason: error.message };
    }

    return data;
  } catch {
    return { success: false, queued: false, reason: 'Unknown error' };
  }
}

// Check if a user is online
export async function checkUserOnline(userId: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('user_presence')
      .select('is_online, last_activity_at')
      .eq('user_id', userId)
      .maybeSingle();

    if (error || !data) return false;

    // Check if last activity is within threshold (5 minutes)
    const lastActivity = new Date(data.last_activity_at);
    const now = new Date();
    const threshold = 5 * 60 * 1000; // 5 minutes

    return data.is_online && (now.getTime() - lastActivity.getTime()) < threshold;
  } catch {
    return false;
  }
}

// Get online status for multiple users
export async function getOnlineStatuses(userIds: string[]): Promise<Record<string, boolean>> {
  if (userIds.length === 0) return {};

  try {
    const { data, error } = await supabase
      .from('user_presence')
      .select('user_id, is_online, last_activity_at')
      .in('user_id', userIds);

    if (error || !data) return {};

    const threshold = 5 * 60 * 1000; // 5 minutes
    const now = new Date();

    return data.reduce((acc, presence) => {
      const lastActivity = new Date(presence.last_activity_at);
      const isRecentlyActive = (now.getTime() - lastActivity.getTime()) < threshold;
      acc[presence.user_id] = presence.is_online && isRecentlyActive;
      return acc;
    }, {} as Record<string, boolean>);
  } catch {
    return {};
  }
}

export default usePresence;
