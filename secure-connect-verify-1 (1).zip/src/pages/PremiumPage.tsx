import React from 'react';
import PremiumPage from '@/components/premium/PremiumPage';

const PremiumPageRoute: React.FC = () => {
  return <PremiumPage />;
};

export default PremiumPageRoute;
