import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePremium } from '@/contexts/PremiumContext';
import { supabase } from '@/lib/supabase';
import { 
  X, 
  Camera, 
  Lock, 
  Check, 
  Loader2, 
  AlertCircle,
  Eye,
  Clock,
  User,
  Crown
} from 'lucide-react';
import PremiumGate, { usePremiumGate } from '@/components/premium/PremiumGate';

interface PhotoRequest {
  id: string;
  requester_id: string;

  target_id: string;
  status: 'pending' | 'approved' | 'rejected';
  message: string | null;
  created_at: string;
  responded_at: string | null;
  requester_profile?: {
    display_name: string | null;
    avatar_url: string | null;
  };
}

interface PhotoRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUserId?: string;
  targetUserName?: string;
  mode: 'request' | 'manage';
}

const PhotoRequestModal: React.FC<PhotoRequestModalProps> = ({
  isOpen,
  onClose,
  targetUserId,
  targetUserName,
  mode
}) => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [requests, setRequests] = useState<PhotoRequest[]>([]);
  const [message, setMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [existingRequest, setExistingRequest] = useState<PhotoRequest | null>(null);

  useEffect(() => {
    if (isOpen && user) {
      if (mode === 'request' && targetUserId) {
        checkExistingRequest();
      } else if (mode === 'manage') {
        fetchPendingRequests();
      }
    }
  }, [isOpen, user, mode, targetUserId]);

  const checkExistingRequest = async () => {
    if (!user || !targetUserId) return;

    const { data } = await supabase
      .from('photo_requests')
      .select('*')
      .eq('requester_id', user.id)
      .eq('target_id', targetUserId)
      .single();

    setExistingRequest(data);
  };

  const fetchPendingRequests = async () => {
    if (!user) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('photo_requests')
      .select(`
        *,
        requester_profile:profiles!photo_requests_requester_id_fkey(display_name, avatar_url)
      `)
      .eq('target_id', user.id)
      .eq('status', 'pending')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching requests:', error);
    } else {
      setRequests(data || []);
    }
    setLoading(false);
  };

  const sendRequest = async () => {
    if (!user || !targetUserId) return;

    setLoading(true);
    setError(null);

    try {
      const { error } = await supabase
        .from('photo_requests')
        .insert({
          requester_id: user.id,
          target_id: targetUserId,
          message: message.trim() || null,
          status: 'pending'
        });

      if (error) throw error;

      setSuccess('Photo request sent!');
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to send request');
    } finally {
      setLoading(false);
    }
  };

  const respondToRequest = async (requestId: string, approve: boolean) => {
    if (!user) return;

    setLoading(true);
    setError(null);

    try {
      // Update request status
      const { error: updateError } = await supabase
        .from('photo_requests')
        .update({
          status: approve ? 'approved' : 'rejected',
          responded_at: new Date().toISOString()
        })
        .eq('id', requestId);

      if (updateError) throw updateError;

      // If approved, create photo permission
      if (approve) {
        const request = requests.find(r => r.id === requestId);
        if (request) {
          await supabase
            .from('photo_permissions')
            .upsert({
              owner_id: user.id,
              viewer_id: request.requester_id,
              permission_type: 'approved'
            });
        }
      }

      // Remove from local state
      setRequests(requests.filter(r => r.id !== requestId));
      setSuccess(approve ? 'Request approved' : 'Request declined');
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to respond to request');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative min-h-full flex items-center justify-center p-4">
        <div className="relative w-full max-w-md bg-[#141414] rounded-2xl shadow-2xl border border-[#2a2a2a]">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-[#2a2a2a]">
            <h2 className="text-lg font-semibold text-white flex items-center gap-2">
              <Camera className="w-5 h-5 text-[#C9A24D]" />
              {mode === 'request' ? 'Request Photos' : 'Photo Requests'}
            </h2>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white hover:bg-[#2a2a2a] rounded-full transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-4 space-y-4">
            {/* Error/Success Messages */}
            {error && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400" />
                <span className="text-red-400 text-sm">{error}</span>
              </div>
            )}
            {success && (
              <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-xl flex items-center gap-2">
                <Check className="w-4 h-4 text-green-400" />
                <span className="text-green-400 text-sm">{success}</span>
              </div>
            )}

            {mode === 'request' ? (
              <>
                {/* Request Mode */}
                {existingRequest ? (
                  <div className="text-center py-6">
                    {existingRequest.status === 'pending' ? (
                      <>
                        <div className="w-16 h-16 bg-yellow-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                          <Clock className="w-8 h-8 text-yellow-500" />
                        </div>
                        <h3 className="text-white font-medium mb-2">Request Pending</h3>
                        <p className="text-gray-400 text-sm">
                          You've already requested to see {targetUserName}'s photos.
                          They'll be notified and can approve your request.
                        </p>
                      </>
                    ) : existingRequest.status === 'approved' ? (
                      <>
                        <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                          <Check className="w-8 h-8 text-green-500" />
                        </div>
                        <h3 className="text-white font-medium mb-2">Request Approved</h3>
                        <p className="text-gray-400 text-sm">
                          {targetUserName} has approved your photo request.
                          You can now see their photos.
                        </p>
                      </>
                    ) : (
                      <>
                        <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                          <X className="w-8 h-8 text-red-500" />
                        </div>
                        <h3 className="text-white font-medium mb-2">Request Declined</h3>
                        <p className="text-gray-400 text-sm">
                          {targetUserName} has declined your photo request.
                        </p>
                      </>
                    )}
                  </div>
                ) : (
                  <>
                    <div className="text-center py-4">
                      <div className="w-16 h-16 bg-[#C9A24D]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Lock className="w-8 h-8 text-[#C9A24D]" />
                      </div>
                      <h3 className="text-white font-medium mb-2">
                        Request to see {targetUserName}'s photos
                      </h3>
                      <p className="text-gray-400 text-sm">
                        Their photos are private. Send a request and they'll decide
                        whether to share them with you.
                      </p>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Add a message (optional)
                      </label>
                      <textarea
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Hi! I'd love to see your photos..."
                        rows={3}
                        maxLength={200}
                        className="w-full px-4 py-3 bg-[#1a1a1a] border border-[#2a2a2a] text-white placeholder-gray-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#C9A24D]/50 focus:border-[#C9A24D] transition-all resize-none"
                      />
                      <p className="text-xs text-gray-500 mt-1 text-right">
                        {message.length}/200
                      </p>
                    </div>

                    {/* Send Request Button - Wrapped with PremiumGate for early photo access */}
                    <PremiumGate feature="earlyPhotoRequest" compactLock>
                      <button
                        onClick={sendRequest}
                        disabled={loading}
                        className="w-full py-3 bg-[#C9A24D] text-[#141414] font-semibold rounded-xl hover:bg-[#d4af5a] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                      >
                        {loading ? (
                          <Loader2 className="w-5 h-5 animate-spin" />
                        ) : (
                          <>
                            <Eye className="w-5 h-5" />
                            Send Request
                          </>
                        )}
                      </button>
                    </PremiumGate>
                  </>

                )}

              </>
            ) : (
              <>

                {/* Manage Mode */}
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-8 h-8 text-[#C9A24D] animate-spin" />
                  </div>
                ) : requests.length === 0 ? (
                  <div className="text-center py-8">
                    <div className="w-16 h-16 bg-[#1a1a1a] rounded-full flex items-center justify-center mx-auto mb-4">
                      <Camera className="w-8 h-8 text-gray-500" />
                    </div>
                    <h3 className="text-white font-medium mb-2">No Pending Requests</h3>
                    <p className="text-gray-400 text-sm">
                      You don't have any photo requests to review.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {requests.map((request) => (
                      <div
                        key={request.id}
                        className="p-4 bg-[#1a1a1a] rounded-xl border border-[#2a2a2a]"
                      >
                        <div className="flex items-start gap-3">
                          {request.requester_profile?.avatar_url ? (
                            <img
                              src={request.requester_profile.avatar_url}
                              alt=""
                              className="w-10 h-10 rounded-full object-cover"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded-full bg-[#2a2a2a] flex items-center justify-center">
                              <User className="w-5 h-5 text-gray-500" />
                            </div>
                          )}
                          <div className="flex-1 min-w-0">
                            <p className="text-white font-medium">
                              {request.requester_profile?.display_name || 'Anonymous'}
                            </p>
                            <p className="text-xs text-gray-500">
                              {new Date(request.created_at).toLocaleDateString()}
                            </p>
                            {request.message && (
                              <p className="text-sm text-gray-400 mt-2 italic">
                                "{request.message}"
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-2 mt-4">
                          <button
                            onClick={() => respondToRequest(request.id, true)}
                            disabled={loading}
                            className="flex-1 py-2 bg-[#C9A24D] text-[#141414] font-medium rounded-lg hover:bg-[#d4af5a] transition-all disabled:opacity-50 flex items-center justify-center gap-1"
                          >
                            <Check className="w-4 h-4" />
                            Approve
                          </button>
                          <button
                            onClick={() => respondToRequest(request.id, false)}
                            disabled={loading}
                            className="flex-1 py-2 bg-[#2a2a2a] text-gray-300 font-medium rounded-lg hover:bg-[#3a3a3a] transition-all disabled:opacity-50 flex items-center justify-center gap-1"
                          >
                            <X className="w-4 h-4" />
                            Decline
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PhotoRequestModal;
