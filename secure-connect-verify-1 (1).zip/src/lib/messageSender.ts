/**
 * =============================================================================
 * DWADIDO — CENTRALIZED MESSAGE SENDER
 * =============================================================================
 *
 * ALL chat messages MUST be sent through this module. Direct inserts to the
 * `messages` table from UI components are PROHIBITED.
 *
 * Enforcement pipeline (in order):
 *
 *   1. CLIENT-SIDE PRE-CHECK
 *      - Fetch fresh restriction state from `contact_restriction_removals`
 *      - Run `checkMessageForRestrictedContent()` regex/heuristics
 *      - Block immediately if restricted content detected while restriction active
 *
 *   2. SERVER-SIDE VALIDATION (edge function: `send-chat-message`)
 *      - Edge function re-validates restriction state from DB
 *      - Re-runs content filter server-side (cannot be bypassed)
 *      - Inserts message only if validation passes
 *      - If edge function unavailable → falls back to client-validated direct insert
 *
 *   3. FALLBACK: CLIENT-VALIDATED DIRECT INSERT
 *      - Only used when edge function is unavailable (404/500)
 *      - Client-side validation already passed at step 1
 *      - Direct insert to `messages` table
 *
 * WHY THIS EXISTS:
 *   Previously, ChatModal.tsx had 3 separate `.from('messages').insert()` calls
 *   (user messages, meeting suggestion messages, meeting response messages).
 *   Only the user message path had restriction checking. The other two paths
 *   could bypass restriction enforcement entirely.
 *
 * FUTURE: When the `send-chat-message` edge function is deployed, step 2
 * becomes the authoritative enforcement layer and step 3 is never reached.
 *
 * =============================================================================
 * SERVER-SIDE ENFORCEMENT — REQUIRED DATABASE OBJECTS
 * =============================================================================
 *
 * For true server-side enforcement that cannot be bypassed via API:
 *
 * OPTION A: PostgreSQL trigger on `messages` table (recommended)
 * ```sql
 * CREATE OR REPLACE FUNCTION enforce_contact_restriction()
 * RETURNS TRIGGER AS $$
 * DECLARE
 *   _match RECORD;
 *   _both_removed BOOLEAN;
 *   _content_lower TEXT;
 * BEGIN
 *   -- Get the match to find both user IDs
 *   SELECT * INTO _match FROM matches WHERE id = NEW.match_id;
 *   IF NOT FOUND THEN
 *     RAISE EXCEPTION 'Match not found';
 *   END IF;
 *
 *   -- Check if BOTH users have removed restriction
 *   SELECT COUNT(*) = 2 INTO _both_removed
 *   FROM contact_restriction_removals
 *   WHERE match_id = NEW.match_id
 *     AND user_id IN (_match.user1_id, _match.user2_id);
 *
 *   -- If both removed, allow anything
 *   IF _both_removed THEN
 *     RETURN NEW;
 *   END IF;
 *
 *   -- Otherwise, check content for restricted patterns
 *   _content_lower := lower(NEW.content);
 *
 *   -- Phone numbers (7+ digits)
 *   IF (SELECT array_length(regexp_matches(_content_lower, '\d[\d\s.\-()]{6,}\d', 'g'), 1)) > 0 THEN
 *     RAISE EXCEPTION 'Message blocked: contains phone number (contact restriction active)';
 *   END IF;
 *
 *   -- Email addresses
 *   IF _content_lower ~ '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}' THEN
 *     RAISE EXCEPTION 'Message blocked: contains email address (contact restriction active)';
 *   END IF;
 *
 *   -- URLs
 *   IF _content_lower ~ '(https?://|www\.)[^\s]+' THEN
 *     RAISE EXCEPTION 'Message blocked: contains URL (contact restriction active)';
 *   END IF;
 *
 *   -- Social handles (@username)
 *   IF _content_lower ~ '@[a-z0-9_]{3,}' THEN
 *     RAISE EXCEPTION 'Message blocked: contains social handle (contact restriction active)';
 *   END IF;
 *
 *   -- Social platform names with context
 *   IF _content_lower ~ '\m(instagram|snapchat|telegram|whatsapp|facebook|twitter|tiktok|signal|discord)\M' THEN
 *     RAISE EXCEPTION 'Message blocked: contains social platform reference (contact restriction active)';
 *   END IF;
 *
 *   RETURN NEW;
 * END;
 * $$ LANGUAGE plpgsql;
 *
 * CREATE TRIGGER trg_enforce_contact_restriction
 *   BEFORE INSERT OR UPDATE ON messages
 *   FOR EACH ROW
 *   EXECUTE FUNCTION enforce_contact_restriction();
 * ```
 *
 * OPTION B: Edge function `send-chat-message` (see edge function docs)
 *
 * =============================================================================
 */

import { supabase, invokeEdgeFunction } from './supabase';
import {
  fetchRestrictionState,
  checkMessageForRestrictedContent,
  getBlockedMessageText,
  type RestrictionState,
} from './contactRestriction';

// ─── Types ──────────────────────────────────────────────────────────────
export interface SendMessageResult {
  success: boolean;
  /** User-facing error message (e.g., "Message blocked: contains phone number") */
  error?: string;
  /** Technical error for logging */
  technicalError?: string;
  /** If blocked by restriction, the specific reasons */
  blockedReasons?: string[];
  /** Whether the message was blocked by contact restriction (vs. a DB/network error) */
  blockedByRestriction?: boolean;
  /**
   * The exact Postgres trigger error code extracted from the RAISE EXCEPTION message.
   * e.g., "CONTACT_RESTRICTION_BLOCKED_PHONE", "CONTACT_RESTRICTION_BLOCKED_EMAIL"
   * Only present when the DB trigger rejects the insert.
   */
  triggerErrorCode?: string;
  /**
   * The inserted message row returned from the DB after a successful insert.
   * Used by ChatModal to immediately confirm optimistic messages without
   * waiting for the realtime subscription.
   * May be null if the edge function path was used (edge fn doesn't return the row).
   */
  insertedMessage?: {
    id: string;
    match_id: string;
    sender_id: string;
    content: string;
    created_at: string;
    read_at: string | null;
  } | null;
}



export interface SendMessageParams {
  matchId: string;
  senderId: string;
  content: string;
  /** The other user's ID (needed for restriction check) */
  otherUserId: string;
  /** 
   * If true, skip restriction check (e.g., for system-generated messages that
   * don't contain user-typed content). Default: false.
   * 
   * IMPORTANT: Only set this for messages where the content is fully controlled
   * by the application (e.g., "I accepted the meeting at X"). Never for
   * user-typed content.
   */
  skipRestrictionCheck?: boolean;
  /**
   * Optional: pass cached restriction state to avoid redundant DB query.
   * If not provided, will fetch fresh from DB.
   */
  cachedRestrictionState?: RestrictionState;
}
// ─── Client-side Rate Limiting ──────────────────────────────────────────
// Lightweight in-memory sliding window to prevent rapid-fire sends.
// This is a first line of defense; the DB trigger / edge function is authoritative.

const MESSAGE_RATE_LIMIT_MAX = 15;       // max messages per window
const MESSAGE_RATE_LIMIT_WINDOW_MS = 60_000; // 60-second window
const _messageSendTimestamps: Map<string, number[]> = new Map(); // keyed by senderId

/**
 * Check if the user has exceeded the client-side message send rate limit.
 * Returns { allowed, retryAfterMs } — retryAfterMs is 0 if allowed.
 */
function checkClientRateLimit(senderId: string): { allowed: boolean; retryAfterMs: number } {
  const now = Date.now();
  const windowStart = now - MESSAGE_RATE_LIMIT_WINDOW_MS;

  let timestamps = _messageSendTimestamps.get(senderId) || [];
  // Prune entries outside the window
  timestamps = timestamps.filter(t => t > windowStart);

  if (timestamps.length >= MESSAGE_RATE_LIMIT_MAX) {
    const oldest = timestamps[0];
    const retryAfterMs = oldest + MESSAGE_RATE_LIMIT_WINDOW_MS - now;
    console.warn(`[MessageSender:RateLimit] User ${senderId} exceeded ${MESSAGE_RATE_LIMIT_MAX} msgs/${MESSAGE_RATE_LIMIT_WINDOW_MS / 1000}s — retry in ${Math.ceil(retryAfterMs / 1000)}s`);
    return { allowed: false, retryAfterMs: Math.max(retryAfterMs, 1000) };
  }

  timestamps.push(now);
  _messageSendTimestamps.set(senderId, timestamps);
  return { allowed: true, retryAfterMs: 0 };
}

// ─── Edge Function Availability Cache ───────────────────────────────────
// We cache whether the edge function exists to avoid repeated 404s.
// Reset on page reload (module-level variable).

let _edgeFunctionAvailable: boolean | null = null; // null = unknown, true/false = cached
let _edgeFunctionCheckTime = 0;
const EDGE_FN_CACHE_TTL_MS = 5 * 60 * 1000; // Re-check every 5 minutes

// ─── Trigger Error Code Extraction ──────────────────────────────────────

/**
 * Extract the CONTACT_RESTRICTION_BLOCKED_* error code from a Postgres
 * trigger RAISE EXCEPTION message.
 *
 * The deployed trigger uses error codes as message prefixes:
 *   RAISE EXCEPTION 'CONTACT_RESTRICTION_BLOCKED_PHONE: Message blocked: ...'
 *
 * Supabase/PostgREST surfaces the RAISE EXCEPTION text in `error.message`.
 * The Postgres error code is always P0001 (raise_exception), so the
 * application-level code is embedded in the message string itself.
 *
 * @param errorMessage - The raw error.message from Supabase
 * @returns The extracted code (e.g., "CONTACT_RESTRICTION_BLOCKED_PHONE") or null
 */
function extractTriggerErrorCode(errorMessage: string | undefined | null): string | null {
  if (!errorMessage) return null;

  // Pattern 0: Server-side message rate limit trigger
  if (errorMessage.includes('MESSAGE_RATE_LIMITED')) return 'MESSAGE_RATE_LIMITED';

  // Pattern 1: Code as prefix — "CONTACT_RESTRICTION_BLOCKED_PHONE: ..."
  const prefixMatch = errorMessage.match(/\b(CONTACT_RESTRICTION_BLOCKED_[A-Z_]+)\b/);
  if (prefixMatch) return prefixMatch[1];

  // Pattern 2: Fallback — any CONTACT_RESTRICTION_* code anywhere in the message
  const fallbackMatch = errorMessage.match(/\b(CONTACT_RESTRICTION_[A-Z_]+)\b/);
  if (fallbackMatch) return fallbackMatch[1];

  return null;
}


/**
 * Log a trigger block event prominently to the console for debugging.
 * This is intentionally verbose so false positives are easy to spot in DevTools.
 */
function logTriggerBlock(
  triggerCode: string | null,
  rawErrorMessage: string,
  messageContent: string,
  source: 'DB_TRIGGER' | 'EDGE_FUNCTION'
): void {
  const separator = '═'.repeat(72);
  const timestamp = new Date().toISOString();

  console.group(
    `%c[ContactRestriction] ${source} BLOCKED MESSAGE`,
    'color: #ff6b6b; font-weight: bold; font-size: 13px;'
  );
  console.log(`%c${separator}`, 'color: #ff6b6b;');
  console.log(`%cTimestamp:      %c${timestamp}`, 'color: #999;', 'color: #fff;');
  console.log(
    `%cTrigger Code:   %c${triggerCode ?? 'UNKNOWN (could not extract)'}`,
    'color: #999;',
    `color: ${triggerCode ? '#ffcc00' : '#ff6b6b'}; font-weight: bold;`
  );
  console.log(`%cSource:         %c${source}`, 'color: #999;', 'color: #66ccff;');
  console.log(`%cRaw Error:      %c${rawErrorMessage}`, 'color: #999;', 'color: #ff9966;');
  console.log(`%cBlocked Content:%c ${messageContent}`, 'color: #999;', 'color: #ccc;');
  console.log(`%c${separator}`, 'color: #ff6b6b;');
  console.groupEnd();
}

// ─── Main Send Function ─────────────────────────────────────────────────

/**
 * Send a chat message with full contact restriction enforcement.
 *
 * This is the ONLY function that should be used to send messages.
 * Direct `.from('messages').insert()` calls are prohibited.
 *
 * @returns SendMessageResult with success/failure and user-facing error
 */
export async function sendChatMessage(params: SendMessageParams): Promise<SendMessageResult> {
  const { matchId, senderId, content, otherUserId, skipRestrictionCheck, cachedRestrictionState } = params;

  // ── Step 0: Basic validation ──
  const trimmed = content.trim();
  if (!trimmed) {
    return { success: false, error: 'Message cannot be empty.' };
  }
  if (!matchId || !senderId) {
    return { success: false, error: 'Invalid message parameters.', technicalError: 'Missing matchId or senderId' };
  }

  // ── Step 0.5: Client-side rate limiting ──
  const rateCheck = checkClientRateLimit(senderId);
  if (!rateCheck.allowed) {
    const retrySec = Math.ceil(rateCheck.retryAfterMs / 1000);
    return {
      success: false,
      error: `You're sending messages too quickly. Please wait ${retrySec} second${retrySec > 1 ? 's' : ''}.`,
      technicalError: `CLIENT_RATE_LIMITED: ${MESSAGE_RATE_LIMIT_MAX} msgs/${MESSAGE_RATE_LIMIT_WINDOW_MS / 1000}s exceeded`,
    };
  }

  // ── Step 1: Client-side restriction enforcement ──
  if (!skipRestrictionCheck) {
    try {
      // Fetch FRESH restriction state (don't rely solely on cached state)
      const restrictionState = cachedRestrictionState ?? await fetchRestrictionState(matchId, senderId, otherUserId);

      if (!restrictionState.fullyUnlocked) {
        const filterResult = checkMessageForRestrictedContent(trimmed);
        if (filterResult.blocked) {
          console.warn('[MessageSender] Blocked by client-side restriction check:', filterResult.reasons);
          return {
            success: false,
            error: getBlockedMessageText(filterResult.reasons),
            blockedReasons: filterResult.reasons,
            blockedByRestriction: true,
          };
        }
      }
    } catch (err) {
      // If restriction check fails, err on the side of caution — still allow
      // the message but log the error. The server-side check (if available)
      // will catch anything we miss.
      console.error('[MessageSender] Restriction check failed, proceeding with send:', err);
    }
  }

  // ── Step 2: Try server-side validated send (edge function) ──
  const shouldTryEdgeFn = _edgeFunctionAvailable !== false ||
    (Date.now() - _edgeFunctionCheckTime > EDGE_FN_CACHE_TTL_MS);

  if (shouldTryEdgeFn) {
    try {
      const { data, error } = await invokeEdgeFunction<{ success: boolean; error?: string; code?: string }>(
        'send-chat-message',
        {
          match_id: matchId,
          content: trimmed,
          skip_restriction_check: skipRestrictionCheck ?? false,
        },
        undefined,
        { timeoutMs: 10_000 } // 10s timeout for message send
      );

      if (error) {
        const errMsg = error.message || '';
        const errCode = (error as any).code;

        // Edge function doesn't exist — cache this and fall through to direct insert
        if (errMsg.includes('404') || errMsg.includes('not found') || errMsg.includes('Not Found')) {
          console.info('[MessageSender] Edge function not deployed, falling back to direct insert');
          _edgeFunctionAvailable = false;
          _edgeFunctionCheckTime = Date.now();
          // Fall through to Step 3
        }
        // Server-side restriction block (edge function or trigger behind it)
        else if (errCode === 'CONTACT_RESTRICTED' || errMsg.includes('contact restriction') || errMsg.includes('CONTACT_RESTRICTION_BLOCKED')) {
          const triggerCode = extractTriggerErrorCode(errMsg) || extractTriggerErrorCode(data?.error) || extractTriggerErrorCode(data?.code);
          logTriggerBlock(triggerCode, errMsg, trimmed, 'EDGE_FUNCTION');

          return {
            success: false,
            error: data?.error || 'Message blocked: contains personal contact information while restriction is active.',
            blockedByRestriction: true,
            triggerErrorCode: triggerCode ?? undefined,
            technicalError: errMsg,
          };
        }
        // Other server error — fall through to direct insert
        else {
          console.warn('[MessageSender] Edge function error, falling back to direct insert:', errMsg);
          // Fall through to Step 3
        }
      } else if (data?.success) {
        // Edge function succeeded — message sent and validated server-side
        _edgeFunctionAvailable = true;
        _edgeFunctionCheckTime = Date.now();

        // Edge function doesn't return the inserted row, so fetch it for
        // immediate optimistic confirmation in the UI.
        let insertedMessage: SendMessageResult['insertedMessage'] = null;
        try {
          const { data: fetchedRow } = await supabase
            .from('messages')
            .select('*')
            .eq('match_id', matchId)
            .eq('sender_id', senderId)
            .order('created_at', { ascending: false })
            .limit(1)
            .single();
          if (fetchedRow && fetchedRow.content === trimmed) {
            insertedMessage = {
              id: fetchedRow.id,
              match_id: fetchedRow.match_id,
              sender_id: fetchedRow.sender_id,
              content: fetchedRow.content,
              created_at: fetchedRow.created_at,
              read_at: fetchedRow.read_at ?? null,
            };
          }
        } catch {
          // Non-critical: UI will fall back to timeout-based confirmation
          console.warn('[MessageSender] Could not fetch inserted row after edge fn success');
        }

        return { success: true, insertedMessage };

      } else if (data && !data.success) {
        // Edge function returned explicit failure — check for trigger code in response
        const triggerCode = extractTriggerErrorCode(data.error) || extractTriggerErrorCode(data.code);
        const isRestrictionBlock = !!(triggerCode || data.error?.includes('restriction') || data.error?.includes('CONTACT_RESTRICTION'));

        if (isRestrictionBlock) {
          logTriggerBlock(triggerCode, data.error || 'No error message', trimmed, 'EDGE_FUNCTION');
        }

        return {
          success: false,
          error: data.error || 'Message could not be sent.',
          blockedByRestriction: isRestrictionBlock,
          triggerErrorCode: triggerCode ?? undefined,
        };
      }
    } catch (edgeFnErr) {
      console.warn('[MessageSender] Edge function call failed, falling back to direct insert:', edgeFnErr);
      // Fall through to Step 3
    }
  }

  // ── Step 3: Fallback — client-validated direct insert ──
  // Client-side validation already passed in Step 1, so this is safe
  // (though not as secure as server-side validation).
  // Uses .select().single() to return the inserted row for immediate
  // optimistic message confirmation (no need to wait for realtime).
  try {
    const { data: insertedRow, error } = await supabase
      .from('messages')
      .insert({
        match_id: matchId,
        sender_id: senderId,
        content: trimmed,
      })
      .select()
      .single();

    if (error) {
      const rawMsg = error.message || '';
      const triggerCode = extractTriggerErrorCode(rawMsg);

      // Check if this is a DB trigger rejection (server-side enforcement)
      if (triggerCode || rawMsg.includes('contact restriction') || rawMsg.includes('blocked') || rawMsg.includes('CONTACT_RESTRICTION')) {
        logTriggerBlock(triggerCode, rawMsg, trimmed, 'DB_TRIGGER');

        return {
          success: false,
          error: 'Message blocked: contains personal contact information while restriction is active.',
          blockedByRestriction: true,
          technicalError: rawMsg,
          triggerErrorCode: triggerCode ?? undefined,
        };
      }

      console.error('[MessageSender] Direct insert failed:', {
        message: error.message,
        code: error.code,
        details: error.details,
        hint: error.hint,
      });
      return {
        success: false,
        error: 'Failed to send message. Please try again.',
        technicalError: `${error.code}: ${rawMsg} | details: ${error.details} | hint: ${error.hint}`,
      };
    }

    return {
      success: true,
      insertedMessage: insertedRow ? {
        id: insertedRow.id,
        match_id: insertedRow.match_id,
        sender_id: insertedRow.sender_id,
        content: insertedRow.content,
        created_at: insertedRow.created_at,
        read_at: insertedRow.read_at ?? null,
      } : null,
    };
  } catch (err: any) {
    const rawMsg = err?.message || 'Unknown error';
    const triggerCode = extractTriggerErrorCode(rawMsg);

    // Even in catch block, check for trigger rejection (some clients throw instead of returning error)
    if (triggerCode) {
      logTriggerBlock(triggerCode, rawMsg, trimmed, 'DB_TRIGGER');

      return {
        success: false,
        error: 'Message blocked: contains personal contact information while restriction is active.',
        blockedByRestriction: true,
        technicalError: rawMsg,
        triggerErrorCode: triggerCode,
      };
    }

    console.error('[MessageSender] Unexpected error:', err);
    return {
      success: false,
      error: 'Failed to send message. Please try again.',
      technicalError: rawMsg,
    };
  }
}


// ─── Convenience: Validate Without Sending ──────────────────────────────


/**
 * Check if a message would be blocked by contact restriction WITHOUT sending it.
 * Useful for real-time input validation (e.g., showing warnings as user types).
 *
 * @param text - The message text to validate
 * @param restrictionActive - Whether the restriction is currently active
 * @returns { blocked, reasons } if the message would be blocked
 */
export function validateMessageContent(
  text: string,
  restrictionActive: boolean
): { blocked: boolean; reasons: string[]; userMessage: string } {
  if (!restrictionActive) {
    return { blocked: false, reasons: [], userMessage: '' };
  }

  const trimmed = text.trim();
  if (!trimmed) {
    return { blocked: false, reasons: [], userMessage: '' };
  }

  const result = checkMessageForRestrictedContent(trimmed);
  return {
    blocked: result.blocked,
    reasons: result.reasons,
    userMessage: result.blocked ? getBlockedMessageText(result.reasons) : '',
  };
}

// ─── Paste Content Validator ────────────────────────────────────────────

/**
 * Validate pasted content against contact restriction.
 * Returns the cleaned text (original if allowed, empty if fully blocked).
 *
 * @param pastedText - The text being pasted
 * @param restrictionActive - Whether the restriction is currently active
 * @returns { allowed, text, reason } — if not allowed, text is empty
 */
export function validatePastedContent(
  pastedText: string,
  restrictionActive: boolean
): { allowed: boolean; text: string; reason: string } {
  if (!restrictionActive) {
    return { allowed: true, text: pastedText, reason: '' };
  }

  const result = checkMessageForRestrictedContent(pastedText);
  if (result.blocked) {
    return {
      allowed: false,
      text: '',
      reason: 'Pasted content blocked: appears to contain personal contact information. Both users must remove the chat restriction before sharing contact details.',
    };
  }

  return { allowed: true, text: pastedText, reason: '' };
}
