import React, { createContext, useContext, useCallback, ReactNode } from 'react';

/**
 * AISettingsContext — NO-OP PROVIDER
 * 
 * All user-facing AI controls have been removed. AI is internal-only
 * (support/admin/moderation). This provider exists solely to prevent
 * import errors from any remaining consumers. It performs ZERO database
 * reads/writes — no calls to user_ai_settings, no Supabase queries.
 * 
 * All settings are permanently OFF (false).
 */

export interface AISettings {
  messageModeration: boolean;
  scamPatternDetection: boolean;
  intentAlignmentInsight: boolean;
  sharedInterestHighlight: boolean;
}

export const defaultAISettings: AISettings = {
  messageModeration: false,
  scamPatternDetection: false,
  intentAlignmentInsight: false,
  sharedInterestHighlight: false,
};

interface AISettingsContextType {
  settings: AISettings;
  updateSetting: (key: keyof AISettings, value: boolean) => Promise<void>;
  updateSettings: (updates: Partial<AISettings>) => Promise<void>;
  loading: boolean;
  lastError: string | null;
  isFeatureEnabled: (key: keyof AISettings) => boolean;
}

const AISettingsContext = createContext<AISettingsContextType | undefined>(undefined);

export const AISettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // No-op: settings are always OFF, no DB interaction
  const updateSetting = useCallback(async (_key: keyof AISettings, _value: boolean) => {
    // No-op — AI settings are no longer user-configurable
  }, []);

  const updateSettings = useCallback(async (_updates: Partial<AISettings>) => {
    // No-op — AI settings are no longer user-configurable
  }, []);

  const isFeatureEnabled = useCallback((_key: keyof AISettings): boolean => {
    return false; // All AI features permanently OFF for end users
  }, []);

  return (
    <AISettingsContext.Provider value={{
      settings: defaultAISettings,
      updateSetting,
      updateSettings,
      loading: false,
      lastError: null,
      isFeatureEnabled,
    }}>
      {children}
    </AISettingsContext.Provider>
  );
};

export const useAISettings = () => {
  const context = useContext(AISettingsContext);
  if (context === undefined) {
    throw new Error('useAISettings must be used within an AISettingsProvider');
  }
  return context;
};
