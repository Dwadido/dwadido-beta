import React, { useState, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, getPublicPhotoUrl } from '@/lib/supabase';
import { compressImage } from '@/lib/imageCompressor';
import {
  Camera,
  Loader2,
  X,
  Lock,
  AlertCircle,
  Check,
  Shield,
  UserX,
  WifiOff,
  RotateCcw
} from 'lucide-react';

/**
 * =============================================================================
 * DWADIDO PHOTO MANAGER — PUBLIC BUCKET, DIRECT UPLOAD
 * =============================================================================
 *
 * Architecture (V2 — simplified):
 * - Upload: Supabase Storage SDK → profile-photos/{user.id}/primary.jpg
 * - Display: Public URL → ${SUPABASE_URL}/storage/v1/object/public/profile-photos/${path}?t=${updated_at}
 * - Profile: primary_photo_path (text) + primary_photo_updated_at (timestamptz)
 * - NO edge functions, NO signed URLs, NO user_photos table queries
 *
 * Product rules (non-negotiable):
 * - ONE real profile photo only
 * - Replace-only (no user delete button)
 * - Hidden by default: only visible to the user until match + mutual consent
 * - NO avatars, NO Photo Debug, NO multi-photo / gallery UI
 *
 * Loading rules:
 * - If no primary_photo_path on profile, show "Add Photo" immediately (no spinner)
 * - Only show loading state during actual upload
 * - Always clear loading in success + error + timeout (finally block)
 * =============================================================================
 */

interface PhotoManagerProps {
  onClose?: () => void;
}

interface UploadError {
  message: string;
  code?: string;
  canRetry: boolean;
}

const MAX_RAW_FILE_SIZE = 50 * 1024 * 1024; // 50MB sanity check

const PhotoManager: React.FC<PhotoManagerProps> = ({ onClose }) => {
  const { user, profile, updateProfile } = useAuth();

  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<string>('');
  const [error, setError] = useState<UploadError | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [lastFailedFile, setLastFailedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadLockRef = useRef(false);

  // ── Derive photo URL from profile (no fetch, no useEffect) ────────────
  const photoPath = profile?.primary_photo_path;
  const photoUpdatedAt = profile?.primary_photo_updated_at;
  const photoUrl = getPublicPhotoUrl(photoPath, photoUpdatedAt);
  const hasPhoto = !!photoUrl;

  // ── Upload (replace) ──────────────────────────────────────────────────
  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;
    await processUpload(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const processUpload = async (file: File) => {
    if (!user) return;
    if (uploadLockRef.current) return;

    setError(null);
    setLastFailedFile(null);

    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/jpg'];
    if (!validTypes.includes(file.type.toLowerCase())) {
      setError({ message: 'Please select a valid image (JPEG, PNG, WebP, or GIF)', code: 'INVALID_TYPE', canRetry: false });
      return;
    }

    if (file.size > MAX_RAW_FILE_SIZE) {
      setError({ message: `Image is too large (${(file.size / 1024 / 1024).toFixed(0)}MB). Please select a smaller photo.`, code: 'FILE_TOO_LARGE', canRetry: false });
      return;
    }

    uploadLockRef.current = true;
    setUploading(true);
    setUploadProgress('Compressing image...');

    try {
      // Step 1: Compress image client-side
      const compressed = await compressImage(file, (msg) => setUploadProgress(msg));

      setUploadProgress('Uploading photo...');

      const storagePath = `${user.id}/primary.jpg`;

      // Step 2: Try to remove old file first (ignore errors — file may not exist)
      try {
        await supabase.storage.from('profile-photos').remove([storagePath]);
      } catch {
        // Ignore — old file may not exist
      }

      // Step 3: Upload new file directly via Supabase Storage SDK
      const { error: uploadError } = await supabase.storage
        .from('profile-photos')
        .upload(storagePath, compressed.file, {
          contentType: 'image/jpeg',
          cacheControl: '3600',
          upsert: true,
        });

      if (uploadError) {
        console.error('[PhotoManager] Storage upload error:', uploadError);
        throw new Error(uploadError.message || 'Storage upload failed');
      }

      // Step 4: Update profile with the new photo path
      setUploadProgress('Saving to profile...');
      const now = new Date().toISOString();
      const { error: profileError } = await updateProfile({
        primary_photo_path: storagePath,
        primary_photo_updated_at: now,
      } as any);

      if (profileError) {
        console.error('[PhotoManager] Profile update error:', profileError);
        throw new Error(profileError.message || 'Failed to save photo to profile');
      }

      // Success — profile state is updated by updateProfile, photoUrl will re-derive
      setSuccess('Photo uploaded successfully!');
      setTimeout(() => setSuccess(null), 3000);

    } catch (err: any) {
      console.error('[PhotoManager] Upload error:', err);
      setLastFailedFile(file);

      let errorMessage = err.message || 'Failed to upload photo.';
      let canRetry = true;
      let code = 'UNKNOWN';

      if (err.message?.includes('Payload too large') || err.message?.includes('413')) {
        errorMessage = 'Photo is still too large after compression. Please try a smaller image.';
        code = 'PAYLOAD_TOO_LARGE';
        canRetry = false;
      } else if (err.message?.includes('overloaded') || err.message?.includes('503')) {
        errorMessage = 'Server is busy. Please wait a few seconds and try again.';
        code = 'SERVER_BUSY';
      } else if (err.message?.includes('network') || err.message?.includes('fetch') || err.message?.includes('Load failed')) {
        errorMessage = 'Cannot reach the server. Please check your connection.';
        code = 'NETWORK_ERROR';
      } else if (err.message?.includes('auth') || err.message?.includes('session') || err.message?.includes('sign in')) {
        errorMessage = 'Session expired. Please refresh the page and sign in again.';
        code = 'AUTH_ERROR';
        canRetry = false;
      } else if (err.message?.includes('timed out') || err.message?.includes('timeout')) {
        errorMessage = 'Upload timed out. Please try again.';
        code = 'TIMEOUT';
      } else if (err.message?.includes('not allowed') || err.message?.includes('security') || err.message?.includes('policy')) {
        errorMessage = 'Upload not permitted. Please sign in again.';
        code = 'POLICY_ERROR';
        canRetry = false;
      }

      setError({ message: errorMessage, code, canRetry });
    } finally {
      uploadLockRef.current = false;
      setUploading(false);
      setUploadProgress('');
    }
  };

  const handleRetry = async () => {
    if (lastFailedFile) await processUpload(lastFailedFile);
  };

  if (!user) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <Camera className="w-5 h-5 text-[#C9A24D]" />
            Profile Photo
          </h3>
          <p className="text-sm text-gray-400 mt-1">
            One real photo required — replace anytime
          </p>
        </div>
        <div className="flex items-center gap-2">
          {onClose && (
            <button onClick={onClose} className="p-2 text-gray-400 hover:text-white hover:bg-[#2a2a2a] rounded-full transition-all">
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Photo Requirement Notice — only when no photo */}
      {!hasPhoto && !uploading && (
        <div className="p-4 bg-[#C9A24D]/10 border border-[#C9A24D]/30 rounded-xl">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-[#C9A24D] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-[#C9A24D] font-medium">Photo Required</p>
              <p className="text-sm text-gray-300 mt-1">
                Dwadido requires 1 real photo for trust and verification. Your photo is hidden until you choose to reveal it to a match.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Real Photo Guidelines */}
      <div className="p-4 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl">
        <div className="flex items-start gap-3">
          <UserX className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-white font-medium text-sm">Real Photos Only</p>
            <p className="text-xs text-gray-400 mt-1">
              Avatars, cartoons, AI-generated images, and photos where you can't be identified are not allowed. Your face should be clearly visible.
            </p>
          </div>
        </div>
      </div>

      {/* Error Messages */}
      {error && (
        <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl">
          <div className="flex items-start gap-3">
            {error.code === 'NETWORK_ERROR' ? (
              <WifiOff className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            )}
            <div className="flex-1">
              <p className="text-red-400 font-medium text-sm">
                {error.code === 'SERVER_BUSY' ? 'Server Busy' : error.code === 'NETWORK_ERROR' ? 'Connection Error' : 'Upload Failed'}
              </p>
              <p className="text-sm text-red-300 mt-1">{error.message}</p>
              {error.canRetry && lastFailedFile && (
                <button
                  onClick={handleRetry}
                  disabled={uploading}
                  className="mt-3 flex items-center gap-2 px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-300 rounded-lg text-sm transition-colors"
                >
                  <RotateCcw className="w-4 h-4" />
                  Try Again
                </button>
              )}
            </div>
            <button onClick={() => { setError(null); setLastFailedFile(null); }} className="p-1 hover:bg-red-500/20 rounded">
              <X className="w-4 h-4 text-red-400" />
            </button>
          </div>
        </div>
      )}

      {/* Success Messages */}
      {success && (
        <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-xl flex items-center gap-2">
          <Check className="w-4 h-4 text-green-400" />
          <span className="text-green-400 text-sm">{success}</span>
        </div>
      )}

      {/* Upload Progress */}
      {uploading && uploadProgress && (
        <div className="p-3 bg-[#C9A24D]/10 border border-[#C9A24D]/30 rounded-xl flex items-center gap-3">
          <Loader2 className="w-5 h-5 text-[#C9A24D] animate-spin" />
          <span className="text-[#C9A24D] text-sm">{uploadProgress}</span>
        </div>
      )}

      {/* Single Photo Display */}
      <div className="flex flex-col items-center gap-4">
        {hasPhoto ? (
          <div className="relative group">
            <img
              src={photoUrl!}
              alt="Your profile photo"
              className="w-48 h-48 object-cover rounded-2xl bg-[#1a1a1a] ring-2 ring-[#C9A24D]/30"
            />
            {/* Replace overlay */}
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl flex items-center justify-center">
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="px-4 py-2 bg-[#C9A24D] text-[#141414] rounded-xl font-medium hover:bg-[#d4af5a] transition-colors disabled:opacity-50"
              >
                Replace Photo
              </button>
            </div>
          </div>
        ) : (
          /* No photo — show "Add Photo" button immediately (no spinner) */
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="w-48 h-48 border-2 border-dashed bg-[#C9A24D]/10 border-[#C9A24D]/50 hover:border-[#C9A24D] hover:bg-[#C9A24D]/20 rounded-2xl flex flex-col items-center justify-center gap-3 transition-all disabled:opacity-50"
          >
            {uploading ? (
              <Loader2 className="w-8 h-8 text-[#C9A24D] animate-spin" />
            ) : (
              <>
                <Camera className="w-8 h-8 text-[#C9A24D]" />
                <span className="text-sm text-[#C9A24D] font-medium">Add Photo (Required)</span>
              </>
            )}
          </button>
        )}

        {/* Replace button below photo (mobile-friendly) */}
        {hasPhoto && (
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="px-6 py-2.5 bg-[#1a1a1a] border border-[#2a2a2a] text-gray-300 hover:text-white hover:border-[#C9A24D]/50 rounded-xl text-sm font-medium transition-all disabled:opacity-50"
          >
            {uploading ? 'Uploading...' : 'Replace Photo'}
          </button>
        )}
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/gif,image/heic,image/heif"
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* Trust-First Privacy Notice */}
      <div className="bg-[#1a1a1a] rounded-xl p-4 border border-[#2a2a2a]">
        <div className="flex items-start gap-3">
          <Shield className="w-5 h-5 text-[#C9A24D] flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-white font-medium text-sm">Privacy-First Photo</p>
            <ul className="text-xs text-gray-400 mt-2 space-y-1">
              <li className="flex items-center gap-2">
                <Lock className="w-3 h-3 text-[#C9A24D]" />
                Hidden by default — only you can see it
              </li>
              <li className="flex items-center gap-2">
                <Lock className="w-3 h-3 text-[#C9A24D]" />
                Revealed only when both you and a match opt in
              </li>
              <li className="flex items-center gap-2">
                <Lock className="w-3 h-3 text-[#C9A24D]" />
                No public browsing or swiping on photos
              </li>
              <li className="flex items-center gap-2">
                <Lock className="w-3 h-3 text-[#C9A24D]" />
                Large photos are automatically compressed
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PhotoManager;
