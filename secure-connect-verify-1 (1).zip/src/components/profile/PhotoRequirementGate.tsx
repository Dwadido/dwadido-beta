import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Camera, Shield, Heart, AlertCircle, ArrowRight, Check } from 'lucide-react';

interface PhotoRequirementGateProps {
  children: React.ReactNode;
  onOpenPhotoManager?: () => void;
}

/**
 * PhotoRequirementGate
 * 
 * Blocks access to matches/connections until user has at least one real photo.
 * 
 * ==========================================================================
 * BUG FIX (2026-02-17):
 * Previously queried the `user_photos` table, but the PhotoManager upload
 * flow stores photos in Supabase Storage and records the path in the
 * `profiles.primary_photo_path` column — NOT in `user_photos`.
 * The `user_photos` table was never populated, so the gate always returned
 * "no photos" and blocked access even when a valid photo existed.
 *
 * FIX: Check `profile.primary_photo_path` (and `avatar_url` as fallback)
 * directly from the AuthContext profile object. No separate DB query needed.
 * When the user uploads via PhotoManager → updateProfile() updates the
 * AuthContext profile state → this component re-renders and sees the photo.
 * ==========================================================================
 * 
 * V1 Design Philosophy:
 * - Photos are for TRUST and VERIFICATION only
 * - NOT for appearance scoring or attractiveness metrics
 * - Real photos required - no avatars, no cartoons, no AI-generated images
 * - Clear, calm messaging that explains the "why"
 */
const PhotoRequirementGate: React.FC<PhotoRequirementGateProps> = ({ 
  children, 
  onOpenPhotoManager 
}) => {
  const { user, profile, loading } = useAuth();

  // ── Derive "has photo" from the profile object (already in memory) ──
  // Primary check: primary_photo_path (set by PhotoManager upload flow)
  // Fallback check: avatar_url (legacy field, may be set from older flows)
  const hasPhoto = !!(
    profile?.primary_photo_path ||
    profile?.avatar_url
  );

  // Loading state — only while AuthContext is still initializing
  if (loading || !user) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-8 h-8 border-2 border-[#C9A24D] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // User has photos - show children
  if (hasPhoto) {
    return <>{children}</>;
  }

  // No photos - show requirement gate
  return (
    <div className="bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a] overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#C9A24D]/20 to-[#C9A24D]/5 px-6 py-8 text-center border-b border-[#2a2a2a]">
        <div className="w-16 h-16 mx-auto mb-4 bg-[#C9A24D]/20 rounded-full flex items-center justify-center">
          <Camera className="w-8 h-8 text-[#C9A24D]" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">
          Add a Photo to Connect
        </h2>
        <p className="text-gray-400 max-w-md mx-auto">
          Dwadido requires at least one real photo before you can view or connect with matches.
        </p>
      </div>

      {/* Why Photos Matter */}
      <div className="p-6 space-y-6">
        <div className="bg-[#141414] rounded-xl p-5 border border-[#2a2a2a]">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Shield className="w-5 h-5 text-[#C9A24D]" />
            Why We Require Photos
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-[#C9A24D]/20 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                <Check className="w-4 h-4 text-[#C9A24D]" />
              </div>
              <div>
                <p className="text-white font-medium">Trust & Verification</p>
                <p className="text-sm text-gray-400">
                  Photos help verify you're a real person and build trust with potential connections.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-[#C9A24D]/20 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                <Check className="w-4 h-4 text-[#C9A24D]" />
              </div>
              <div>
                <p className="text-white font-medium">Mutual Recognition</p>
                <p className="text-sm text-gray-400">
                  When you meet in person, you'll both know who you're looking for.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-[#C9A24D]/20 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                <Check className="w-4 h-4 text-[#C9A24D]" />
              </div>
              <div>
                <p className="text-white font-medium">Safety First</p>
                <p className="text-sm text-gray-400">
                  Real photos create accountability and a safer environment for everyone.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* What We Don't Do */}
        <div className="bg-[#C9A24D]/5 rounded-xl p-5 border border-[#C9A24D]/20">
          <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
            <Heart className="w-5 h-5 text-[#C9A24D]" />
            What We Don't Do
          </h3>
          <ul className="space-y-2 text-sm text-gray-300">
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-[#C9A24D] rounded-full" />
              No appearance scoring or attractiveness ratings
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-[#C9A24D] rounded-full" />
              No public browsing or swiping on photos
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-[#C9A24D] rounded-full" />
              No AI analysis of your appearance
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-[#C9A24D] rounded-full" />
              No ranking based on looks
            </li>
          </ul>
        </div>

        {/* Photo Requirements */}
        <div className="bg-[#141414] rounded-xl p-5 border border-[#2a2a2a]">
          <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-[#C9A24D]" />
            Photo Requirements
          </h3>
          <ul className="space-y-2 text-sm text-gray-300">
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-400" />
              Must be a real photo of you
            </li>
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-400" />
              Your face should be clearly visible
            </li>
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-400" />
              Recent photo (within the last year)
            </li>
          </ul>
          <div className="mt-4 pt-4 border-t border-[#2a2a2a]">
            <p className="text-sm text-gray-400">
              <span className="text-red-400 font-medium">Not allowed:</span> Avatars, cartoons, AI-generated images, group photos where you can't be identified, or photos of objects/pets only.
            </p>
          </div>
        </div>

        {/* CTA Button */}
        <button
          onClick={onOpenPhotoManager}
          className="w-full py-4 bg-[#C9A24D] hover:bg-[#d4af5a] text-[#141414] font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shadow-[0_4px_20px_rgba(201,162,77,0.3)]"
        >
          <Camera className="w-5 h-5" />
          Add Your Photo
          <ArrowRight className="w-5 h-5" />
        </button>

        <p className="text-center text-xs text-gray-500">
          Your photos are protected by our privacy settings. You control who sees them.
        </p>
      </div>
    </div>
  );
};

export default PhotoRequirementGate;
