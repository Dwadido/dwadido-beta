import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { usePremium } from '@/contexts/PremiumContext';
import { 
  ChevronDown, 
  ChevronUp, 
  BarChart3, 
  CreditCard, 
  CheckCircle, 
  Users, 
  Clock,
  Loader2,
  Info,
  Shield,
  Share2,
  Mail,
  Link2,
  MessageSquare,
  Eye,
  Crown,
  Lock
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface UserAnalytics {
  total_codes_generated: number;
  total_codes_redeemed: number;
  active_connections: number;
  total_redemption_time_hours: number;
  last_code_generated_at: string | null;
  last_code_redeemed_at: string | null;
  total_shares?: number;
  lifetime_codes_created?: number;
}

interface ShareBreakdown {
  twitter: number;
  facebook: number;
  whatsapp: number;
  email: number;
  sms: number;
  link_copies: number;
  time_limited: number;
  total: number;
}

interface OGPreviewStats {
  total_views: number;
  by_platform: {
    facebook: number;
    twitter: number;
    linkedin: number;
    whatsapp: number;
    slack: number;
    discord: number;
    other: number;
  };
}

const CrushCodeAnalytics: React.FC = () => {
  const { user } = useAuth();
  const { isPremium } = usePremium();
  const navigate = useNavigate();
  const [isExpanded, setIsExpanded] = useState(true); // Default expanded for premium
  const [analytics, setAnalytics] = useState<UserAnalytics | null>(null);
  const [shareBreakdown, setShareBreakdown] = useState<ShareBreakdown>({
    twitter: 0,
    facebook: 0,
    whatsapp: 0,
    email: 0,
    sms: 0,
    link_copies: 0,
    time_limited: 0,
    total: 0
  });
  const [ogPreviewStats, setOgPreviewStats] = useState<OGPreviewStats>({
    total_views: 0,
    by_platform: {
      facebook: 0,
      twitter: 0,
      linkedin: 0,
      whatsapp: 0,
      slack: 0,
      discord: 0,
      other: 0
    }
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Gate analytics for premium users only
  if (!isPremium) {
    return (
      <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
        <div className="px-6 py-8 text-center">
          <div className="w-14 h-14 bg-gold/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <BarChart3 className="w-7 h-7 text-gold" />
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">Code Analytics Dashboard</h3>
          <p className="text-gray-400 text-sm mb-4">
            Track scans, shares, timestamps, and conversion rates for all your codes.
          </p>
          <div className="flex items-center justify-center gap-2 text-gold text-sm mb-4">
            <Lock className="w-4 h-4" />
            <span>Premium Feature</span>
          </div>
          <button
            onClick={() => navigate('/premium')}
            className="px-6 py-2.5 bg-gradient-to-r from-gold to-gold-400 text-charcoal font-semibold rounded-xl hover:from-gold-400 hover:to-gold transition-all flex items-center gap-2 mx-auto"
          >
            <Crown className="w-4 h-4" />
            Upgrade to Premium
          </button>
        </div>
      </div>
    );
  }

  const fetchAnalytics = async () => {
    if (!user) return;
    
    setLoading(true);
    setError(null);
    
    try {
      // Fetch user analytics
      const { data, error: fetchError } = await supabase
        .from('user_analytics')
        .select('*')
        .eq('user_id', user.id)
        .single();
      
      if (fetchError && fetchError.code !== 'PGRST116') {
        throw fetchError;
      }
      
      setAnalytics(data || {
        total_codes_generated: 0,
        total_codes_redeemed: 0,
        active_connections: 0,
        total_redemption_time_hours: 0,
        last_code_generated_at: null,
        last_code_redeemed_at: null,
        total_shares: 0,
        lifetime_codes_created: 0
      });

      // Fetch share breakdown from crush_cards
      const { data: cardsData, error: cardsError } = await supabase
        .from('crush_cards')
        .select('id, twitter_shares, facebook_shares, whatsapp_shares, email_shares, sms_shares, link_copies, time_limited_shares, total_shares, og_preview_views')
        .eq('creator_id', user.id);

      if (!cardsError && cardsData) {
        const breakdown = cardsData.reduce((acc, card) => ({
          twitter: acc.twitter + (card.twitter_shares || 0),
          facebook: acc.facebook + (card.facebook_shares || 0),
          whatsapp: acc.whatsapp + (card.whatsapp_shares || 0),
          email: acc.email + (card.email_shares || 0),
          sms: acc.sms + (card.sms_shares || 0),
          link_copies: acc.link_copies + (card.link_copies || 0),
          time_limited: acc.time_limited + (card.time_limited_shares || 0),
          total: acc.total + (card.total_shares || 0)
        }), { twitter: 0, facebook: 0, whatsapp: 0, email: 0, sms: 0, link_copies: 0, time_limited: 0, total: 0 });
        
        setShareBreakdown(breakdown);

        // Fetch OG preview analytics
        const codeIds = cardsData.map(c => c.id);
        if (codeIds.length > 0) {
          const { data: ogData, error: ogError } = await supabase
            .from('og_preview_analytics')
            .select('platform')
            .in('code_id', codeIds);

          if (!ogError && ogData) {
            const platformCounts = ogData.reduce((acc, row) => {
              const platform = row.platform || 'other';
              acc[platform] = (acc[platform] || 0) + 1;
              return acc;
            }, {} as Record<string, number>);

            setOgPreviewStats({
              total_views: ogData.length,
              by_platform: {
                facebook: platformCounts.facebook || 0,
                twitter: platformCounts.twitter || 0,
                linkedin: platformCounts.linkedin || 0,
                whatsapp: platformCounts.whatsapp || 0,
                slack: platformCounts.slack || 0,
                discord: platformCounts.discord || 0,
                other: (platformCounts.other || 0) + 
                       (platformCounts.google || 0) + 
                       (platformCounts.bing || 0) +
                       (platformCounts.apple || 0)
              }
            });
          }
        }
      }
    } catch (err) {
      console.error('Error fetching analytics:', err);
      setError('Unable to load analytics');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isExpanded && !analytics && !loading) {
      fetchAnalytics();
    }
  }, [isExpanded, user]);

  const averageRedemptionTime = analytics && analytics.total_codes_redeemed > 0
    ? analytics.total_redemption_time_hours / analytics.total_codes_redeemed
    : 0;

  const formatTime = (hours: number): string => {
    if (hours < 1) {
      const minutes = Math.round(hours * 60);
      return `${minutes} min${minutes !== 1 ? 's' : ''}`;
    } else if (hours < 24) {
      const roundedHours = Math.round(hours * 10) / 10;
      return `${roundedHours} hr${roundedHours !== 1 ? 's' : ''}`;
    } else {
      const days = Math.round(hours / 24 * 10) / 10;
      return `${days} day${days !== 1 ? 's' : ''}`;
    }
  };

  const redemptionRate = analytics && analytics.total_codes_generated > 0
    ? Math.round((analytics.total_codes_redeemed / analytics.total_codes_generated) * 100)
    : 0;

  const shareConversionRate = shareBreakdown.total > 0 && analytics
    ? Math.round((analytics.total_codes_redeemed / shareBreakdown.total) * 100)
    : 0;

  const getBestPlatform = () => {
    const platforms = [
      { name: 'X / Twitter', count: shareBreakdown.twitter, color: 'text-white' },
      { name: 'Facebook', count: shareBreakdown.facebook, color: 'text-[#1877F2]' },
      { name: 'WhatsApp', count: shareBreakdown.whatsapp, color: 'text-[#25D366]' },
      { name: 'Email', count: shareBreakdown.email, color: 'text-[#EA4335]' },
      { name: 'SMS', count: shareBreakdown.sms, color: 'text-[#34C759]' },
      { name: 'Link Copy', count: shareBreakdown.link_copies, color: 'text-gold' },
      { name: 'Time-Limited', count: shareBreakdown.time_limited, color: 'text-purple-400' },
    ];
    
    return platforms.reduce((best, current) => 
      current.count > best.count ? current : best
    , platforms[0]);
  };

  return (
    <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
      {/* Header */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full px-6 py-4 flex items-center justify-between hover:bg-charcoal-600/50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-gold" />
          </div>
          <div className="text-left">
            <h3 className="font-semibold text-white flex items-center gap-2">
              Code Analytics
              <Crown className="w-4 h-4 text-gold" />
            </h3>
            <p className="text-sm text-gray-400">Your activity summary</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {analytics && (
            <span className="text-sm text-gray-400 hidden sm:block">
              {analytics.lifetime_codes_created || analytics.total_codes_generated} codes created
            </span>
          )}
          {isExpanded ? (
            <ChevronUp className="w-5 h-5 text-gray-400" />
          ) : (
            <ChevronDown className="w-5 h-5 text-gray-400" />
          )}
        </div>
      </button>

      {/* Expanded Content */}
      {isExpanded && (
        <div className="px-6 pb-6 border-t border-charcoal-600">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 text-gold animate-spin" />
            </div>
          ) : error ? (
            <div className="py-6 text-center">
              <p className="text-red-400 text-sm">{error}</p>
              <button
                onClick={fetchAnalytics}
                className="mt-2 text-gold text-sm hover:underline"
              >
                Try again
              </button>
            </div>
          ) : analytics ? (
            <>
              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div className="bg-charcoal-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <CreditCard className="w-4 h-4 text-gold" />
                    <span className="text-xs text-gray-400 uppercase tracking-wide">Generated</span>
                  </div>
                  <p className="text-2xl font-bold text-white">{analytics.lifetime_codes_created || analytics.total_codes_generated}</p>
                  <p className="text-xs text-gray-500 mt-1">Total codes created</p>
                </div>

                <div className="bg-charcoal-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span className="text-xs text-gray-400 uppercase tracking-wide">Redeemed</span>
                  </div>
                  <p className="text-2xl font-bold text-white">{analytics.total_codes_redeemed}</p>
                  <p className="text-xs text-gray-500 mt-1">Codes accepted</p>
                </div>

                <div className="bg-charcoal-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="w-4 h-4 text-blue-400" />
                    <span className="text-xs text-gray-400 uppercase tracking-wide">Connections</span>
                  </div>
                  <p className="text-2xl font-bold text-white">{analytics.active_connections}</p>
                  <p className="text-xs text-gray-500 mt-1">Active connections</p>
                </div>

                <div className="bg-charcoal-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Share2 className="w-4 h-4 text-pink-400" />
                    <span className="text-xs text-gray-400 uppercase tracking-wide">Shares</span>
                  </div>
                  <p className="text-2xl font-bold text-white">{shareBreakdown.total}</p>
                  <p className="text-xs text-gray-500 mt-1">Total code shares</p>
                </div>
              </div>

              {/* OG Preview Stats */}
              {ogPreviewStats.total_views > 0 && (
                <div className="mt-4 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-xl p-4 border border-blue-500/20">
                  <div className="flex items-center gap-2 mb-3">
                    <Eye className="w-4 h-4 text-blue-400" />
                    <span className="text-sm font-medium text-white">Social Media Link Previews</span>
                    <span className="text-xs text-gray-400 ml-auto">{ogPreviewStats.total_views} total views</span>
                  </div>
                  <p className="text-xs text-gray-400 mb-3">
                    When you share your code link on social media, platforms fetch a preview:
                  </p>
                  <div className="grid grid-cols-4 gap-2">
                    {ogPreviewStats.by_platform.facebook > 0 && (
                      <div className="text-center p-2 bg-charcoal-800 rounded-lg">
                        <svg className="w-4 h-4 mx-auto text-[#1877F2] mb-1" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                        </svg>
                        <p className="text-sm font-semibold text-white">{ogPreviewStats.by_platform.facebook}</p>
                        <p className="text-[10px] text-gray-500">Facebook</p>
                      </div>
                    )}
                    {ogPreviewStats.by_platform.twitter > 0 && (
                      <div className="text-center p-2 bg-charcoal-800 rounded-lg">
                        <svg className="w-4 h-4 mx-auto text-gray-400 mb-1" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                        </svg>
                        <p className="text-sm font-semibold text-white">{ogPreviewStats.by_platform.twitter}</p>
                        <p className="text-[10px] text-gray-500">X</p>
                      </div>
                    )}
                    {ogPreviewStats.by_platform.whatsapp > 0 && (
                      <div className="text-center p-2 bg-charcoal-800 rounded-lg">
                        <svg className="w-4 h-4 mx-auto text-[#25D366] mb-1" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                        </svg>
                        <p className="text-sm font-semibold text-white">{ogPreviewStats.by_platform.whatsapp}</p>
                        <p className="text-[10px] text-gray-500">WhatsApp</p>
                      </div>
                    )}
                    {ogPreviewStats.by_platform.other > 0 && (
                      <div className="text-center p-2 bg-charcoal-800 rounded-lg">
                        <Eye className="w-4 h-4 mx-auto text-gray-400 mb-1" />
                        <p className="text-sm font-semibold text-white">{ogPreviewStats.by_platform.other}</p>
                        <p className="text-[10px] text-gray-500">Other</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Share Breakdown */}
              {shareBreakdown.total > 0 && (
                <div className="mt-4 bg-charcoal-800 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium text-white">Share Breakdown</span>
                    <span className="text-xs text-gray-400">{shareBreakdown.total} total</span>
                  </div>
                  
                  <div className="grid grid-cols-7 gap-1.5">
                    <div className="text-center p-2 bg-charcoal-700 rounded-lg">
                      <svg className="w-4 h-4 mx-auto text-gray-400 mb-1" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                      </svg>
                      <p className="text-sm font-semibold text-white">{shareBreakdown.twitter}</p>
                      <p className="text-[10px] text-gray-500">X</p>
                    </div>
                    <div className="text-center p-2 bg-charcoal-700 rounded-lg">
                      <svg className="w-4 h-4 mx-auto text-[#1877F2] mb-1" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                      </svg>
                      <p className="text-sm font-semibold text-white">{shareBreakdown.facebook}</p>
                      <p className="text-[10px] text-gray-500">FB</p>
                    </div>
                    <div className="text-center p-2 bg-charcoal-700 rounded-lg">
                      <svg className="w-4 h-4 mx-auto text-[#25D366] mb-1" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                      </svg>
                      <p className="text-sm font-semibold text-white">{shareBreakdown.whatsapp}</p>
                      <p className="text-[10px] text-gray-500">WA</p>
                    </div>
                    <div className="text-center p-2 bg-charcoal-700 rounded-lg">
                      <MessageSquare className="w-4 h-4 mx-auto text-[#34C759] mb-1" />
                      <p className="text-sm font-semibold text-white">{shareBreakdown.sms}</p>
                      <p className="text-[10px] text-gray-500">SMS</p>
                    </div>
                    <div className="text-center p-2 bg-charcoal-700 rounded-lg">
                      <Mail className="w-4 h-4 mx-auto text-[#EA4335] mb-1" />
                      <p className="text-sm font-semibold text-white">{shareBreakdown.email}</p>
                      <p className="text-[10px] text-gray-500">Email</p>
                    </div>
                    <div className="text-center p-2 bg-charcoal-700 rounded-lg">
                      <Link2 className="w-4 h-4 mx-auto text-gold mb-1" />
                      <p className="text-sm font-semibold text-white">{shareBreakdown.link_copies}</p>
                      <p className="text-[10px] text-gray-500">Link</p>
                    </div>
                    <div className="text-center p-2 bg-charcoal-700 rounded-lg">
                      <Clock className="w-4 h-4 mx-auto text-purple-400 mb-1" />
                      <p className="text-sm font-semibold text-white">{shareBreakdown.time_limited}</p>
                      <p className="text-[10px] text-gray-500">Timed</p>
                    </div>
                  </div>

                  {shareBreakdown.total > 0 && (
                    <div className="mt-3 pt-3 border-t border-charcoal-600">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Top Platform</span>
                        <span className={`font-semibold ${getBestPlatform().color}`}>
                          {getBestPlatform().name} ({getBestPlatform().count})
                        </span>
                      </div>
                    </div>
                  )}
                  
                  {shareConversionRate > 0 && (
                    <div className="mt-3 pt-3 border-t border-charcoal-600">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400">Share Conversion Rate</span>
                        <span className="text-gold font-semibold">{shareConversionRate}%</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        {analytics.total_codes_redeemed} redemptions from {shareBreakdown.total} shares
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* Redemption Rate */}
              {analytics.total_codes_generated > 0 && (
                <div className="mt-4 bg-charcoal-800 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-400">Redemption Rate</span>
                    <span className="text-sm font-semibold text-white">{redemptionRate}%</span>
                  </div>
                  <div className="w-full h-2 bg-charcoal-600 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-gold to-gold-400 rounded-full transition-all duration-500"
                      style={{ width: `${redemptionRate}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    {analytics.total_codes_redeemed} of {analytics.total_codes_generated} codes were accepted
                  </p>
                </div>
              )}

              {/* Average Redemption Time */}
              {analytics.total_codes_redeemed > 0 && (
                <div className="mt-4 bg-charcoal-800 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-4 h-4 text-purple-400" />
                    <span className="text-sm text-gray-400">Average Time to Redemption</span>
                  </div>
                  <p className="text-2xl font-bold text-white">
                    {formatTime(averageRedemptionTime)}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    How long it takes for your codes to be redeemed on average
                  </p>
                </div>
              )}

              {/* Privacy Notice */}
              <div className="mt-4 flex items-start gap-3 p-3 bg-charcoal-800/50 rounded-xl">
                <Shield className="w-4 h-4 text-gold mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-xs text-gray-400">
                    <span className="text-gold font-medium">Privacy First:</span> These analytics only show aggregate counts. 
                    We never reveal who redeemed your codes or any identifying information.
                  </p>
                </div>
              </div>

              {/* Last Activity */}
              {(analytics.last_code_generated_at || analytics.last_code_redeemed_at) && (
                <div className="mt-4 pt-4 border-t border-charcoal-600">
                  <p className="text-xs text-gray-500 uppercase tracking-wide mb-2">Recent Activity</p>
                  <div className="space-y-1">
                    {analytics.last_code_generated_at && (
                      <p className="text-xs text-gray-400">
                        Last code generated: {new Date(analytics.last_code_generated_at).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                          hour: 'numeric',
                          minute: '2-digit'
                        })}
                      </p>
                    )}
                    {analytics.last_code_redeemed_at && (
                      <p className="text-xs text-gray-400">
                        Last code redeemed: {new Date(analytics.last_code_redeemed_at).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                          hour: 'numeric',
                          minute: '2-digit'
                        })}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Empty State */}
              {analytics.total_codes_generated === 0 && (
                <div className="mt-4 text-center py-6 bg-charcoal-800/50 rounded-xl">
                  <Info className="w-8 h-8 text-gray-500 mx-auto mb-2" />
                  <p className="text-gray-400 text-sm">No activity yet</p>
                  <p className="text-gray-500 text-xs mt-1">Generate your first Crush Code to start tracking</p>
                </div>
              )}
            </>
          ) : null}
        </div>
      )}
    </div>
  );
};

export default CrushCodeAnalytics;
