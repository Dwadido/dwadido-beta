/**
 * Image Compressor
 * 
 * Aggressively compresses images on the client side before upload.
 * This is necessary because the platform gateway (Fastify) has a ~2MB
 * request body limit. Since we send images as base64 in JSON, the
 * binary image must be kept under ~600KB (base64 adds ~33% overhead,
 * plus JSON wrapper overhead).
 *
 * Strategy:
 *   1. Resize to max 1080px on longest side
 *   2. Convert to JPEG at quality 0.7
 *   3. If still too large, iteratively reduce quality
 *   4. Final target: < 600KB binary (< 800KB base64)
 */

const MAX_DIMENSION = 1080;
const INITIAL_QUALITY = 0.70;
const MIN_QUALITY = 0.30;
const QUALITY_STEP = 0.08;
const TARGET_SIZE_BYTES = 600 * 1024; // 600KB binary target


export interface CompressionResult {
  file: File;
  originalSize: number;
  compressedSize: number;
  width: number;
  height: number;
  quality: number;
  wasCompressed: boolean;
}

/**
 * Load an image from a File object
 */
function loadImage(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(img.src);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(img.src);
      reject(new Error('Failed to load image'));
    };
    img.src = URL.createObjectURL(file);
  });
}

/**
 * Draw image to canvas at target dimensions
 */
function drawToCanvas(
  img: HTMLImageElement,
  maxDim: number
): { canvas: HTMLCanvasElement; width: number; height: number } {
  let { naturalWidth: w, naturalHeight: h } = img;

  // Scale down if either dimension exceeds max
  if (w > maxDim || h > maxDim) {
    if (w > h) {
      h = Math.round((h / w) * maxDim);
      w = maxDim;
    } else {
      w = Math.round((w / h) * maxDim);
      h = maxDim;
    }
  }

  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d')!;
  
  // Use high-quality image smoothing
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, w, h);

  return { canvas, width: w, height: h };
}

/**
 * Convert canvas to blob at given JPEG quality
 */
function canvasToBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) resolve(blob);
        else reject(new Error('Canvas toBlob returned null'));
      },
      'image/jpeg',
      quality
    );
  });
}

/**
 * Compress an image file to be under the gateway body size limit.
 * Always converts to JPEG and resizes.
 * 
 * @param file - The original image file from file input
 * @param onProgress - Optional callback for progress updates
 * @returns CompressionResult with the compressed file
 */
export async function compressImage(
  file: File,
  onProgress?: (message: string) => void
): Promise<CompressionResult> {
  const originalSize = file.size;

  // If file is already tiny (under 200KB), skip compression
  if (originalSize <= 200 * 1024 && (file.type === 'image/jpeg' || file.type === 'image/jpg')) {
    return {
      file,
      originalSize,
      compressedSize: originalSize,
      width: 0,
      height: 0,
      quality: 1,
      wasCompressed: false,
    };
  }

  onProgress?.('Loading image...');
  const img = await loadImage(file);

  onProgress?.('Resizing...');
  const { canvas, width, height } = drawToCanvas(img, MAX_DIMENSION);

  // Iterative compression: start at INITIAL_QUALITY, reduce until under target
  let quality = INITIAL_QUALITY;
  let blob: Blob | null = null;

  onProgress?.('Compressing...');

  while (quality >= MIN_QUALITY) {
    blob = await canvasToBlob(canvas, quality);
    
    console.log(
      `[imageCompressor] quality=${quality.toFixed(2)} → ${(blob.size / 1024).toFixed(0)}KB`
    );

    if (blob.size <= TARGET_SIZE_BYTES) {
      break;
    }

    quality -= QUALITY_STEP;
  }

  // If still too large at min quality, try with smaller dimensions
  if (blob && blob.size > TARGET_SIZE_BYTES) {
    onProgress?.('Reducing dimensions further...');
    const { canvas: smallCanvas } = drawToCanvas(img, 800);
    blob = await canvasToBlob(smallCanvas, MIN_QUALITY);
    console.log(
      `[imageCompressor] fallback 800px quality=${MIN_QUALITY} → ${(blob.size / 1024).toFixed(0)}KB`
    );
  }

  if (!blob) {
    throw new Error('Image compression failed');
  }

  const compressedFile = new File(
    [blob],
    file.name.replace(/\.[^.]+$/, '.jpg'),
    { type: 'image/jpeg', lastModified: Date.now() }
  );

  const result: CompressionResult = {
    file: compressedFile,
    originalSize,
    compressedSize: compressedFile.size,
    width,
    height,
    quality: Math.max(quality, MIN_QUALITY),
    wasCompressed: true,
  };

  const savings = ((1 - compressedFile.size / originalSize) * 100).toFixed(0);
  console.log(
    `[imageCompressor] ${(originalSize / 1024 / 1024).toFixed(1)}MB → ${(compressedFile.size / 1024).toFixed(0)}KB (${savings}% reduction)`
  );

  onProgress?.('Ready to upload');
  return result;
}

/**
 * Convert a File to a base64 data URL string
 */
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

/**
 * Estimate the JSON payload size for a base64 upload
 * (base64 string + JSON wrapper overhead)
 */
export function estimatePayloadSize(base64: string): number {
  // base64 string length + ~200 bytes for JSON keys/values
  return base64.length + 200;
}
