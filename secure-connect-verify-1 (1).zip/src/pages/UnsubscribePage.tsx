import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { 
  Mail, 
  MailX, 
  Check, 
  AlertCircle, 
  Loader2, 
  Settings, 
  Heart,
  MessageCircle,
  Calendar,
  QrCode,
  Shield,
  Eye,
  Megaphone,
  CreditCard,
  Crown,
  ArrowLeft,
  RefreshCw
} from 'lucide-react';

interface PreferencesData {
  email: string;
  displayName: string;
  language: string;
  currentPreferences: Record<string, boolean>;
  typeNames: Record<string, string>;
}

type UnsubscribeType = 
  | 'matches' 
  | 'messages' 
  | 'weekly_digest' 
  | 'crush_codes' 
  | 'verification' 
  | 'profile_views' 
  | 'marketing' 
  | 'payment' 
  | 'subscription'
  | 'all';

const TYPE_ICONS: Record<string, React.ElementType> = {
  matches: Heart,
  messages: MessageCircle,
  weekly_digest: Calendar,
  crush_codes: QrCode,
  verification: Shield,
  profile_views: Eye,
  marketing: Megaphone,
  payment: CreditCard,
  subscription: Crown,
  all: MailX
};

const TYPE_COLORS: Record<string, string> = {
  matches: 'text-pink-400',
  messages: 'text-blue-400',
  weekly_digest: 'text-gold',
  crush_codes: 'text-purple-400',
  verification: 'text-green-400',
  profile_views: 'text-amber-400',
  marketing: 'text-orange-400',
  payment: 'text-emerald-400',
  subscription: 'text-gold',
  all: 'text-red-400'
};

// UI Text translations
const UI_TEXT = {
  en: {
    title: 'Email Preferences',
    subtitle: 'Manage your email notifications',
    loading: 'Loading your preferences...',
    invalidToken: 'Invalid or Expired Link',
    invalidTokenDesc: 'This unsubscribe link is no longer valid. Please use a recent email or manage your preferences from your account settings.',
    goToSettings: 'Go to Settings',
    goHome: 'Go to Homepage',
    emailFor: 'Managing emails for',
    unsubscribeFrom: 'Unsubscribe from:',
    selectTypes: 'Select the notification types you want to unsubscribe from:',
    unsubscribeSelected: 'Unsubscribe Selected',
    unsubscribeAll: 'Unsubscribe from All Emails',
    resubscribe: 'Re-subscribe',
    processing: 'Processing...',
    successTitle: 'Successfully Updated!',
    successUnsubscribed: 'You have been unsubscribed from:',
    successResubscribed: 'You have been re-subscribed to:',
    errorTitle: 'Something went wrong',
    errorDesc: 'We couldn\'t update your preferences. Please try again or contact support.',
    tryAgain: 'Try Again',
    manageAll: 'Manage All Preferences',
    manageAllDesc: 'For more detailed control over your notifications, visit your account settings.',
    openSettings: 'Open Email Settings',
    legalNotice: 'Note: Important transactional emails (security alerts, account updates) will still be sent regardless of your preferences.',
    currentlySubscribed: 'Currently subscribed',
    currentlyUnsubscribed: 'Currently unsubscribed',
    quickUnsubscribe: 'Quick Unsubscribe',
    quickUnsubscribeDesc: 'Unsubscribe from this specific notification type:',
    orManageAll: 'Or manage all your email preferences below:'
  },
  es: {
    title: 'Preferencias de Email',
    subtitle: 'Gestiona tus notificaciones por correo',
    loading: 'Cargando tus preferencias...',
    invalidToken: 'Enlace Inválido o Expirado',
    invalidTokenDesc: 'Este enlace de cancelación ya no es válido. Por favor usa un correo reciente o gestiona tus preferencias desde la configuración de tu cuenta.',
    goToSettings: 'Ir a Configuración',
    goHome: 'Ir al Inicio',
    emailFor: 'Gestionando correos para',
    unsubscribeFrom: 'Cancelar suscripción de:',
    selectTypes: 'Selecciona los tipos de notificación de los que quieres cancelar la suscripción:',
    unsubscribeSelected: 'Cancelar Seleccionados',
    unsubscribeAll: 'Cancelar Todos los Correos',
    resubscribe: 'Re-suscribirse',
    processing: 'Procesando...',
    successTitle: '¡Actualizado Exitosamente!',
    successUnsubscribed: 'Has cancelado la suscripción de:',
    successResubscribed: 'Te has re-suscrito a:',
    errorTitle: 'Algo salió mal',
    errorDesc: 'No pudimos actualizar tus preferencias. Por favor intenta de nuevo o contacta soporte.',
    tryAgain: 'Intentar de Nuevo',
    manageAll: 'Gestionar Todas las Preferencias',
    manageAllDesc: 'Para un control más detallado de tus notificaciones, visita la configuración de tu cuenta.',
    openSettings: 'Abrir Configuración de Email',
    legalNotice: 'Nota: Los correos transaccionales importantes (alertas de seguridad, actualizaciones de cuenta) se seguirán enviando independientemente de tus preferencias.',
    currentlySubscribed: 'Actualmente suscrito',
    currentlyUnsubscribed: 'Actualmente cancelado',
    quickUnsubscribe: 'Cancelación Rápida',
    quickUnsubscribeDesc: 'Cancela la suscripción de este tipo de notificación específico:',
    orManageAll: 'O gestiona todas tus preferencias de correo abajo:'
  },
  fr: {
    title: 'Préférences Email',
    subtitle: 'Gérez vos notifications par email',
    loading: 'Chargement de vos préférences...',
    invalidToken: 'Lien Invalide ou Expiré',
    invalidTokenDesc: 'Ce lien de désinscription n\'est plus valide. Veuillez utiliser un email récent ou gérer vos préférences depuis les paramètres de votre compte.',
    goToSettings: 'Aller aux Paramètres',
    goHome: 'Aller à l\'Accueil',
    emailFor: 'Gestion des emails pour',
    unsubscribeFrom: 'Se désinscrire de:',
    selectTypes: 'Sélectionnez les types de notifications dont vous souhaitez vous désinscrire:',
    unsubscribeSelected: 'Désinscrire Sélectionnés',
    unsubscribeAll: 'Se Désinscrire de Tous les Emails',
    resubscribe: 'Se Réinscrire',
    processing: 'Traitement...',
    successTitle: 'Mis à Jour avec Succès!',
    successUnsubscribed: 'Vous avez été désinscrit de:',
    successResubscribed: 'Vous avez été réinscrit à:',
    errorTitle: 'Une erreur s\'est produite',
    errorDesc: 'Nous n\'avons pas pu mettre à jour vos préférences. Veuillez réessayer ou contacter le support.',
    tryAgain: 'Réessayer',
    manageAll: 'Gérer Toutes les Préférences',
    manageAllDesc: 'Pour un contrôle plus détaillé de vos notifications, visitez les paramètres de votre compte.',
    openSettings: 'Ouvrir les Paramètres Email',
    legalNotice: 'Note: Les emails transactionnels importants (alertes de sécurité, mises à jour de compte) seront toujours envoyés indépendamment de vos préférences.',
    currentlySubscribed: 'Actuellement inscrit',
    currentlyUnsubscribed: 'Actuellement désinscrit',
    quickUnsubscribe: 'Désinscription Rapide',
    quickUnsubscribeDesc: 'Désinscrire de ce type de notification spécifique:',
    orManageAll: 'Ou gérez toutes vos préférences email ci-dessous:'
  },
  de: {
    title: 'E-Mail-Einstellungen',
    subtitle: 'Verwalten Sie Ihre E-Mail-Benachrichtigungen',
    loading: 'Laden Ihrer Einstellungen...',
    invalidToken: 'Ungültiger oder Abgelaufener Link',
    invalidTokenDesc: 'Dieser Abmeldelink ist nicht mehr gültig. Bitte verwenden Sie eine aktuelle E-Mail oder verwalten Sie Ihre Einstellungen in Ihren Kontoeinstellungen.',
    goToSettings: 'Zu den Einstellungen',
    goHome: 'Zur Startseite',
    emailFor: 'E-Mails verwalten für',
    unsubscribeFrom: 'Abmelden von:',
    selectTypes: 'Wählen Sie die Benachrichtigungstypen aus, von denen Sie sich abmelden möchten:',
    unsubscribeSelected: 'Ausgewählte Abmelden',
    unsubscribeAll: 'Von Allen E-Mails Abmelden',
    resubscribe: 'Wieder Anmelden',
    processing: 'Verarbeitung...',
    successTitle: 'Erfolgreich Aktualisiert!',
    successUnsubscribed: 'Sie wurden abgemeldet von:',
    successResubscribed: 'Sie wurden wieder angemeldet bei:',
    errorTitle: 'Etwas ist schief gelaufen',
    errorDesc: 'Wir konnten Ihre Einstellungen nicht aktualisieren. Bitte versuchen Sie es erneut oder kontaktieren Sie den Support.',
    tryAgain: 'Erneut Versuchen',
    manageAll: 'Alle Einstellungen Verwalten',
    manageAllDesc: 'Für eine detailliertere Kontrolle über Ihre Benachrichtigungen besuchen Sie Ihre Kontoeinstellungen.',
    openSettings: 'E-Mail-Einstellungen Öffnen',
    legalNotice: 'Hinweis: Wichtige Transaktions-E-Mails (Sicherheitswarnungen, Kontoaktualisierungen) werden unabhängig von Ihren Einstellungen weiterhin gesendet.',
    currentlySubscribed: 'Derzeit abonniert',
    currentlyUnsubscribed: 'Derzeit abgemeldet',
    quickUnsubscribe: 'Schnelle Abmeldung',
    quickUnsubscribeDesc: 'Von diesem spezifischen Benachrichtigungstyp abmelden:',
    orManageAll: 'Oder verwalten Sie alle Ihre E-Mail-Einstellungen unten:'
  }
};

type SupportedLanguage = keyof typeof UI_TEXT;

const UnsubscribePage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const typeFromUrl = searchParams.get('type') as UnsubscribeType | null;

  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [prefsData, setPrefsData] = useState<PreferencesData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedTypes, setSelectedTypes] = useState<Set<UnsubscribeType>>(new Set());
  const [result, setResult] = useState<{
    type: 'success' | 'error';
    action: 'unsubscribe' | 'resubscribe';
    types: string[];
  } | null>(null);

  const lang: SupportedLanguage = (prefsData?.language as SupportedLanguage) || 'en';
  const text = UI_TEXT[lang] || UI_TEXT.en;

  useEffect(() => {
    if (token) {
      validateToken();
    } else {
      setLoading(false);
      setError('INVALID_TOKEN');
    }
  }, [token]);

  // Pre-select the type from URL if provided
  useEffect(() => {
    if (typeFromUrl && prefsData?.currentPreferences[typeFromUrl]) {
      setSelectedTypes(new Set([typeFromUrl]));
    }
  }, [typeFromUrl, prefsData]);

  const validateToken = async () => {
    try {
      const { data, error: invokeError } = await supabase.functions.invoke('email-unsubscribe', {
        body: {
          token,
          action: 'validate'
        }
      });

      if (invokeError || !data?.success) {
        setError('INVALID_TOKEN');
        return;
      }

      setPrefsData(data);
    } catch (err) {
      console.error('Token validation error:', err);
      setError('INVALID_TOKEN');
    } finally {
      setLoading(false);
    }
  };

  const handleUnsubscribe = async (types: UnsubscribeType[]) => {
    if (!token || types.length === 0) return;

    setProcessing(true);
    setResult(null);

    try {
      const { data, error: invokeError } = await supabase.functions.invoke('email-unsubscribe', {
        body: {
          token,
          action: 'unsubscribe',
          types,
          source: 'web'
        }
      });

      if (invokeError || !data?.success) {
        setResult({ type: 'error', action: 'unsubscribe', types: [] });
        return;
      }

      setResult({ 
        type: 'success', 
        action: 'unsubscribe', 
        types: data.unsubscribedFrom || types 
      });

      // Update local state
      if (prefsData) {
        const newPrefs = { ...prefsData.currentPreferences };
        for (const type of types) {
          if (type === 'all') {
            Object.keys(newPrefs).forEach(k => newPrefs[k] = false);
          } else {
            newPrefs[type] = false;
          }
        }
        setPrefsData({ ...prefsData, currentPreferences: newPrefs });
      }

      setSelectedTypes(new Set());
    } catch (err) {
      console.error('Unsubscribe error:', err);
      setResult({ type: 'error', action: 'unsubscribe', types: [] });
    } finally {
      setProcessing(false);
    }
  };

  const handleResubscribe = async (types: UnsubscribeType[]) => {
    if (!token || types.length === 0) return;

    setProcessing(true);
    setResult(null);

    try {
      const { data, error: invokeError } = await supabase.functions.invoke('email-unsubscribe', {
        body: {
          token,
          action: 'resubscribe',
          types
        }
      });

      if (invokeError || !data?.success) {
        setResult({ type: 'error', action: 'resubscribe', types: [] });
        return;
      }

      setResult({ 
        type: 'success', 
        action: 'resubscribe', 
        types: data.resubscribedTo || types 
      });

      // Update local state
      if (prefsData) {
        const newPrefs = { ...prefsData.currentPreferences };
        for (const type of types) {
          if (type === 'all') {
            newPrefs['all'] = true;
          } else {
            newPrefs[type] = true;
          }
        }
        setPrefsData({ ...prefsData, currentPreferences: newPrefs });
      }
    } catch (err) {
      console.error('Resubscribe error:', err);
      setResult({ type: 'error', action: 'resubscribe', types: [] });
    } finally {
      setProcessing(false);
    }
  };

  const toggleType = (type: UnsubscribeType) => {
    const newSelected = new Set(selectedTypes);
    if (newSelected.has(type)) {
      newSelected.delete(type);
    } else {
      newSelected.add(type);
    }
    setSelectedTypes(newSelected);
  };

  const notificationTypes: UnsubscribeType[] = [
    'matches',
    'messages', 
    'weekly_digest',
    'crush_codes',
    'verification',
    'profile_views',
    'marketing',
    'payment',
    'subscription'
  ];

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-charcoal-900 flex items-center justify-center p-4">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-gold animate-spin mx-auto mb-4" />
          <p className="text-gray-400">{text.loading}</p>
        </div>
      </div>
    );
  }

  // Invalid token state
  if (error === 'INVALID_TOKEN' || !prefsData) {
    return (
      <div className="min-h-screen bg-charcoal-900 flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-charcoal-800 rounded-2xl p-8 text-center">
          <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="w-8 h-8 text-red-400" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-3">{text.invalidToken}</h1>
          <p className="text-gray-400 mb-8">{text.invalidTokenDesc}</p>
          <div className="flex flex-col sm:flex-row gap-3">
            <Link 
              to="/settings#notifications"
              className="flex-1 px-4 py-3 bg-gold text-charcoal-900 rounded-xl font-semibold hover:bg-gold/90 transition-colors flex items-center justify-center gap-2"
            >
              <Settings className="w-4 h-4" />
              {text.goToSettings}
            </Link>
            <Link 
              to="/"
              className="flex-1 px-4 py-3 bg-charcoal-700 text-white rounded-xl font-semibold hover:bg-charcoal-600 transition-colors flex items-center justify-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              {text.goHome}
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-charcoal-900 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Mail className="w-8 h-8 text-gold" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">{text.title}</h1>
          <p className="text-gray-400">{text.subtitle}</p>
          <p className="text-sm text-gray-500 mt-2">
            {text.emailFor} <span className="text-gold">{prefsData.email}</span>
          </p>
        </div>

        {/* Result message */}
        {result && (
          <div className={`mb-6 p-4 rounded-xl ${
            result.type === 'success' 
              ? 'bg-green-500/20 border border-green-500/30' 
              : 'bg-red-500/20 border border-red-500/30'
          }`}>
            <div className="flex items-start gap-3">
              {result.type === 'success' ? (
                <Check className="w-5 h-5 text-green-400 mt-0.5" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-400 mt-0.5" />
              )}
              <div>
                <p className={`font-semibold ${
                  result.type === 'success' ? 'text-green-400' : 'text-red-400'
                }`}>
                  {result.type === 'success' ? text.successTitle : text.errorTitle}
                </p>
                {result.type === 'success' ? (
                  <p className="text-sm text-gray-300 mt-1">
                    {result.action === 'unsubscribe' ? text.successUnsubscribed : text.successResubscribed}
                    <span className="text-white font-medium ml-1">
                      {result.types.map(t => prefsData.typeNames[t] || t).join(', ')}
                    </span>
                  </p>
                ) : (
                  <p className="text-sm text-gray-300 mt-1">{text.errorDesc}</p>
                )}
              </div>
            </div>
            {result.type === 'error' && (
              <button
                onClick={() => setResult(null)}
                className="mt-3 text-sm text-red-400 hover:text-red-300 flex items-center gap-1"
              >
                <RefreshCw className="w-4 h-4" />
                {text.tryAgain}
              </button>
            )}
          </div>
        )}

        {/* Quick unsubscribe for specific type from URL */}
        {typeFromUrl && prefsData.currentPreferences[typeFromUrl] && !result && (
          <div className="bg-charcoal-800 rounded-2xl p-6 mb-6 border border-charcoal-700">
            <h2 className="text-lg font-semibold text-white mb-2">{text.quickUnsubscribe}</h2>
            <p className="text-sm text-gray-400 mb-4">{text.quickUnsubscribeDesc}</p>
            
            <button
              onClick={() => handleUnsubscribe([typeFromUrl])}
              disabled={processing}
              className="w-full flex items-center justify-center gap-3 p-4 bg-red-500/20 border border-red-500/30 rounded-xl hover:bg-red-500/30 transition-colors disabled:opacity-50"
            >
              {processing ? (
                <Loader2 className="w-5 h-5 text-red-400 animate-spin" />
              ) : (
                <>
                  {React.createElement(TYPE_ICONS[typeFromUrl] || MailX, { 
                    className: `w-5 h-5 ${TYPE_COLORS[typeFromUrl] || 'text-red-400'}` 
                  })}
                  <span className="text-white font-medium">
                    {text.unsubscribeFrom} {prefsData.typeNames[typeFromUrl]}
                  </span>
                </>
              )}
            </button>

            <p className="text-sm text-gray-500 mt-4 text-center">{text.orManageAll}</p>
          </div>
        )}

        {/* Main preferences panel */}
        <div className="bg-charcoal-800 rounded-2xl p-6 border border-charcoal-700">
          <h2 className="text-lg font-semibold text-white mb-4">{text.selectTypes}</h2>
          
          {/* Notification type checkboxes */}
          <div className="space-y-2 mb-6">
            {notificationTypes.map((type) => {
              const Icon = TYPE_ICONS[type] || Mail;
              const isSubscribed = prefsData.currentPreferences[type];
              const isSelected = selectedTypes.has(type);
              
              return (
                <div
                  key={type}
                  onClick={() => isSubscribed && toggleType(type)}
                  className={`flex items-center justify-between p-4 rounded-xl transition-all ${
                    isSubscribed 
                      ? 'bg-charcoal-700 hover:bg-charcoal-600 cursor-pointer' 
                      : 'bg-charcoal-700/50 opacity-60'
                  } ${isSelected ? 'ring-2 ring-gold' : ''}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      isSubscribed ? 'bg-charcoal-600' : 'bg-charcoal-800'
                    }`}>
                      <Icon className={`w-5 h-5 ${TYPE_COLORS[type] || 'text-gray-400'}`} />
                    </div>
                    <div>
                      <p className="font-medium text-white">{prefsData.typeNames[type]}</p>
                      <p className="text-xs text-gray-500">
                        {isSubscribed ? text.currentlySubscribed : text.currentlyUnsubscribed}
                      </p>
                    </div>
                  </div>
                  
                  {isSubscribed ? (
                    <div className={`w-6 h-6 rounded-md border-2 flex items-center justify-center transition-colors ${
                      isSelected 
                        ? 'bg-gold border-gold' 
                        : 'border-charcoal-500 hover:border-charcoal-400'
                    }`}>
                      {isSelected && <Check className="w-4 h-4 text-charcoal-900" />}
                    </div>
                  ) : (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleResubscribe([type]);
                      }}
                      disabled={processing}
                      className="px-3 py-1.5 text-xs bg-charcoal-600 text-gray-300 rounded-lg hover:bg-charcoal-500 transition-colors disabled:opacity-50"
                    >
                      {text.resubscribe}
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {/* Action buttons */}
          <div className="space-y-3">
            <button
              onClick={() => handleUnsubscribe(Array.from(selectedTypes))}
              disabled={processing || selectedTypes.size === 0}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gold text-charcoal-900 rounded-xl font-semibold hover:bg-gold/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {processing ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <MailX className="w-5 h-5" />
                  {text.unsubscribeSelected} ({selectedTypes.size})
                </>
              )}
            </button>

            {prefsData.currentPreferences['all'] && (
              <button
                onClick={() => handleUnsubscribe(['all'])}
                disabled={processing}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-red-500/20 text-red-400 border border-red-500/30 rounded-xl font-semibold hover:bg-red-500/30 transition-colors disabled:opacity-50"
              >
                {processing ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <MailX className="w-5 h-5" />
                    {text.unsubscribeAll}
                  </>
                )}
              </button>
            )}

            {!prefsData.currentPreferences['all'] && (
              <button
                onClick={() => handleResubscribe(['all'])}
                disabled={processing}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-green-500/20 text-green-400 border border-green-500/30 rounded-xl font-semibold hover:bg-green-500/30 transition-colors disabled:opacity-50"
              >
                {processing ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <>
                    <Mail className="w-5 h-5" />
                    {text.resubscribe} {prefsData.typeNames['all']}
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Link to full settings */}
        <div className="mt-6 bg-charcoal-800/50 rounded-2xl p-6 border border-charcoal-700">
          <h3 className="text-white font-semibold mb-2">{text.manageAll}</h3>
          <p className="text-sm text-gray-400 mb-4">{text.manageAllDesc}</p>
          <Link
            to="/settings#notifications"
            className="inline-flex items-center gap-2 px-4 py-2 bg-charcoal-700 text-white rounded-lg hover:bg-charcoal-600 transition-colors"
          >
            <Settings className="w-4 h-4" />
            {text.openSettings}
          </Link>
        </div>

        {/* Legal notice */}
        <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
          <p className="text-xs text-blue-300">{text.legalNotice}</p>
        </div>

        {/* Back to home */}
        <div className="mt-8 text-center">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            {text.goHome}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default UnsubscribePage;
