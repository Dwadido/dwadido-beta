import { supabase } from './supabase';

/**
 * =============================================================================
 * DWADIDO EMAIL NOTIFICATIONS
 * =============================================================================
 * 
 * V1 Design Decisions:
 * - Email notifications are OPTIONAL and MINIMAL
 * - Only critical connection or meeting updates
 * - NO marketing or re-engagement emails
 * 
 * KEPT (Critical Updates):
 * - new_match: When someone accepts your code
 * - new_message: When you receive a message (optional)
 * - crush_code_redeemed: When your code is used
 * - match_expiring: When a match is about to expire
 * - verification_approved: When verification is approved
 * - verification_rejected: When verification is rejected
 * 
 * REMOVED (Marketing/Re-engagement):
 * - message_reminder: Re-engagement
 * - weekly_summary: Marketing/engagement
 * - profile_view: Engagement metric
 * - welcome: Marketing
 * =============================================================================
 */

export type EmailNotificationType = 
  | 'new_match'
  | 'new_message'
  | 'crush_code_redeemed'
  | 'verification_approved'
  | 'verification_rejected'
  | 'match_expiring';

export interface EmailNotificationData {
  // For new_match
  matchName?: string;
  matchPhoto?: string;
  chatUrl?: string;
  
  // For new_message
  senderName?: string;
  messagePreview?: string;
  
  // For crush_code_redeemed
  code?: string;
  matchUrl?: string;
  
  // For verification_rejected
  reason?: string;
  
  // For match_expiring
  hoursLeft?: number;
}

export interface SendEmailResult {
  success: boolean;
  messageId?: string;
  error?: string;
  skipped?: boolean;
}

/**
 * Send an email notification to a user
 * Only sends critical connection/meeting updates
 */
export async function sendEmailNotification(
  userId: string,
  emailType: EmailNotificationType,
  data?: EmailNotificationData,
  language?: string
): Promise<SendEmailResult> {
  try {
    const { data: result, error } = await supabase.functions.invoke('send-email-notification', {
      body: {
        userId,
        emailType,
        data: data || {},
        language
      }
    });

    if (error) {
      console.error('Error sending email notification:', error);
      return { success: false, error: error.message };
    }

    return result;
  } catch (err) {
    console.error('Failed to send email notification:', err);
    return { success: false, error: err instanceof Error ? err.message : 'Unknown error' };
  }
}

/**
 * Send a new match email notification
 * Critical: Notifies user when someone accepts their code
 */
export async function notifyNewMatch(
  userId: string,
  matchName: string,
  matchPhoto?: string,
  chatUrl?: string
): Promise<SendEmailResult> {
  return sendEmailNotification(userId, 'new_match', {
    matchName,
    matchPhoto,
    chatUrl
  });
}

/**
 * Send a new message email notification
 * Optional: User can disable this in settings
 */
export async function notifyNewMessage(
  userId: string,
  senderName: string,
  messagePreview?: string,
  chatUrl?: string
): Promise<SendEmailResult> {
  return sendEmailNotification(userId, 'new_message', {
    senderName,
    messagePreview,
    chatUrl
  });
}

/**
 * Send a crush code redeemed notification
 * Critical: Notifies user when their code is used
 */
export async function notifyCrushCodeRedeemed(
  userId: string,
  code: string,
  matchUrl?: string
): Promise<SendEmailResult> {
  return sendEmailNotification(userId, 'crush_code_redeemed', {
    code,
    matchUrl
  });
}

/**
 * Send a verification approved notification
 * Critical: Notifies user when verification is approved
 */
export async function notifyVerificationApproved(
  userId: string
): Promise<SendEmailResult> {
  return sendEmailNotification(userId, 'verification_approved');
}

/**
 * Send a verification rejected notification
 * Critical: Notifies user when verification is rejected
 */
export async function notifyVerificationRejected(
  userId: string,
  reason?: string
): Promise<SendEmailResult> {
  return sendEmailNotification(userId, 'verification_rejected', { reason });
}

/**
 * Send a match expiring notification
 * Critical: Notifies user when a match is about to expire
 */
export async function notifyMatchExpiring(
  userId: string,
  matchName: string,
  hoursLeft: number,
  chatUrl?: string
): Promise<SendEmailResult> {
  return sendEmailNotification(userId, 'match_expiring', {
    matchName,
    hoursLeft,
    chatUrl
  });
}

/**
 * Check if user has email notifications enabled for a specific type
 */
export async function checkEmailPreference(
  userId: string,
  emailType: EmailNotificationType
): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('email_preferences')
      .select('email_enabled, new_matches, new_messages, crush_code_alerts, verification_alerts')
      .eq('user_id', userId)
      .maybeSingle();

    if (error || !data) return true; // Default to enabled if no preferences

    if (!data.email_enabled) return false;

    switch (emailType) {
      case 'new_match':
      case 'match_expiring':
        return data.new_matches !== false;
      case 'new_message':
        return data.new_messages !== false;
      case 'crush_code_redeemed':
        return data.crush_code_alerts !== false;
      case 'verification_approved':
      case 'verification_rejected':
        return data.verification_alerts !== false;
      default:
        return true;
    }
  } catch (err) {
    console.error('Error checking email preference:', err);
    return true;
  }
}

/**
 * Get email notification history for a user
 */
export async function getEmailHistory(
  userId: string,
  limit: number = 20
): Promise<Array<{
  id: string;
  email_type: string;
  subject: string;
  status: string;
  created_at: string;
}>> {
  try {
    const { data, error } = await supabase
      .from('email_log')
      .select('id, email_type, subject, status, created_at')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;
    return data || [];
  } catch (err) {
    console.error('Error fetching email history:', err);
    return [];
  }
}

/**
 * Get the user's unsubscribe token for generating unsubscribe links
 */
export async function getUnsubscribeToken(userId: string): Promise<string | null> {
  try {
    const { data, error } = await supabase
      .from('email_preferences')
      .select('unsubscribe_token')
      .eq('user_id', userId)
      .maybeSingle();

    if (error || !data) return null;
    return data.unsubscribe_token;
  } catch (err) {
    console.error('Error getting unsubscribe token:', err);
    return null;
  }
}

/**
 * Generate an unsubscribe URL for a specific notification type
 * V1: Simplified types - removed marketing categories
 */
export function generateUnsubscribeUrl(
  token: string, 
  type: 'matches' | 'messages' | 'crush_codes' | 'verification' | 'all' = 'all'
): string {
  const baseUrl = window.location.origin;
  return `${baseUrl}/unsubscribe?token=${token}&type=${type}`;
}

/**
 * Unsubscribe from specific notification types using a token
 */
export async function unsubscribeWithToken(
  token: string,
  types: string[]
): Promise<{ success: boolean; error?: string; unsubscribedFrom?: string[] }> {
  try {
    const { data, error } = await supabase.functions.invoke('email-unsubscribe', {
      body: {
        token,
        action: 'unsubscribe',
        types,
        source: 'web'
      }
    });

    if (error) {
      return { success: false, error: error.message };
    }

    return data;
  } catch (err) {
    console.error('Error unsubscribing:', err);
    return { success: false, error: err instanceof Error ? err.message : 'Unknown error' };
  }
}

/**
 * Re-subscribe to specific notification types using a token
 */
export async function resubscribeWithToken(
  token: string,
  types: string[]
): Promise<{ success: boolean; error?: string; resubscribedTo?: string[] }> {
  try {
    const { data, error } = await supabase.functions.invoke('email-unsubscribe', {
      body: {
        token,
        action: 'resubscribe',
        types
      }
    });

    if (error) {
      return { success: false, error: error.message };
    }

    return data;
  } catch (err) {
    console.error('Error resubscribing:', err);
    return { success: false, error: err instanceof Error ? err.message : 'Unknown error' };
  }
}

/**
 * Validate an unsubscribe token and get current preferences
 */
export async function validateUnsubscribeToken(token: string): Promise<{
  success: boolean;
  email?: string;
  displayName?: string;
  language?: string;
  currentPreferences?: Record<string, boolean>;
  typeNames?: Record<string, string>;
  error?: string;
}> {
  try {
    const { data, error } = await supabase.functions.invoke('email-unsubscribe', {
      body: {
        token,
        action: 'validate'
      }
    });

    if (error) {
      return { success: false, error: error.message };
    }

    return data;
  } catch (err) {
    console.error('Error validating token:', err);
    return { success: false, error: err instanceof Error ? err.message : 'Unknown error' };
  }
}
