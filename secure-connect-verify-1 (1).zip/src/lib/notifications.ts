// Dwadido Push Notification Service
import { supabase } from './supabase';

export interface NotificationPreferences {
  push_enabled: boolean;
  new_match: boolean;
  new_message: boolean;
  crush_code_redeemed: boolean;
  verification_update: boolean;
  photo_request: boolean;
  photo_request_response: boolean;
  meeting_suggestion: boolean;
  meeting_response: boolean;
}

export const defaultNotificationPreferences: NotificationPreferences = {
  push_enabled: true,
  new_match: true,
  new_message: true,
  crush_code_redeemed: true,
  verification_update: true,
  photo_request: true,
  photo_request_response: true,
  meeting_suggestion: true,
  meeting_response: true,
};

// Notification types
export type NotificationType = 
  | 'new_match' 
  | 'mutual_match'
  | 'new_message' 
  | 'crush_code_redeemed' 
  | 'verification_update'
  | 'photo_request'
  | 'photo_request_response'
  | 'meeting_suggestion'
  | 'meeting_response';


export interface AppNotification {
  id: string;
  user_id: string;
  type: NotificationType;
  title: string;
  body: string;
  data: Record<string, any> | null;
  read: boolean;
  created_at: string;
}


// Re-export as Notification for backward compatibility
export type { AppNotification as Notification };


// Check if browser supports push notifications
export const isPushSupported = (): boolean => {
  return 'Notification' in window && 'serviceWorker' in navigator && 'PushManager' in window;
};

// Get current notification permission status
export const getNotificationPermission = (): NotificationPermission => {
  if (!isPushSupported()) return 'denied';
  return Notification.permission;
};

// Request notification permission
export const requestNotificationPermission = async (): Promise<NotificationPermission> => {
  if (!isPushSupported()) {
    console.warn('Push notifications not supported');
    return 'denied';
  }

  try {
    const permission = await Notification.requestPermission();
    return permission;
  } catch (error) {
    console.error('Error requesting notification permission:', error);
    return 'denied';
  }
};

// Register service worker for push notifications
export const registerServiceWorker = async (): Promise<ServiceWorkerRegistration | null> => {
  if (!('serviceWorker' in navigator)) {
    console.warn('Service workers not supported');
    return null;
  }

  try {
    // Check if service worker file exists before registering
    const swResponse = await fetch('/sw.js', { method: 'HEAD' }).catch(() => null);
    if (!swResponse || !swResponse.ok) {
      console.warn('Service worker file not found, skipping registration');
      return null;
    }
    
    const registration = await navigator.serviceWorker.register('/sw.js');
    console.log('Service worker registered:', registration);
    return registration;
  } catch (error) {
    // Handle AbortError silently - it's expected during page navigation
    if (error instanceof Error && error.name === 'AbortError') {
      return null;
    }
    console.error('Service worker registration failed:', error);
    return null;
  }
};



// VAPID public key for push subscriptions
const VAPID_PUBLIC_KEY = 'BEl62iUYgUivxIkv69yViEuiBIa-Ib9-SkvMeAtA3LFgDzkrxZJjSgSnfckjBJuBkr3qBUYIHBQFLXYp5Nksh8U';

// Subscribe to push notifications
export const subscribeToPush = async (userId: string): Promise<PushSubscription | null> => {
  try {
    const registration = await navigator.serviceWorker.ready;
    
    // Get existing subscription or create new one
    let subscription = await registration.pushManager.getSubscription();
    
    if (!subscription) {
      // Create new subscription
      subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
      });
    }

    // Save subscription to database via edge function
    const subscriptionJSON = subscription.toJSON();
    await supabase.functions.invoke('subscribe-push', {
      body: {
        action: 'subscribe',
        subscription: {
          endpoint: subscriptionJSON.endpoint,
          keys: subscriptionJSON.keys
        }
      }
    });
    
    return subscription;
  } catch (error) {
    console.error('Error subscribing to push:', error);
    return null;
  }
};

// Unsubscribe from push notifications
export const unsubscribeFromPush = async (userId: string): Promise<boolean> => {
  try {
    const registration = await navigator.serviceWorker.ready;
    const subscription = await registration.pushManager.getSubscription();
    
    if (subscription) {
      const subscriptionJSON = subscription.toJSON();
      await subscription.unsubscribe();
      
      await supabase.functions.invoke('subscribe-push', {
        body: {
          action: 'unsubscribe',
          subscription: {
            endpoint: subscriptionJSON.endpoint
          }
        }
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error unsubscribing from push:', error);
    return false;
  }
};

// Save notification preferences
export const saveNotificationPreferences = async (
  userId: string,
  preferences: NotificationPreferences
): Promise<boolean> => {
  const { error } = await supabase
    .from('notification_preferences')
    .upsert({
      user_id: userId,
      ...preferences,
      updated_at: new Date().toISOString(),
    }, {
      onConflict: 'user_id',
    });

  if (error) {
    console.error('Error saving notification preferences:', error);
    return false;
  }
  return true;
};

// Get notification preferences
export const getNotificationPreferences = async (
  userId: string
): Promise<NotificationPreferences> => {
  const { data, error } = await supabase
    .from('notification_preferences')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (error || !data) {
    return defaultNotificationPreferences;
  }

  return {
    push_enabled: data.push_enabled ?? true,
    new_match: data.new_match ?? true,
    new_message: data.new_message ?? true,
    crush_code_redeemed: data.crush_code_redeemed ?? true,
    verification_update: data.verification_update ?? true,
    photo_request: data.photo_request ?? true,
    photo_request_response: data.photo_request_response ?? true,
    meeting_suggestion: data.meeting_suggestion ?? true,
    meeting_response: data.meeting_response ?? true,
  };
};

// Get notifications for a user
export const getNotifications = async (
  userId: string,
  options?: { limit?: number; unreadOnly?: boolean }
): Promise<AppNotification[]> => {
  let query = supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (options?.limit) {
    query = query.limit(options.limit);
  }

  if (options?.unreadOnly) {
    query = query.eq('read', false);
  }

  const { data, error } = await query;

  if (error) {
    console.error('Error fetching notifications:', error);
    return [];
  }

  return (data || []) as AppNotification[];
};

// Get unread notification count
export const getUnreadCount = async (userId: string): Promise<number> => {
  const { count, error } = await supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('read', false);

  if (error) {
    console.error('Error fetching unread count:', error);
    return 0;
  }

  return count || 0;
};

// Mark notifications as read
export const markAsRead = async (notificationIds: string[]): Promise<boolean> => {
  const { error } = await supabase
    .from('notifications')
    .update({ read: true })
    .in('id', notificationIds);

  if (error) {
    console.error('Error marking notifications as read:', error);
    return false;
  }

  return true;
};

// Mark all notifications as read
export const markAllAsRead = async (userId: string): Promise<boolean> => {
  const { error } = await supabase
    .from('notifications')
    .update({ read: true })
    .eq('user_id', userId)
    .eq('read', false);

  if (error) {
    console.error('Error marking all notifications as read:', error);
    return false;
  }

  return true;
};

// =============================================================================
// DIRECT NOTIFICATION CREATION (Frontend → Database)
// =============================================================================
// The edge functions (redeem-crush-code, generate-crush-code) do NOT insert
// notification rows. This function inserts directly into the notifications
// table from the frontend, ensuring users see updates for key events.
// =============================================================================

/**
 * Create a notification row directly in the notifications table.
 * This bypasses the send-push-notification edge function which may not exist.
 * 
 * @param userId - The user who should receive the notification
 * @param type - Notification type
 * @param title - Notification title
 * @param body - Notification body text
 * @param data - Optional metadata (url, match_id, etc.)
 * @returns The created notification or null on failure
 */
export const createNotificationDirect = async (
  userId: string,
  type: NotificationType,
  title: string,
  body: string,
  data?: Record<string, any>
): Promise<AppNotification | null> => {
  try {
    const { data: notification, error } = await supabase
      .from('notifications')
      .insert({
        user_id: userId,
        type,
        title,
        body,
        data: data || null,
        read: false,
      })
      .select()
      .single();

    if (error) {
      console.error('[Notifications] Error creating notification directly:', error);
      // If RLS blocks the insert, log it but don't throw
      if (error.code === '42501' || error.message?.includes('policy')) {
        console.warn('[Notifications] RLS policy blocked direct insert for user:', userId);
      }
      return null;
    }

    console.log('[Notifications] Created notification directly:', notification?.id, type);
    return notification as AppNotification;
  } catch (err) {
    console.error('[Notifications] Failed to create notification:', err);
    return null;
  }
};

/**
 * Create notifications for BOTH users after a successful crush code redemption.
 * Called from CodeRedeemer after handleConfirmConnection succeeds.
 * 
 * @param redeemerId - The user who redeemed the code
 * @param creatorId - The user who created the code
 * @param redeemerName - Display name of the redeemer
 * @param creatorName - Display name of the code creator
 * @param matchId - The match ID created
 */
export const createMatchNotifications = async (
  redeemerId: string,
  creatorId: string,
  redeemerName: string | null,
  creatorName: string | null,
  matchId: string
): Promise<void> => {
  const safeRedeemerName = redeemerName || 'Someone';
  const safeCreatorName = creatorName || 'Someone';

  // Notification for the REDEEMER: "You connected with [creator]"
  await createNotificationDirect(
    redeemerId,
    'new_match',
    'New Connection',
    `You connected with ${safeCreatorName}. Start a conversation when you're ready.`,
    { url: '/dashboard', match_id: matchId, other_user_id: creatorId }
  );

  // Notification for the CODE CREATOR: "Someone used your Crush Code"
  await createNotificationDirect(
    creatorId,
    'crush_code_redeemed',
    'Crush Code Redeemed',
    `${safeRedeemerName} used your Crush Code. You have a new connection.`,
    { url: '/dashboard', match_id: matchId, other_user_id: redeemerId }
  );
};

/**
 * Sync missed notifications: checks for matches that don't have
 * corresponding notification rows and creates them retroactively.
 * 
 * This handles the case where:
 * - Edge functions created matches but didn't insert notifications
 * - Notifications were lost due to errors
 * - User logged in for the first time after matches were created
 * 
 * @param userId - The current user's ID
 * @returns Number of notifications created
 */
export const syncMissedNotifications = async (userId: string): Promise<number> => {
  try {
    // 1. Get all confirmed/active matches for this user
    const { data: matches, error: matchError } = await supabase
      .from('matches')
      .select('id, user1_id, user2_id, confirmed_at, status')
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .in('status', ['confirmed', 'active'])
      .order('confirmed_at', { ascending: false })
      .limit(50);

    if (matchError || !matches || matches.length === 0) {
      return 0;
    }

    // 2. Get existing notifications for this user (match-related)
    const { data: existingNotifications, error: notifError } = await supabase
      .from('notifications')
      .select('id, data')
      .eq('user_id', userId)
      .in('type', ['new_match', 'crush_code_redeemed', 'mutual_match']);

    if (notifError) {
      console.warn('[Notifications] Error fetching existing notifications for sync:', notifError);
      return 0;
    }

    // 3. Find match IDs that already have notifications
    const notifiedMatchIds = new Set<string>();
    (existingNotifications || []).forEach(n => {
      if (n.data?.match_id) {
        notifiedMatchIds.add(n.data.match_id);
      }
    });

    // 4. Create notifications for matches that don't have them
    let created = 0;
    for (const match of matches) {
      if (notifiedMatchIds.has(match.id)) continue;

      const otherUserId = match.user1_id === userId ? match.user2_id : match.user1_id;

      // Fetch the other user's display name
      const { data: otherProfile } = await supabase
        .from('profiles')
        .select('display_name')
        .eq('id', otherUserId)
        .single();

      const otherName = otherProfile?.display_name || 'Someone';

      // Determine if this user was the code creator or redeemer
      // If user is user1_id, they were likely the code creator (edge function convention)
      const isCreator = match.user1_id === userId;

      const notification = await createNotificationDirect(
        userId,
        isCreator ? 'crush_code_redeemed' : 'new_match',
        isCreator ? 'Crush Code Redeemed' : 'New Connection',
        isCreator
          ? `${otherName} used your Crush Code. You have a new connection.`
          : `You connected with ${otherName}. Start a conversation when you're ready.`,
        { url: '/dashboard', match_id: match.id, other_user_id: otherUserId }
      );

      if (notification) {
        created++;
      }
    }

    if (created > 0) {
      console.log(`[Notifications] Synced ${created} missed notifications for user ${userId}`);
    }

    return created;
  } catch (err) {
    console.error('[Notifications] Error syncing missed notifications:', err);
    return 0;
  }
};

// =============================================================================
// MATCH-DERIVED NOTIFICATIONS (Frontend Fallback)
// =============================================================================
// The notifications table may be empty due to RLS blocking inserts, edge
// functions not creating rows, or sync failures. This function derives
// notification objects directly from the matches table — the actual source
// of truth — so users ALWAYS see updates for their connections.
//
// Read/unread state is tracked in localStorage since we can't rely on the
// notifications table for storage.
// =============================================================================

const DERIVED_READ_STORAGE_KEY = 'dwadido_derived_notif_read';
const DERIVED_DISMISSED_STORAGE_KEY = 'dwadido_derived_notif_dismissed';

/** Prefix for derived notification IDs — used to distinguish from DB rows */
const DERIVED_ID_PREFIX = 'match-derived-';

/** Check if a notification ID is a derived (non-DB) notification */
export const isDerivedNotificationId = (id: string): boolean =>
  id.startsWith(DERIVED_ID_PREFIX);

/** Get the set of derived notification IDs the user has marked as read */
function getDerivedReadIds(): Set<string> {
  try {
    const raw = localStorage.getItem(DERIVED_READ_STORAGE_KEY);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
}

/** Persist the set of read derived notification IDs */
function setDerivedReadIds(ids: Set<string>): void {
  try {
    localStorage.setItem(DERIVED_READ_STORAGE_KEY, JSON.stringify([...ids]));
  } catch {
    // localStorage full or unavailable — ignore
  }
}

/** Get the set of derived notification IDs the user has dismissed/deleted */
function getDerivedDismissedIds(): Set<string> {
  try {
    const raw = localStorage.getItem(DERIVED_DISMISSED_STORAGE_KEY);
    return raw ? new Set(JSON.parse(raw)) : new Set();
  } catch {
    return new Set();
  }
}

function setDerivedDismissedIds(ids: Set<string>): void {
  try {
    localStorage.setItem(DERIVED_DISMISSED_STORAGE_KEY, JSON.stringify([...ids]));
  } catch {
    // ignore
  }
}

/** Mark a single derived notification as read (localStorage) */
export const markDerivedNotificationRead = (notificationId: string): void => {
  const ids = getDerivedReadIds();
  ids.add(notificationId);
  setDerivedReadIds(ids);
};

/** Mark ALL derived notifications as read (localStorage) */
export const markAllDerivedRead = (allIds: string[]): void => {
  const ids = getDerivedReadIds();
  allIds.forEach(id => ids.add(id));
  setDerivedReadIds(ids);
};

/** Dismiss/delete a derived notification (localStorage) */
export const dismissDerivedNotification = (notificationId: string): void => {
  const ids = getDerivedDismissedIds();
  ids.add(notificationId);
  setDerivedDismissedIds(ids);
};

/** Dismiss all derived notifications (localStorage) */
export const dismissAllDerivedNotifications = (allIds: string[]): void => {
  const ids = getDerivedDismissedIds();
  allIds.forEach(id => ids.add(id));
  setDerivedDismissedIds(ids);
};

/**
 * Derive notification objects from the matches table.
 *
 * This is the FALLBACK that ensures users always see updates even when
 * the notifications table is empty. It queries the same matches data
 * that the Dashboard already fetches, creates AppNotification-shaped
 * objects with deterministic IDs, and uses localStorage for read state.
 *
 * @param userId - The current user's ID
 * @returns Array of AppNotification objects derived from matches
 */
export const getMatchDerivedNotifications = async (
  userId: string
): Promise<AppNotification[]> => {
  try {
    // 1. Fetch confirmed/active matches for this user
    const { data: matches, error: matchError } = await supabase
      .from('matches')
      .select('id, user1_id, user2_id, confirmed_at, status, created_at')
      .or(`user1_id.eq.${userId},user2_id.eq.${userId}`)
      .in('status', ['confirmed', 'active'])
      .order('confirmed_at', { ascending: false })
      .limit(50);

    if (matchError || !matches || matches.length === 0) {
      return [];
    }

    // 2. Get read & dismissed state from localStorage
    const readIds = getDerivedReadIds();
    const dismissedIds = getDerivedDismissedIds();

    // 3. Fetch display names for all other users in one batch
    const otherUserIds = matches.map(m =>
      m.user1_id === userId ? m.user2_id : m.user1_id
    );
    const uniqueOtherIds = [...new Set(otherUserIds)];

    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, display_name')
      .in('id', uniqueOtherIds);

    const nameMap = new Map<string, string>();
    (profiles || []).forEach(p => {
      if (p.display_name) nameMap.set(p.id, p.display_name);
    });

    // 4. Build notification objects
    const notifications: AppNotification[] = [];

    for (const match of matches) {
      const derivedId = `${DERIVED_ID_PREFIX}${match.id}`;

      // Skip dismissed notifications
      if (dismissedIds.has(derivedId)) continue;

      const otherUserId = match.user1_id === userId ? match.user2_id : match.user1_id;
      const otherName = nameMap.get(otherUserId) || 'Someone';
      const isCreator = match.user1_id === userId;

      const notification: AppNotification = {
        id: derivedId,
        user_id: userId,
        type: isCreator ? 'crush_code_redeemed' : 'new_match',
        title: isCreator ? 'Crush Code Redeemed' : 'New Connection',
        body: isCreator
          ? `${otherName} used your Crush Code. You have a new connection.`
          : `You connected with ${otherName}. Start a conversation when you're ready.`,
        data: { url: '/dashboard', match_id: match.id, other_user_id: otherUserId },
        read: readIds.has(derivedId),
        created_at: match.confirmed_at || match.created_at || new Date().toISOString(),
      };

      notifications.push(notification);
    }

    return notifications;
  } catch (err) {
    console.error('[Notifications] Error deriving notifications from matches:', err);
    return [];
  }
};


// Send a notification (calls edge function) - LEGACY, may not work
// Kept for backward compatibility but createNotificationDirect is preferred
export const sendNotification = async (
  userId: string,
  type: NotificationType,
  data?: Record<string, any>
): Promise<boolean> => {
  try {
    const { error } = await supabase.functions.invoke('send-push-notification', {
      body: {
        user_id: userId,
        notification: { type, data }
      }
    });

    if (error) {
      console.error('Error sending notification:', error);
      return false;
    }

    return true;
  } catch (error) {
    console.error('Error sending notification:', error);
    return false;
  }
};

// Show local notification (fallback when push not available)
export const showLocalNotification = (
  title: string,
  body: string,
  icon?: string,
  tag?: string
): void => {
  if (getNotificationPermission() !== 'granted') return;

  const notification = new Notification(title, {
    body,
    icon: icon || '/dwadido-icon.png',
    tag,
    badge: '/dwadido-badge.png',
    vibrate: [200, 100, 200],
    requireInteraction: false,
  });

  notification.onclick = () => {
    window.focus();
    notification.close();
  };
};

// Helper function to convert VAPID key
function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

// Initialize notifications on app load
export const initializeNotifications = async (userId: string): Promise<void> => {
  if (!isPushSupported()) {
    console.log('Push notifications not supported in this browser');
    return;
  }

  // Register service worker
  await registerServiceWorker();

  // Check if permission already granted
  if (getNotificationPermission() === 'granted') {
    await subscribeToPush(userId);
  }
};

// Subscribe to real-time notifications
export const subscribeToNotifications = (
  userId: string,
  onNotification: (notification: AppNotification) => void
) => {
  const channel = supabase
    .channel(`notifications:${userId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${userId}`
      },
      (payload) => {
        onNotification(payload.new as AppNotification);
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
};
