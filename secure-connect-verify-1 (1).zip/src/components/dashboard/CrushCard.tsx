import React, { useState } from 'react';
import { Copy, Check, Clock, Share2, Trash2 } from 'lucide-react';
import CrushCodeShare from './CrushCodeShare';

interface ShareStats {
  total: number;
  twitter: number;
  facebook: number;
  whatsapp: number;
  email: number;
  link_copies: number;
  time_limited: number;
}

interface CrushCardProps {
  card: {
    id: string;
    code: string;
    status: string;
    expires_at: string;
    created_at: string;
    total_shares?: number;
    twitter_shares?: number;
    facebook_shares?: number;
    whatsapp_shares?: number;
    email_shares?: number;
    link_copies?: number;
    time_limited_shares?: number;
  };
  onDelete?: (id: string) => void;
}

const CrushCard: React.FC<CrushCardProps> = ({ card, onDelete }) => {
  const [copied, setCopied] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareStats, setShareStats] = useState<ShareStats>({
    total: card.total_shares || 0,
    twitter: card.twitter_shares || 0,
    facebook: card.facebook_shares || 0,
    whatsapp: card.whatsapp_shares || 0,
    email: card.email_shares || 0,
    link_copies: card.link_copies || 0,
    time_limited: card.time_limited_shares || 0
  });


  const expiresAt = new Date(card.expires_at);
  const now = new Date();
  const hoursLeft = Math.max(0, Math.floor((expiresAt.getTime() - now.getTime()) / (1000 * 60 * 60)));
  const isExpired = expiresAt < now || card.status === 'expired';
  const isRedeemed = card.status === 'redeemed';

  const handleCopy = async () => {
    await navigator.clipboard.writeText(card.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    setShowShareModal(true);
  };

  const handleShareTracked = (stats: ShareStats) => {
    setShareStats(stats);
  };

  const getStatusColor = () => {
    if (isRedeemed) return 'from-gold to-gold-400';
    if (isExpired) return 'from-charcoal-500 to-charcoal-600';
    return 'from-gold to-gold-400';
  };

  const getStatusBadge = () => {
    if (isRedeemed) return { text: 'Verified', color: 'bg-gold/20 text-gold', stage: 'Stage 3' };
    if (isExpired) return { text: 'Expired', color: 'bg-charcoal-500 text-gray-400', stage: 'Closed' };
    return { text: 'Active', color: 'bg-gold/20 text-gold', stage: 'Stage 1' };
  };

  const status = getStatusBadge();

  return (
    <>
      <div className="relative group">
        {!isExpired && !isRedeemed && (
          <div className="absolute inset-0 bg-gold/20 rounded-2xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity" />
        )}
        
        <div className="relative bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
          {/* Card header */}
          <div className={`h-1 bg-gradient-to-r ${getStatusColor()}`} />
          
          <div className="p-6">
            {/* Status badge */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${status.color}`}>
                  {status.text}
                </span>
                <span className="text-xs text-gray-500">{status.stage}</span>
              </div>
              <div className="flex items-center gap-3">
                {shareStats.total > 0 && (
                  <div className="flex items-center gap-1 text-gold text-sm" title={`Shared ${shareStats.total} times`}>
                    <Share2 className="w-3.5 h-3.5" />
                    <span className="text-xs">{shareStats.total}</span>
                  </div>
                )}
                {!isExpired && !isRedeemed && (
                  <div className="flex items-center gap-1 text-gray-400 text-sm">
                    <Clock className="w-4 h-4" />
                    <span>{hoursLeft}h left</span>
                  </div>
                )}
              </div>
            </div>

            {/* Code display */}
            <div className="bg-charcoal-600 rounded-xl p-4 mb-4">
              <p className="text-xs text-gray-500 text-center mb-2">CRUSH CODE</p>

              <div className="font-mono text-3xl font-bold text-center tracking-[0.3em] text-white">
                {card.code}
              </div>
            </div>

            {/* Actions */}
            {!isExpired && !isRedeemed && (
              <div className="flex gap-2">
                <button
                  onClick={handleCopy}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-charcoal-600 hover:bg-charcoal-500 text-gray-300 rounded-xl font-medium transition-all"
                >
                  {copied ? <Check className="w-4 h-4 text-gold" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied!' : 'Copy'}
                </button>
                <button
                  onClick={handleShare}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-gold hover:bg-gold-400 text-charcoal rounded-xl font-semibold transition-all"
                >
                  <Share2 className="w-4 h-4" />
                  Share
                </button>
              </div>
            )}

            {/* Redeemed info */}
            {isRedeemed && (
              <div className="flex items-center justify-center gap-2 py-2.5 bg-gold/10 text-gold rounded-xl font-medium">
                <Check className="w-4 h-4" />
                Connection Verified
              </div>
            )}

            {/* Delete button for expired cards */}
            {isExpired && !isRedeemed && onDelete && (
              <button
                onClick={() => onDelete(card.id)}
                className="w-full flex items-center justify-center gap-2 py-2.5 text-gray-500 hover:text-red-400 hover:bg-red-500/10 rounded-xl font-medium transition-all"
              >
                <Trash2 className="w-4 h-4" />
                Remove from history
              </button>
            )}
          </div>

          {/* Decorative elements */}
          <div className="absolute top-4 right-4 w-24 h-24 bg-gold/5 rounded-full blur-2xl" />
        </div>
      </div>

      {/* Share Modal */}
      <CrushCodeShare
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        code={card.code}
        codeId={card.id}
        initialStats={shareStats}
        onShareTracked={handleShareTracked}
      />
    </>
  );
};

export default CrushCard;
