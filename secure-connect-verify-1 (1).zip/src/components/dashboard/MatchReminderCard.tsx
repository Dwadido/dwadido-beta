import React, { useState } from 'react';
import { Heart, Coffee, MessageCircle, X, ChevronRight } from 'lucide-react';

/**
 * DWADIDO DESIGN PHILOSOPHY - MATCH REMINDER CARD
 * 
 * Match reminders must be:
 * - Optional (user-controlled)
 * - Low-frequency
 * - Supportive, not pushy
 * 
 * Rules:
 * - No "You haven't replied" guilt prompts
 * - No countdown timers
 * - No engagement pressure
 * 
 * Allowed reminder style:
 * Gentle, context-based nudges that encourage clarity or offline action.
 * 
 * Example:
 * "You matched with someone whose intentions align with yours. 
 *  If it feels right, this could be a good time to suggest meeting."
 * 
 * Reminders should respect user autonomy and never create pressure.
 */

interface MatchReminderData {
  id: string;
  matchId: string;
  connectionName: string;
  connectionAvatar?: string | null;
  sharedIntentions?: string[];
  communicationStyle?: string;
  sharedInterests?: string[];
  lastInteraction?: string;
}

interface MatchReminderCardProps {
  reminder: MatchReminderData;
  style?: 'gentle' | 'minimal';
  encourageOffline?: boolean;
  onDismiss?: (id: string) => void;
  onOpenChat?: (matchId: string) => void;
  onSuggestMeeting?: (matchId: string) => void;
}

// Generate context-based explanation for WHY this reminder exists
const generateReminderExplanation = (reminder: MatchReminderData, style: 'gentle' | 'minimal'): string => {
  if (style === 'minimal') {
    return `You have a connection with ${reminder.connectionName || 'someone'} you haven't chatted with recently.`;
  }

  const explanations: string[] = [];

  // Intent alignment
  if (reminder.sharedIntentions && reminder.sharedIntentions.length > 0) {
    explanations.push('your relationship intentions align');
  }

  // Communication style compatibility
  if (reminder.communicationStyle) {
    const styleDescriptions: Record<string, string> = {
      'direct': 'your communication styles suggest straightforward conversations may feel natural',
      'thoughtful': 'your communication styles suggest deeper conversations may feel natural',
      'casual': 'your communication styles suggest relaxed conversations may feel natural',
      'in-person': 'your communication styles suggest in-person meetings may feel natural'
    };
    if (styleDescriptions[reminder.communicationStyle]) {
      explanations.push(styleDescriptions[reminder.communicationStyle]);
    }
  }

  // Shared interests
  if (reminder.sharedInterests && reminder.sharedInterests.length > 0) {
    if (reminder.sharedInterests.length === 1) {
      explanations.push(`you both share an interest in ${reminder.sharedInterests[0]}`);
    } else {
      explanations.push(`you share interests in ${reminder.sharedInterests.slice(0, 2).join(' and ')}`);
    }
  }

  // Build the full explanation
  if (explanations.length === 0) {
    return `You have a connection with ${reminder.connectionName || 'someone'}. Take your time getting to know each other.`;
  }

  const connectionPart = `You connected with ${reminder.connectionName || 'someone'}`;
  const explanationPart = explanations.length === 1 
    ? explanations[0]
    : explanations.slice(0, -1).join(', ') + ', and ' + explanations[explanations.length - 1];

  return `${connectionPart} because ${explanationPart}.`;
};

// Generate gentle offline meeting suggestion
const generateOfflineSuggestion = (reminder: MatchReminderData): string => {
  const suggestions = [
    'If it feels right, this could be a good time to suggest meeting.',
    'When you\'re ready, consider suggesting a place to meet in person.',
    'Take your time. If you\'d like, you could suggest meeting for coffee.',
    'There\'s no rush. When it feels natural, you might suggest meeting up.'
  ];

  // Use a deterministic selection based on match ID
  const index = reminder.matchId.charCodeAt(0) % suggestions.length;
  return suggestions[index];
};

const MatchReminderCard: React.FC<MatchReminderCardProps> = ({
  reminder,
  style = 'gentle',
  encourageOffline = true,
  onDismiss,
  onOpenChat,
  onSuggestMeeting
}) => {
  const [isDismissed, setIsDismissed] = useState(false);

  const handleDismiss = () => {
    setIsDismissed(true);
    setTimeout(() => {
      onDismiss?.(reminder.id);
    }, 300);
  };

  if (isDismissed) {
    return null;
  }

  const explanation = generateReminderExplanation(reminder, style);
  const offlineSuggestion = encourageOffline ? generateOfflineSuggestion(reminder) : null;

  return (
    <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden transition-all duration-300">
      {/* Header - minimal, calm design */}
      <div className="p-4 border-b border-charcoal-600/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Avatar or placeholder */}
            <div className="w-12 h-12 rounded-full bg-charcoal-600 flex items-center justify-center overflow-hidden">
              {reminder.connectionAvatar ? (
                <img 
                  src={reminder.connectionAvatar} 
                  alt="" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <Heart className="w-5 h-5 text-gold/60" />
              )}
            </div>
            <div>
              <p className="font-medium text-white">
                {reminder.connectionName || 'A Connection'}
              </p>
              <p className="text-xs text-gray-500">Connection reminder</p>
            </div>
          </div>
          
          {/* Dismiss button - subtle, not prominent */}
          <button
            onClick={handleDismiss}
            className="p-2 text-gray-500 hover:text-gray-400 hover:bg-charcoal-600 rounded-lg transition-colors"
            aria-label="Dismiss reminder"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main content - the explanation is more important than the alert */}
      <div className="p-4 space-y-4">
        {/* Primary explanation - WHY the match exists */}
        <p className="text-gray-300 leading-relaxed">
          {explanation}
        </p>

        {/* Shared interests pills (if gentle style) */}
        {style === 'gentle' && reminder.sharedInterests && reminder.sharedInterests.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {reminder.sharedInterests.slice(0, 3).map((interest, index) => (
              <span 
                key={index}
                className="px-3 py-1 bg-charcoal-600 text-gray-400 text-xs rounded-full"
              >
                {interest}
              </span>
            ))}
          </div>
        )}

        {/* Offline meeting suggestion - gentle, not pushy */}
        {encourageOffline && offlineSuggestion && (
          <div className="p-3 bg-gold/5 border border-gold/10 rounded-xl">
            <div className="flex items-start gap-2">
              <Coffee className="w-4 h-4 text-gold/70 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-gray-400 leading-relaxed">
                {offlineSuggestion}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Actions - subtle, not prominent */}
      <div className="px-4 pb-4">
        <div className="flex items-center gap-3">
          {/* Primary action - open chat */}
          <button
            onClick={() => onOpenChat?.(reminder.matchId)}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-3 bg-charcoal-600 hover:bg-charcoal-500 text-gray-300 hover:text-white rounded-xl transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span className="text-sm font-medium">View Conversation</span>
          </button>

          {/* Secondary action - suggest meeting (if enabled) */}
          {encourageOffline && onSuggestMeeting && (
            <button
              onClick={() => onSuggestMeeting?.(reminder.matchId)}
              className="flex items-center justify-center gap-2 px-4 py-3 bg-gold/10 hover:bg-gold/20 text-gold rounded-xl transition-colors"
            >
              <Coffee className="w-4 h-4" />
              <span className="text-sm font-medium">Suggest Meeting</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Footer note - respecting autonomy */}
      <div className="px-4 pb-4">
        <p className="text-xs text-gray-600 text-center">
          Take your time. There's no pressure to respond.
        </p>
      </div>
    </div>
  );
};

export default MatchReminderCard;
