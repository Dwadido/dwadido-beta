import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Crown,
  Infinity,
  RefreshCw,
  BarChart3,
  Layers,
  Printer,
  Clock,
  X,
  Sparkles,
  Heart,
  Bell,
  Mail,
  Link2,
  History,
  BadgeCheck,
  Shield,
  QrCode,
  TrendingUp,
  MousePointer,
  Palette,
  Timer,
  MessageSquare,
  Smartphone,
  AlertCircle
} from 'lucide-react';

// All possible trigger types for the upsell modal

export type UpsellTrigger = 
  // Code features
  | 'code_limit'
  | 'renewal'
  | 'bulk'
  | 'expired'
  // Printing & QR
  | 'printing'
  | 'card_templates'
  | 'qr_scan_history'
  | 'print_analytics'
  | 'animated_qr'
  // Analytics
  | 'analytics'
  | 'code_analytics'
  | 'match_analytics'
  | 'match_insights'
  | 'verification_analytics'
  // Notifications
  | 'notifications'
  | 'push_notifications'
  | 'email_notifications'
  | 'sms_notifications'
  | 'match_reminders'
  | 'offline_alerts'
  | 'email_template_editor'
  | 'digest_settings'
  // Sharing
  | 'link_history'
  | 'link_tracking'
  | 'time_limited_links'
  | 'share_preview'
  | 'referral_rewards'
  // Verification
  | 'verification'
  | 'age_verification'
  | 'verification_history';






interface FreemiumUpsellProps {
  isOpen: boolean;
  onClose: () => void;
  trigger: UpsellTrigger;
  expiredCode?: string;
}

const UPSELL_CONTENT: Record<UpsellTrigger, {
  title: string;
  description: string;
  icon: React.ElementType;
  iconColor: string;
  highlight: string;
}> = {
  // Code features
  code_limit: {
    title: 'You\'ve Used Your Free Code',
    description: 'Free users get one Crush Code to experience a real connection. Ready for more?',
    icon: Heart,
    iconColor: 'text-pink-400',
    highlight: 'Unlock unlimited codes with Premium'
  },
  renewal: {
    title: 'Code Renewal is Premium',
    description: 'Your code has expired. Premium members can renew expired codes instantly.',
    icon: RefreshCw,
    iconColor: 'text-blue-400',
    highlight: 'Never lose a connection again'
  },
  bulk: {
    title: 'Bulk Code Generation',
    description: 'Generate up to 20 codes at once - perfect for events, networking, or sharing with groups.',
    icon: Layers,
    iconColor: 'text-purple-400',
    highlight: 'Create multiple codes instantly'
  },
  expired: {
    title: 'Your Code Has Expired',
    description: 'Free codes expire after 7 days. Premium codes last longer and can be renewed.',
    icon: Clock,
    iconColor: 'text-orange-400',
    highlight: 'Extend validity up to 90 days'
  },
  
  // Printing & QR
  printing: {
    title: 'QR Code Printing',
    description: 'Create beautiful printable business cards with your QR code for offline sharing.',
    icon: Printer,
    iconColor: 'text-cyan-400',
    highlight: 'Professional cards & postcards'
  },
  card_templates: {
    title: 'Card Templates',
    description: 'Choose from 8+ professional card designs and color themes for your printed cards.',
    icon: Palette,
    iconColor: 'text-pink-400',
    highlight: 'Beautiful designs that stand out'
  },
  qr_scan_history: {
    title: 'QR Scan History',
    description: 'Track when and where your QR codes are scanned to understand your reach.',
    icon: History,
    iconColor: 'text-indigo-400',
    highlight: 'See every scan with timestamps'
  },
  print_analytics: {
    title: 'Print Analytics',
    description: 'Track how many cards you\'ve printed and their conversion rates.',
    icon: BarChart3,
    iconColor: 'text-green-400',
    highlight: 'Optimize your offline sharing'
  },
  animated_qr: {
    title: 'Animated QR Codes',
    description: 'Create eye-catching animated QR codes that stand out and grab attention.',
    icon: QrCode,
    iconColor: 'text-purple-400',
    highlight: 'Make your QR codes unforgettable'
  },

  // Analytics

  analytics: {
    title: 'Analytics Dashboard',
    description: 'Track who\'s scanning your codes, when, and where. Get insights to improve your connections.',
    icon: BarChart3,
    iconColor: 'text-green-400',
    highlight: 'See detailed scan & share analytics'
  },
  code_analytics: {
    title: 'Code Analytics',
    description: 'Track scans, shares, timestamps, and conversion rates for all your codes.',
    icon: BarChart3,
    iconColor: 'text-green-400',
    highlight: 'Understand your code performance'
  },
  match_analytics: {
    title: 'Match Analytics',
    description: 'Understand your matching patterns, success rates, and connection trends.',
    icon: TrendingUp,
    iconColor: 'text-blue-400',
    highlight: 'Optimize your matching strategy'
  },
  match_insights: {
    title: 'Match Insights',
    description: 'Get AI-powered explanations about why connections make sense and what to do next.',
    icon: Sparkles,
    iconColor: 'text-yellow-400',
    highlight: 'AI explains your connections in plain language'
  },



  verification_analytics: {
    title: 'Verification Analytics',
    description: 'Track your verification status and see how it affects your matches.',
    icon: BadgeCheck,
    iconColor: 'text-gold',
    highlight: 'Understand verification impact'
  },
  
  // Notifications - Calm, supportive language (no urgency)
  notifications: {
    title: 'Notifications',
    description: 'Stay informed about your connections with customizable alerts.',
    icon: Bell,
    iconColor: 'text-yellow-400',
    highlight: 'Stay connected on your terms'
  },
  push_notifications: {
    title: 'Push Notifications',
    description: 'Get updates on your device when someone connects with you.',
    icon: Bell,
    iconColor: 'text-yellow-400',
    highlight: 'Convenient connection alerts'
  },
  email_notifications: {
    title: 'Email Notifications',
    description: 'Receive email updates about your matches and messages.',
    icon: Mail,
    iconColor: 'text-red-400',
    highlight: 'Customizable email alerts'
  },
  sms_notifications: {
    title: 'SMS Notifications',
    description: 'Get text message alerts for important updates.',
    icon: Smartphone,
    iconColor: 'text-green-400',
    highlight: 'Stay informed via text'
  },
  match_reminders: {
    title: 'Connection Reminders',
    description: 'Optional, gentle reminders about your connections when you want them.',
    icon: Clock,
    iconColor: 'text-purple-400',
    highlight: 'Supportive reminders on your schedule'
  },
  offline_alerts: {
    title: 'Offline Message Alerts',
    description: 'Get notified about messages you received while offline.',
    icon: MessageSquare,
    iconColor: 'text-blue-400',
    highlight: 'Catch up on missed messages'
  },

  email_template_editor: {
    title: 'Email Template Editor',
    description: 'Customize the wording and tone of your notification emails within system limits.',
    icon: Mail,
    iconColor: 'text-purple-400',
    highlight: 'Personalize your email communications'
  },
  digest_settings: {
    title: 'Digest Settings Control',
    description: 'Full control over notification frequency and event-level preferences.',
    icon: Clock,
    iconColor: 'text-indigo-400',
    highlight: 'Fine-tune when and how you\'re notified'
  },


  // Sharing
  link_history: {
    title: 'Link History',
    description: 'View and manage all your shared links, including time-limited ones.',
    icon: History,
    iconColor: 'text-indigo-400',
    highlight: 'Track all your shared links'
  },
  link_tracking: {
    title: 'Link Click Tracking',
    description: 'See who clicked your shared links and when.',
    icon: MousePointer,
    iconColor: 'text-cyan-400',
    highlight: 'Detailed click analytics'
  },
  time_limited_links: {
    title: 'Time-Limited Links',
    description: 'Create links that automatically expire after 1, 6, or 24 hours.',
    icon: Timer,
    iconColor: 'text-purple-400',
    highlight: 'Control your link lifespan'
  },
  share_preview: {
    title: 'Share Link Preview',
    description: 'Customize how your links appear when shared on social media.',
    icon: Link2,
    iconColor: 'text-blue-400',
    highlight: 'Beautiful social previews'
  },
  referral_rewards: {
    title: 'Referral Rewards',
    description: 'Earn rewards when you refer friends to Dwadido. Share your unique link and get benefits!',
    icon: Sparkles,
    iconColor: 'text-gold',
    highlight: 'Earn rewards for sharing Dwadido'
  },


  
  // Verification
  verification: {
    title: 'Profile Verification',
    description: 'Get verified to build trust and increase your visibility to potential matches.',
    icon: BadgeCheck,
    iconColor: 'text-gold',
    highlight: 'Build trust with verification'
  },
  age_verification: {
    title: 'Age Verification Badge',
    description: 'Display a verified age badge on your profile to build trust.',
    icon: Shield,
    iconColor: 'text-green-400',
    highlight: 'Show you\'re who you say you are'
  },
  verification_history: {
    title: 'Verification History',
    description: 'View your verification history and status changes.',
    icon: History,
    iconColor: 'text-indigo-400',
    highlight: 'Track your verification journey'
  },
};

// Benefits shown in the upsell modal, organized by category
const PREMIUM_BENEFITS_BY_CATEGORY = {
  codes: [
    { icon: Infinity, text: 'Unlimited code creation' },
    { icon: RefreshCw, text: 'Renew expired codes' },
    { icon: Layers, text: 'Bulk code generation' },
  ],
  printing: [
    { icon: Printer, text: 'Print QR cards' },
    { icon: Palette, text: 'Card templates' },
    { icon: History, text: 'Print history' },
  ],
  analytics: [
    { icon: BarChart3, text: 'Full analytics dashboard' },
    { icon: TrendingUp, text: 'Match insights' },
    // V1 REMOVED: 'AI-powered tips' - coaching/quality tips not allowed
  ],

  notifications: [
    { icon: Bell, text: 'Push notifications' },
    { icon: Mail, text: 'Email alerts' },
    { icon: Clock, text: 'Expiration reminders' },
  ],
  sharing: [
    { icon: Link2, text: 'Time-limited links' },
    { icon: History, text: 'Link history' },
    { icon: MousePointer, text: 'Click tracking' },
  ],
  verification: [
    { icon: BadgeCheck, text: 'Profile verification' },
    { icon: Shield, text: 'Age verification badge' },
    { icon: Sparkles, text: 'Priority processing' },
  ],
};

// Map triggers to their relevant benefit category
const getTriggerCategory = (trigger: UpsellTrigger): keyof typeof PREMIUM_BENEFITS_BY_CATEGORY => {
  if (['code_limit', 'renewal', 'bulk', 'expired'].includes(trigger)) return 'codes';
  if (['printing', 'card_templates', 'qr_scan_history', 'print_analytics', 'animated_qr'].includes(trigger)) return 'printing';
  if (['analytics', 'code_analytics', 'match_analytics', 'match_insights', 'verification_analytics'].includes(trigger)) return 'analytics';
  if (['notifications', 'push_notifications', 'email_notifications', 'sms_notifications', 'match_reminders', 'offline_alerts', 'email_template_editor', 'digest_settings'].includes(trigger)) return 'notifications';
  if (['link_history', 'link_tracking', 'time_limited_links', 'share_preview', 'referral_rewards'].includes(trigger)) return 'sharing';
  return 'verification';
};


const FreemiumUpsell: React.FC<FreemiumUpsellProps> = ({
  isOpen,
  onClose,
  trigger,
  expiredCode
}) => {
  const navigate = useNavigate();
  const content = UPSELL_CONTENT[trigger];
  const IconComponent = content.icon;
  const category = getTriggerCategory(trigger);
  const benefits = PREMIUM_BENEFITS_BY_CATEGORY[category];

  if (!isOpen) return null;

  const handleUpgrade = () => {
    onClose();
    navigate('/premium');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-charcoal-800 rounded-2xl border border-charcoal-600 overflow-hidden animate-in fade-in zoom-in duration-200">
        {/* Close Button */}
        <div className="flex justify-end p-3">
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="px-6 pb-6">
          {/* Icon */}
          <div className="flex justify-center mb-4">
            <div className={`w-16 h-16 bg-gradient-to-br from-gold/20 to-gold/5 rounded-2xl flex items-center justify-center`}>
              <IconComponent className={`w-8 h-8 ${content.iconColor}`} />
            </div>
          </div>

          {/* Title & Description */}
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-white mb-2">{content.title}</h2>
            <p className="text-gray-400 text-sm">{content.description}</p>
            {expiredCode && (
              <div className="mt-3 px-4 py-2 bg-charcoal-700 rounded-lg inline-block">
                <span className="text-xs text-gray-500">Code: </span>
                <span className="font-mono font-bold text-white">{expiredCode}</span>
              </div>
            )}
          </div>

          {/* Highlight */}
          <div className="bg-gradient-to-r from-gold/10 to-gold/5 rounded-xl p-4 mb-6 border border-gold/20">
            <div className="flex items-center gap-3">
              <Sparkles className="w-5 h-5 text-gold flex-shrink-0" />
              <p className="text-gold font-medium text-sm">{content.highlight}</p>
            </div>
          </div>

          {/* Premium Benefits */}
          <div className="mb-6">
            <p className="text-xs text-gray-500 uppercase tracking-wide mb-3">Premium includes:</p>
            <div className="grid grid-cols-1 gap-2">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-3 p-2 bg-charcoal-700/50 rounded-lg">
                  <benefit.icon className="w-4 h-4 text-gold flex-shrink-0" />
                  <span className="text-sm text-gray-300">{benefit.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Free vs Premium comparison */}
          <div className="mb-6 p-4 bg-charcoal-700/30 rounded-xl border border-charcoal-600">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wide mb-2">Free</p>
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-gray-500" />
                  <span className="text-sm text-gray-400">Limited access</span>
                </div>
              </div>
              <div>
                <p className="text-xs text-gold uppercase tracking-wide mb-2">Premium</p>
                <div className="flex items-center gap-2">
                  <Crown className="w-4 h-4 text-gold" />
                  <span className="text-sm text-white">Full access</span>
                </div>
              </div>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="space-y-3">
            <button
              onClick={handleUpgrade}
              className="w-full py-3.5 bg-gradient-to-r from-gold to-gold-400 hover:from-gold-400 hover:to-gold text-charcoal font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-gold/20"
            >
              <Crown className="w-5 h-5" />
              Upgrade to Premium
            </button>
            <button
              onClick={onClose}
              className="w-full py-2.5 text-gray-400 hover:text-white text-sm transition-colors"
            >
              Maybe Later
            </button>
          </div>

          {/* Pricing Hint */}
          <p className="text-center text-xs text-gray-500 mt-4">
            Starting at $9.99/month • Cancel anytime
          </p>
        </div>
      </div>
    </div>
  );
};

export default FreemiumUpsell;
