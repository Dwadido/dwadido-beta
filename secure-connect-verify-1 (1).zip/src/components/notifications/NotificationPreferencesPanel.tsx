import React, { useState, useEffect } from 'react';
import { 
  Bell, BellOff, Smartphone, Heart, MessageSquare, User, Camera, Calendar, 
  BadgeCheck, Loader2, Check, AlertCircle, Settings, Volume2, VolumeX,
  Clock, Zap, Shield, Crown, Lock, CheckCircle
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useNotifications } from '@/contexts/NotificationContext';
import { usePremium } from '@/contexts/PremiumContext';
import {
  isPushSupported,
  getNotificationPermission,
  requestNotificationPermission,
  subscribeToPush,
  unsubscribeFromPush,
  NotificationPreferences,
} from '@/lib/notifications';
import FreemiumUpsell, { UpsellTrigger } from '@/components/dashboard/FreemiumUpsell';

interface NotificationPreferencesPanelProps {
  compact?: boolean;
}

const NotificationPreferencesPanel: React.FC<NotificationPreferencesPanelProps> = ({ compact = false }) => {
  const { user } = useAuth();
  const { preferences, updatePreferences } = useNotifications();
  const { isPremium, canUseFeature } = usePremium();
  const [pushPermission, setPushPermission] = useState<NotificationPermission>('default');
  const [isLoading, setIsLoading] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  
  // Upsell modal state
  const [upsellModal, setUpsellModal] = useState<{
    isOpen: boolean;
    trigger: UpsellTrigger;
  }>({ isOpen: false, trigger: 'notifications' });

  useEffect(() => {
    setPushPermission(getNotificationPermission());
  }, []);

  // ==========================================================================
  // FEATURE TIER CHECKS
  // Basic Match Alerts: FREE (simple notification)
  // Advanced Notifications: PREMIUM (push, SMS, email, history, reminders)
  // ==========================================================================
  const canAccessBasicMatchAlerts = canUseFeature('basicMatchAlerts'); // FREE
  const canAccessAdvancedNotifications = canUseFeature('pushNotifications'); // PREMIUM

  const handleEnablePush = async () => {
    // Gate for premium (push notifications are premium)
    if (!canAccessAdvancedNotifications) {
      setUpsellModal({ isOpen: true, trigger: 'push_notifications' });
      return;
    }
    
    if (!user) return;
    setIsLoading(true);

    try {
      const permission = await requestNotificationPermission();
      setPushPermission(permission);

      if (permission === 'granted') {
        await subscribeToPush(user.id);
        await updatePreferences({ push_enabled: true });
      }
    } catch (error) {
      console.error('Error enabling push:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDisablePush = async () => {
    if (!user) return;
    setIsLoading(true);

    try {
      await unsubscribeFromPush(user.id);
      await updatePreferences({ push_enabled: false });
    } catch (error) {
      console.error('Error disabling push:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePreferenceChange = async (key: keyof NotificationPreferences, value: boolean) => {
    // Gate for premium on advanced notifications
    if (!canAccessAdvancedNotifications) {
      setUpsellModal({ isOpen: true, trigger: 'notifications' });
      return;
    }
    
    setSaveStatus('saving');
    await updatePreferences({ [key]: value });
    setSaveStatus('saved');
    setTimeout(() => setSaveStatus('idle'), 2000);
  };

  const Toggle = ({ 
    enabled, 
    onChange, 
    disabled = false,
    locked = false
  }: { 
    enabled: boolean; 
    onChange: () => void; 
    disabled?: boolean;
    locked?: boolean;
  }) => (
    <button
      onClick={onChange}
      disabled={disabled}
      className={`relative w-11 h-6 rounded-full transition-all ${
        locked ? 'bg-charcoal-600' : enabled ? 'bg-gold' : 'bg-charcoal-500'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
    >
      {locked ? (
        <div className="absolute inset-0 flex items-center justify-center">
          <Lock className="w-3 h-3 text-gray-500" />
        </div>
      ) : (
        <div
          className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow-md transform transition-transform ${
            enabled ? 'translate-x-5' : 'translate-x-0.5'
          }`}
        />
      )}
    </button>
  );


  const notificationTypes = [
    {
      key: 'new_match' as keyof NotificationPreferences,
      icon: Heart,
      iconColor: 'text-pink-400',
      iconBg: 'bg-pink-500/20',
      title: 'New Matches',
      description: 'When you match with someone new',
    },
    {
      key: 'new_message' as keyof NotificationPreferences,
      icon: MessageSquare,
      iconColor: 'text-blue-400',
      iconBg: 'bg-blue-500/20',
      title: 'New Messages',
      description: 'When you receive a message',
    },
    {
      key: 'crush_code_redeemed' as keyof NotificationPreferences,
      icon: User,
      iconColor: 'text-gold',
      iconBg: 'bg-gold/20',
      title: 'Crush Code Redeemed',
      description: 'When someone uses your crush code',
    },
    {
      key: 'photo_request' as keyof NotificationPreferences,
      icon: Camera,
      iconColor: 'text-purple-400',
      iconBg: 'bg-purple-500/20',
      title: 'Photo Requests',
      description: 'When someone requests your photos',
    },
    {
      key: 'photo_request_response' as keyof NotificationPreferences,
      icon: Camera,
      iconColor: 'text-purple-400',
      iconBg: 'bg-purple-500/20',
      title: 'Photo Request Responses',
      description: 'When your photo request is answered',
    },
    {
      key: 'meeting_suggestion' as keyof NotificationPreferences,
      icon: Calendar,
      iconColor: 'text-green-400',
      iconBg: 'bg-green-500/20',
      title: 'Meeting Suggestions',
      description: 'When someone suggests a meeting',
    },
    {
      key: 'meeting_response' as keyof NotificationPreferences,
      icon: Calendar,
      iconColor: 'text-green-400',
      iconBg: 'bg-green-500/20',
      title: 'Meeting Responses',
      description: 'When your meeting suggestion is answered',
    },
    {
      key: 'verification_update' as keyof NotificationPreferences,
      icon: BadgeCheck,
      iconColor: 'text-gold',
      iconBg: 'bg-gold/20',
      title: 'Verification Updates',
      description: 'When your verification status changes',
    },
  ];

  const pushSupported = isPushSupported();
  const isPushEnabled = preferences.push_enabled && pushPermission === 'granted';

  // Show locked state for free users (advanced notifications are premium)
  // Note: Basic match alerts are FREE, but push/SMS/email are PREMIUM
  if (!canAccessAdvancedNotifications) {
    return (
      <>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-white flex items-center gap-2">
                Notification Settings
                <Lock className="w-4 h-4 text-gray-500" />
              </h2>
              <p className="text-gray-400">Premium feature</p>
            </div>
            <span className="px-2 py-1 bg-gold/20 text-gold text-xs font-medium rounded-full flex items-center gap-1">
              <Crown className="w-3 h-3" />
              Premium
            </span>
          </div>

          {/* Locked Preview */}
          <div className="relative">
            <div className="opacity-30 blur-sm pointer-events-none">
              <div className="p-5 rounded-2xl border bg-charcoal-600 border-charcoal-500">
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-2xl flex items-center justify-center bg-charcoal-500">
                    <BellOff className="w-7 h-7 text-gray-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-white">Push Notifications</h3>
                    <p className="text-sm text-gray-400 mt-1">
                      Get instant alerts for matches, messages, and more.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Lock overlay */}
            <div 
              onClick={() => setUpsellModal({ isOpen: true, trigger: 'push_notifications' })}
              className="absolute inset-0 flex items-center justify-center bg-charcoal-800/80 backdrop-blur-sm cursor-pointer rounded-2xl"
            >
              <div className="text-center p-6">
                <div className="w-14 h-14 bg-gold/10 rounded-2xl flex items-center justify-center mx-auto mb-3">
                  <Bell className="w-7 h-7 text-gold" />
                </div>
                <p className="text-white font-medium mb-1">Notifications are Premium</p>
                <p className="text-sm text-gray-400 mb-3">Stay informed about your connections</p>

                <button className="px-4 py-2 bg-gold hover:bg-gold-400 text-charcoal font-medium rounded-lg transition-colors flex items-center gap-2 mx-auto">
                  <Crown className="w-4 h-4" />
                  Upgrade to Premium
                </button>
              </div>
            </div>
          </div>

          {/* Benefits list */}
          <div className="bg-charcoal-700 rounded-xl p-4 border border-charcoal-600">
            <p className="text-sm font-medium text-white mb-3">Premium notifications include:</p>
            <div className="space-y-2">
              {[
                { icon: Heart, text: 'New match alerts', color: 'text-pink-400' },
                { icon: MessageSquare, text: 'Message notifications', color: 'text-blue-400' },
                { icon: Clock, text: 'Match expiring reminders', color: 'text-orange-400' },
                { icon: BadgeCheck, text: 'Verification updates', color: 'text-gold' },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3 text-sm">
                  <item.icon className={`w-4 h-4 ${item.color}`} />
                  <span className="text-gray-300">{item.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <FreemiumUpsell
          isOpen={upsellModal.isOpen}
          onClose={() => setUpsellModal({ ...upsellModal, isOpen: false })}
          trigger={upsellModal.trigger}
        />
      </>
    );
  }

  if (compact) {
    return (
      <div className="space-y-4">
        {/* Push Status */}
        <div className="flex items-center justify-between p-4 bg-charcoal-600 rounded-xl">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              isPushEnabled ? 'bg-gold/20' : 'bg-charcoal-500'
            }`}>
              {isPushEnabled ? (
                <Bell className="w-5 h-5 text-gold" />
              ) : (
                <BellOff className="w-5 h-5 text-gray-400" />
              )}
            </div>
            <div>
              <p className="font-medium text-white">Push Notifications</p>
              <p className="text-sm text-gray-400">
                {!pushSupported 
                  ? 'Not supported'
                  : pushPermission === 'denied'
                    ? 'Blocked by browser'
                    : isPushEnabled
                      ? 'Enabled'
                      : 'Disabled'
                }
              </p>
            </div>
          </div>
          {pushSupported && pushPermission !== 'denied' && (
            <button
              onClick={isPushEnabled ? handleDisablePush : handleEnablePush}
              disabled={isLoading}
              className={`px-4 py-2 rounded-xl font-medium transition-all ${
                isPushEnabled
                  ? 'bg-charcoal-500 text-gray-300 hover:bg-charcoal-400'
                  : 'bg-gold text-charcoal hover:bg-gold-400'
              }`}
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : isPushEnabled ? 'Disable' : 'Enable'}
            </button>
          )}
        </div>

        {/* Quick toggles */}
        <div className="space-y-2">
          {notificationTypes.slice(0, 4).map((type) => (
            <div key={type.key} className="flex items-center justify-between py-2">
              <div className="flex items-center gap-2">
                <type.icon className={`w-4 h-4 ${type.iconColor}`} />
                <span className="text-sm text-gray-300">{type.title}</span>
              </div>
              <Toggle
                enabled={preferences[type.key] as boolean}
                onChange={() => handlePreferenceChange(type.key, !preferences[type.key])}
                disabled={!isPushEnabled}
              />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-white">Notification Settings</h2>
            <p className="text-gray-400">Choose how you want to be notified</p>
          </div>
          <div className="flex items-center gap-2">
            {saveStatus === 'saved' && (
              <div className="flex items-center gap-1.5 text-green-400 text-sm">
                <Check className="w-4 h-4" />
                Saved
              </div>
            )}
            <span className="px-2 py-1 bg-gold/20 text-gold text-xs font-medium rounded-full flex items-center gap-1">
              <Crown className="w-3 h-3" />
              Premium
            </span>
          </div>
        </div>

        {/* Push Notification Status Card */}
        <div className={`p-5 rounded-2xl border ${
          isPushEnabled 
            ? 'bg-gold/10 border-gold/30' 
            : 'bg-charcoal-600 border-charcoal-500'
        }`}>
          <div className="flex items-start gap-4">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${
              isPushEnabled ? 'bg-gold/20' : 'bg-charcoal-500'
            }`}>
              {isPushEnabled ? (
                <Bell className="w-7 h-7 text-gold" />
              ) : (
                <BellOff className="w-7 h-7 text-gray-400" />
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-white">Push Notifications</h3>
                {isPushEnabled && (
                  <span className="px-2 py-0.5 bg-gold/20 text-gold text-xs font-medium rounded-full">
                    Active
                  </span>
                )}
              </div>
              <p className="text-sm text-gray-400 mt-1">
                {!pushSupported 
                  ? 'Push notifications are not supported in this browser. Try using Chrome, Firefox, or Edge.'
                  : pushPermission === 'denied'
                    ? 'Notifications are blocked by your browser. To enable them, click the lock icon in your address bar and allow notifications.'
                    : isPushEnabled
                      ? 'You\'ll receive real-time alerts for matches, messages, and more.'
                      : 'Enable push notifications to get instant alerts when something important happens.'
                }
              </p>

              {pushSupported && pushPermission !== 'denied' && (
                <button
                  onClick={isPushEnabled ? handleDisablePush : handleEnablePush}
                  disabled={isLoading}
                  className={`mt-4 px-5 py-2.5 rounded-xl font-medium transition-all flex items-center gap-2 ${
                    isPushEnabled
                      ? 'bg-charcoal-500 text-gray-300 hover:bg-charcoal-400'
                      : 'bg-gold text-charcoal hover:bg-gold-400 shadow-gold'
                  }`}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      {isPushEnabled ? 'Disabling...' : 'Enabling...'}
                    </>
                  ) : isPushEnabled ? (
                    <>
                      <BellOff className="w-5 h-5" />
                      Disable Notifications
                    </>
                  ) : (
                    <>
                      <Bell className="w-5 h-5" />
                      Enable Notifications
                    </>
                  )}
                </button>
              )}

              {pushPermission === 'denied' && (
                <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm text-red-300 font-medium">Notifications Blocked</p>
                      <p className="text-xs text-red-400/70 mt-1">
                        To enable notifications, click the lock/info icon in your browser's address bar and change the notification setting to "Allow".
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Notification Types */}
        <div className="space-y-1">
          <h3 className="text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Notification Types
          </h3>

          <div className="bg-charcoal-600 rounded-2xl border border-charcoal-500 divide-y divide-charcoal-500">
            {notificationTypes.map((type) => (
              <div
                key={type.key}
                className={`flex items-center justify-between p-4 transition-colors ${
                  !isPushEnabled ? 'opacity-50' : ''
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${type.iconBg}`}>
                    <type.icon className={`w-5 h-5 ${type.iconColor}`} />
                  </div>
                  <div>
                    <p className="font-medium text-white">{type.title}</p>
                    <p className="text-sm text-gray-400">{type.description}</p>
                  </div>
                </div>
                <Toggle
                  enabled={preferences[type.key] as boolean}
                  onChange={() => handlePreferenceChange(type.key, !preferences[type.key])}
                  disabled={!isPushEnabled}
                />
              </div>
            ))}
          </div>

          {!isPushEnabled && (
            <p className="text-xs text-gray-500 mt-2 flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5" />
              Enable push notifications above to customize notification types
            </p>
          )}
        </div>

        {/* Quick Actions */}
        <div className="flex flex-wrap gap-3">
          <button
            onClick={async () => {
              const allEnabled: Partial<NotificationPreferences> = {};
              notificationTypes.forEach(t => {
                allEnabled[t.key] = true;
              });
              setSaveStatus('saving');
              await updatePreferences(allEnabled);
              setSaveStatus('saved');
              setTimeout(() => setSaveStatus('idle'), 2000);
            }}
            disabled={!isPushEnabled}
            className="px-4 py-2 text-sm font-medium text-gold hover:bg-gold/10 rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Enable All
          </button>
          <button
            onClick={async () => {
              const allDisabled: Partial<NotificationPreferences> = {};
              notificationTypes.forEach(t => {
                allDisabled[t.key] = false;
              });
              setSaveStatus('saving');
              await updatePreferences(allDisabled);
              setSaveStatus('saved');
              setTimeout(() => setSaveStatus('idle'), 2000);
            }}
            disabled={!isPushEnabled}
            className="px-4 py-2 text-sm font-medium text-gray-400 hover:text-white hover:bg-charcoal-600 rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Disable All
          </button>
        </div>

        {/* Info Box */}
        <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
          <div className="flex items-start gap-3">
            <Zap className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-blue-300 font-medium">Real-time Notifications</p>
              <p className="text-xs text-blue-400/70 mt-1">
                Push notifications are delivered instantly, even when you're not using the app. 
                You can also manage notification sounds and vibration in your device settings.
              </p>
            </div>
          </div>
        </div>
      </div>

      <FreemiumUpsell
        isOpen={upsellModal.isOpen}
        onClose={() => setUpsellModal({ ...upsellModal, isOpen: false })}
        trigger={upsellModal.trigger}
      />
    </>
  );
};

export default NotificationPreferencesPanel;
