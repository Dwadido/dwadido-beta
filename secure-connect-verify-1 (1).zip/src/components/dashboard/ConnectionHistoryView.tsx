import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { formatTimeCalm } from '@/lib/designGuidelines';
import { 
  Clock, 
  MessageCircle, 
  Users, 
  Archive, 
  ChevronDown, 
  ChevronUp,
  Edit3,
  Check,
  X
} from 'lucide-react';

/**
 * Connection History View
 * 
 * DESIGN PHILOSOPHY:
 * - Minimal, reflective, and user-controlled
 * - Help users reflect on what felt right, not optimize behavior
 * - Private, calm, and non-judgmental
 * 
 * ALLOWED:
 * - Simple timeline of past connections
 * - Optional notes written by the user
 * - Clear distinction between: Met in person, Chatted only, Closed/expired
 * 
 * NOT ALLOWED:
 * - Performance stats
 * - Match counts
 * - Response rate metrics
 * - AI judgments or summaries
 */

type ConnectionStatus = 'met_in_person' | 'chatted_only' | 'closed' | 'expired';

interface PastConnection {
  id: string;
  display_name: string;
  avatar_url: string | null;
  status: ConnectionStatus;
  connected_at: string;
  ended_at: string | null;
  user_note: string | null;
}

interface ConnectionHistoryViewProps {
  compact?: boolean;
}

const ConnectionHistoryView: React.FC<ConnectionHistoryViewProps> = ({ compact = false }) => {
  const { user } = useAuth();
  const [connections, setConnections] = useState<PastConnection[]>([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(!compact);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [noteText, setNoteText] = useState('');

  useEffect(() => {
    fetchConnectionHistory();
  }, [user]);

  const fetchConnectionHistory = async () => {
    if (!user) return;
    setLoading(true);

    try {
      // Fetch ended/expired matches
      const { data: matchesData, error } = await supabase
        .from('matches')
        .select('*')
        .or(`user1_id.eq.${user.id},user2_id.eq.${user.id}`)
        .in('status', ['ended', 'expired', 'closed'])
        .order('updated_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      if (matchesData && matchesData.length > 0) {
        // Fetch profiles for other users
        const connectionsWithProfiles = await Promise.all(
          matchesData.map(async (match) => {
            const otherUserId = match.user1_id === user.id ? match.user2_id : match.user1_id;

            const { data: profile } = await supabase
              .from('profiles')
              .select('id, display_name, avatar_url')
              .eq('id', otherUserId)
              .single();

            // Determine connection status based on match data
            let status: ConnectionStatus = 'closed';
            if (match.met_in_person) {
              status = 'met_in_person';
            } else if (match.status === 'expired') {
              status = 'expired';
            } else if (match.message_count && match.message_count > 0) {
              status = 'chatted_only';
            }

            // Get user's note for this connection
            const userNoteField = match.user1_id === user.id ? 'user1_note' : 'user2_note';

            return {
              id: match.id,
              display_name: profile?.display_name || 'Someone',
              avatar_url: profile?.avatar_url,
              status,
              connected_at: match.confirmed_at || match.created_at,
              ended_at: match.updated_at,
              user_note: match[userNoteField] || null
            };
          })
        );

        setConnections(connectionsWithProfiles);
      }
    } catch (err) {
      console.error('Error fetching connection history:', err);
    }

    setLoading(false);
  };

  const handleSaveNote = async (connectionId: string) => {
    if (!user) return;

    try {
      // Determine which note field to update
      const { data: match } = await supabase
        .from('matches')
        .select('user1_id, user2_id')
        .eq('id', connectionId)
        .single();

      if (match) {
        const noteField = match.user1_id === user.id ? 'user1_note' : 'user2_note';
        
        await supabase
          .from('matches')
          .update({ [noteField]: noteText || null })
          .eq('id', connectionId);

        // Update local state
        setConnections(prev => 
          prev.map(c => 
            c.id === connectionId ? { ...c, user_note: noteText || null } : c
          )
        );
      }
    } catch (err) {
      console.error('Error saving note:', err);
    }

    setEditingNoteId(null);
    setNoteText('');
  };

  const startEditingNote = (connection: PastConnection) => {
    setEditingNoteId(connection.id);
    setNoteText(connection.user_note || '');
  };

  const cancelEditingNote = () => {
    setEditingNoteId(null);
    setNoteText('');
  };

  const getStatusDisplay = (status: ConnectionStatus) => {
    switch (status) {
      case 'met_in_person':
        return {
          label: 'Met in person',
          icon: Users,
          color: 'text-emerald-400',
          bgColor: 'bg-emerald-500/10',
          borderColor: 'border-emerald-500/20'
        };
      case 'chatted_only':
        return {
          label: 'Chatted only',
          icon: MessageCircle,
          color: 'text-blue-400',
          bgColor: 'bg-blue-500/10',
          borderColor: 'border-blue-500/20'
        };
      case 'closed':
        return {
          label: 'Closed',
          icon: Archive,
          color: 'text-gray-400',
          bgColor: 'bg-gray-500/10',
          borderColor: 'border-gray-500/20'
        };
      case 'expired':
        return {
          label: 'Expired',
          icon: Clock,
          color: 'text-amber-400',
          bgColor: 'bg-amber-500/10',
          borderColor: 'border-amber-500/20'
        };
    }
  };

  // Compact header view
  if (compact && !expanded) {
    return (
      <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600">
        <button
          onClick={() => setExpanded(true)}
          className="w-full p-4 flex items-center justify-between text-left hover:bg-charcoal-600/50 rounded-2xl transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-charcoal-600 rounded-xl flex items-center justify-center">
              <Clock className="w-5 h-5 text-gray-400" />
            </div>
            <div>
              <h3 className="font-medium text-white">Connection History</h3>
              <p className="text-sm text-gray-500">Reflect on past connections</p>
            </div>
          </div>
          <ChevronDown className="w-5 h-5 text-gray-400" />
        </button>
      </div>
    );
  }

  return (
    <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-charcoal-600">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-charcoal-600 rounded-xl flex items-center justify-center">
              <Clock className="w-5 h-5 text-gray-400" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Connection History</h3>
              <p className="text-sm text-gray-500">A private space to reflect</p>
            </div>
          </div>
          {compact && (
            <button
              onClick={() => setExpanded(false)}
              className="p-2 hover:bg-charcoal-600 rounded-lg transition-colors"
            >
              <ChevronUp className="w-5 h-5 text-gray-400" />
            </button>
          )}
        </div>

        {/* Calm, supportive message */}
        <p className="mt-4 text-sm text-gray-400 leading-relaxed">
          This is your private space to look back on past connections. 
          Add notes to remember what felt meaningful. There's no judgment here—just reflection.
        </p>
      </div>

      {/* Content */}
      <div className="p-6">
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <div className="w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full animate-spin" />
          </div>
        ) : connections.length === 0 ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 mx-auto mb-4 bg-charcoal-600 rounded-full flex items-center justify-center">
              <Clock className="w-8 h-8 text-gray-500" />
            </div>
            <p className="text-gray-400 mb-2">No past connections yet</p>
            <p className="text-sm text-gray-500">
              When connections end, they'll appear here for you to reflect on.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Timeline */}
            {connections.map((connection, index) => {
              const statusDisplay = getStatusDisplay(connection.status);
              const StatusIcon = statusDisplay.icon;
              const isEditing = editingNoteId === connection.id;

              return (
                <div 
                  key={connection.id}
                  className="relative"
                >
                  {/* Timeline line */}
                  {index < connections.length - 1 && (
                    <div className="absolute left-5 top-14 bottom-0 w-px bg-charcoal-600" />
                  )}

                  <div className={`p-4 rounded-xl border ${statusDisplay.bgColor} ${statusDisplay.borderColor}`}>
                    <div className="flex items-start gap-4">
                      {/* Avatar */}
                      <div className="relative flex-shrink-0">
                        {connection.avatar_url ? (
                          <img
                            src={connection.avatar_url}
                            alt=""
                            className="w-10 h-10 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-10 h-10 bg-charcoal-600 rounded-full flex items-center justify-center">
                            <span className="text-gray-400 font-medium">
                              {connection.display_name.charAt(0).toUpperCase()}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="font-medium text-white truncate">
                            {connection.display_name}
                          </h4>
                          <span className="text-xs text-gray-500 flex-shrink-0">
                            {formatTimeCalm(new Date(connection.connected_at))}
                          </span>
                        </div>

                        {/* Status badge */}
                        <div className="flex items-center gap-2 mt-2">
                          <div className={`flex items-center gap-1.5 px-2 py-1 rounded-lg ${statusDisplay.bgColor}`}>
                            <StatusIcon className={`w-3.5 h-3.5 ${statusDisplay.color}`} />
                            <span className={`text-xs font-medium ${statusDisplay.color}`}>
                              {statusDisplay.label}
                            </span>
                          </div>
                        </div>

                        {/* User note section */}
                        <div className="mt-3">
                          {isEditing ? (
                            <div className="space-y-2">
                              <textarea
                                value={noteText}
                                onChange={(e) => setNoteText(e.target.value)}
                                placeholder="Add a private note about this connection..."
                                className="w-full px-3 py-2 bg-charcoal-800 border border-charcoal-600 rounded-lg text-white text-sm placeholder-gray-500 focus:outline-none focus:border-gold/50 resize-none"
                                rows={2}
                                maxLength={500}
                              />
                              <div className="flex items-center justify-between">
                                <span className="text-xs text-gray-500">
                                  {noteText.length}/500
                                </span>
                                <div className="flex items-center gap-2">
                                  <button
                                    onClick={cancelEditingNote}
                                    className="p-1.5 text-gray-400 hover:text-white hover:bg-charcoal-600 rounded-lg transition-colors"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={() => handleSaveNote(connection.id)}
                                    className="p-1.5 text-gold hover:bg-gold/10 rounded-lg transition-colors"
                                  >
                                    <Check className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          ) : connection.user_note ? (
                            <div className="group relative">
                              <p className="text-sm text-gray-300 italic bg-charcoal-800/50 px-3 py-2 rounded-lg">
                                "{connection.user_note}"
                              </p>
                              <button
                                onClick={() => startEditingNote(connection)}
                                className="absolute top-2 right-2 p-1 text-gray-500 hover:text-gold opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => startEditingNote(connection)}
                              className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-300 transition-colors"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                              Add a note
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Footer message */}
        {connections.length > 0 && (
          <p className="mt-6 text-center text-xs text-gray-500">
            Your notes are private and only visible to you.
          </p>
        )}
      </div>
    </div>
  );
};

export default ConnectionHistoryView;
