import React, { useState, useRef, useEffect } from 'react';
import { Bell, Check, CheckCheck, Heart, MessageSquare, Camera, Calendar, BadgeCheck, User, X } from 'lucide-react';
import { useNotifications } from '@/contexts/NotificationContext';
import { useNavigate } from 'react-router-dom';
import { Notification } from '@/lib/notifications';

// =============================================================================
// DWADIDO NOTIFICATION BELL
// 
// Design Philosophy (from Dwadido AI Matching Instructions):
// - Match alerts must be minimal, calm, and non-addictive
// - NO flashing animations (removed animate-pulse)
// - NO red badges (changed from pink-500 to calm gold)
// - NO "You have X new matches" gamification
// - NO urgency language
// 
// Users should feel: Understood, Respected, In control
// =============================================================================

const NotificationBell: React.FC = () => {
  const { notifications, unreadCount, markNotificationAsRead, markAllNotificationsAsRead, loading } = useNotifications();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'new_match':
      case 'mutual_match':
        // Using gold color instead of pink for calm, non-urgent feel
        return <Heart className="w-4 h-4 text-[#C9A24D]" />;
      case 'new_message':
        return <MessageSquare className="w-4 h-4 text-blue-400" />;
      case 'crush_code_redeemed':
        return <Heart className="w-4 h-4 text-[#C9A24D]" />;
      case 'photo_request':
      case 'photo_request_response':
        return <Camera className="w-4 h-4 text-purple-400" />;
      case 'meeting_suggestion':
      case 'meeting_response':
        return <Calendar className="w-4 h-4 text-green-400" />;
      case 'verification_update':
        return <BadgeCheck className="w-4 h-4 text-[#C9A24D]" />;
      default:
        return <Bell className="w-4 h-4 text-gray-400" />;
    }
  };

  // Format time in a calm, non-urgent way (no "just now!" urgency)
  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    // Calm, non-urgent time formatting
    if (diffMins < 5) return 'Recently';
    if (diffMins < 60) return `${diffMins}m`;
    if (diffHours < 24) return `${diffHours}h`;
    if (diffDays < 7) return `${diffDays}d`;
    return date.toLocaleDateString();
  };

  const handleNotificationClick = async (notification: Notification) => {
    if (!notification.read) {
      await markNotificationAsRead(notification.id);
    }

    // Navigate based on notification data
    const url = notification.data?.url || '/dashboard';
    navigate(url);
    setIsOpen(false);
  };

  const recentNotifications = notifications.slice(0, 10);

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Bell Button - calm, no urgency */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-xl text-gray-400 hover:text-white hover:bg-charcoal-600 transition-all"
        aria-label="Notifications"
      >
        <Bell className="w-5 h-5" />
        
        {/* Badge - calm gold color, NO animate-pulse, NO red/pink urgency colors */}
        {/* Shows a simple dot indicator instead of count to avoid gamification */}
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 w-2 h-2 bg-[#C9A24D] rounded-full" />
        )}
      </button>

      {/* Dropdown */}
      {isOpen && (
        <div className="absolute right-0 top-12 w-80 sm:w-96 bg-charcoal-700 rounded-2xl shadow-2xl border border-charcoal-600 overflow-hidden z-50">
          {/* Header - calm, no gamification language */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-charcoal-600">
            <h3 className="font-semibold text-white">Updates</h3>
            <div className="flex items-center gap-2">
              {unreadCount > 0 && (
                <button
                  onClick={markAllNotificationsAsRead}
                  className="text-xs text-[#C9A24D] hover:text-[#d4af5a] transition-colors flex items-center gap-1"
                >
                  <CheckCheck className="w-3.5 h-3.5" />
                  Mark read
                </button>
              )}
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-charcoal-600 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Notifications List */}
          <div className="max-h-[400px] overflow-y-auto">
            {loading && notifications.length === 0 ? (
              <div className="flex items-center justify-center py-12">
                <div className="w-6 h-6 border-2 border-[#C9A24D] border-t-transparent rounded-full animate-spin" />
              </div>
            ) : recentNotifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 px-4">
                <div className="w-12 h-12 bg-charcoal-600 rounded-full flex items-center justify-center mb-3">
                  <Bell className="w-6 h-6 text-gray-500" />
                </div>
                {/* Calm, non-urgent empty state */}
                <p className="text-gray-400 text-sm text-center">No updates yet</p>
                <p className="text-gray-500 text-xs text-center mt-1">
                  New connections and messages will appear here
                </p>
              </div>
            ) : (
              <div className="divide-y divide-charcoal-600">
                {recentNotifications.map((notification) => (
                  <button
                    key={notification.id}
                    onClick={() => handleNotificationClick(notification)}
                    className={`w-full flex items-start gap-3 p-4 text-left transition-colors hover:bg-charcoal-600 ${
                      !notification.read ? 'bg-[#C9A24D]/5' : ''
                    }`}
                  >
                    {/* Icon - using calm colors */}
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                      !notification.read ? 'bg-[#C9A24D]/10' : 'bg-charcoal-600'
                    }`}>
                      {getNotificationIcon(notification.type)}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-medium ${!notification.read ? 'text-white' : 'text-gray-300'}`}>
                        {notification.title}
                      </p>
                      <p className="text-xs text-gray-400 mt-0.5 line-clamp-2">
                        {notification.body}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {formatTime(notification.created_at)}
                      </p>
                    </div>

                    {/* Unread indicator - subtle gold dot, no flashing */}
                    {!notification.read && (
                      <div className="w-2 h-2 bg-[#C9A24D] rounded-full flex-shrink-0 mt-2" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div className="border-t border-charcoal-600 p-3">
              <button
                onClick={() => {
                  navigate('/notifications');
                  setIsOpen(false);
                }}
                className="w-full py-2 text-sm text-[#C9A24D] hover:text-[#d4af5a] font-medium transition-colors"
              >
                View all updates
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default NotificationBell;
