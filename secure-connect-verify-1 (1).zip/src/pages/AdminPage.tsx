import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Navigate } from 'react-router-dom';
import { 
  Shield, Users, CheckCircle, XCircle, Clock, Eye, 
  Loader2, RefreshCw, AlertTriangle, ChevronRight,
  User, Calendar, Camera, Search, Flag, BarChart3,
  Ban, MessageSquare, AlertCircle, FileText, UserX,
  Activity, Heart, TrendingUp, X, Sparkles, Crown,
  Timer, QrCode
} from 'lucide-react';
import ScheduledJobsPanel from '@/components/admin/ScheduledJobsPanel';
import QRScanAnalytics from '@/components/admin/QRScanAnalytics';

interface UserReport {
  id: string;
  reporter_id: string;
  reported_user_id: string;
  reason: string;
  description: string;
  status: 'pending' | 'resolved' | 'dismissed';
  created_at: string;
  admin_notes: string | null;
  action_taken: string | null;
  reviewed_at: string | null;
  reporter_profile?: {
    display_name: string | null;
    email: string;
    avatar_url: string | null;
  };
  reported_profile?: {
    display_name: string | null;
    email: string;
    avatar_url: string | null;
    is_suspended: boolean;
    warning_count: number;
  };
}

interface UserProfile {
  id: string;
  email: string;
  display_name: string | null;
  avatar_url: string | null;
  is_suspended: boolean;
  warning_count: number;
  created_at: string;
  last_active_at: string | null;
  bio: string | null;
  suspended_reason: string | null;
  suspended_at: string | null;
}

interface Stats {
  total_users: number;
  active_users_7d: number;
  total_matches: number;
  pending_reports: number;
  total_reports: number;
  suspended_users: number;
}

type AdminTab = 'overview' | 'reports' | 'users' | 'scheduled-jobs' | 'qr-analytics';

const AdminPage: React.FC = () => {
  const { profile, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [stats, setStats] = useState<Stats | null>(null);
  const [statsLoading, setStatsLoading] = useState(true);
  
  // Reports state
  const [reportTab, setReportTab] = useState<'pending' | 'resolved' | 'dismissed'>('pending');
  const [reports, setReports] = useState<UserReport[]>([]);
  const [reportsLoading, setReportsLoading] = useState(false);
  const [selectedReport, setSelectedReport] = useState<UserReport | null>(null);
  
  // User search state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [selectedUser, setSelectedUser] = useState<UserProfile | null>(null);
  const [userDetails, setUserDetails] = useState<any>(null);
  
  // Modal states
  const [showActionModal, setShowActionModal] = useState(false);
  const [actionType, setActionType] = useState<'warn' | 'suspend' | 'dismiss' | null>(null);
  const [actionReason, setActionReason] = useState('');
  const [adminNotes, setAdminNotes] = useState('');
  const [processing, setProcessing] = useState(false);

  // Fetch stats
  const fetchStats = async () => {
    setStatsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('admin-moderate-user', {
        body: { action: 'get_stats' }
      });
      if (error) throw error;
      if (data?.stats) setStats(data.stats);
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
    setStatsLoading(false);
  };

  // Fetch reports
  const fetchReports = async () => {
    setReportsLoading(true);
    try {
      const { data, error } = await supabase
        .from('user_reports')
        .select('*')
        .eq('status', reportTab)
        .order('created_at', { ascending: reportTab === 'pending' });

      if (error) throw error;

      const reportsWithProfiles = await Promise.all(
        (data || []).map(async (report) => {
          const [{ data: reporterData }, { data: reportedData }] = await Promise.all([
            supabase.from('profiles').select('display_name, email, avatar_url').eq('id', report.reporter_id).single(),
            supabase.from('profiles').select('display_name, email, avatar_url, is_suspended, warning_count').eq('id', report.reported_user_id).single()
          ]);
          
          return {
            ...report,
            reporter_profile: reporterData || undefined,
            reported_profile: reportedData || undefined
          };
        })
      );

      setReports(reportsWithProfiles);
    } catch (err) {
      console.error('Error fetching reports:', err);
    }
    setReportsLoading(false);
  };

  // Search users
  const searchUsers = async () => {
    setSearchLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('admin-moderate-user', {
        body: { action: 'search_users', query: searchQuery, limit: 30 }
      });
      if (error) throw error;
      if (data?.users) setSearchResults(data.users);
    } catch (err) {
      console.error('Error searching users:', err);
    }
    setSearchLoading(false);
  };

  // Get user details
  const fetchUserDetails = async (userId: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('admin-moderate-user', {
        body: { action: 'get_user_details', user_id: userId }
      });
      if (error) throw error;
      setUserDetails(data);
    } catch (err) {
      console.error('Error fetching user details:', err);
    }
  };

  // Handle moderation actions
  const handleModerateAction = async () => {
    if (!actionType) return;
    setProcessing(true);

    try {
      let body: any = { action: '' };

      if (actionType === 'warn') {
        body = {
          action: 'warn_user',
          user_id: selectedReport?.reported_user_id || selectedUser?.id,
          report_id: selectedReport?.id,
          admin_notes: adminNotes
        };
      } else if (actionType === 'suspend') {
        body = {
          action: 'suspend_user',
          user_id: selectedReport?.reported_user_id || selectedUser?.id,
          report_id: selectedReport?.id,
          reason: actionReason,
          admin_notes: adminNotes
        };
      } else if (actionType === 'dismiss') {
        body = {
          action: 'dismiss_report',
          report_id: selectedReport?.id,
          admin_notes: adminNotes
        };
      }

      const { data, error } = await supabase.functions.invoke('admin-moderate-user', { body });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      // Refresh data
      if (selectedReport) {
        setReports(reports.filter(r => r.id !== selectedReport.id));
        setSelectedReport(null);
      }
      if (selectedUser) {
        await fetchUserDetails(selectedUser.id);
      }
      
      setShowActionModal(false);
      setActionType(null);
      setActionReason('');
      setAdminNotes('');
      fetchStats();
    } catch (err: any) {
      console.error('Error:', err);
      alert(err.message || 'Action failed');
    }
    setProcessing(false);
  };

  // Handle unsuspend
  const handleUnsuspend = async (userId: string) => {
    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('admin-moderate-user', {
        body: { action: 'unsuspend_user', user_id: userId }
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      
      if (selectedUser) {
        await fetchUserDetails(selectedUser.id);
        setSelectedUser({ ...selectedUser, is_suspended: false });
      }
      fetchStats();
    } catch (err: any) {
      console.error('Error:', err);
      alert(err.message || 'Failed to unsuspend');
    }
    setProcessing(false);
  };

  useEffect(() => {
    if (profile?.is_admin) {
      fetchStats();
    }
  }, [profile?.is_admin]);

  useEffect(() => {
    if (profile?.is_admin && activeTab === 'reports') {
      fetchReports();
    }
  }, [activeTab, reportTab, profile?.is_admin]);

  useEffect(() => {
    if (profile?.is_admin && activeTab === 'users') {
      searchUsers();
    }
  }, [activeTab, profile?.is_admin]);

  useEffect(() => {
    if (selectedUser) {
      fetchUserDetails(selectedUser.id);
    }
  }, [selectedUser]);

  const getReasonLabel = (reason: string) => {
    const reasons: Record<string, string> = {
      'harassment': 'Harassment',
      'inappropriate_content': 'Inappropriate Content',
      'spam': 'Spam',
      'fake_profile': 'Fake Profile',
      'underage': 'Underage User',
      'threatening': 'Threatening Behavior',
      'other': 'Other'
    };
    return reasons[reason] || reason;
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-charcoal flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-gold animate-spin" />
      </div>
    );
  }

  if (!profile?.is_admin) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="min-h-screen bg-charcoal">
      {/* Header */}
      <div className="bg-charcoal-700 border-b border-charcoal-600 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center">
                <Shield className="w-5 h-5 text-gold" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Admin Dashboard</h1>
                <p className="text-xs text-gray-400">Dwadido Moderation Center</p>
              </div>
            </div>
            <button
              onClick={() => {
                fetchStats();
                if (activeTab === 'reports') fetchReports();
                if (activeTab === 'users') searchUsers();
              }}
              className="flex items-center gap-2 px-4 py-2 text-gray-400 hover:text-gold hover:bg-charcoal-600 rounded-xl transition-all"
            >
              <RefreshCw className={`w-4 h-4 ${statsLoading ? 'animate-spin' : ''}`} />
              Refresh
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-1 -mb-px overflow-x-auto">
            {[
              { id: 'overview', label: 'Overview', icon: BarChart3 },
              { id: 'reports', label: 'Reports', icon: Flag },
              { id: 'users', label: 'Users', icon: Users },
              { id: 'scheduled-jobs', label: 'Scheduled Jobs', icon: Timer },
              { id: 'qr-analytics', label: 'QR Analytics', icon: QrCode }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as AdminTab)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'border-gold text-gold'
                    : 'border-transparent text-gray-400 hover:text-white hover:border-charcoal-500'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
                {tab.id === 'reports' && stats?.pending_reports ? (
                  <span className="px-2 py-0.5 bg-red-500/20 text-red-400 text-xs rounded-full">
                    {stats.pending_reports}
                  </span>
                ) : null}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-charcoal-700 rounded-2xl p-6 border border-charcoal-600">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gold/20 rounded-xl flex items-center justify-center">
                    <Users className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">{stats?.total_users || 0}</p>
                    <p className="text-gray-400 text-sm">Total Users</p>
                  </div>
                </div>
              </div>

              <div className="bg-charcoal-700 rounded-2xl p-6 border border-charcoal-600">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                    <Activity className="w-6 h-6 text-green-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">{stats?.active_users_7d || 0}</p>
                    <p className="text-gray-400 text-sm">Active (7 days)</p>
                  </div>
                </div>
              </div>

              <div className="bg-charcoal-700 rounded-2xl p-6 border border-charcoal-600">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gold/20 rounded-xl flex items-center justify-center">
                    <Heart className="w-6 h-6 text-gold" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">{stats?.total_matches || 0}</p>
                    <p className="text-gray-400 text-sm">Total Matches</p>
                  </div>
                </div>
              </div>

              <div className="bg-charcoal-700 rounded-2xl p-6 border border-charcoal-600">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-red-500/20 rounded-xl flex items-center justify-center">
                    <Flag className="w-6 h-6 text-red-400" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">{stats?.pending_reports || 0}</p>
                    <p className="text-gray-400 text-sm">Pending Reports</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Items */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
                <div className="p-4 border-b border-charcoal-600 flex items-center justify-between">
                  <h3 className="font-semibold text-white flex items-center gap-2">
                    <Flag className="w-5 h-5 text-red-400" />
                    Pending Reports
                  </h3>
                  <span className="px-3 py-1 bg-red-500/20 text-red-400 text-sm font-medium rounded-full">
                    {stats?.pending_reports || 0}
                  </span>
                </div>
                <div className="p-6">
                  {stats?.pending_reports ? (
                    <div className="text-center">
                      <p className="text-gray-400 mb-4">
                        You have {stats.pending_reports} report{stats.pending_reports > 1 ? 's' : ''} waiting for review.
                      </p>
                      <button
                        onClick={() => setActiveTab('reports')}
                        className="px-4 py-2 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all"
                      >
                        Review Reports
                      </button>
                    </div>
                  ) : (
                    <div className="text-center text-gray-500">
                      <CheckCircle className="w-12 h-12 text-green-500/30 mx-auto mb-2" />
                      <p>All caught up! No pending reports.</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
                <div className="p-4 border-b border-charcoal-600 flex items-center justify-between">
                  <h3 className="font-semibold text-white flex items-center gap-2">
                    <Shield className="w-5 h-5 text-gold" />
                    Platform Safety
                  </h3>
                </div>
                <div className="p-6">
                  <div className="text-center text-gray-500">
                    <Shield className="w-12 h-12 text-gold/30 mx-auto mb-2" />
                    <p className="text-gray-400 text-sm">
                      Dwadido uses real-life verification through in-person meetings and the 17-day gated chat window as primary trust infrastructure.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 p-6">
              <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-gold" />
                Platform Health
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                <div>
                  <p className="text-sm text-gray-400 mb-1">Suspended Users</p>
                  <p className="text-2xl font-bold text-red-400">{stats?.suspended_users || 0}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400 mb-1">Total Reports</p>
                  <p className="text-2xl font-bold text-white">{stats?.total_reports || 0}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-400 mb-1">Active Rate (7d)</p>
                  <p className="text-2xl font-bold text-green-400">
                    {stats?.total_users ? Math.round((stats.active_users_7d / stats.total_users) * 100) : 0}%
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Reports Tab */}
        {activeTab === 'reports' && (
          <div className="space-y-6">
            {/* Report Status Tabs */}
            <div className="flex gap-2">
              {['pending', 'resolved', 'dismissed'].map((status) => (
                <button
                  key={status}
                  onClick={() => setReportTab(status as any)}
                  className={`px-4 py-2 rounded-xl font-medium transition-all ${
                    reportTab === status
                      ? status === 'pending' ? 'bg-red-500/20 text-red-400' :
                        status === 'resolved' ? 'bg-green-500/20 text-green-400' :
                        'bg-charcoal-500 text-gray-300'
                      : 'bg-charcoal-700 text-gray-400 hover:bg-charcoal-600'
                  }`}
                >
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Reports List */}
              <div className="lg:col-span-1">
                <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
                  <div className="p-4 border-b border-charcoal-600">
                    <h2 className="font-semibold text-white capitalize">{reportTab} Reports</h2>
                  </div>

                  {reportsLoading ? (
                    <div className="p-8 flex items-center justify-center">
                      <Loader2 className="w-6 h-6 text-gold animate-spin" />
                    </div>
                  ) : reports.length === 0 ? (
                    <div className="p-8 text-center">
                      <Flag className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                      <p className="text-gray-400">No {reportTab} reports</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-charcoal-600 max-h-[600px] overflow-y-auto">
                      {reports.map((report) => (
                        <button
                          key={report.id}
                          onClick={() => setSelectedReport(report)}
                          className={`w-full p-4 text-left hover:bg-charcoal-600 transition-all ${
                            selectedReport?.id === report.id ? 'bg-gold/10' : ''
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            {report.reported_profile?.avatar_url ? (
                              <img
                                src={report.reported_profile.avatar_url}
                                alt=""
                                className="w-10 h-10 rounded-full object-cover"
                              />
                            ) : (
                              <div className="w-10 h-10 rounded-full bg-charcoal-500 flex items-center justify-center">
                                <User className="w-5 h-5 text-gray-400" />
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-white truncate">
                                {report.reported_profile?.display_name || 'Anonymous'}
                              </p>
                              <p className="text-xs text-red-400 font-medium">
                                {getReasonLabel(report.reason)}
                              </p>
                            </div>
                            <ChevronRight className="w-4 h-4 text-gray-500" />
                          </div>
                          <div className="mt-2 flex items-center gap-2 text-xs text-gray-500">
                            <Calendar className="w-3 h-3" />
                            {new Date(report.created_at).toLocaleDateString()}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Report Detail */}
              <div className="lg:col-span-2">
                {selectedReport ? (
                  <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
                    <div className="p-6 border-b border-charcoal-600">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold text-white">Report Details</h3>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          selectedReport.status === 'pending' ? 'bg-red-500/20 text-red-400' :
                          selectedReport.status === 'resolved' ? 'bg-green-500/20 text-green-400' :
                          'bg-charcoal-500 text-gray-300'
                        }`}>
                          {selectedReport.status.charAt(0).toUpperCase() + selectedReport.status.slice(1)}
                        </span>
                      </div>
                    </div>

                    <div className="p-6 space-y-6">
                      {/* Reported User */}
                      <div className="p-4 bg-red-500/10 rounded-xl border border-red-500/20">
                        <p className="text-xs text-red-400 font-medium mb-2">REPORTED USER</p>
                        <div className="flex items-center gap-3">
                          {selectedReport.reported_profile?.avatar_url ? (
                            <img
                              src={selectedReport.reported_profile.avatar_url}
                              alt=""
                              className="w-12 h-12 rounded-full object-cover"
                            />
                          ) : (
                            <div className="w-12 h-12 rounded-full bg-charcoal-500 flex items-center justify-center">
                              <User className="w-6 h-6 text-gray-400" />
                            </div>
                          )}
                          <div>
                            <p className="font-medium text-white">
                              {selectedReport.reported_profile?.display_name || 'Anonymous'}
                            </p>
                            <p className="text-sm text-gray-400">{selectedReport.reported_profile?.email}</p>
                            <div className="flex gap-2 mt-1">
                              {selectedReport.reported_profile?.is_suspended && (
                                <span className="px-2 py-0.5 bg-red-500/20 text-red-400 text-xs rounded-full">Suspended</span>
                              )}
                              {(selectedReport.reported_profile?.warning_count || 0) > 0 && (
                                <span className="px-2 py-0.5 bg-yellow-500/20 text-yellow-400 text-xs rounded-full">
                                  {selectedReport.reported_profile?.warning_count} Warning(s)
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Reporter */}
                      <div className="p-4 bg-charcoal-600 rounded-xl">
                        <p className="text-xs text-gray-400 font-medium mb-2">REPORTED BY</p>
                        <div className="flex items-center gap-3">
                          {selectedReport.reporter_profile?.avatar_url ? (
                            <img
                              src={selectedReport.reporter_profile.avatar_url}
                              alt=""
                              className="w-10 h-10 rounded-full object-cover"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded-full bg-charcoal-500 flex items-center justify-center">
                              <User className="w-5 h-5 text-gray-400" />
                            </div>
                          )}
                          <div>
                            <p className="font-medium text-white">
                              {selectedReport.reporter_profile?.display_name || 'Anonymous'}
                            </p>
                            <p className="text-sm text-gray-400">{selectedReport.reporter_profile?.email}</p>
                          </div>
                        </div>
                      </div>

                      {/* Reason & Description */}
                      <div>
                        <p className="text-sm font-medium text-gray-300 mb-2">Reason</p>
                        <div className="px-4 py-2 bg-red-500/20 text-red-400 rounded-xl inline-block font-medium">
                          {getReasonLabel(selectedReport.reason)}
                        </div>
                      </div>

                      {selectedReport.description && (
                        <div>
                          <p className="text-sm font-medium text-gray-300 mb-2">Description</p>
                          <p className="text-gray-300 bg-charcoal-600 p-4 rounded-xl">{selectedReport.description}</p>
                        </div>
                      )}

                      {/* Admin Notes */}
                      {selectedReport.admin_notes && (
                        <div className="p-4 bg-gold/10 rounded-xl border border-gold/20">
                          <p className="text-xs text-gold font-medium mb-2">ADMIN NOTES</p>
                          <p className="text-gray-300">{selectedReport.admin_notes}</p>
                        </div>
                      )}

                      {/* Action Taken */}
                      {selectedReport.action_taken && (
                        <div className="p-4 bg-green-500/10 rounded-xl border border-green-500/20">
                          <p className="text-xs text-green-400 font-medium mb-2">ACTION TAKEN</p>
                          <p className="text-gray-300 capitalize">{selectedReport.action_taken.replace(/_/g, ' ')}</p>
                          {selectedReport.reviewed_at && (
                            <p className="text-xs text-gray-500 mt-1">
                              Reviewed on {new Date(selectedReport.reviewed_at).toLocaleString()}
                            </p>
                          )}
                        </div>
                      )}

                      {/* Actions */}
                      {selectedReport.status === 'pending' && (
                        <div className="flex gap-3 pt-4 border-t border-charcoal-600">
                          <button
                            onClick={() => {
                              setActionType('dismiss');
                              setShowActionModal(true);
                            }}
                            className="flex-1 py-3 bg-charcoal-600 text-gray-300 font-medium rounded-xl hover:bg-charcoal-500 transition-all flex items-center justify-center gap-2"
                          >
                            <XCircle className="w-5 h-5" />
                            Dismiss
                          </button>
                          <button
                            onClick={() => {
                              setActionType('warn');
                              setShowActionModal(true);
                            }}
                            className="flex-1 py-3 bg-yellow-500/20 text-yellow-400 font-medium rounded-xl hover:bg-yellow-500/30 transition-all flex items-center justify-center gap-2"
                          >
                            <AlertTriangle className="w-5 h-5" />
                            Warn User
                          </button>
                          <button
                            onClick={() => {
                              setActionType('suspend');
                              setShowActionModal(true);
                            }}
                            className="flex-1 py-3 bg-red-500 text-white font-medium rounded-xl hover:bg-red-600 transition-all flex items-center justify-center gap-2"
                          >
                            <Ban className="w-5 h-5" />
                            Suspend
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 p-12 text-center">
                    <Flag className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">Select a Report</h3>
                    <p className="text-gray-400">Choose a report from the list to review</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="space-y-6">
            {/* Search Bar */}
            <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 p-4">
              <div className="flex gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && searchUsers()}
                    placeholder="Search by email or display name..."
                    className="w-full pl-12 pr-4 py-3 bg-charcoal-600 border border-charcoal-500 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent"
                  />
                </div>
                <button
                  onClick={searchUsers}
                  disabled={searchLoading}
                  className="px-6 py-3 bg-gold text-charcoal font-medium rounded-xl hover:bg-gold-400 transition-all disabled:opacity-50 flex items-center gap-2"
                >
                  {searchLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
                  Search
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* User List */}
              <div className="lg:col-span-1">
                <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
                  <div className="p-4 border-b border-charcoal-600">
                    <h2 className="font-semibold text-white">Users ({searchResults.length})</h2>
                  </div>

                  {searchLoading ? (
                    <div className="p-8 flex items-center justify-center">
                      <Loader2 className="w-6 h-6 text-gold animate-spin" />
                    </div>
                  ) : searchResults.length === 0 ? (
                    <div className="p-8 text-center">
                      <Users className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                      <p className="text-gray-400">No users found</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-charcoal-600 max-h-[600px] overflow-y-auto">
                      {searchResults.map((user) => (
                        <button
                          key={user.id}
                          onClick={() => setSelectedUser(user)}
                          className={`w-full p-4 text-left hover:bg-charcoal-600 transition-all ${
                            selectedUser?.id === user.id ? 'bg-gold/10' : ''
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            {user.avatar_url ? (
                              <img
                                src={user.avatar_url}
                                alt=""
                                className="w-10 h-10 rounded-full object-cover"
                              />
                            ) : (
                              <div className="w-10 h-10 rounded-full bg-charcoal-500 flex items-center justify-center">
                                <User className="w-5 h-5 text-gray-400" />
                              </div>
                            )}
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-white truncate">
                                {user.display_name || 'Anonymous'}
                              </p>
                              <p className="text-xs text-gray-400 truncate">{user.email}</p>
                            </div>
                            {user.is_suspended && (
                              <Ban className="w-4 h-4 text-red-400" />
                            )}
                            <ChevronRight className="w-4 h-4 text-gray-500" />
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* User Detail */}
              <div className="lg:col-span-2">
                {selectedUser && userDetails ? (
                  <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
                    <div className="p-6 border-b border-charcoal-600">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          {selectedUser.avatar_url ? (
                            <img
                              src={selectedUser.avatar_url}
                              alt=""
                              className="w-16 h-16 rounded-full object-cover"
                            />
                          ) : (
                            <div className="w-16 h-16 rounded-full bg-charcoal-500 flex items-center justify-center">
                              <User className="w-8 h-8 text-gray-400" />
                            </div>
                          )}
                          <div>
                            <h3 className="text-xl font-semibold text-white">
                              {selectedUser.display_name || 'Anonymous'}
                            </h3>
                            <p className="text-gray-400">{selectedUser.email}</p>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2 items-end">
                          {selectedUser.is_suspended ? (
                            <span className="px-3 py-1 bg-red-500/20 text-red-400 text-sm font-medium rounded-full">
                              Suspended
                            </span>
                          ) : (
                            <span className="px-3 py-1 bg-green-500/20 text-green-400 text-sm font-medium rounded-full">
                              Active
                            </span>
                          )}
                          {(userDetails.user?.warning_count || 0) > 0 && (
                            <span className="px-3 py-1 bg-yellow-500/20 text-yellow-400 text-sm font-medium rounded-full">
                              {userDetails.user?.warning_count} Warning(s)
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="p-6 space-y-6">
                      {/* User Stats */}
                      <div className="grid grid-cols-3 gap-4">
                        <div className="p-4 bg-charcoal-600 rounded-xl text-center">
                          <p className="text-2xl font-bold text-white">{userDetails.matches_count || 0}</p>
                          <p className="text-sm text-gray-400">Matches</p>
                        </div>
                        <div className="p-4 bg-charcoal-600 rounded-xl text-center">
                          <p className="text-2xl font-bold text-red-400">{userDetails.reports_received?.length || 0}</p>
                          <p className="text-sm text-gray-400">Reports Received</p>
                        </div>
                        <div className="p-4 bg-charcoal-600 rounded-xl text-center">
                          <p className="text-2xl font-bold text-gray-300">{userDetails.reports_made?.length || 0}</p>
                          <p className="text-sm text-gray-400">Reports Made</p>
                        </div>
                      </div>

                      {/* Account Info */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-charcoal-600 rounded-xl">
                          <p className="text-xs text-gray-400 mb-1">Joined</p>
                          <p className="font-medium text-white">
                            {new Date(selectedUser.created_at).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="p-4 bg-charcoal-600 rounded-xl">
                          <p className="text-xs text-gray-400 mb-1">Last Active</p>
                          <p className="font-medium text-white">
                            {selectedUser.last_active_at 
                              ? new Date(selectedUser.last_active_at).toLocaleDateString()
                              : 'Never'}
                          </p>
                        </div>
                      </div>

                      {/* Bio */}
                      {userDetails.user?.bio && (
                        <div>
                          <p className="text-sm font-medium text-gray-300 mb-2">Bio</p>
                          <p className="text-gray-300 bg-charcoal-600 p-4 rounded-xl">{userDetails.user.bio}</p>
                        </div>
                      )}

                      {/* Suspension Info */}
                      {selectedUser.is_suspended && userDetails.user?.suspended_reason && (
                        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
                          <p className="text-sm font-medium text-red-400 mb-1">Suspension Reason</p>
                          <p className="text-gray-300">{userDetails.user.suspended_reason}</p>
                          {userDetails.user.suspended_at && (
                            <p className="text-xs text-gray-500 mt-2">
                              Suspended on {new Date(userDetails.user.suspended_at).toLocaleString()}
                            </p>
                          )}
                        </div>
                      )}

                      {/* Recent Reports Received */}
                      {userDetails.reports_received?.length > 0 && (
                        <div>
                          <p className="text-sm font-medium text-gray-300 mb-3">Recent Reports Received</p>
                          <div className="space-y-2">
                            {userDetails.reports_received.slice(0, 3).map((report: any) => (
                              <div key={report.id} className="p-3 bg-red-500/10 rounded-xl">
                                <div className="flex items-center justify-between">
                                  <span className="font-medium text-red-400">{getReasonLabel(report.reason)}</span>
                                  <span className={`px-2 py-0.5 text-xs rounded-full ${
                                    report.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                                    report.status === 'resolved' ? 'bg-green-500/20 text-green-400' :
                                    'bg-charcoal-500 text-gray-300'
                                  }`}>
                                    {report.status}
                                  </span>
                                </div>
                                <p className="text-xs text-gray-500 mt-1">
                                  {new Date(report.created_at).toLocaleDateString()}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex gap-3 pt-4 border-t border-charcoal-600">
                        {selectedUser.is_suspended ? (
                          <button
                            onClick={() => handleUnsuspend(selectedUser.id)}
                            disabled={processing}
                            className="flex-1 py-3 bg-green-500 text-white font-medium rounded-xl hover:bg-green-600 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                          >
                            {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle className="w-5 h-5" />}
                            Unsuspend Account
                          </button>
                        ) : (
                          <>
                            <button
                              onClick={() => {
                                setActionType('warn');
                                setShowActionModal(true);
                              }}
                              className="flex-1 py-3 bg-yellow-500/20 text-yellow-400 font-medium rounded-xl hover:bg-yellow-500/30 transition-all flex items-center justify-center gap-2"
                            >
                              <AlertTriangle className="w-5 h-5" />
                              Warn User
                            </button>
                            <button
                              onClick={() => {
                                setActionType('suspend');
                                setShowActionModal(true);
                              }}
                              className="flex-1 py-3 bg-red-500 text-white font-medium rounded-xl hover:bg-red-600 transition-all flex items-center justify-center gap-2"
                            >
                              <Ban className="w-5 h-5" />
                              Suspend Account
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 p-12 text-center">
                    <Users className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">Select a User</h3>
                    <p className="text-gray-400">Search and select a user to view their profile</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Scheduled Jobs Tab */}
        {activeTab === 'scheduled-jobs' && (
          <ScheduledJobsPanel />
        )}

        {/* QR Analytics Tab */}
        {activeTab === 'qr-analytics' && (
          <QRScanAnalytics />
        )}
      </div>

      {/* Action Modal */}
      {showActionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-charcoal-700 rounded-2xl shadow-2xl w-full max-w-md p-6 border border-charcoal-600">
            <div className="flex items-center gap-3 mb-6">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                actionType === 'warn' ? 'bg-yellow-500/20' :
                actionType === 'suspend' ? 'bg-red-500/20' :
                'bg-charcoal-600'
              }`}>
                {actionType === 'warn' ? <AlertTriangle className="w-5 h-5 text-yellow-400" /> :
                 actionType === 'suspend' ? <Ban className="w-5 h-5 text-red-400" /> :
                 <XCircle className="w-5 h-5 text-gray-400" />}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">
                  {actionType === 'warn' ? 'Warn User' :
                   actionType === 'suspend' ? 'Suspend Account' :
                   'Dismiss Report'}
                </h3>
                <p className="text-sm text-gray-400">
                  {actionType === 'warn' ? 'Issue a warning to this user' :
                   actionType === 'suspend' ? 'Suspend this user\'s account' :
                   'Dismiss this report without action'}
                </p>
              </div>
            </div>

            {actionType === 'suspend' && (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Suspension Reason
                </label>
                <input
                  type="text"
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                  placeholder="e.g., Repeated violations of community guidelines"
                  className="w-full px-4 py-3 bg-charcoal-600 border border-charcoal-500 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
            )}

            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Admin Notes
              </label>
              <textarea
                value={adminNotes}
                onChange={(e) => setAdminNotes(e.target.value)}
                placeholder="Add any notes about this action..."
                rows={3}
                className="w-full px-4 py-3 bg-charcoal-600 border border-charcoal-500 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold resize-none"
              />
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowActionModal(false);
                  setActionType(null);
                  setActionReason('');
                  setAdminNotes('');
                }}
                className="flex-1 py-3 bg-charcoal-600 text-gray-300 font-medium rounded-xl hover:bg-charcoal-500 transition-all"
              >
                Cancel
              </button>
              <button
                onClick={handleModerateAction}
                disabled={processing}
                className={`flex-1 py-3 font-medium rounded-xl transition-all disabled:opacity-50 flex items-center justify-center gap-2 ${
                  actionType === 'warn' ? 'bg-yellow-500 text-charcoal hover:bg-yellow-400' :
                  actionType === 'suspend' ? 'bg-red-500 text-white hover:bg-red-600' :
                  'bg-charcoal-500 text-white hover:bg-charcoal-400'
                }`}
              >
                {processing ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Confirm'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPage;
