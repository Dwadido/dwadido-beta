import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/layout/Header';
import SettingsPanel from '@/components/settings/SettingsPanel';
import AuthModal from '@/components/auth/AuthModal';
import ProactiveAlerts from '@/components/support/ProactiveAlerts';

const SettingsPage: React.FC = () => {
  const { user, loading, error, clearError } = useAuth();
  const navigate = useNavigate();
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');

  useEffect(() => {
    if (!loading && !user) {
      navigate('/');
    }
  }, [user, loading, navigate]);

  const handleProactiveAction = (actionType: string, triggerType: string) => {
    switch (actionType) {
      case 'update_payment':
      case 'fix_payment':
        window.dispatchEvent(new CustomEvent('openSupportChat', { detail: { category: 'billing' } }));
        break;
      case 'manage_subscription':
      case 'resubscribe':
        navigate('/premium');
        break;
      default:
        window.dispatchEvent(new CustomEvent('openSupportChat', { detail: { category: 'billing' } }));
    }
  };

  const handleRetry = () => {
    clearError();
    window.location.reload();
  };

  // Show error state if there's a connection/timeout error
  if (error && user) {
    return (
      <div className="min-h-screen bg-charcoal">
        <Header
          onSignIn={() => { setAuthMode('signin'); setAuthModalOpen(true); }}
          onSignUp={() => { setAuthMode('signup'); setAuthModalOpen(true); }}
          transparent={false}
        />
        <div className="pt-24 flex items-center justify-center">
          <div className="text-center max-w-md mx-auto px-4">
            <div className="w-16 h-16 mx-auto mb-4 bg-charcoal-700 rounded-2xl flex items-center justify-center border border-yellow-500/30">
              <svg className="w-8 h-8 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h2 className="text-xl font-semibold text-white mb-2">Something went wrong</h2>
            <p className="text-gray-400 mb-6">{error}</p>
            <button
              onClick={handleRetry}
              className="px-6 py-3 bg-gold text-charcoal font-medium rounded-lg hover:bg-gold-400 transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-charcoal">
        <div className="animate-spin w-8 h-8 border-4 border-gold border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!user) {
    return null;
  }


  return (
    <div className="min-h-screen bg-charcoal">
      <Header
        onSignIn={() => { setAuthMode('signin'); setAuthModalOpen(true); }}
        onSignUp={() => { setAuthMode('signup'); setAuthModalOpen(true); }}
        transparent={false}
      />
      {/* Proactive Alerts Banner */}
      <div className="pt-16">
        <ProactiveAlerts 
          variant="banner" 
          onAction={handleProactiveAction}
        />
      </div>
      <div>
        <SettingsPanel />
      </div>
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authMode}
      />
    </div>
  );
};

export default SettingsPage;
