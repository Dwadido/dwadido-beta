import React, { useState, useEffect } from 'react';
import { Camera, Lock, Eye, Loader2 } from 'lucide-react';
import { supabase, getPublicPhotoUrl } from '@/lib/supabase';
import PhotoRequestModal from './PhotoRequestModal';

interface BlurredPhotoPreviewProps {
  userId: string;
  userName?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  fallbackAvatar?: string | null;
  onRequestSent?: () => void;
}

const BlurredPhotoPreview: React.FC<BlurredPhotoPreviewProps> = ({
  userId,
  userName = 'this user',
  size = 'md',
  className = '',
  fallbackAvatar,
  onRequestSent
}) => {
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  // Size configurations
  const sizeConfig = {
    sm: {
      container: 'w-12 h-12',
      icon: 'w-4 h-4',
      lockIcon: 'w-3 h-3',
      text: 'text-[8px]',
      buttonPadding: 'px-1.5 py-0.5'
    },
    md: {
      container: 'w-14 h-14',
      icon: 'w-5 h-5',
      lockIcon: 'w-3.5 h-3.5',
      text: 'text-[9px]',
      buttonPadding: 'px-2 py-1'
    },
    lg: {
      container: 'w-20 h-20',
      icon: 'w-6 h-6',
      lockIcon: 'w-4 h-4',
      text: 'text-[10px]',
      buttonPadding: 'px-2.5 py-1'
    },
    xl: {
      container: 'w-32 h-32',
      icon: 'w-8 h-8',
      lockIcon: 'w-5 h-5',
      text: 'text-xs',
      buttonPadding: 'px-3 py-1.5'
    }
  };

  const config = sizeConfig[size];

  // FIX: Fetch the primary photo URL from `profiles` table, NOT `user_photos`.
  // The PhotoManager upload flow stores photos in Supabase Storage and records
  // the path in `profiles.primary_photo_path`. The `user_photos` table is never
  // populated, so querying it always returned null.
  useEffect(() => {
    const fetchPrimaryPhoto = async () => {
      if (!userId) {
        setLoading(false);
        return;
      }

      try {
        const { data: userProfile } = await supabase
          .from('profiles')
          .select('primary_photo_path, primary_photo_updated_at, avatar_url')
          .eq('id', userId)
          .single();

        if (userProfile?.primary_photo_path) {
          const url = getPublicPhotoUrl(userProfile.primary_photo_path, userProfile.primary_photo_updated_at);
          if (url) {
            setPhotoUrl(url);
          }
        } else if (userProfile?.avatar_url) {
          setPhotoUrl(userProfile.avatar_url);
        }
      } catch (error) {
        console.error('Error fetching photo for blur preview:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPrimaryPhoto();
  }, [userId]);


  const handleRequestClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowRequestModal(true);
  };

  const handleModalClose = () => {
    setShowRequestModal(false);
    if (onRequestSent) {
      onRequestSent();
    }
  };

  if (loading) {
    return (
      <div className={`${config.container} ${className} rounded-full bg-[#1a1a1a] flex items-center justify-center border border-[#2a2a2a]`}>
        <Loader2 className={`${config.icon} text-[#C9A24D] animate-spin`} />
      </div>
    );
  }

  return (
    <>
      <div
        className={`${config.container} ${className} relative rounded-full overflow-hidden cursor-pointer group`}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={handleRequestClick}
      >
        {/* Blurred photo background */}
        {photoUrl ? (
          <img
            src={photoUrl}
            alt="Blurred preview"
            className="w-full h-full object-cover"
            style={{
              filter: 'blur(12px) brightness(0.7)',
              transform: 'scale(1.1)' // Prevent blur edges from showing
            }}
          />
        ) : fallbackAvatar ? (
          <img
            src={fallbackAvatar}
            alt="Blurred preview"
            className="w-full h-full object-cover"
            style={{
              filter: 'blur(10px) brightness(0.7)',
              transform: 'scale(1.1)'
            }}
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-[#C9A24D]/30 to-[#C9A24D]/10" />
        )}

        {/* Overlay with lock icon and request button */}
        <div 
          className={`absolute inset-0 flex flex-col items-center justify-center bg-black/40 transition-all duration-200 ${
            isHovered ? 'bg-black/60' : 'bg-black/40'
          }`}
        >
          {/* Lock indicator */}
          <div className={`p-1.5 bg-[#1a1a1a]/80 rounded-full mb-1 border border-[#C9A24D]/30 ${
            isHovered ? 'scale-110' : 'scale-100'
          } transition-transform duration-200`}>
            <Lock className={`${config.lockIcon} text-[#C9A24D]`} />
          </div>

          {/* Request button - shows on hover for larger sizes */}
          {(size === 'lg' || size === 'xl') && (
            <button
              onClick={handleRequestClick}
              className={`${config.buttonPadding} ${config.text} bg-[#C9A24D] text-[#141414] font-semibold rounded-full 
                opacity-0 group-hover:opacity-100 transform translate-y-1 group-hover:translate-y-0 
                transition-all duration-200 hover:bg-[#d4af5a] flex items-center gap-1 whitespace-nowrap`}
            >
              <Eye className="w-3 h-3" />
              Request
            </button>
          )}
        </div>

        {/* Ring indicator */}
        <div className="absolute inset-0 rounded-full ring-2 ring-[#C9A24D]/30 ring-inset pointer-events-none" />
      </div>

      {/* Photo Request Modal */}
      <PhotoRequestModal
        isOpen={showRequestModal}
        onClose={handleModalClose}
        targetUserId={userId}
        targetUserName={userName}
        mode="request"
      />
    </>
  );
};

export default BlurredPhotoPreview;
