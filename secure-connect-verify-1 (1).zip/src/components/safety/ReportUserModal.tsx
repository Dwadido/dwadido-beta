import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { X, AlertTriangle, Loader2, CheckCircle } from 'lucide-react';

interface ReportUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportedUserId: string;
  reportedUserName?: string;
}

const REPORT_REASONS = [
  { id: 'harassment', label: 'Harassment or bullying' },
  { id: 'inappropriate', label: 'Inappropriate content' },
  { id: 'spam', label: 'Spam or scam' },
  { id: 'fake', label: 'Fake profile' },
  { id: 'underage', label: 'Appears to be underage' },
  { id: 'threatening', label: 'Threatening behavior' },
  { id: 'other', label: 'Other' }
];

const ReportUserModal: React.FC<ReportUserModalProps> = ({
  isOpen,
  onClose,
  reportedUserId,
  reportedUserName
}) => {
  const [selectedReason, setSelectedReason] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  // Handle body scroll lock for iOS
  useEffect(() => {
    if (isOpen) {
      const scrollY = window.scrollY;
      document.body.style.position = 'fixed';
      document.body.style.top = `-${scrollY}px`;
      document.body.style.width = '100%';
    } else {
      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);
    }

    return () => {
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
    };
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedReason) {
      setError('Please select a reason for your report');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      const { data, error: fnError } = await supabase.functions.invoke('report-user', {
        body: {
          reported_user_id: reportedUserId,
          reason: selectedReason,
          description: description.trim() || undefined
        }
      });

      if (fnError) throw fnError;
      if (data.error) throw new Error(data.error);

      setSubmitted(true);
      setTimeout(() => {
        onClose();
        setSubmitted(false);
        setSelectedReason('');
        setDescription('');
      }, 2000);
    } catch (err: any) {
      setError(err.message || 'Failed to submit report');
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden" style={{ WebkitOverflowScrolling: 'touch' }}>
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      
      {/* Subtle gold ambient glow */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#C9A24D]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#C9A24D]/5 rounded-full blur-3xl" />
      </div>
      
      <div className="relative min-h-full flex items-center justify-center p-4 py-8">
        <div className="relative bg-[#141414] rounded-2xl w-full max-w-md shadow-2xl border border-[#C9A24D]/20">
          {submitted ? (
            <div className="p-8 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-[#C9A24D]/10 rounded-full flex items-center justify-center border border-[#C9A24D]/30">
                <CheckCircle className="w-8 h-8 text-[#C9A24D]" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Report Submitted</h3>
              <p className="text-gray-400">
                Thank you for helping keep Dwadido safe. We'll review your report promptly.
              </p>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between p-6 border-b border-[#1a1a1a]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-red-500/10 rounded-xl flex items-center justify-center border border-red-500/30">
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-white">Report User</h2>
                    {reportedUserName && (
                      <p className="text-sm text-gray-500">Reporting: {reportedUserName}</p>
                    )}
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-[#1a1a1a] rounded-xl transition-colors text-gray-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-3">
                    Why are you reporting this user?
                  </label>
                  <div className="space-y-2">
                    {REPORT_REASONS.map((reason) => (
                      <label
                        key={reason.id}
                        className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${
                          selectedReason === reason.id
                            ? 'border-[#C9A24D] bg-[#C9A24D]/10'
                            : 'border-[#252525] hover:border-[#333333] bg-[#1a1a1a]'
                        }`}
                      >
                        <input
                          type="radio"
                          name="reason"
                          value={reason.id}
                          checked={selectedReason === reason.id}
                          onChange={(e) => setSelectedReason(e.target.value)}
                          className="w-4 h-4 text-[#C9A24D] bg-[#1a1a1a] border-[#333333] focus:ring-[#C9A24D] focus:ring-offset-[#141414]"
                        />
                        <span className="text-white">{reason.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Additional details (optional)
                  </label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Provide any additional context that might help us investigate..."
                    rows={3}
                    className="w-full px-4 py-3 bg-[#1a1a1a] border border-[#252525] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#C9A24D]/50 focus:border-[#C9A24D] resize-none transition-all"
                  />
                </div>

                {error && (
                  <div className="p-3 bg-red-900/20 border border-red-500/30 rounded-xl text-red-400 text-sm">
                    {error}
                  </div>
                )}

                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={onClose}
                    className="flex-1 py-3 bg-[#1a1a1a] text-gray-300 font-medium rounded-xl hover:bg-[#252525] transition-all border border-[#252525]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting || !selectedReason}
                    className="flex-1 py-3 bg-[#C9A24D] text-[#141414] font-semibold rounded-xl hover:bg-[#D4AF5B] transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-[#C9A24D]/20"
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      'Submit Report'
                    )}
                  </button>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReportUserModal;
