// RedeemPage — Build 2026-02-19T16:52:00Z-v4 (already-connected alignment fix)


import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { confirmRedeemCode } from '@/lib/redeemCode';


import { Heart, Loader2, Check, X, ArrowRight, Shield, Sparkles, Clock, AlertTriangle } from 'lucide-react';
import AuthModal from '@/components/auth/AuthModal';
import { calmTimeColors, calmMessages, formatRemainingTimeCalm } from '@/lib/designGuidelines';

/**
 * RedeemPage - Crush Code Redemption
 * 
 * Design Philosophy (Dwadido Guidelines):
 * - NO urgency language ("Hurry!", "Act fast!", "Don't miss out!")
 * - NO countdown timers with escalating colors (red/orange warnings)
 * - NO animate-pulse on time-sensitive elements
 * - Calm, informational display of time remaining
 * - Supportive language that respects user autonomy
 */

interface TimeRemaining {
  total_ms: number;
  hours: number;
  minutes: number;
  seconds: number;
  formatted: string;
}

interface TimeLimitedLinkData {
  valid: boolean;
  code: string;
  expires_at: string;
  time_remaining: TimeRemaining;
  expiration_hours: number;
}

const RedeemPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const [code, setCode] = useState(searchParams.get('code') || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  
  // Time-limited link state
  const [isTimeLimitedLink, setIsTimeLimitedLink] = useState(false);
  const [timeLimitedData, setTimeLimitedData] = useState<TimeLimitedLinkData | null>(null);
  const [linkExpired, setLinkExpired] = useState(false);
  const [linkError, setLinkError] = useState<string | null>(null);
  const [validatingLink, setValidatingLink] = useState(false);
  const [countdown, setCountdown] = useState<TimeRemaining | null>(null);

  // Check for time-limited link token
  const linkToken = searchParams.get('t');

  // Validate time-limited link
  const validateTimeLimitedLink = useCallback(async (token: string) => {
    setValidatingLink(true);
    setLinkError(null);
    
    try {
      const { data, error } = await supabase.functions.invoke('time-limited-link', {
        body: {
          action: 'validate',
          token: token
        }
      });

      if (error) throw error;
      
      if (data?.valid) {
        setTimeLimitedData(data);
        setCode(data.code);
        setCountdown(data.time_remaining);
        setIsTimeLimitedLink(true);
      } else {
        setLinkExpired(data?.expired || false);
        setLinkError(data?.error || 'This link is no longer valid');
      }
    } catch (err: any) {
      console.error('Error validating link:', err);
      setLinkError(err.message || 'Failed to validate link');
    } finally {
      setValidatingLink(false);
    }
  }, []);

  // Check for time-limited link on mount
  useEffect(() => {
    if (linkToken) {
      validateTimeLimitedLink(linkToken);
    } else {
      const urlCode = searchParams.get('code');
      if (urlCode) {
        setCode(urlCode.toUpperCase());
      }
    }
  }, [linkToken, searchParams, validateTimeLimitedLink]);

  // Countdown timer for time-limited links (calm, no urgency escalation)
  useEffect(() => {
    if (!isTimeLimitedLink || !timeLimitedData) return;

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const expiresAt = new Date(timeLimitedData.expires_at).getTime();
      const remaining = expiresAt - now;

      if (remaining <= 0) {
        setLinkExpired(true);
        setCountdown(null);
        clearInterval(interval);
        return;
      }

      const hours = Math.floor(remaining / (1000 * 60 * 60));
      const minutes = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((remaining % (1000 * 60)) / 1000);

      setCountdown({
        total_ms: remaining,
        hours,
        minutes,
        seconds,
        // Calm formatting - no urgency
        formatted: formatRemainingTimeCalm(hours, minutes, seconds)
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isTimeLimitedLink, timeLimitedData]);

  const handleRedeem = async () => {
    if (!code.trim()) {
      setError('Please enter a code');
      return;
    }

    if (!isAuthenticated || !user?.id) {
      setShowAuthModal(true);
      return;
    }

    // Check if link expired before redeeming
    if (isTimeLimitedLink && linkExpired) {
      setError('This link has expired. Please ask for a new link.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const normalizedCode = code.toUpperCase();
      console.log('[RedeemPage] Redeeming code:', normalizedCode, 'user:', user.id);

      // ── Direct DB call ──
      const result = await confirmRedeemCode(normalizedCode, user.id);
      console.log('[RedeemPage] Redeem response:', result);

      if (!result.success) {
        // V4: If already connected, redirect to dashboard connections tab
        if (result.code === 'ALREADY_CONNECTED' || result.code === 'ALREADY_MATCHED') {
          setError('You already have an active connection with this person. Redirecting to your connections...');
          setTimeout(() => {
            navigate('/dashboard');
          }, 1500);
          return;
        }
        throw new Error(result.error || 'Failed to redeem code');
      }

      setSuccess(true);
      
      // Redirect to dashboard after success
      setTimeout(() => {
        navigate('/dashboard');
      }, 2000);
    } catch (err: any) {
      console.error('[RedeemPage] Redeem error:', err);
      setError(err.message || 'Failed to redeem code. Please try again.');
    } finally {
      setLoading(false);
    }

  };


  const handleCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
    setCode(value);
    setError(null);
  };

  // Show loading state while validating time-limited link
  if (validatingLink) {
    return (
      <div className="min-h-screen bg-charcoal flex items-center justify-center p-4">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-gold animate-spin mx-auto mb-4" />
          <p className="text-gray-400">Validating your link...</p>
        </div>
      </div>
    );
  }

  // Show error state for invalid/expired time-limited links (calm, no urgency)
  if (linkToken && (linkError || linkExpired)) {
    return (
      <div className="min-h-screen bg-charcoal flex items-center justify-center p-4">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gray-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gray-500/5 rounded-full blur-3xl" />
        </div>

        <div className="relative w-full max-w-md">
          <div className="bg-charcoal-800 rounded-3xl border border-charcoal-600 overflow-hidden shadow-2xl">
            {/* Calm header - no red urgency colors */}
            <div className="bg-gradient-to-r from-gray-500/20 to-gray-500/10 p-8 text-center">
              <div className="w-20 h-20 bg-gray-500/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Clock className="w-10 h-10 text-gray-400" />
              </div>
              <h1 className="text-2xl font-bold text-white mb-2">
                {calmMessages.timeLimited.expired}
              </h1>
              <p className="text-gray-400">
                {calmMessages.timeLimited.expiredSubtitle}
              </p>
            </div>

            <div className="p-8">
              <p className="text-sm text-gray-400 text-center mb-6">
                You can still redeem a code manually if you have one.
              </p>
              
              <button
                onClick={() => {
                  setLinkError(null);
                  setLinkExpired(false);
                  navigate('/redeem');
                }}
                className="w-full py-4 bg-gold hover:bg-gold-400 text-charcoal font-semibold rounded-xl transition-all flex items-center justify-center gap-2"
              >
                Enter Code Manually
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div className="mt-6 text-center">
            <button
              onClick={() => navigate('/')}
              className="text-gray-400 hover:text-white text-sm transition-colors"
            >
              ← Back to Dwadido
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-charcoal flex items-center justify-center p-4">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gold/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Time-Limited Info Banner - Calm, no urgency */}
        {isTimeLimitedLink && countdown && !success && (
          <div className={`mb-4 rounded-2xl overflow-hidden ${calmTimeColors.available.bg} border ${calmTimeColors.available.border}`}>
            <div className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center bg-purple-500/30`}>
                    {/* No animate-pulse - calm, static icon */}
                    <Clock className={`w-5 h-5 ${calmTimeColors.available.icon}`} />
                  </div>
                  <div>
                    <p className={`text-sm font-medium ${calmTimeColors.available.text}`}>
                      {calmMessages.timeLimited.title}
                    </p>
                    <p className="text-xs text-gray-400">
                      {calmMessages.timeLimited.subtitle}
                    </p>
                  </div>
                </div>
                <div className={`text-right px-4 py-2 rounded-xl bg-purple-500/30`}>
                  <p className={`text-lg font-bold font-mono ${calmTimeColors.available.text}`}>
                    {countdown.formatted}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Card */}
        <div className="bg-charcoal-800 rounded-3xl border border-charcoal-600 overflow-hidden shadow-2xl">
          {/* Header */}
          <div className="bg-gradient-to-r from-gold/20 to-gold/10 p-8 text-center">
            <div className="w-20 h-20 bg-gold/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Heart className="w-10 h-10 text-gold" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">
              Someone wants to connect!
            </h1>
            <p className="text-gray-400">
              {isTimeLimitedLink 
                ? 'Use this link to connect with someone special'
                : 'Enter the Crush Code to start a conversation'}

            </p>
          </div>

          {/* Content */}
          <div className="p-8">
            {success ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Check className="w-8 h-8 text-green-400" />
                </div>
                <h2 className="text-xl font-semibold text-white mb-2">Connection Made!</h2>
                <p className="text-gray-400 mb-4">
                  You're now connected. Redirecting to your dashboard...
                </p>
                <Loader2 className="w-5 h-5 text-gold animate-spin mx-auto" />
              </div>
            ) : (
              <>
                {/* Code Input */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-gray-400 mb-2">
                    {isTimeLimitedLink ? 'Your Connection Code' : 'Enter Crush Code'}
                  </label>

                  <input
                    type="text"
                    value={code}
                    onChange={handleCodeChange}
                    placeholder="XXXXXX"
                    disabled={isTimeLimitedLink}
                    className={`w-full px-4 py-4 bg-charcoal-700 border border-charcoal-600 rounded-xl text-white text-center font-mono text-2xl tracking-[0.3em] placeholder:text-gray-600 focus:outline-none focus:ring-2 focus:ring-gold/50 focus:border-gold/50 transition-all ${
                      isTimeLimitedLink ? 'bg-charcoal-600 cursor-not-allowed' : ''
                    }`}
                    maxLength={6}
                    autoFocus={!isTimeLimitedLink}
                  />
                  {isTimeLimitedLink && (
                    <p className="mt-2 text-xs text-purple-400 text-center">
                      Code auto-filled from your link
                    </p>
                  )}
                  {error && (
                    <div className="mt-2 flex items-center gap-2 text-red-400 text-sm">
                      <X className="w-4 h-4" />
                      {error}
                    </div>
                  )}
                </div>

                {/* Redeem Button */}
                <button
                  onClick={handleRedeem}
                  disabled={loading || code.length < 6 || (isTimeLimitedLink && linkExpired)}
                  className="w-full py-4 bg-gold hover:bg-gold-400 disabled:bg-charcoal-600 disabled:text-gray-500 text-charcoal font-semibold rounded-xl transition-all flex items-center justify-center gap-2"
                >
                  {loading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      {isAuthenticated ? 'Accept Connection' : 'Sign in to Connect'}
                      <ArrowRight className="w-5 h-5" />
                    </>
                  )}
                </button>

                {/* Info - Calm, supportive language */}
                <div className="mt-6 space-y-3">
                  <div className="flex items-start gap-3 p-3 bg-charcoal-700/50 rounded-xl">
                    <Shield className="w-5 h-5 text-gold mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-300 font-medium">Safe & Verified</p>
                      <p className="text-xs text-gray-500">
                        All connections require mutual consent. You can end any chat at any time.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 p-3 bg-charcoal-700/50 rounded-xl">
                    <Sparkles className="w-5 h-5 text-gold mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-300 font-medium">Intentional Connections</p>
                      <p className="text-xs text-gray-500">
                        {/* Calm language - no "Act fast!" or urgency */}
                        This code was shared specifically with you. Take your time.
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Footer */}
          <div className="px-8 pb-8">
            <div className="text-center">
              <p className="text-xs text-gray-500">
                Don't have an account?{' '}
                <button
                  onClick={() => setShowAuthModal(true)}
                  className="text-gold hover:underline"
                >
                  Sign up for free
                </button>
              </p>
            </div>
          </div>
        </div>

        {/* Back to home link */}
        <div className="mt-6 text-center">
          <button
            onClick={() => navigate('/')}
            className="text-gray-400 hover:text-white text-sm transition-colors"
          >
            ← Back to Dwadido
          </button>
        </div>
      </div>

      {/* Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        initialMode="signup"
      />
    </div>
  );
};

export default RedeemPage;
