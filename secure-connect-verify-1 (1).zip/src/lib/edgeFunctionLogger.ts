/**
 * Lightweight structured error logger for edge function calls.
 * 
 * Purpose: Improve production visibility without adding external services.
 * - Logs structured error details (function name, action, error message, timestamp)
 * - Provides user-friendly error messages for common failure modes
 * - Zero external dependencies — console-only logging
 * 
 * This does NOT change any UI behavior. It only adds structured console output
 * for debugging production issues.
 */

// ─── Error Classification ────────────────────────────────────────────────
type ErrorSeverity = 'low' | 'medium' | 'high' | 'critical';

interface StructuredError {
  function: string;
  action?: string;
  message: string;
  code?: string;
  severity: ErrorSeverity;
  timestamp: string;
  retryable: boolean;
  userMessage: string;
}

// Known error patterns and their user-friendly messages
const ERROR_PATTERNS: Array<{
  pattern: RegExp | string;
  severity: ErrorSeverity;
  retryable: boolean;
  userMessage: string;
}> = [
  {
    pattern: /timed?\s*out/i,
    severity: 'medium',
    retryable: true,
    userMessage: 'The request took too long. Please try again.',
  },
  {
    pattern: /rate.?limit/i,
    severity: 'low',
    retryable: true,
    userMessage: 'Too many requests. Please wait a moment and try again.',
  },
  {
    pattern: /unauthorized|auth/i,
    severity: 'high',
    retryable: false,
    userMessage: 'Your session may have expired. Please sign in again.',
  },
  {
    pattern: /network|fetch|connect/i,
    severity: 'medium',
    retryable: true,
    userMessage: 'Network issue. Please check your connection and try again.',
  },
  {
    pattern: /not.?found/i,
    severity: 'low',
    retryable: false,
    userMessage: 'The requested resource was not found.',
  },
  {
    pattern: /server|internal|500/i,
    severity: 'high',
    retryable: true,
    userMessage: 'Something went wrong on our end. Please try again shortly.',
  },
  {
    pattern: /unavailable|502|503|504/i,
    severity: 'medium',
    retryable: true,
    userMessage: 'Service temporarily unavailable. Please try again shortly.',
  },
];

function classifyError(
  errorMessage: string,
  errorCode?: string
): { severity: ErrorSeverity; retryable: boolean; userMessage: string } {
  // Check error code first
  if (errorCode === 'RATE_LIMITED') {
    return {
      severity: 'low',
      retryable: true,
      userMessage: 'Too many requests. Please wait a moment and try again.',
    };
  }

  if (errorCode === 'AUTH_ERROR') {
    return {
      severity: 'high',
      retryable: false,
      userMessage: 'Your session may have expired. Please sign in again.',
    };
  }

  // Check message patterns
  for (const { pattern, severity, retryable, userMessage } of ERROR_PATTERNS) {
    if (typeof pattern === 'string') {
      if (errorMessage.toLowerCase().includes(pattern.toLowerCase())) {
        return { severity, retryable, userMessage };
      }
    } else if (pattern.test(errorMessage)) {
      return { severity, retryable, userMessage };
    }
  }

  // Default classification
  return {
    severity: 'medium',
    retryable: false,
    userMessage: 'Something went wrong. Please try again.',
  };
}

// ─── Public API ──────────────────────────────────────────────────────────

/**
 * Log a structured error from an edge function call.
 * Returns a user-friendly error message suitable for display in the UI.
 */
export function logEdgeFunctionError(
  functionName: string,
  error: Error | string | unknown,
  action?: string
): string {
  const errorMessage =
    error instanceof Error
      ? error.message
      : typeof error === 'string'
        ? error
        : 'Unknown error';

  const errorCode =
    error instanceof Error ? (error as any).code : undefined;

  const classification = classifyError(errorMessage, errorCode);

  const structured: StructuredError = {
    function: functionName,
    action,
    message: errorMessage,
    code: errorCode,
    severity: classification.severity,
    timestamp: new Date().toISOString(),
    retryable: classification.retryable,
    userMessage: classification.userMessage,
  };

  // Structured console output for production debugging
  if (classification.severity === 'critical' || classification.severity === 'high') {
    console.error(
      `[EdgeFn:${functionName}${action ? `:${action}` : ''}] ${classification.severity.toUpperCase()}: ${errorMessage}`,
      structured
    );
  } else {
    console.warn(
      `[EdgeFn:${functionName}${action ? `:${action}` : ''}] ${classification.severity.toUpperCase()}: ${errorMessage}`,
      structured
    );
  }

  return classification.userMessage;
}

/**
 * Log a successful edge function call (for monitoring patterns).
 * Only logs in development mode to avoid production noise.
 */
export function logEdgeFunctionSuccess(
  functionName: string,
  action?: string,
  durationMs?: number
): void {
  if (import.meta.env.DEV) {
    console.debug(
      `[EdgeFn:${functionName}${action ? `:${action}` : ''}] OK${durationMs ? ` (${durationMs}ms)` : ''}`
    );
  }
}

/**
 * Wrap an edge function call with structured error logging.
 * Returns { data, error, userMessage } where userMessage is always a safe string for UI display.
 */
export async function withEdgeFunctionLogging<T>(
  functionName: string,
  action: string | undefined,
  callFn: () => Promise<{ data: T | null; error: Error | null }>
): Promise<{ data: T | null; error: Error | null; userMessage: string | null }> {
  const start = Date.now();

  try {
    const result = await callFn();
    const duration = Date.now() - start;

    if (result.error) {
      const userMessage = logEdgeFunctionError(functionName, result.error, action);
      return { data: null, error: result.error, userMessage };
    }

    logEdgeFunctionSuccess(functionName, action, duration);
    return { data: result.data, error: null, userMessage: null };
  } catch (err) {
    const userMessage = logEdgeFunctionError(functionName, err, action);
    return {
      data: null,
      error: err instanceof Error ? err : new Error(String(err)),
      userMessage,
    };
  }
}
