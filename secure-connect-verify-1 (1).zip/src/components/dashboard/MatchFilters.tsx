/**
 * =============================================================================
 * DWADIDO INTENT ALIGNMENT UTILITIES
 * =============================================================================
 * 
 * Per V1 Decisions:
 * - Profile Search Filters are REMOVED - Dwadido is intent-led, not search-led
 * - This file now only contains utility functions for intent alignment
 * - NO UI components, NO filter state management
 * 
 * Per AI Matching Instructions: Intent mismatch = no match
 * =============================================================================
 */

// =============================================================================
// INTENT ALIGNMENT CHECK
// Per AI Matching Instructions: Intent mismatch = no match
// =============================================================================

// Intent Types aligned with Dwadido's core philosophy:
// - friends_first: Friends First - standalone intent, valid intentional path
// - dating: Dating - open to meeting new people
// - long_term_relationship: Long-Term Relationship - seeking committed relationship
// - lifetime_partner: Lifetime Partner / Marriage - looking for marriage

/**
 * Check if two users have aligned relationship intents
 * Returns true if intents are compatible, false if they should not match
 * Intent is a HARD FILTER: Intent mismatch = no match | Intent alignment = match eligible
 */
export function checkIntentAlignment(
  userIntent: string | null | undefined,
  matchIntent: string | null | undefined
): boolean {
  // If either user hasn't set intent, allow the match (don't penalize incomplete profiles)
  if (!userIntent || !matchIntent) return true;
  
  // Exact match - always aligned
  if (userIntent === matchIntent) return true;
  
  // Compatible intent pairs (per Dwadido philosophy)
  // Intent is a HARD FILTER - only these specific combinations are allowed
  // "Friends First" is a standalone first-class intent, not a sub-label
  const compatibleIntents: Record<string, string[]> = {
    // Friends First can match with Dating (natural progression)
    'friends_first': ['dating'],
    // Dating can match with Friends First or Long-Term Relationship
    'dating': ['friends_first', 'long_term_relationship'],
    // Long-Term Relationship can match with Dating or Lifetime Partner
    'long_term_relationship': ['dating', 'lifetime_partner'],
    // Lifetime Partner can match with Long-Term Relationship
    'lifetime_partner': ['long_term_relationship']
  };
  
  return compatibleIntents[userIntent]?.includes(matchIntent) || false;
}

/**
 * Helper function to calculate age from date of birth
 */
export function calculateAge(dateOfBirth: string | null | undefined): number | null {
  if (!dateOfBirth) return null;
  
  const today = new Date();
  const birthDate = new Date(dateOfBirth);
  
  if (isNaN(birthDate.getTime())) return null;
  
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  
  return age;
}
