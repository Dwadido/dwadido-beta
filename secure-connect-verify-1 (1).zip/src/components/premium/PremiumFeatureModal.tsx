import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Crown,
  Lock,
  X,
  Sparkles,
  Key,
  Clock,
  Filter,
  BadgeCheck,
  Video,
  Image,
  CheckCheck,
  Check,
  ArrowRight,
} from 'lucide-react';
import { PremiumFeatures, PREMIUM_PLANS } from '@/contexts/PremiumContext';

// Feature metadata for displaying in the modal
export interface PremiumFeatureInfo {
  id: keyof PremiumFeatures | string;
  title: string;
  description: string;
  benefit: string;
  icon: React.FC<{ className?: string }>;
  freeValue: string;
  premiumValue: string;
}

// Map of all premium features with their display info
// NOTE: advancedFilters removed - V1 decision: Dwadido is intent-led, not search-led

export const PREMIUM_FEATURE_INFO: Record<string, PremiumFeatureInfo> = {
  maxActiveCodes: {
    id: 'maxActiveCodes',
    title: 'Multiple Active Codes',
    description: 'Generate up to 3 active Crush Codes at once instead of just 1.',

    benefit: 'Share your code with more people simultaneously and increase your chances of meaningful connections.',
    icon: Key,
    freeValue: '1 active code',
    premiumValue: 'Up to 3 active codes',
  },
  codeValidityHours: {
    id: 'codeValidityHours',
    title: 'Extended Code Validity',
    description: 'Keep your codes active for up to 72 hours instead of 48 hours.',
    benefit: 'More time for your crush to find and enter your code, perfect for busy schedules.',
    icon: Clock,
    freeValue: '48 hours',
    premiumValue: 'Up to 72 hours',
  },

  verificationPriority: {
    id: 'verificationPriority',
    title: 'Priority Verification',
    description: 'Get your identity verification processed faster with priority queue access.',
    benefit: 'Skip the wait and get verified sooner, building trust with your matches faster.',
    icon: BadgeCheck,
    freeValue: 'Standard processing (24-48h)',
    premiumValue: 'Priority processing (4-8h)',
  },
  videoSpeedDate: {
    id: 'videoSpeedDate',
    title: 'Video Speed-Date',
    description: 'Optional 5-minute video calls with mutual consent before meeting in person.',
    benefit: 'Get a real sense of chemistry and connection before committing to an in-person date.',
    icon: Video,
    freeValue: 'Not available',
    premiumValue: 'Unlimited video dates',
  },
  earlyPhotoRequest: {
    id: 'earlyPhotoRequest',
    title: 'Earlier Photo Access',
    description: 'Request full photo access earlier in your connections.',
    benefit: 'See who you\'re talking to sooner while still maintaining privacy-first principles.',
    icon: Image,
    freeValue: 'Standard timing',
    premiumValue: 'Earlier requests',
  },
  readReceiptControl: {
    id: 'readReceiptControl',
    title: 'Read Receipt Control',
    description: 'Choose whether to show read receipts to your matches.',
    benefit: 'Take control of your messaging experience and respond on your own schedule.',
    icon: CheckCheck,
    freeValue: 'Always visible',
    premiumValue: 'Toggle on/off',
  },
};

interface PremiumFeatureModalProps {
  isOpen: boolean;
  onClose: () => void;
  featureId: keyof PremiumFeatures | string;
  onUpgrade?: () => void;
}

const PremiumFeatureModal: React.FC<PremiumFeatureModalProps> = ({
  isOpen,
  onClose,
  featureId,
  onUpgrade,
}) => {
  const navigate = useNavigate();
  const feature = PREMIUM_FEATURE_INFO[featureId];

  if (!isOpen || !feature) return null;

  const Icon = feature.icon;

  const handleUpgrade = () => {
    if (onUpgrade) {
      onUpgrade();
    } else {
      navigate('/premium');
    }
    onClose();
  };

  // Prevent body scroll when modal is open
  React.useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-md bg-charcoal-800 rounded-2xl border border-charcoal-600 overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        {/* Header with gradient */}
        <div className="relative bg-gradient-to-br from-gold/20 via-gold/10 to-transparent p-6 pb-8">
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Lock icon with feature icon */}
          <div className="relative w-20 h-20 mx-auto mb-4">
            <div className="absolute inset-0 bg-gold/20 rounded-2xl rotate-6" />
            <div className="relative w-full h-full bg-charcoal-700 rounded-2xl flex items-center justify-center border border-gold/30">
              <Icon className="w-10 h-10 text-gold" />
            </div>
            <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-charcoal-800 rounded-full flex items-center justify-center border-2 border-gold/50">
              <Lock className="w-4 h-4 text-gold" />
            </div>
          </div>

          {/* Premium badge */}
          <div className="flex items-center justify-center gap-2 mb-3">
            <Crown className="w-5 h-5 text-gold" />
            <span className="text-gold font-semibold">Premium Feature</span>
          </div>

          {/* Feature title */}
          <h2 className="text-2xl font-bold text-white text-center">
            {feature.title}
          </h2>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Description */}
          <p className="text-gray-300 text-center leading-relaxed">
            {feature.description}
          </p>

          {/* Benefit highlight */}
          <div className="bg-gold/10 border border-gold/20 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-gold/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-4 h-4 text-gold" />
              </div>
              <div>
                <p className="text-sm font-medium text-gold mb-1">Why you'll love it</p>
                <p className="text-sm text-gray-300">{feature.benefit}</p>
              </div>
            </div>
          </div>

          {/* Free vs Premium comparison */}
          <div className="grid grid-cols-2 gap-3">
            {/* Free tier */}
            <div className="bg-charcoal-700 rounded-xl p-4 border border-charcoal-600">
              <p className="text-xs text-gray-500 uppercase tracking-wide mb-2">Free</p>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-gray-600 flex items-center justify-center">
                  <X className="w-3 h-3 text-gray-400" />
                </div>
                <span className="text-sm text-gray-400">{feature.freeValue}</span>
              </div>
            </div>

            {/* Premium tier */}
            <div className="bg-gold/10 rounded-xl p-4 border border-gold/30">
              <p className="text-xs text-gold uppercase tracking-wide mb-2">Premium</p>
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-gold/30 flex items-center justify-center">
                  <Check className="w-3 h-3 text-gold" />
                </div>
                <span className="text-sm text-gold font-medium">{feature.premiumValue}</span>
              </div>
            </div>
          </div>

          {/* Pricing hint */}
          <p className="text-center text-sm text-gray-500">
            Starting at just {PREMIUM_PLANS.monthly.currencySymbol}{PREMIUM_PLANS.monthly.price}/month
          </p>

        </div>

        {/* Actions */}
        <div className="p-6 pt-0 space-y-3">
          {/* Upgrade button */}
          <button
            onClick={handleUpgrade}
            className="w-full py-4 bg-gold hover:bg-gold-400 text-charcoal font-semibold rounded-xl transition-all flex items-center justify-center gap-2 shadow-gold"
          >
            <Crown className="w-5 h-5" />
            Upgrade to Premium
            <ArrowRight className="w-5 h-5" />
          </button>

          {/* Maybe later */}
          <button
            onClick={onClose}
            className="w-full py-3 text-gray-400 hover:text-white font-medium transition-colors"
          >
            Maybe later
          </button>
        </div>
      </div>
    </div>
  );
};

export default PremiumFeatureModal;
