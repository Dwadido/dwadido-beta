/**
 * =============================================================================
 * CRUSH CODE REDEMPTION — Direct DB Implementation
 * =============================================================================
 *
 * Build: 2026-02-19T16:52:00Z-v4 (already-connected alignment fix)
 *
 * Replaces the broken `invokeEdgeFunction('redeem-crush-code', ...)` calls.
 *
 * Root cause of the edge function failure:
 *   The databasepad.com isolated-vm runtime does NOT support `req.headers.get()`.
 *   The edge function crashed on `req.headers.get('Authorization')` before any
 *   business logic ran, returning a generic 500 "unexpected error".
 *
 * This module performs the same logic client-side using the Supabase JS client,
 * which handles auth headers automatically via the session token.
 *
 * Flow:
 *   1. previewRedeemCode()  — validate code, return creator profile for confirmation UI
 *   2. confirmRedeemCode()  — create match, mark card as redeemed
 *
 * V4 Fixes:
 *   - "Already connected" check now uses SAME status filter as Dashboard: ['confirmed', 'active']
 *   - Removed 'pending' from the check (Dashboard never shows pending matches)
 *   - When INSERT fails with 23505 (unique constraint), looks up existing match:
 *     - If 'ended': re-activates it to 'confirmed' (allows re-matching)
 *     - If 'confirmed'/'active': returns ALREADY_CONNECTED with match details
 *   - Returns existingMatchId + existingMatchStatus when blocking, so UI can navigate
 * =============================================================================
 */

import { supabase, SUPABASE_URL } from './supabase';

// ─── Runtime Diagnostic ─────────────────────────────────────────────────
console.log('[redeemCode] Module loaded. SUPABASE_URL:', SUPABASE_URL ? `${SUPABASE_URL.substring(0, 30)}...` : '*** UNDEFINED ***');
if (!SUPABASE_URL || SUPABASE_URL === 'undefined') {
  console.error('[redeemCode] CRITICAL: SUPABASE_URL is not set! All DB calls will fail with "Failed to parse URL".');
}


// ─── Statuses that count as "visible" in the Dashboard ──────────────────
// CRITICAL: This MUST match the filter in Dashboard.tsx fetchData()
const VISIBLE_MATCH_STATUSES = ['confirmed', 'active'];


// ─── Types ──────────────────────────────────────────────────────────────

export interface RedeemPreviewUser {
  id: string;
  display_name: string | null;
  avatar_url: string | null;
  intent: string | null;
  relationship_status: string | null;
}

export interface RedeemResult {
  success: boolean;
  previewUser?: RedeemPreviewUser;
  matchedUser?: RedeemPreviewUser;
  match?: { id: string };
  matchId?: string;
  error?: string;
  code?: string; // error code like NOT_FOUND, EXPIRED, OWN_CODE, etc.
  // V4: existing match details when ALREADY_CONNECTED
  existingMatchId?: string;
  existingMatchStatus?: string;
}

// Custom error with a `.code` field for structured error handling
class RedeemError extends Error {
  code: string;
  existingMatchId?: string;
  existingMatchStatus?: string;
  constructor(message: string, code: string, opts?: { matchId?: string; matchStatus?: string }) {
    super(message);
    this.code = code;
    this.name = 'RedeemError';
    this.existingMatchId = opts?.matchId;
    this.existingMatchStatus = opts?.matchStatus;
  }
}

// ─── Defensive URL check ────────────────────────────────────────────────
function assertSupabaseReady() {
  if (!SUPABASE_URL || SUPABASE_URL === 'undefined') {
    throw new RedeemError(
      'App configuration error: database URL is missing. Please force-refresh the page (pull down on iPhone, or Ctrl+Shift+R on desktop) to load the latest version.',
      'CONFIG_ERROR'
    );
  }
}

// ─── Helper: Look up existing match between two users (any status) ──────
async function findExistingMatch(userA: string, userB: string) {
  const { data, error } = await supabase
    .from('matches')
    .select('id, status, user1_id, user2_id, confirmed_at, ended_at')
    .or(
      `and(user1_id.eq.${userA},user2_id.eq.${userB}),and(user1_id.eq.${userB},user2_id.eq.${userA})`
    )
    .maybeSingle();

  if (error) {
    console.warn('[redeemCode] findExistingMatch error:', error.message);
    return null;
  }
  return data;
}

// ─── Shared validation ──────────────────────────────────────────────────

async function validateCode(code: string, userId: string) {
  assertSupabaseReady();

  const normalizedCode = code.toUpperCase().trim();

  if (!normalizedCode || normalizedCode.length !== 6) {
    throw new RedeemError('Please enter a valid 6-character code.', 'INVALID_CODE');
  }

  // 1. Look up the crush card
  console.log('[redeemCode] Looking up code:', normalizedCode);
  const { data: card, error: cardError } = await supabase
    .from('crush_cards')
    .select('id, code, status, expires_at, creator_id')
    .eq('code', normalizedCode)
    .maybeSingle();

  if (cardError) {
    console.error('[redeemCode] Card lookup error:', cardError.message, cardError.code, cardError);
    if (cardError.message?.includes('parse URL') || cardError.message?.includes('Failed to construct')) {
      throw new RedeemError(
        'Connection error: please force-refresh the page to load the latest app version. (Pull down on iPhone, or Ctrl+Shift+R on desktop.)',
        'CONFIG_ERROR'
      );
    }
    throw new RedeemError(`Lookup failed: ${cardError.message}`, 'LOOKUP_ERROR');
  }

  if (!card) {
    console.warn('[redeemCode] Code not found:', normalizedCode);
    throw new RedeemError('Code not found. Please double-check and try again.', 'NOT_FOUND');
  }

  // 2. Check status
  if (card.status === 'redeemed') {
    throw new RedeemError('This code has already been used.', 'ALREADY_REDEEMED');
  }
  if (card.status !== 'active') {
    throw new RedeemError('This code is no longer active.', 'INACTIVE');
  }

  // 3. Check expiry
  if (new Date(card.expires_at) < new Date()) {
    throw new RedeemError('This code has expired. Ask the sender for a new one.', 'EXPIRED');
  }

  // 4. Self-redeem check
  if (card.creator_id === userId) {
    throw new RedeemError('You cannot redeem your own code.', 'OWN_CODE');
  }

  // 5. Check for existing VISIBLE match between these two users
  //    V4 FIX: Only check for statuses that the Dashboard actually shows.
  //    This prevents the "already connected" error when the match isn't visible.
  console.log('[redeemCode] Checking for existing match between', userId, 'and', card.creator_id);
  const { data: existingMatch, error: matchCheckError } = await supabase
    .from('matches')
    .select('id, status')
    .or(
      `and(user1_id.eq.${card.creator_id},user2_id.eq.${userId}),and(user1_id.eq.${userId},user2_id.eq.${card.creator_id})`
    )
    .in('status', VISIBLE_MATCH_STATUSES)  // V4: aligned with Dashboard
    .maybeSingle();

  if (matchCheckError) {
    console.warn('[redeemCode] Match check error (non-fatal):', matchCheckError.message);
    // Non-fatal — proceed anyway; the INSERT will fail if there's a unique constraint
  }

  if (existingMatch) {
    console.warn('[redeemCode] Already connected:', existingMatch.id, 'status:', existingMatch.status);
    throw new RedeemError(
      'You already have an active connection with this person. Check your Connections tab.',
      'ALREADY_CONNECTED',
      { matchId: existingMatch.id, matchStatus: existingMatch.status }
    );
  }

  // 6. Fetch creator profile
  console.log('[redeemCode] Fetching creator profile:', card.creator_id);
  const { data: creatorProfile, error: profileError } = await supabase
    .from('profiles')
    .select('id, display_name, avatar_url, intent, relationship_status')
    .eq('id', card.creator_id)
    .maybeSingle();

  if (profileError) {
    console.warn('[redeemCode] Creator profile fetch error:', profileError.message);
  }

  const previewUser: RedeemPreviewUser = creatorProfile || {
    id: card.creator_id,
    display_name: null,
    avatar_url: null,
    intent: null,
    relationship_status: null,
  };

  return { card, previewUser };
}

// ─── Preview (validate only) ────────────────────────────────────────────

export async function previewRedeemCode(code: string, userId: string): Promise<RedeemResult> {
  try {
    const { previewUser } = await validateCode(code, userId);
    console.log('[redeemCode] Preview success for code:', code);
    return { success: true, previewUser };
  } catch (err: any) {
    console.error('[redeemCode] Preview error:', err.message, err.code);
    return {
      success: false,
      error: err.message,
      code: err.code || 'UNKNOWN',
      existingMatchId: err.existingMatchId,
      existingMatchStatus: err.existingMatchStatus,
    };
  }
}

// ─── Confirm (create match) ─────────────────────────────────────────────

export async function confirmRedeemCode(code: string, userId: string): Promise<RedeemResult> {
  try {
    assertSupabaseReady();
    const { card, previewUser } = await validateCode(code, userId);

    // ── Ensure redeemer's profile exists (FK constraint on matches) ──
    console.log('[redeemCode] Ensuring redeemer profile exists:', userId);
    const { data: redeemerProfile } = await supabase
      .from('profiles')
      .select('id')
      .eq('id', userId)
      .maybeSingle();

    if (!redeemerProfile) {
      console.warn('[redeemCode] Redeemer profile missing — auto-creating');
      let email = '';
      let displayName = '';
      try {
        const { data: authData } = await supabase.auth.getUser();
        if (authData?.user) {
          email = authData.user.email || '';
          displayName = authData.user.user_metadata?.display_name || '';
        }
      } catch (e) {
        console.warn('[redeemCode] Could not fetch auth metadata:', e);
      }
      displayName = displayName || (email ? email.split('@')[0] : '') || 'User';

      const { error: profileInsertErr } = await supabase
        .from('profiles')
        .insert({
          id: userId,
          email,
          display_name: displayName,
          intent: 'dating',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });

      if (profileInsertErr && profileInsertErr.code !== '23505') {
        console.error('[redeemCode] Failed to create redeemer profile:', profileInsertErr.message);
        throw new RedeemError(
          'Could not set up your profile. Please refresh and try again.',
          'PROFILE_ERROR'
        );
      }
    }

    // ── Create the match ──
    console.log('[redeemCode] Creating match: creator=', card.creator_id, 'redeemer=', userId);
    const now = new Date().toISOString();

    const { data: matchData, error: matchError } = await supabase
      .from('matches')
      .insert({
        user1_id: card.creator_id,
        user2_id: userId,
        status: 'confirmed',
        confirmed_at: now,
        created_at: now,
      })
      .select('id')
      .single();

    if (matchError) {
      console.error('[redeemCode] Match insert error:', matchError.message, matchError.code);

      // ── V4 FIX: Handle unique constraint (23505) gracefully ──
      // The table has an order-independent unique index:
      //   UNIQUE(LEAST(user1_id, user2_id), GREATEST(user1_id, user2_id))
      // This means if a match was previously 'ended', we can't INSERT a new one.
      // Instead, we should UPDATE the existing match back to 'confirmed'.
      if (matchError.code === '23505') {
        console.log('[redeemCode] Unique constraint hit — looking up existing match to re-activate');
        
        const existingMatch = await findExistingMatch(card.creator_id, userId);
        
        if (existingMatch) {
          console.log('[redeemCode] Found existing match:', existingMatch.id, 'status:', existingMatch.status);
          
          // If the match is 'ended' or 'pending' or any non-active status, re-activate it
          if (existingMatch.status === 'ended' || existingMatch.status === 'pending' || existingMatch.status === 'expired') {
            console.log('[redeemCode] Re-activating ended/pending match:', existingMatch.id);
            
            const { error: updateErr } = await supabase
              .from('matches')
              .update({
                status: 'confirmed',
                confirmed_at: now,
                ended_at: null,
                ended_by: null,
                updated_at: now,
              })
              .eq('id', existingMatch.id);

            if (updateErr) {
              console.error('[redeemCode] Failed to re-activate match:', updateErr.message);
              throw new RedeemError(
                `Failed to re-activate connection: ${updateErr.message}`,
                'MATCH_UPDATE_ERROR'
              );
            }

            console.log('[redeemCode] Match re-activated successfully:', existingMatch.id);

            // Mark the crush card as redeemed
            const { error: cardUpdateError } = await supabase
              .from('crush_cards')
              .update({
                status: 'redeemed',
                redeemed_by: userId,
                redeemed_at: now,
              })
              .eq('id', card.id)
              .eq('creator_id', card.creator_id);

            if (cardUpdateError) {
              console.warn('[redeemCode] Card update error (non-fatal):', cardUpdateError.message);
            }

            return {
              success: true,
              matchedUser: previewUser,
              match: { id: existingMatch.id },
              matchId: existingMatch.id,
            };
          }
          
          // If the match is already 'confirmed' or 'active', it's truly a duplicate
          throw new RedeemError(
            'You already have an active connection with this person. Check your Connections tab.',
            'ALREADY_CONNECTED',
            { matchId: existingMatch.id, matchStatus: existingMatch.status }
          );
        }
        
        // Couldn't find the existing match (shouldn't happen, but handle gracefully)
        throw new RedeemError(
          'A connection with this person already exists. Please check your Connections tab.',
          'ALREADY_CONNECTED'
        );
      }

      throw new RedeemError(
        `Failed to create connection: ${matchError.message}`,
        'MATCH_INSERT_ERROR'
      );
    }

    console.log('[redeemCode] Match created:', matchData?.id);

    // ── Mark the crush card as redeemed ──
    const { error: updateError } = await supabase
      .from('crush_cards')
      .update({
        status: 'redeemed',
        redeemed_by: userId,
        redeemed_at: now,
      })
      .eq('id', card.id)
      .eq('creator_id', card.creator_id);

    if (updateError) {
      console.warn('[redeemCode] Card update error (non-fatal):', updateError.message);
      // Non-fatal — the match was already created successfully
    }

    console.log('[redeemCode] Confirm success. Match ID:', matchData?.id);

    return {
      success: true,
      matchedUser: previewUser,
      match: matchData ? { id: matchData.id } : undefined,
      matchId: matchData?.id,
    };
  } catch (err: any) {
    console.error('[redeemCode] Confirm error:', err.message, err.code);
    return {
      success: false,
      error: err.message,
      code: err.code || 'UNKNOWN',
      existingMatchId: err.existingMatchId,
      existingMatchStatus: err.existingMatchStatus,
    };
  }
}
