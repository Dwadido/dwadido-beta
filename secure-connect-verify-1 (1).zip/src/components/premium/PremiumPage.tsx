import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { usePremium, PREMIUM_PLANS, PREMIUM_FEATURE_DESCRIPTIONS, FEATURE_CATEGORIES } from '@/contexts/PremiumContext';
import { supabase } from '@/lib/supabase';
import {
  Crown,
  Check,
  Key,
  Clock,
  Filter,
  BadgeCheck,
  Video,
  Image,
  CheckCheck,
  Loader2,
  Shield,
  Heart,
  Lock,
  Sparkles,
  ArrowLeft,
  HelpCircle,
  MessageCircle,
  Infinity,
  RefreshCw,
  BarChart3,
  Layers,
  Printer,
  Bell,
  Mail,
  Link2,
  History,
  TrendingUp,
  MousePointer,
  Palette,
  Timer,
  X,
  QrCode,
  Smartphone,
  CreditCard,
  ExternalLink,
  AlertCircle,
} from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';


const iconMap: Record<string, React.FC<{ className?: string }>> = {
  key: Key,
  clock: Clock,
  filter: Filter,
  'badge-check': BadgeCheck,
  video: Video,
  image: Image,
  'check-check': CheckCheck,
  infinity: Infinity,
  'refresh-cw': RefreshCw,
  'bar-chart-3': BarChart3,
  layers: Layers,
  printer: Printer,
  bell: Bell,
  mail: Mail,
  link: Link2,
  history: History,
  'trending-up': TrendingUp,
  'mouse-pointer': MousePointer,
  palette: Palette,
  timer: Timer,
  sparkles: Sparkles,
  'shield-check': Shield,
};

// Category icons
const categoryIcons: Record<string, React.FC<{ className?: string }>> = {
  codes: Heart,
  printing_qr: Printer,
  analytics: BarChart3,
  notifications: Bell,
  sharing: Link2,
  verification: BadgeCheck,
};

const PremiumPage: React.FC = () => {
  const { user, profile } = useAuth();
  const { isPremium, subscription, daysRemaining, refreshSubscription } = usePremium();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'yearly'>('yearly');
  const [loading, setLoading] = useState(false);
  const [portalLoading, setPortalLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Check for success/cancel from Stripe redirect
  useEffect(() => {
    const success = searchParams.get('success');
    const canceled = searchParams.get('canceled');

    if (success === 'true') {
      setShowSuccess(true);
      refreshSubscription();
      // Clean up URL
      window.history.replaceState({}, '', '/premium');
    }

    if (canceled === 'true') {
      setError('Checkout was cancelled. You can try again when ready.');
      // Clean up URL
      window.history.replaceState({}, '', '/premium');
    }
  }, [searchParams, refreshSubscription]);

  const openBillingSupport = () => {
    window.dispatchEvent(new CustomEvent('openSupportChat', { detail: { category: 'billing' } }));
  };

  // Handle Stripe Checkout
  const handleSubscribe = async () => {
    if (!user || !profile) {
      navigate('/');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('stripe-create-checkout-session', {
        body: {
          plan: selectedPlan,
          userId: user.id,
          email: profile.email || user.email,
          successUrl: `${window.location.origin}/premium?success=true`,
          cancelUrl: `${window.location.origin}/premium?canceled=true`,
        },
      });

      if (fnError) {
        throw new Error(fnError.message || 'Failed to create checkout session');
      }

      if (data?.error) {
        throw new Error(data.error);
      }

      if (data?.url) {
        // Redirect to Stripe Checkout
        window.location.href = data.url;
      } else {
        throw new Error('No checkout URL returned');
      }
    } catch (error: any) {
      console.error('Error creating checkout:', error);
      setError(error.message || 'Failed to start checkout. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Handle Stripe Billing Portal
  const handleManageSubscription = async () => {
    if (!user) return;

    setPortalLoading(true);
    setError(null);

    try {
      const { data, error: fnError } = await supabase.functions.invoke('stripe-billing-portal', {
        body: {
          userId: user.id,
          returnUrl: `${window.location.origin}/premium`,
        },
      });

      if (fnError) {
        throw new Error(fnError.message || 'Failed to open billing portal');
      }

      if (data?.error) {
        throw new Error(data.error);
      }

      if (data?.url) {
        // Redirect to Stripe Billing Portal
        window.location.href = data.url;
      } else {
        throw new Error('No portal URL returned');
      }
    } catch (error: any) {
      console.error('Error opening billing portal:', error);
      setError(error.message || 'Failed to open billing portal. Please try again.');
    } finally {
      setPortalLoading(false);
    }
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-charcoal flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center">
          <div className="w-20 h-20 bg-gold/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Crown className="w-10 h-10 text-gold" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-4">Welcome to Premium!</h1>
          <p className="text-gray-400 mb-8">
            You now have access to unlimited codes, analytics, bulk generation, code renewal, notifications, verification, and all premium features.
          </p>
          <button
            onClick={() => navigate('/dashboard')}
            className="w-full py-4 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all shadow-gold"
          >
            Go to Dashboard
          </button>
        </div>
      </div>
    );
  }

  // ==========================================================================
  // DETAILED FEATURE LISTS BY CATEGORY
  // Aligned with Dwadido's offline-to-online dating model
  // MVP Priority: Core QR flow, Stripe subscription, Feature flags
  // ==========================================================================
  const featuresByCategory = {
    codes: [
      { name: 'Create Crush Codes', free: '1 code', premium: 'Unlimited' },
      { name: 'Code Validity', free: '7 days (fixed)', premium: 'Up to 90 days' },
      { name: 'Code Renewal', free: false, premium: true },
      { name: 'Bulk Generation', free: false, premium: 'Up to 20 at once' },
      { name: 'Basic Expiration Alerts', free: '24h alert', premium: 'Full control' },
      { name: 'Advanced Alert Timing', free: false, premium: '12h, 6h, 1h' },
    ],
    printing_qr: [
      { name: 'Digital QR Display', free: 'On-screen only', premium: 'Full features' },
      { name: 'Print QR Cards', free: false, premium: 'PDF & templates' },
      { name: 'Card Templates', free: false, premium: '8+ designs' },
      { name: 'Animated QR Codes', free: false, premium: 'Branded & animated' },
      { name: 'QR Scan History', free: false, premium: 'Full history' },
      { name: 'Print Analytics', free: false, premium: true },
    ],
    analytics: [
      { name: 'Code Analytics Dashboard', free: false, premium: true },
      { name: 'Match Analytics Dashboard', free: false, premium: true },
      { name: 'Match Insights', free: false, premium: 'AI-powered explanations' },
    ],
    notifications: [
      { name: 'Match Notifications', free: 'Basic', premium: 'Full control' },
      { name: 'Push Notifications', free: false, premium: true },
      { name: 'SMS Notifications', free: false, premium: 'High-intent events' },
      { name: 'Email Notifications', free: false, premium: 'Customizable' },
      { name: 'Match Expiring Reminders', free: false, premium: true },
      { name: 'Offline Message Alerts', free: false, premium: true },
    ],
    sharing: [
      { name: 'Basic Link Sharing', free: true, premium: true },
      { name: 'Advanced QR Sharing', free: false, premium: true },
      { name: 'Time-Limited Links', free: false, premium: '1h, 6h, 24h' },
      { name: 'Link History View', free: false, premium: true },
      { name: 'Link Click Tracking', free: false, premium: true },
      { name: 'Referral Rewards', free: false, premium: true },
    ],
    verification: [
      { name: 'Profile Verification', free: false, premium: true },
      { name: 'Age Verification Badge', free: false, premium: true },
      { name: 'Verification History', free: false, premium: true },
      { name: 'Priority Processing', free: false, premium: true },
    ],
  };

  return (
    <div className="min-h-screen bg-charcoal">
      {/* Header */}
      <div className="bg-gradient-to-b from-gold/10 to-transparent">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-gray-400 hover:text-white mb-6 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>

          <div className="text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold/20 rounded-full mb-4">
              <Crown className="w-5 h-5 text-gold" />
              <span className="text-gold font-medium">Dwadido Premium</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Unlimited connections. Full control.
            </h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Free is for understanding the concept. Premium is for managing and optimizing your connections.
            </p>
          </div>
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <div className="max-w-4xl mx-auto px-4 mb-6">
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-red-400">{error}</p>
              <button
                onClick={() => setError(null)}
                className="text-sm text-red-400/70 hover:text-red-400 mt-1"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Free vs Premium Quick Comparison */}
      <div className="max-w-4xl mx-auto px-4 mb-12">
        <div className="grid md:grid-cols-2 gap-6">
          {/* Free Tier */}
          <div className="bg-charcoal-700 border border-charcoal-600 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-gray-500/20 rounded-xl flex items-center justify-center">
                <Heart className="w-5 h-5 text-gray-400" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">Free</h3>
                <p className="text-sm text-gray-400">Intent preview only</p>
              </div>
            </div>
            <p className="text-sm text-gray-400 mb-4">
              Experience one real connection to understand how Dwadido works.
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-gray-400">
                <Check className="w-4 h-4 text-gray-500" />
                <span className="text-sm">1 Crush Code (lifetime)</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <Check className="w-4 h-4 text-gray-500" />
                <span className="text-sm">Basic scan & match</span>
              </div>
              <div className="flex items-center gap-3 text-gray-500">
                <X className="w-4 h-4" />
                <span className="text-sm">No templates</span>
              </div>
              <div className="flex items-center gap-3 text-gray-500">
                <X className="w-4 h-4" />
                <span className="text-sm">No analytics</span>
              </div>
              <div className="flex items-center gap-3 text-gray-500">
                <X className="w-4 h-4" />
                <span className="text-sm">No history</span>
              </div>
              <div className="flex items-center gap-3 text-gray-500">
                <X className="w-4 h-4" />
                <span className="text-sm">No bulk actions</span>
              </div>
            </div>
          </div>

          {/* Premium Tier */}
          <div className="bg-gradient-to-br from-gold/10 to-gold/5 border-2 border-gold/30 rounded-2xl p-6 relative">
            <div className="absolute -top-3 right-4 px-3 py-1 bg-gold text-charcoal text-xs font-bold rounded-full">
              RECOMMENDED
            </div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center">
                <Crown className="w-5 h-5 text-gold" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">Premium</h3>
                <p className="text-sm text-gold">Power & control</p>
              </div>
            </div>
            <p className="text-sm text-gray-400 mb-4">
              Manage, optimize, and scale your connections with full control.
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-3 text-white">
                <Check className="w-4 h-4 text-gold" />
                <span className="text-sm font-medium">Unlimited Crush Codes</span>
              </div>
              <div className="flex items-center gap-3 text-white">
                <Check className="w-4 h-4 text-gold" />
                <span className="text-sm">Full analytics dashboard</span>
              </div>
              <div className="flex items-center gap-3 text-white">
                <Check className="w-4 h-4 text-gold" />
                <span className="text-sm">All notifications</span>
              </div>
              <div className="flex items-center gap-3 text-white">
                <Check className="w-4 h-4 text-gold" />
                <span className="text-sm">Profile verification</span>
              </div>
              <div className="flex items-center gap-3 text-white">
                <Check className="w-4 h-4 text-gold" />
                <span className="text-sm">QR printing & templates</span>
              </div>
              <div className="flex items-center gap-3 text-white">
                <Check className="w-4 h-4 text-gold" />
                <span className="text-sm">Link history & tracking</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Current Status (if premium) */}
      {isPremium && subscription && (
        <div className="max-w-4xl mx-auto px-4 mb-8">
          <div className="bg-gold/10 border border-gold/30 rounded-2xl p-6">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gold/20 rounded-xl flex items-center justify-center">
                  <Crown className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">Premium Active</h3>
                  <p className="text-gray-400">
                    {subscription.plan === 'yearly' ? 'Yearly' : 'Monthly'} plan
                    {daysRemaining !== null && ` • ${daysRemaining} days remaining`}
                  </p>
                </div>
              </div>
              <button
                onClick={handleManageSubscription}
                disabled={portalLoading}
                className="flex items-center gap-2 px-4 py-2 bg-charcoal-600 hover:bg-charcoal-500 text-white rounded-lg transition-colors disabled:opacity-50"
              >
                {portalLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <CreditCard className="w-4 h-4" />
                    Manage Subscription
                    <ExternalLink className="w-3 h-3" />
                  </>
                )}
              </button>
            </div>
            {subscription.status === 'cancelled' && (
              <p className="mt-4 text-yellow-500 text-sm">
                Your subscription has been cancelled and will expire on{' '}
                {new Date(subscription.expiresAt!).toLocaleDateString()}
              </p>
            )}
          </div>
        </div>
      )}

      {/* Detailed Feature Comparison by Category */}
      <div className="max-w-4xl mx-auto px-4 mb-12">
        <h2 className="text-2xl font-bold text-white mb-6">Premium Features by Category</h2>
        <div className="space-y-4">
          {Object.entries(FEATURE_CATEGORIES).map(([key, category]) => {
            const CategoryIcon = categoryIcons[key] || Heart;
            const features = featuresByCategory[key as keyof typeof featuresByCategory] || [];
            const isExpanded = expandedCategory === key;
            
            return (
              <div key={key} className="bg-charcoal-700 border border-charcoal-600 rounded-xl overflow-hidden">
                <button
                  onClick={() => setExpandedCategory(isExpanded ? null : key)}
                  className="w-full flex items-center justify-between p-5 hover:bg-charcoal-600/50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center">
                      <CategoryIcon className="w-5 h-5 text-gold" />
                    </div>
                    <div className="text-left">
                      <h3 className="font-semibold text-white">{category.title}</h3>
                      <p className="text-sm text-gray-400">{category.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="px-2 py-1 bg-gold/20 text-gold text-xs font-medium rounded-full">
                      {features.length} features
                    </span>
                    <ArrowLeft className={`w-5 h-5 text-gray-400 transition-transform ${isExpanded ? 'rotate-90' : '-rotate-90'}`} />
                  </div>
                </button>
                
                {isExpanded && (
                  <div className="border-t border-charcoal-600 p-5">
                    <div className="grid grid-cols-3 gap-4 mb-4 text-sm font-medium">
                      <div className="text-gray-400">Feature</div>
                      <div className="text-gray-500 text-center">Free</div>
                      <div className="text-gold text-center">Premium</div>
                    </div>
                    <div className="space-y-3">
                      {features.map((feature, index) => (
                        <div key={index} className="grid grid-cols-3 gap-4 text-sm py-2 border-b border-charcoal-600 last:border-0">
                          <div className="text-gray-300">{feature.name}</div>
                          <div className="text-center">
                            {feature.free === false ? (
                              <Lock className="w-4 h-4 text-gray-500 mx-auto" />
                            ) : feature.free === true ? (
                              <Check className="w-4 h-4 text-gray-500 mx-auto" />
                            ) : (
                              <span className="text-gray-500">{feature.free}</span>
                            )}
                          </div>
                          <div className="text-center">
                            {feature.premium === true ? (
                              <Check className="w-4 h-4 text-gold mx-auto" />
                            ) : (
                              <span className="text-gold">{feature.premium}</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* What Premium is NOT */}
      <div className="max-w-4xl mx-auto px-4 mb-12">
        <div className="bg-charcoal-700 border border-charcoal-600 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-6 h-6 text-gold" />
            <h2 className="text-xl font-bold text-white">Our Promise</h2>
          </div>
          <p className="text-gray-400 mb-4">
            Premium is about giving you more control, not more exposure. We will never:
          </p>
          <div className="grid md:grid-cols-2 gap-3">
            {[
              'Add boosts, likes, or popularity scores',
              'Show profile views or activity tracking',
              'Create endless discovery or swipe feeds',
              'Gamify with streaks, badges, or leaderboards',
              'Affect who sees whom on the map',
              'Use dark patterns or pressure messaging',
            ].map((item, index) => (
              <div key={index} className="flex items-center gap-2 text-gray-300">
                <X className="w-4 h-4 text-gray-500" />
                <span className="text-sm">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Pricing */}
      {!isPremium && (
        <div className="max-w-4xl mx-auto px-4 pb-12">
          <h2 className="text-2xl font-bold text-white mb-6 text-center">Choose Your Plan</h2>
          
          <div className="grid md:grid-cols-2 gap-4 mb-8">
            {/* Monthly Plan */}
            <button
              onClick={() => setSelectedPlan('monthly')}
              className={`p-6 rounded-2xl border-2 text-left transition-all ${
                selectedPlan === 'monthly'
                  ? 'border-gold bg-gold/5'
                  : 'border-charcoal-600 bg-charcoal-700 hover:border-charcoal-500'
              }`}
            >
              <div className="flex items-center justify-between mb-4">
                <span className="text-lg font-semibold text-white">Monthly</span>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  selectedPlan === 'monthly' ? 'border-gold bg-gold' : 'border-gray-500'
                }`}>
                  {selectedPlan === 'monthly' && <Check className="w-3 h-3 text-charcoal" />}
                </div>
              </div>
              <div className="flex items-baseline gap-1 mb-2">
                <span className="text-3xl font-bold text-white">{PREMIUM_PLANS.monthly.currencySymbol}{PREMIUM_PLANS.monthly.price}</span>
                <span className="text-gray-400">/month</span>
              </div>
              <p className="text-sm text-gray-400">{PREMIUM_PLANS.monthly.description}</p>
            </button>

            {/* Yearly Plan */}
            <button
              onClick={() => setSelectedPlan('yearly')}
              className={`p-6 rounded-2xl border-2 text-left transition-all relative ${
                selectedPlan === 'yearly'
                  ? 'border-gold bg-gold/5'
                  : 'border-charcoal-600 bg-charcoal-700 hover:border-charcoal-500'
              }`}
            >
              <div className="absolute -top-3 left-4 px-3 py-1 bg-gold text-charcoal text-xs font-bold rounded-full">
                SAVE {PREMIUM_PLANS.yearly.savings}
              </div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-lg font-semibold text-white">Yearly</span>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                  selectedPlan === 'yearly' ? 'border-gold bg-gold' : 'border-gray-500'
                }`}>
                  {selectedPlan === 'yearly' && <Check className="w-3 h-3 text-charcoal" />}
                </div>
              </div>
              <div className="flex items-baseline gap-1 mb-2">
                <span className="text-3xl font-bold text-white">{PREMIUM_PLANS.yearly.currencySymbol}{PREMIUM_PLANS.yearly.price}</span>
                <span className="text-gray-400">/year</span>
              </div>
              <p className="text-sm text-gray-400">{PREMIUM_PLANS.yearly.description}</p>
            </button>
          </div>

          <button
            onClick={handleSubscribe}
            disabled={loading || !user}
            className="w-full py-4 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all shadow-gold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <CreditCard className="w-5 h-5" />
                Subscribe to Premium
              </>
            )}
          </button>

          {!user && (
            <p className="text-center text-sm text-yellow-500 mt-4">
              Please sign in to subscribe to Premium.
            </p>
          )}

          <p className="text-center text-sm text-gray-500 mt-4">
            Secure payment powered by Stripe. Cancel anytime.
          </p>

          <div className="flex items-center justify-center gap-4 mt-4">
            <img src="https://cdn.brandfolder.io/KGT2DTA4/at/8vbr8k4mr5xjwk4hxq4t9vs/Powered_by_Stripe_-_black.svg" alt="Powered by Stripe" className="h-6 opacity-50" />
          </div>
        </div>
      )}


      {/* Billing Support Section */}
      <div className="max-w-4xl mx-auto px-4 pb-12">
        <div className="bg-charcoal-700 border border-charcoal-600 rounded-2xl p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-gold/10 rounded-xl flex items-center justify-center flex-shrink-0">
              <HelpCircle className="w-6 h-6 text-gold" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-white mb-2">Need Help with Billing?</h3>
              <p className="text-gray-400 text-sm mb-4">
                Our AI support assistant can help with subscription questions, cancellations, refunds, payment issues, and finding receipts.
              </p>
              <button
                onClick={openBillingSupport}
                className="inline-flex items-center gap-2 px-4 py-2 bg-charcoal-600 hover:bg-charcoal-500 text-white rounded-lg transition-colors"
              >
                <MessageCircle className="w-4 h-4" />
                Chat with Billing Support
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Trust Section */}
      <div className="bg-charcoal-800 border-t border-charcoal-700">
        <div className="max-w-4xl mx-auto px-4 py-12">
          <div className="flex items-center justify-center gap-8 flex-wrap">
            <div className="flex items-center gap-2 text-gray-400">
              <Shield className="w-5 h-5" />
              <span>Privacy-first</span>
            </div>
            <div className="flex items-center gap-2 text-gray-400">
              <Heart className="w-5 h-5" />
              <span>Trust-focused</span>
            </div>
            <div className="flex items-center gap-2 text-gray-400">
              <Lock className="w-5 h-5" />
              <span>No dark patterns</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PremiumPage;
