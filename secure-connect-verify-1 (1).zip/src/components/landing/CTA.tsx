import React from 'react';
import { ArrowRight, Sparkles, Shield, Clock, CheckCircle } from 'lucide-react';

interface CTAProps {
  onGetStarted: () => void;
}

const CTA: React.FC<CTAProps> = ({ onGetStarted }) => {
  return (
    <section className="py-24 bg-charcoal">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative bg-charcoal-700 rounded-3xl p-12 text-center overflow-hidden border border-charcoal-600">
          {/* Background elements */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-gold/5 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-gold/5 rounded-full blur-3xl" />
          </div>

          {/* Content */}
          <div className="relative">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold/10 backdrop-blur-sm rounded-full text-gold text-sm font-medium mb-6 border border-gold/20">
              <Sparkles className="w-4 h-4" />
              Free to get started
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
              Ready for verified connections?
            </h2>

            <p className="text-lg text-gray-400 mb-8 max-w-2xl mx-auto">
              Experience a fundamentally different approach to connection—where trust comes first. 
              Create your first Crush Code in seconds.

            </p>

            {/* Trust badges */}
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <div className="flex items-center gap-2 px-4 py-2 bg-charcoal-600 rounded-full text-gray-300 text-sm border border-charcoal-500">
                <Shield className="w-4 h-4 text-gold" />
                Zero spam
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-charcoal-600 rounded-full text-gray-300 text-sm border border-charcoal-500">
                <Clock className="w-4 h-4 text-gold" />
                17-day window
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-charcoal-600 rounded-full text-gray-300 text-sm border border-charcoal-500">
                <CheckCircle className="w-4 h-4 text-gold" />
                Verified intent
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={onGetStarted}
                className="group px-8 py-4 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all shadow-gold flex items-center justify-center gap-2"
              >
                Create Free Account
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="px-8 py-4 bg-charcoal-600 backdrop-blur-sm text-white font-semibold rounded-xl border border-charcoal-500 hover:border-gold/30 hover:bg-charcoal-500 transition-all">
                Learn More
              </button>
            </div>

            <p className="text-gray-500 text-sm mt-6">
              No credit card required • Cancel anytime • Full privacy control
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;
