// Internationalization (i18n) system for Dwadido
// Supports multiple languages with English as default

import { en, TranslationKeys } from './translations/en';
import { es } from './translations/es';
import { fr } from './translations/fr';
import { de } from './translations/de';
import { ja } from './translations/ja';
import { ko } from './translations/ko';
import { zh } from './translations/zh';
import { th } from './translations/th';
import { vi } from './translations/vi';
import { hi } from './translations/hi';
import { id } from './translations/id';
import { tl } from './translations/tl';
import { ar } from './translations/ar';
import { pt } from './translations/pt';
import { ms } from './translations/ms';

// Type for supported language codes
export type LanguageCode = 'en' | 'es' | 'fr' | 'de' | 'ja' | 'ko' | 'zh' | 'th' | 'vi' | 'hi' | 'id' | 'tl' | 'ar' | 'pt' | 'ms';

// Language metadata
export interface LanguageInfo {
  code: LanguageCode;
  name: string;
  nativeName: string;
  isRTL: boolean;
}

// Available languages
export const SUPPORTED_LANGUAGES: LanguageInfo[] = [
  { code: 'en', name: 'English', nativeName: 'English', isRTL: false },
  { code: 'es', name: 'Spanish', nativeName: 'Español', isRTL: false },
  { code: 'fr', name: 'French', nativeName: 'Français', isRTL: false },
  { code: 'de', name: 'German', nativeName: 'Deutsch', isRTL: false },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', isRTL: false },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', isRTL: true },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', isRTL: false },
  { code: 'ko', name: 'Korean', nativeName: '한국어', isRTL: false },
  { code: 'zh', name: 'Chinese', nativeName: '中文', isRTL: false },
  { code: 'th', name: 'Thai', nativeName: 'ภาษาไทย', isRTL: false },
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt', isRTL: false },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', isRTL: false },
  { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia', isRTL: false },
  { code: 'tl', name: 'Filipino', nativeName: 'Filipino/Tagalog', isRTL: false },
  { code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu', isRTL: false },
];

// Currently active languages (all languages are now active)
export const ACTIVE_LANGUAGES: LanguageCode[] = ['en', 'es', 'fr', 'de', 'pt', 'ar', 'ja', 'ko', 'zh', 'th', 'vi', 'hi', 'id', 'tl', 'ms'];

// Translation storage
const translations: Record<string, TranslationKeys> = {
  en,
  es,
  fr,
  de,
  pt,
  ar,
  ja,
  ko,
  zh,
  th,
  vi,
  hi,
  id,
  tl,
  ms,
};






// Get translations for a language (with fallback to English)
export function getTranslations(lang: LanguageCode): TranslationKeys {
  return translations[lang] || translations.en;
}

// Deep get a nested translation key using dot notation
// e.g., t('landing.hero.title') returns the title string
export function getNestedValue(obj: any, path: string): string {
  const keys = path.split('.');
  let current = obj;
  
  for (const key of keys) {
    if (current === undefined || current === null) {
      return path; // Return the key path if not found
    }
    current = current[key];
  }
  
  return typeof current === 'string' ? current : path;
}

// Interpolate variables in translation strings
// e.g., interpolate('Hello {name}!', { name: 'John' }) => 'Hello John!'
export function interpolate(text: string, variables: Record<string, string | number>): string {
  return text.replace(/\{(\w+)\}/g, (match, key) => {
    return variables[key]?.toString() ?? match;
  });
}

// Format a translation with optional variables
export function formatTranslation(
  translations: TranslationKeys,
  key: string,
  variables?: Record<string, string | number>
): string {
  const text = getNestedValue(translations, key);
  
  if (variables) {
    return interpolate(text, variables);
  }
  
  return text;
}

// Detect browser language
export function detectBrowserLanguage(): LanguageCode {
  if (typeof navigator === 'undefined') return 'en';
  
  const browserLang = navigator.language.split('-')[0];
  
  if (ACTIVE_LANGUAGES.includes(browserLang as LanguageCode)) {
    return browserLang as LanguageCode;
  }
  
  return 'en';
}

// Get language info by code
export function getLanguageInfo(code: LanguageCode): LanguageInfo | undefined {
  return SUPPORTED_LANGUAGES.find(lang => lang.code === code);
}

// Check if a language is RTL
export function isRTL(code: LanguageCode): boolean {
  const lang = getLanguageInfo(code);
  return lang?.isRTL ?? false;
}

// Export types
export type { TranslationKeys };
