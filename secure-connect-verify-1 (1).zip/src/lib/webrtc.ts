import { supabase } from './supabase';

/**
 * WebRTC Configuration
 * 
 * This implementation uses STUN servers only (no TURN).
 * 
 * STUN (Session Traversal Utilities for NAT) helps peers discover their public IP
 * addresses and works for ~80% of connections where at least one peer is not behind
 * a symmetric NAT.
 * 
 * TURN (Traversal Using Relays around NAT) would be needed for the remaining ~20%
 * of connections, but requires external infrastructure or paid services (Twilio, 
 * Daily.co, Xirsys, etc.) with API keys and ongoing costs.
 * 
 * If you need TURN support for maximum connectivity, you'll need to:
 * 1. Sign up for a TURN service (Twilio, Xirsys, Metered, etc.)
 * 2. Add your credentials to environment variables
 * 3. Modify this file to include TURN servers in the ICE configuration
 */

// Free public STUN servers for NAT traversal
const ICE_SERVERS: RTCIceServer[] = [
  // Google's STUN servers (highly reliable)
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun2.l.google.com:19302' },
  { urls: 'stun:stun3.l.google.com:19302' },
  { urls: 'stun:stun4.l.google.com:19302' },
  // Additional free STUN servers for redundancy
  { urls: 'stun:stun.stunprotocol.org:3478' },
  { urls: 'stun:stun.voip.blackberry.com:3478' },
  { urls: 'stun:stun.services.mozilla.com:3478' },
];

export type ConnectionState = 
  | 'new' 
  | 'connecting' 
  | 'connected' 
  | 'disconnected' 
  | 'reconnecting'
  | 'failed' 
  | 'closed';

export type NetworkQuality = 'excellent' | 'good' | 'fair' | 'poor' | 'unknown';

export interface NetworkStats {
  quality: NetworkQuality;
  bitrate: number;
  packetLoss: number;
  latency: number;
  jitter: number;
}

export interface WebRTCCallbacks {
  onRemoteStream: (stream: MediaStream) => void;
  onConnectionStateChange: (state: ConnectionState) => void;
  onNetworkQualityChange: (stats: NetworkStats) => void;
  onError: (error: Error) => void;
  onIceCandidate: (candidate: RTCIceCandidate) => void;
}

export interface SignalingMessage {
  type: 'offer' | 'answer' | 'ice-candidate' | 'bye';
  callId: string;
  senderId: string;
  payload: any;
  timestamp: number;
}

/**
 * WebRTCManager handles peer-to-peer video calling with:
 * - ICE candidate gathering and exchange via Supabase Realtime
 * - Connection state monitoring and automatic reconnection
 * - Network quality tracking
 * - Audio/video track management
 * - Screen sharing support
 */
export class WebRTCManager {
  private peerConnection: RTCPeerConnection | null = null;
  private localStream: MediaStream | null = null;
  private remoteStream: MediaStream | null = null;
  private callbacks: WebRTCCallbacks;
  private callId: string;
  private localUserId: string;
  private remoteUserId: string;
  private isInitiator: boolean;
  private connectionState: ConnectionState = 'new';
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 3;
  private statsInterval: NodeJS.Timeout | null = null;
  private pendingIceCandidates: RTCIceCandidate[] = [];
  private hasRemoteDescription: boolean = false;
  private realtimeChannel: any = null;

  constructor(
    callId: string,
    localUserId: string,
    remoteUserId: string,
    isInitiator: boolean,
    callbacks: WebRTCCallbacks
  ) {
    this.callId = callId;
    this.localUserId = localUserId;
    this.remoteUserId = remoteUserId;
    this.isInitiator = isInitiator;
    this.callbacks = callbacks;
  }

  /**
   * Initialize the WebRTC connection with a local media stream
   */
  async initialize(localStream: MediaStream): Promise<void> {
    this.localStream = localStream;
    
    // Create peer connection
    this.createPeerConnection();
    
    // Set up signaling channel via Supabase Realtime
    await this.setupSignalingChannel();
    
    // Add local tracks to peer connection
    this.addLocalTracks();
    
    // Start network quality monitoring
    this.startNetworkMonitoring();
    
    // If initiator, create and send offer
    if (this.isInitiator) {
      await this.createAndSendOffer();
    }
  }

  private createPeerConnection(): void {
    const config: RTCConfiguration = {
      iceServers: ICE_SERVERS,
      iceCandidatePoolSize: 10,
      bundlePolicy: 'max-bundle',
      rtcpMuxPolicy: 'require',
    };

    this.peerConnection = new RTCPeerConnection(config);

    // Handle ICE candidates
    this.peerConnection.onicecandidate = (event) => {
      if (event.candidate) {
        this.sendSignalingMessage({
          type: 'ice-candidate',
          callId: this.callId,
          senderId: this.localUserId,
          payload: event.candidate.toJSON(),
          timestamp: Date.now(),
        });
        this.callbacks.onIceCandidate(event.candidate);
      }
    };

    // Handle ICE connection state changes
    this.peerConnection.oniceconnectionstatechange = () => {
      const state = this.peerConnection?.iceConnectionState;
      console.log('ICE connection state:', state);
      
      switch (state) {
        case 'checking':
          this.updateConnectionState('connecting');
          break;
        case 'connected':
        case 'completed':
          this.updateConnectionState('connected');
          this.reconnectAttempts = 0;
          break;
        case 'disconnected':
          this.updateConnectionState('disconnected');
          this.attemptReconnection();
          break;
        case 'failed':
          this.handleConnectionFailure();
          break;
        case 'closed':
          this.updateConnectionState('closed');
          break;
      }
    };

    // Handle connection state changes
    this.peerConnection.onconnectionstatechange = () => {
      const state = this.peerConnection?.connectionState;
      console.log('Connection state:', state);
      
      if (state === 'failed') {
        this.handleConnectionFailure();
      }
    };

    // Handle remote tracks
    this.peerConnection.ontrack = (event) => {
      console.log('Received remote track:', event.track.kind);
      
      if (!this.remoteStream) {
        this.remoteStream = new MediaStream();
      }
      
      this.remoteStream.addTrack(event.track);
      this.callbacks.onRemoteStream(this.remoteStream);
    };

    // Handle negotiation needed
    this.peerConnection.onnegotiationneeded = async () => {
      console.log('Negotiation needed');
      if (this.isInitiator && this.connectionState === 'connected') {
        await this.createAndSendOffer();
      }
    };
  }

  private addLocalTracks(): void {
    if (!this.localStream || !this.peerConnection) return;

    this.localStream.getTracks().forEach((track) => {
      console.log('Adding local track:', track.kind);
      this.peerConnection!.addTrack(track, this.localStream!);
    });
  }

  private async setupSignalingChannel(): Promise<void> {
    // Create a unique channel for this call using Supabase Realtime
    const channelName = `video-call-${this.callId}`;
    
    this.realtimeChannel = supabase.channel(channelName, {
      config: {
        broadcast: { self: false },
        presence: { key: this.localUserId },
      },
    });

    // Listen for signaling messages
    this.realtimeChannel.on('broadcast', { event: 'signaling' }, async (payload: any) => {
      const message: SignalingMessage = payload.payload;
      
      // Ignore our own messages
      if (message.senderId === this.localUserId) return;
      
      console.log('Received signaling message:', message.type);
      await this.handleSignalingMessage(message);
    });

    await this.realtimeChannel.subscribe();
  }

  private async sendSignalingMessage(message: SignalingMessage): Promise<void> {
    if (!this.realtimeChannel) return;

    await this.realtimeChannel.send({
      type: 'broadcast',
      event: 'signaling',
      payload: message,
    });
  }

  private async handleSignalingMessage(message: SignalingMessage): Promise<void> {
    if (!this.peerConnection) return;

    try {
      switch (message.type) {
        case 'offer':
          await this.handleOffer(message.payload);
          break;
        case 'answer':
          await this.handleAnswer(message.payload);
          break;
        case 'ice-candidate':
          await this.handleIceCandidate(message.payload);
          break;
        case 'bye':
          this.close();
          break;
      }
    } catch (error) {
      console.error('Error handling signaling message:', error);
      this.callbacks.onError(error as Error);
    }
  }

  private async createAndSendOffer(): Promise<void> {
    if (!this.peerConnection) return;

    try {
      const offer = await this.peerConnection.createOffer({
        offerToReceiveAudio: true,
        offerToReceiveVideo: true,
      });

      await this.peerConnection.setLocalDescription(offer);

      await this.sendSignalingMessage({
        type: 'offer',
        callId: this.callId,
        senderId: this.localUserId,
        payload: offer,
        timestamp: Date.now(),
      });

      this.updateConnectionState('connecting');
    } catch (error) {
      console.error('Error creating offer:', error);
      this.callbacks.onError(error as Error);
    }
  }

  private async handleOffer(offer: RTCSessionDescriptionInit): Promise<void> {
    if (!this.peerConnection) return;

    try {
      await this.peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
      this.hasRemoteDescription = true;

      // Process any pending ICE candidates
      await this.processPendingIceCandidates();

      // Create and send answer
      const answer = await this.peerConnection.createAnswer();
      await this.peerConnection.setLocalDescription(answer);

      await this.sendSignalingMessage({
        type: 'answer',
        callId: this.callId,
        senderId: this.localUserId,
        payload: answer,
        timestamp: Date.now(),
      });
    } catch (error) {
      console.error('Error handling offer:', error);
      this.callbacks.onError(error as Error);
    }
  }

  private async handleAnswer(answer: RTCSessionDescriptionInit): Promise<void> {
    if (!this.peerConnection) return;

    try {
      await this.peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
      this.hasRemoteDescription = true;

      // Process any pending ICE candidates
      await this.processPendingIceCandidates();
    } catch (error) {
      console.error('Error handling answer:', error);
      this.callbacks.onError(error as Error);
    }
  }

  private async handleIceCandidate(candidate: RTCIceCandidateInit): Promise<void> {
    if (!this.peerConnection) return;

    const iceCandidate = new RTCIceCandidate(candidate);

    if (this.hasRemoteDescription) {
      try {
        await this.peerConnection.addIceCandidate(iceCandidate);
      } catch (error) {
        console.error('Error adding ICE candidate:', error);
      }
    } else {
      // Queue the candidate for later
      this.pendingIceCandidates.push(iceCandidate);
    }
  }

  private async processPendingIceCandidates(): Promise<void> {
    if (!this.peerConnection) return;

    for (const candidate of this.pendingIceCandidates) {
      try {
        await this.peerConnection.addIceCandidate(candidate);
      } catch (error) {
        console.error('Error adding pending ICE candidate:', error);
      }
    }
    this.pendingIceCandidates = [];
  }

  private updateConnectionState(state: ConnectionState): void {
    if (this.connectionState !== state) {
      this.connectionState = state;
      this.callbacks.onConnectionStateChange(state);
    }
  }

  private async attemptReconnection(): Promise<void> {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      this.handleConnectionFailure();
      return;
    }

    this.reconnectAttempts++;
    this.updateConnectionState('reconnecting');
    console.log(`Reconnection attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts}`);

    // Wait before attempting reconnection
    await new Promise((resolve) => setTimeout(resolve, 2000));

    if (this.connectionState === 'reconnecting') {
      // Restart ICE
      if (this.peerConnection && this.isInitiator) {
        try {
          const offer = await this.peerConnection.createOffer({ iceRestart: true });
          await this.peerConnection.setLocalDescription(offer);
          
          await this.sendSignalingMessage({
            type: 'offer',
            callId: this.callId,
            senderId: this.localUserId,
            payload: offer,
            timestamp: Date.now(),
          });
        } catch (error) {
          console.error('Error during ICE restart:', error);
          this.attemptReconnection();
        }
      }
    }
  }

  private handleConnectionFailure(): void {
    this.updateConnectionState('failed');
    this.callbacks.onError(new Error('Connection failed after multiple attempts. This may be due to restrictive network conditions (symmetric NAT/firewall).'));
  }

  private startNetworkMonitoring(): void {
    this.statsInterval = setInterval(async () => {
      if (!this.peerConnection || this.connectionState !== 'connected') return;

      try {
        const stats = await this.peerConnection.getStats();
        const networkStats = this.parseNetworkStats(stats);
        this.callbacks.onNetworkQualityChange(networkStats);
      } catch (error) {
        console.error('Error getting stats:', error);
      }
    }, 2000);
  }

  private parseNetworkStats(stats: RTCStatsReport): NetworkStats {
    let bitrate = 0;
    let packetLoss = 0;
    let latency = 0;
    let jitter = 0;
    let packetsReceived = 0;
    let packetsLost = 0;

    stats.forEach((report) => {
      if (report.type === 'inbound-rtp' && report.kind === 'video') {
        packetsReceived = report.packetsReceived || 0;
        packetsLost = report.packetsLost || 0;
        jitter = report.jitter || 0;
        
        if (report.bytesReceived) {
          // Calculate bitrate (simplified)
          bitrate = (report.bytesReceived * 8) / 1000; // kbps
        }
      }

      if (report.type === 'candidate-pair' && report.state === 'succeeded') {
        latency = report.currentRoundTripTime ? report.currentRoundTripTime * 1000 : 0;
      }
    });

    // Calculate packet loss percentage
    const totalPackets = packetsReceived + packetsLost;
    packetLoss = totalPackets > 0 ? (packetsLost / totalPackets) * 100 : 0;

    // Determine quality based on metrics
    const quality = this.calculateQuality(latency, packetLoss, jitter);

    return {
      quality,
      bitrate: Math.round(bitrate),
      packetLoss: Math.round(packetLoss * 100) / 100,
      latency: Math.round(latency),
      jitter: Math.round(jitter * 1000),
    };
  }

  private calculateQuality(latency: number, packetLoss: number, jitter: number): NetworkQuality {
    // Quality thresholds
    if (latency < 50 && packetLoss < 1 && jitter < 0.02) {
      return 'excellent';
    } else if (latency < 100 && packetLoss < 2 && jitter < 0.05) {
      return 'good';
    } else if (latency < 200 && packetLoss < 5 && jitter < 0.1) {
      return 'fair';
    } else if (latency > 0 || packetLoss > 0) {
      return 'poor';
    }
    return 'unknown';
  }

  /**
   * Toggle local video track on/off
   */
  toggleVideo(enabled: boolean): void {
    if (this.localStream) {
      this.localStream.getVideoTracks().forEach((track) => {
        track.enabled = enabled;
      });
    }
  }

  /**
   * Toggle local audio track on/off
   */
  toggleAudio(enabled: boolean): void {
    if (this.localStream) {
      this.localStream.getAudioTracks().forEach((track) => {
        track.enabled = enabled;
      });
    }
  }

  /**
   * Replace video track (e.g., for screen sharing)
   */
  async replaceVideoTrack(newTrack: MediaStreamTrack): Promise<void> {
    if (!this.peerConnection) return;

    const senders = this.peerConnection.getSenders();
    const videoSender = senders.find((sender) => sender.track?.kind === 'video');

    if (videoSender) {
      await videoSender.replaceTrack(newTrack);
    }
  }

  /**
   * Get current connection state
   */
  getConnectionState(): ConnectionState {
    return this.connectionState;
  }

  /**
   * Close the connection and clean up resources
   */
  close(): void {
    // Send bye message to remote peer
    this.sendSignalingMessage({
      type: 'bye',
      callId: this.callId,
      senderId: this.localUserId,
      payload: null,
      timestamp: Date.now(),
    });

    // Stop stats monitoring
    if (this.statsInterval) {
      clearInterval(this.statsInterval);
      this.statsInterval = null;
    }

    // Unsubscribe from realtime channel
    if (this.realtimeChannel) {
      supabase.removeChannel(this.realtimeChannel);
      this.realtimeChannel = null;
    }

    // Close peer connection
    if (this.peerConnection) {
      this.peerConnection.close();
      this.peerConnection = null;
    }

    // Stop local stream
    if (this.localStream) {
      this.localStream.getTracks().forEach((track) => track.stop());
      this.localStream = null;
    }

    this.remoteStream = null;
    this.updateConnectionState('closed');
  }
}

/**
 * Check if the browser supports WebRTC
 */
export function checkWebRTCSupport(): {
  supported: boolean;
  missingFeatures: string[];
} {
  const missingFeatures: string[] = [];

  if (!window.RTCPeerConnection) {
    missingFeatures.push('RTCPeerConnection');
  }

  if (!navigator.mediaDevices?.getUserMedia) {
    missingFeatures.push('getUserMedia');
  }

  if (!window.MediaStream) {
    missingFeatures.push('MediaStream');
  }

  return {
    supported: missingFeatures.length === 0,
    missingFeatures,
  };
}

/**
 * Enumerate available media devices (cameras and microphones)
 */
export async function getMediaDevices(): Promise<{
  videoDevices: MediaDeviceInfo[];
  audioDevices: MediaDeviceInfo[];
}> {
  const devices = await navigator.mediaDevices.enumerateDevices();

  return {
    videoDevices: devices.filter((d) => d.kind === 'videoinput'),
    audioDevices: devices.filter((d) => d.kind === 'audioinput'),
  };
}
