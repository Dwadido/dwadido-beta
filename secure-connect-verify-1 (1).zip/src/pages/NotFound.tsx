import { useLocation, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { Home, ArrowLeft } from "lucide-react";

// Dwadido Logo - Heart with gold checkmark
const DwadidoLogo = ({ className = "w-8 h-8" }: { className?: string }) => (
  <svg className={className} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path 
      d="M20 35L17.09 32.3C8.14 24.2 2 18.55 2 11.5C2 5.85 6.42 1.5 12 1.5C15.09 1.5 18.09 2.97 20 5.27C21.91 2.97 24.91 1.5 28 1.5C33.58 1.5 38 5.85 38 11.5C38 18.55 31.86 24.2 22.91 32.3L20 35Z" 
      fill="#1C1C1C"
      stroke="#C9A24D"
      strokeWidth="2"
    />
    <path 
      d="M14 19L18 23L26 15" 
      stroke="#C9A24D" 
      strokeWidth="3" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    />
  </svg>
);

const NotFound = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-charcoal p-4">
      {/* Subtle background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gold/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gold/3 rounded-full blur-3xl" />
      </div>

      <div className="relative text-center p-8 rounded-2xl border border-charcoal-600 bg-charcoal-700 shadow-2xl animate-slide-in max-w-md w-full">
        <div className="flex justify-center mb-6">
          <DwadidoLogo className="w-16 h-16" />
        </div>
        
        <h1 className="text-6xl font-bold mb-4 text-gold">404</h1>
        <h2 className="text-xl font-semibold text-white mb-2">Page Not Found</h2>
        <p className="text-gray-400 mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => navigate(-1)}
            className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-charcoal-600 text-gray-300 font-medium rounded-xl hover:bg-charcoal-500 transition-all border border-charcoal-500"
          >
            <ArrowLeft className="w-5 h-5" />
            Go Back
          </button>
          <button
            onClick={() => navigate('/')}
            className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-gold text-charcoal font-semibold rounded-xl hover:bg-gold-400 transition-all shadow-gold"
          >
            <Home className="w-5 h-5" />
            Return Home
          </button>
        </div>
      </div>
    </div>
  );
};

export default NotFound;
