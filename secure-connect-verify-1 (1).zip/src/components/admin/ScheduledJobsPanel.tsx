/**
 * ScheduledJobsPanel - Admin-only feature for managing scheduled jobs
 * 
 * POST-MVP FEATURE: This panel is deprioritized until after MVP launch.
 * Focus is on user-facing experience, intentional dating flow, and monetisation clarity.
 * 
 * Enterprise features like Slack alerts, auto job recovery, A/B testing, and ops dashboards
 * should be staged for later iterations.
 */

import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import {
  Clock, Play, Pause, RefreshCw, CheckCircle, XCircle,
  Loader2, Calendar, Timer, AlertTriangle, ChevronDown,
  ChevronUp, Settings, History, Zap, Shield, Mail, Trash2,
  BarChart3, Users, Heart, FileText, Plus, Bell, BellOff,
  AlertCircle, Send, Edit2, Save, X
} from 'lucide-react';

interface ScheduledJob {
  id: string;
  job_name: string;
  description: string;
  schedule: string;
  function_name: string;
  is_enabled: boolean;
  last_run_at: string | null;
  next_run_at: string | null;
  alert_email: string | null;
  alert_on_failure: boolean;
  consecutive_failures: number;
  last_alert_sent_at: string | null;
  created_at: string;
  updated_at: string;
}

interface JobRun {
  id: string;
  job_name: string;
  started_at: string;
  completed_at: string | null;
  status: 'running' | 'completed' | 'failed';
  results: any;
  error_message: string | null;
  triggered_by: 'scheduled' | 'manual' | 'webhook';
  created_at: string;
}

interface JobAlert {
  id: string;
  job_id: string;
  job_name: string;
  error_message: string | null;
  error_details: any;
  alert_type: 'failure' | 'recovery' | 'warning' | 'consecutive_failures';
  sent_to: string;
  sent_at: string;
  email_status: string;
  created_at: string;
}

// Job type icons and colors
const getJobTypeConfig = (jobName: string) => {
  const configs: Record<string, { icon: React.ReactNode; color: string; bgColor: string }> = {
    'verification-expiration-check': {
      icon: <Shield className="w-6 h-6" />,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20'
    },
    'weekly-summary-emails': {
      icon: <Mail className="w-6 h-6" />,
      color: 'text-purple-400',
      bgColor: 'bg-purple-500/20'
    },
    'inactive-user-reengagement': {
      icon: <Users className="w-6 h-6" />,
      color: 'text-pink-400',
      bgColor: 'bg-pink-500/20'
    },
    'match-expiration-cleanup': {
      icon: <Trash2 className="w-6 h-6" />,
      color: 'text-orange-400',
      bgColor: 'bg-orange-500/20'
    },
    'monthly-analytics-report': {
      icon: <BarChart3 className="w-6 h-6" />,
      color: 'text-green-400',
      bgColor: 'bg-green-500/20'
    }
  };

  return configs[jobName] || {
    icon: <Clock className="w-6 h-6" />,
    color: 'text-gold',
    bgColor: 'bg-gold/20'
  };
};

// Default jobs configuration
const DEFAULT_JOBS = [
  {
    job_name: 'verification-expiration-check',
    description: 'Checks for expiring verifications, sends reminder emails at 30 and 7 days, and processes expired verifications',
    schedule: '0 9 * * *',
    function_name: 'check-verification-expiration',
    is_enabled: true,
    alert_email: 'admin@crushconnect.app',
    alert_on_failure: true
  },
  {
    job_name: 'weekly-summary-emails',
    description: 'Sends weekly activity summary emails to all users who have opted in',
    schedule: '0 10 * * 0',
    function_name: 'send-weekly-summary',
    is_enabled: true,
    alert_email: 'admin@crushconnect.app',
    alert_on_failure: true
  },
  {
    job_name: 'inactive-user-reengagement',
    description: 'Sends re-engagement emails to users who have been inactive for 7+ days. Includes personalized content based on unread messages, pending matches, and profile views.',
    schedule: '0 10 * * 0',
    function_name: 'inactive-user-reengagement',
    is_enabled: true,
    alert_email: 'admin@crushconnect.app',
    alert_on_failure: true
  },
  {
    job_name: 'match-expiration-cleanup',
    description: 'Daily cleanup job that expires old pending matches (30+ days), deactivates expired crush codes and time-limited links, archives stale conversations (90+ days), and cleans up old logs.',
    schedule: '0 3 * * *',
    function_name: 'match-expiration-cleanup',
    is_enabled: true,
    alert_email: 'admin@crushconnect.app',
    alert_on_failure: true
  },
  {
    job_name: 'monthly-analytics-report',
    description: 'Generates comprehensive monthly analytics reports including user metrics, engagement stats, crush code performance, and safety metrics. Sends report to admin emails.',
    schedule: '0 9 1 * *',
    function_name: 'monthly-analytics-report',
    is_enabled: true,
    alert_email: 'admin@crushconnect.app',
    alert_on_failure: true
  }
];

const ScheduledJobsPanel: React.FC = () => {
  const [jobs, setJobs] = useState<ScheduledJob[]>([]);
  const [jobRuns, setJobRuns] = useState<JobRun[]>([]);
  const [jobAlerts, setJobAlerts] = useState<JobAlert[]>([]);
  const [loading, setLoading] = useState(true);
  const [runsLoading, setRunsLoading] = useState(false);
  const [alertsLoading, setAlertsLoading] = useState(false);
  const [runningJob, setRunningJob] = useState<string | null>(null);
  const [selectedJob, setSelectedJob] = useState<string | null>(null);
  const [expandedRun, setExpandedRun] = useState<string | null>(null);
  const [showSetupGuide, setShowSetupGuide] = useState(false);
  const [showAlerts, setShowAlerts] = useState(false);
  const [creatingJobs, setCreatingJobs] = useState(false);
  const [editingAlertEmail, setEditingAlertEmail] = useState<string | null>(null);
  const [alertEmailInput, setAlertEmailInput] = useState('');
  const [sendingTestAlert, setSendingTestAlert] = useState<string | null>(null);

  // Fetch scheduled jobs
  const fetchJobs = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('scheduled_jobs')
        .select('*')
        .order('created_at', { ascending: true });

      if (error) throw error;
      setJobs(data || []);

      // If no jobs exist, create the default jobs
      if (!data || data.length === 0) {
        await createDefaultJobs();
      }
    } catch (err) {
      console.error('Error fetching jobs:', err);
    }
    setLoading(false);
  };

  // Fetch job alerts
  const fetchJobAlerts = async () => {
    setAlertsLoading(true);
    try {
      const { data, error } = await supabase
        .from('job_alerts')
        .select('*')
        .order('sent_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setJobAlerts(data || []);
    } catch (err) {
      console.error('Error fetching job alerts:', err);
    }
    setAlertsLoading(false);
  };

  // Create default jobs
  const createDefaultJobs = async () => {
    setCreatingJobs(true);
    try {
      const { data, error } = await supabase
        .from('scheduled_jobs')
        .insert(DEFAULT_JOBS)
        .select();

      if (error) throw error;
      if (data) {
        setJobs(data);
      }
    } catch (err) {
      console.error('Error creating default jobs:', err);
    }
    setCreatingJobs(false);
  };

  // Add missing jobs
  const addMissingJobs = async () => {
    setCreatingJobs(true);
    try {
      const existingJobNames = jobs.map(j => j.job_name);
      const missingJobs = DEFAULT_JOBS.filter(j => !existingJobNames.includes(j.job_name));

      if (missingJobs.length > 0) {
        const { data, error } = await supabase
          .from('scheduled_jobs')
          .insert(missingJobs)
          .select();

        if (error) throw error;
        if (data) {
          setJobs([...jobs, ...data]);
        }
      }
    } catch (err) {
      console.error('Error adding missing jobs:', err);
    }
    setCreatingJobs(false);
  };

  // Fetch job runs for selected job
  const fetchJobRuns = async (jobName: string) => {
    setRunsLoading(true);
    try {
      const { data, error } = await supabase
        .from('scheduled_job_runs')
        .select('*')
        .eq('job_name', jobName)
        .order('started_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setJobRuns(data || []);
    } catch (err) {
      console.error('Error fetching job runs:', err);
    }
    setRunsLoading(false);
  };

  // Toggle job enabled status
  const toggleJobEnabled = async (job: ScheduledJob) => {
    try {
      const { error } = await supabase
        .from('scheduled_jobs')
        .update({ is_enabled: !job.is_enabled, updated_at: new Date().toISOString() })
        .eq('id', job.id);

      if (error) throw error;
      setJobs(jobs.map(j => j.id === job.id ? { ...j, is_enabled: !j.is_enabled } : j));
    } catch (err) {
      console.error('Error toggling job:', err);
    }
  };

  // Toggle alert on failure
  const toggleAlertOnFailure = async (job: ScheduledJob) => {
    try {
      const { error } = await supabase
        .from('scheduled_jobs')
        .update({ alert_on_failure: !job.alert_on_failure, updated_at: new Date().toISOString() })
        .eq('id', job.id);

      if (error) throw error;
      setJobs(jobs.map(j => j.id === job.id ? { ...j, alert_on_failure: !j.alert_on_failure } : j));
    } catch (err) {
      console.error('Error toggling alert:', err);
    }
  };

  // Update alert email
  const updateAlertEmail = async (jobId: string, email: string) => {
    try {
      const { error } = await supabase
        .from('scheduled_jobs')
        .update({ alert_email: email, updated_at: new Date().toISOString() })
        .eq('id', jobId);

      if (error) throw error;
      setJobs(jobs.map(j => j.id === jobId ? { ...j, alert_email: email } : j));
      setEditingAlertEmail(null);
      setAlertEmailInput('');
    } catch (err) {
      console.error('Error updating alert email:', err);
    }
  };

  // Send test alert
  const sendTestAlert = async (job: ScheduledJob) => {
    setSendingTestAlert(job.id);
    try {
      const { data, error } = await supabase.functions.invoke('send-job-alert', {
        body: {
          job_id: job.id,
          job_name: job.job_name,
          alert_type: 'warning',
          error_message: 'This is a test alert to verify your email notification settings are working correctly.',
          alert_email: job.alert_email
        }
      });

      if (error) throw error;
      
      // Refresh alerts
      await fetchJobAlerts();
      
      console.log('Test alert sent:', data);
    } catch (err) {
      console.error('Error sending test alert:', err);
    }
    setSendingTestAlert(null);
  };

  // Manually run a job
  const runJobManually = async (job: ScheduledJob) => {
    setRunningJob(job.job_name);
    try {
      const { data, error } = await supabase.functions.invoke('run-scheduled-job', {
        body: { job_name: job.job_name, triggered_by: 'manual' }
      });

      if (error) throw error;

      // Refresh job data and runs
      await fetchJobs();
      if (selectedJob === job.job_name) {
        await fetchJobRuns(job.job_name);
      }

      // Show success message
      console.log('Job completed:', data);
    } catch (err) {
      console.error('Error running job:', err);
    }
    setRunningJob(null);
  };

  useEffect(() => {
    fetchJobs();
    fetchJobAlerts();
  }, []);

  useEffect(() => {
    if (selectedJob) {
      fetchJobRuns(selectedJob);
    }
  }, [selectedJob]);

  // Parse cron expression to human readable
  const parseCronSchedule = (cron: string): string => {
    const parts = cron.split(' ');
    if (parts.length < 5) return cron;

    const [minute, hour, dayOfMonth, month, dayOfWeek] = parts;

    // Monthly (first day of month)
    if (dayOfMonth === '1' && month === '*' && dayOfWeek === '*') {
      return `Monthly on the 1st at ${hour.padStart(2, '0')}:${minute.padStart(2, '0')} UTC`;
    }
    // Daily
    if (dayOfMonth === '*' && month === '*' && dayOfWeek === '*') {
      return `Daily at ${hour.padStart(2, '0')}:${minute.padStart(2, '0')} UTC`;
    }
    // Weekly
    if (dayOfMonth === '*' && month === '*' && dayOfWeek !== '*') {
      const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      return `Every ${days[parseInt(dayOfWeek)] || dayOfWeek} at ${hour.padStart(2, '0')}:${minute.padStart(2, '0')} UTC`;
    }
    return cron;
  };

  // Get schedule badge color
  const getScheduleBadgeColor = (cron: string) => {
    const parts = cron.split(' ');
    if (parts.length < 5) return 'bg-gray-500/20 text-gray-400';
    
    const [, , dayOfMonth, , dayOfWeek] = parts;
    
    if (dayOfMonth === '1') return 'bg-purple-500/20 text-purple-400'; // Monthly
    if (dayOfWeek !== '*') return 'bg-blue-500/20 text-blue-400'; // Weekly
    return 'bg-green-500/20 text-green-400'; // Daily
  };

  // Format relative time
  const formatRelativeTime = (date: string | null): string => {
    if (!date) return 'Never';
    const now = new Date();
    const then = new Date(date);
    const diffMs = now.getTime() - then.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMs < 0) {
      // Future time
      const futureMins = Math.abs(diffMins);
      const futureHours = Math.abs(diffHours);
      const futureDays = Math.abs(diffDays);

      if (futureMins < 60) return `in ${futureMins} min`;
      if (futureHours < 24) return `in ${futureHours} hours`;
      return `in ${futureDays} days`;
    }

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} min ago`;
    if (diffHours < 24) return `${diffHours} hours ago`;
    return `${diffDays} days ago`;
  };

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-400 bg-green-500/20';
      case 'failed': return 'text-red-400 bg-red-500/20';
      case 'running': return 'text-gold bg-gold/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  // Get trigger badge
  const getTriggerBadge = (trigger: string) => {
    switch (trigger) {
      case 'manual': return { color: 'text-blue-400 bg-blue-500/20', label: 'Manual' };
      case 'scheduled': return { color: 'text-green-400 bg-green-500/20', label: 'Scheduled' };
      case 'webhook': return { color: 'text-purple-400 bg-purple-500/20', label: 'Webhook' };
      default: return { color: 'text-gray-400 bg-gray-500/20', label: trigger };
    }
  };

  // Get alert type badge
  const getAlertTypeBadge = (alertType: string) => {
    switch (alertType) {
      case 'failure': return { color: 'text-red-400 bg-red-500/20', label: 'Failure', icon: <XCircle className="w-3 h-3" /> };
      case 'recovery': return { color: 'text-green-400 bg-green-500/20', label: 'Recovery', icon: <CheckCircle className="w-3 h-3" /> };
      case 'warning': return { color: 'text-yellow-400 bg-yellow-500/20', label: 'Warning', icon: <AlertTriangle className="w-3 h-3" /> };
      case 'consecutive_failures': return { color: 'text-red-400 bg-red-500/20', label: 'Critical', icon: <AlertCircle className="w-3 h-3" /> };
      default: return { color: 'text-gray-400 bg-gray-500/20', label: alertType, icon: <Bell className="w-3 h-3" /> };
    }
  };

  // Render job results based on job type
  const renderJobResults = (run: JobRun) => {
    const results = run.results?.results || run.results;
    if (!results) return <p className="text-sm text-gray-500">No result data available</p>;

    // Verification expiration check results
    if (run.job_name === 'verification-expiration-check') {
      return (
        <div className="space-y-2">
          {results.thirtyDayReminders !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">30-Day Reminders Sent</span>
              <span className="text-white font-medium">{results.thirtyDayReminders}</span>
            </div>
          )}
          {results.sevenDayReminders !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">7-Day Reminders Sent</span>
              <span className="text-white font-medium">{results.sevenDayReminders}</span>
            </div>
          )}
          {results.expired !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Verifications Expired</span>
              <span className="text-white font-medium">{results.expired}</span>
            </div>
          )}
        </div>
      );
    }

    // Inactive user re-engagement results
    if (run.job_name === 'inactive-user-reengagement') {
      return (
        <div className="space-y-2">
          {results.processed !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Users Processed</span>
              <span className="text-white font-medium">{results.processed}</span>
            </div>
          )}
          {results.emailsSent !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Emails Sent</span>
              <span className="text-green-400 font-medium">{results.emailsSent}</span>
            </div>
          )}
          {results.byCategory && (
            <div className="mt-3 pt-3 border-t border-charcoal-500">
              <p className="text-xs text-gray-500 mb-2">By Inactivity Level</p>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-xs">
                  <span className="text-gray-400">1 Week:</span>
                  <span className="text-white ml-2">{results.byCategory.week1}</span>
                </div>
                <div className="text-xs">
                  <span className="text-gray-400">2 Weeks:</span>
                  <span className="text-white ml-2">{results.byCategory.week2}</span>
                </div>
                <div className="text-xs">
                  <span className="text-gray-400">1 Month:</span>
                  <span className="text-white ml-2">{results.byCategory.month1}</span>
                </div>
                <div className="text-xs">
                  <span className="text-gray-400">3 Months:</span>
                  <span className="text-white ml-2">{results.byCategory.month3}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      );
    }

    // Match expiration cleanup results
    if (run.job_name === 'match-expiration-cleanup') {
      return (
        <div className="space-y-2">
          {results.expiredMatches !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Expired Matches</span>
              <span className="text-orange-400 font-medium">{results.expiredMatches}</span>
            </div>
          )}
          {results.expiredCrushCodes !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Expired Crush Codes</span>
              <span className="text-orange-400 font-medium">{results.expiredCrushCodes}</span>
            </div>
          )}
          {results.expiredTimeLimitedLinks !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Expired Time-Limited Links</span>
              <span className="text-orange-400 font-medium">{results.expiredTimeLimitedLinks}</span>
            </div>
          )}
          {results.expiredConversations !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Archived Conversations</span>
              <span className="text-blue-400 font-medium">{results.expiredConversations}</span>
            </div>
          )}
          {results.archivedProfiles !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Archived Profiles</span>
              <span className="text-purple-400 font-medium">{results.archivedProfiles}</span>
            </div>
          )}
        </div>
      );
    }

    // Monthly analytics report results
    if (run.job_name === 'monthly-analytics-report' && results.report) {
      const report = results.report;
      return (
        <div className="space-y-3">
          <div className="text-sm text-gold font-medium">
            {report.reportPeriod?.month} {report.reportPeriod?.year} Report
          </div>
          {report.userMetrics && (
            <div className="grid grid-cols-2 gap-2">
              <div className="text-xs">
                <span className="text-gray-400">Total Users:</span>
                <span className="text-white ml-2">{report.userMetrics.totalUsers?.toLocaleString()}</span>
              </div>
              <div className="text-xs">
                <span className="text-gray-400">New Users:</span>
                <span className="text-green-400 ml-2">+{report.userMetrics.newUsers?.toLocaleString()}</span>
              </div>
              <div className="text-xs">
                <span className="text-gray-400">Active Users:</span>
                <span className="text-white ml-2">{report.userMetrics.activeUsers?.toLocaleString()}</span>
              </div>
              <div className="text-xs">
                <span className="text-gray-400">Retention:</span>
                <span className="text-white ml-2">{report.userMetrics.retentionRate}%</span>
              </div>
            </div>
          )}
          {report.engagementMetrics && (
            <div className="pt-2 border-t border-charcoal-500">
              <div className="grid grid-cols-2 gap-2">
                <div className="text-xs">
                  <span className="text-gray-400">Matches:</span>
                  <span className="text-white ml-2">{report.engagementMetrics.totalMatches?.toLocaleString()}</span>
                </div>
                <div className="text-xs">
                  <span className="text-gray-400">Messages:</span>
                  <span className="text-white ml-2">{report.engagementMetrics.totalMessages?.toLocaleString()}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      );
    }

    // Weekly summary results
    if (run.job_name === 'weekly-summary-emails') {
      return (
        <div className="space-y-2">
          {results.processed !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Users Processed</span>
              <span className="text-white font-medium">{results.processed}</span>
            </div>
          )}
          {results.emailsSent !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Emails Sent</span>
              <span className="text-green-400 font-medium">{results.emailsSent}</span>
            </div>
          )}
          {results.skipped !== undefined && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-400">Skipped (opted out)</span>
              <span className="text-gray-400 font-medium">{results.skipped}</span>
            </div>
          )}
        </div>
      );
    }

    // Default: show raw JSON
    return (
      <pre className="text-xs text-gray-300 overflow-x-auto">
        {JSON.stringify(results, null, 2)}
      </pre>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="w-8 h-8 text-gold animate-spin" />
      </div>
    );
  }

  // Check for missing jobs
  const existingJobNames = jobs.map(j => j.job_name);
  const missingJobsCount = DEFAULT_JOBS.filter(j => !existingJobNames.includes(j.job_name)).length;

  // Count jobs with failures
  const jobsWithFailures = jobs.filter(j => j.consecutive_failures > 0).length;

  return (
    <div className="space-y-6">
      {/* Header with Setup Guide Toggle */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-white flex items-center gap-2">
            <Clock className="w-6 h-6 text-gold" />
            Scheduled Jobs
          </h2>
          <p className="text-sm text-gray-400 mt-1">
            Manage automated tasks and view execution history
          </p>
        </div>
        <div className="flex items-center gap-3">
          {missingJobsCount > 0 && (
            <button
              onClick={addMissingJobs}
              disabled={creatingJobs}
              className="px-4 py-2 bg-gold/20 text-gold rounded-xl hover:bg-gold/30 transition-all flex items-center gap-2"
            >
              {creatingJobs ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Plus className="w-4 h-4" />
              )}
              Add {missingJobsCount} Missing Job{missingJobsCount > 1 ? 's' : ''}
            </button>
          )}
          <button
            onClick={() => { setShowAlerts(!showAlerts); if (!showAlerts) fetchJobAlerts(); }}
            className={`px-4 py-2 rounded-xl transition-all flex items-center gap-2 ${
              showAlerts ? 'bg-red-500/20 text-red-400' : 'bg-charcoal-600 text-gray-300 hover:bg-charcoal-500'
            }`}
          >
            <Bell className="w-4 h-4" />
            Alerts
            {jobAlerts.filter(a => a.alert_type !== 'recovery').length > 0 && (
              <span className="px-1.5 py-0.5 bg-red-500 text-white text-xs rounded-full">
                {jobAlerts.filter(a => a.alert_type !== 'recovery').length}
              </span>
            )}
          </button>
          <button
            onClick={() => setShowSetupGuide(!showSetupGuide)}
            className="px-4 py-2 bg-charcoal-600 text-gray-300 rounded-xl hover:bg-charcoal-500 transition-all flex items-center gap-2"
          >
            <Settings className="w-4 h-4" />
            Setup Guide
          </button>
          <button
            onClick={fetchJobs}
            className="px-4 py-2 bg-charcoal-600 text-gray-300 rounded-xl hover:bg-charcoal-500 transition-all flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>
      </div>

      {/* Job Alerts Panel */}
      {showAlerts && (
        <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 overflow-hidden">
          <div className="p-4 border-b border-charcoal-600 flex items-center justify-between">
            <h3 className="font-semibold text-white flex items-center gap-2">
              <Bell className="w-5 h-5 text-red-400" />
              Job Failure Alerts
            </h3>
            <button
              onClick={fetchJobAlerts}
              className="p-2 text-gray-400 hover:text-white transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
          
          {alertsLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 text-gold animate-spin" />
            </div>
          ) : jobAlerts.length === 0 ? (
            <div className="p-8 text-center">
              <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-3" />
              <p className="text-gray-400">No alerts - all jobs running smoothly!</p>
            </div>
          ) : (
            <div className="max-h-96 overflow-y-auto">
              {jobAlerts.map((alert) => {
                const alertBadge = getAlertTypeBadge(alert.alert_type);
                return (
                  <div key={alert.id} className="p-4 border-b border-charcoal-600 last:border-b-0 hover:bg-charcoal-600/50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-lg ${alertBadge.color.replace('text-', 'bg-').replace('-400', '-500/20')}`}>
                          {alertBadge.icon}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-white">{alert.job_name}</span>
                            <span className={`px-2 py-0.5 text-xs rounded-full ${alertBadge.color}`}>
                              {alertBadge.label}
                            </span>
                          </div>
                          {alert.error_message && (
                            <p className="text-sm text-gray-400 mt-1 line-clamp-2">{alert.error_message}</p>
                          )}
                          <div className="flex items-center gap-3 mt-2 text-xs text-gray-500">
                            <span>Sent to: {alert.sent_to}</span>
                            <span>Status: {alert.email_status}</span>
                          </div>
                        </div>
                      </div>
                      <span className="text-xs text-gray-500 whitespace-nowrap">
                        {formatRelativeTime(alert.sent_at)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Setup Guide */}
      {showSetupGuide && (
        <div className="bg-gold/10 border border-gold/30 rounded-2xl p-6">
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <Zap className="w-5 h-5 text-gold" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-white mb-2">Cron Job Setup Guide</h3>
              <p className="text-gray-300 mb-4">
                To automatically run scheduled jobs, you need to set up an external cron service to call the webhook endpoint.
              </p>
              
              <div className="space-y-4">
                <div className="bg-charcoal-700 rounded-xl p-4">
                  <h4 className="font-medium text-white mb-2">Option 1: External Cron Service</h4>
                  <p className="text-sm text-gray-400 mb-3">
                    Use a service like cron-job.org, EasyCron, or Uptime Robot to call this endpoint:
                  </p>
                  <div className="bg-charcoal-800 rounded-lg p-3 font-mono text-sm text-gold break-all">
                    POST {window.location.origin.replace('http://', 'https://')}/functions/v1/run-scheduled-job
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Set up multiple cron jobs for different schedules (daily, weekly, monthly)
                  </p>
                </div>

                <div className="bg-charcoal-700 rounded-xl p-4">
                  <h4 className="font-medium text-white mb-2">Email Alerts Configuration</h4>
                  <p className="text-sm text-gray-400 mb-3">
                    Each job can be configured with an alert email. When a job fails, an email notification will be sent automatically.
                  </p>
                  <ul className="text-sm text-gray-400 space-y-1 list-disc list-inside">
                    <li>First failure: Immediate alert email</li>
                    <li>3+ consecutive failures: Critical alert with escalation</li>
                    <li>Recovery: Notification when job succeeds after failures</li>
                  </ul>
                </div>

                <div className="bg-charcoal-700 rounded-xl p-4">
                  <h4 className="font-medium text-white mb-2">Recommended Cron Schedules</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Daily (3:00 AM UTC):</span>
                      <code className="text-green-400">0 3 * * *</code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Weekly (Sunday 10:00 AM UTC):</span>
                      <code className="text-blue-400">0 10 * * 0</code>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Monthly (1st at 9:00 AM UTC):</span>
                      <code className="text-purple-400">0 9 1 * *</code>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <button
              onClick={() => setShowSetupGuide(false)}
              className="text-gray-400 hover:text-white"
            >
              <XCircle className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Jobs Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-charcoal-700 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{jobs.filter(j => j.is_enabled).length}</p>
              <p className="text-xs text-gray-400">Active Jobs</p>
            </div>
          </div>
        </div>
        <div className="bg-charcoal-700 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{jobs.filter(j => j.schedule.includes('* * *')).length}</p>
              <p className="text-xs text-gray-400">Daily Jobs</p>
            </div>
          </div>
        </div>
        <div className="bg-charcoal-700 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <Timer className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{jobs.filter(j => j.schedule.includes('* * 0')).length}</p>
              <p className="text-xs text-gray-400">Weekly Jobs</p>
            </div>
          </div>
        </div>
        <div className="bg-charcoal-700 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gold/20 rounded-lg flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-gold" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white">{jobs.filter(j => j.schedule.includes('1 * *')).length}</p>
              <p className="text-xs text-gray-400">Monthly Jobs</p>
            </div>
          </div>
        </div>
        <div className="bg-charcoal-700 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
              jobsWithFailures > 0 ? 'bg-red-500/20' : 'bg-green-500/20'
            }`}>
              {jobsWithFailures > 0 ? (
                <AlertTriangle className="w-5 h-5 text-red-400" />
              ) : (
                <CheckCircle className="w-5 h-5 text-green-400" />
              )}
            </div>
            <div>
              <p className={`text-2xl font-bold ${jobsWithFailures > 0 ? 'text-red-400' : 'text-white'}`}>
                {jobsWithFailures}
              </p>
              <p className="text-xs text-gray-400">Failing Jobs</p>
            </div>
          </div>
        </div>
      </div>

      {/* Jobs List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {jobs.map((job) => {
          const jobConfig = getJobTypeConfig(job.job_name);
          
          return (
            <div
              key={job.id}
              className={`bg-charcoal-700 rounded-2xl border transition-all ${
                selectedJob === job.job_name
                  ? 'border-gold'
                  : job.consecutive_failures > 0
                  ? 'border-red-500/50'
                  : 'border-charcoal-600 hover:border-charcoal-500'
              }`}
            >
              <div className="p-6">
                {/* Failure Warning Banner */}
                {job.consecutive_failures > 0 && (
                  <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center gap-3">
                    <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-red-400">
                        {job.consecutive_failures} consecutive failure{job.consecutive_failures > 1 ? 's' : ''}
                      </p>
                      {job.last_alert_sent_at && (
                        <p className="text-xs text-gray-500">
                          Last alert sent {formatRelativeTime(job.last_alert_sent_at)}
                        </p>
                      )}
                    </div>
                  </div>
                )}

                {/* Job Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      job.is_enabled ? jobConfig.bgColor : 'bg-charcoal-600'
                    }`}>
                      <span className={job.is_enabled ? jobConfig.color : 'text-gray-500'}>
                        {jobConfig.icon}
                      </span>
                    </div>
                    <div>
                      <h3 className="font-semibold text-white">{job.job_name}</h3>
                      <p className="text-sm text-gray-400">{job.function_name}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => toggleJobEnabled(job)}
                    className={`relative w-12 h-6 rounded-full transition-all ${
                      job.is_enabled ? 'bg-gold' : 'bg-charcoal-500'
                    }`}
                  >
                    <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${
                      job.is_enabled ? 'left-7' : 'left-1'
                    }`} />
                  </button>
                </div>

                {/* Job Description */}
                <p className="text-sm text-gray-400 mb-4 line-clamp-2">{job.description}</p>

                {/* Alert Email Configuration */}
                <div className="bg-charcoal-600 rounded-xl p-3 mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                      <Mail className="w-3 h-3" />
                      Alert Email
                    </div>
                    <button
                      onClick={() => toggleAlertOnFailure(job)}
                      className={`flex items-center gap-1 px-2 py-1 rounded-lg text-xs transition-colors ${
                        job.alert_on_failure
                          ? 'bg-green-500/20 text-green-400'
                          : 'bg-gray-500/20 text-gray-400'
                      }`}
                    >
                      {job.alert_on_failure ? (
                        <>
                          <Bell className="w-3 h-3" />
                          Enabled
                        </>
                      ) : (
                        <>
                          <BellOff className="w-3 h-3" />
                          Disabled
                        </>
                      )}
                    </button>
                  </div>
                  
                  {editingAlertEmail === job.id ? (
                    <div className="flex items-center gap-2">
                      <input
                        type="email"
                        value={alertEmailInput}
                        onChange={(e) => setAlertEmailInput(e.target.value)}
                        placeholder="admin@example.com"
                        className="flex-1 px-3 py-2 bg-charcoal-700 border border-charcoal-500 rounded-lg text-sm text-white focus:outline-none focus:border-gold"
                      />
                      <button
                        onClick={() => updateAlertEmail(job.id, alertEmailInput)}
                        className="p-2 bg-green-500/20 text-green-400 rounded-lg hover:bg-green-500/30 transition-colors"
                      >
                        <Save className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => { setEditingAlertEmail(null); setAlertEmailInput(''); }}
                        className="p-2 bg-gray-500/20 text-gray-400 rounded-lg hover:bg-gray-500/30 transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-white truncate">
                        {job.alert_email || 'Not configured'}
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => { setEditingAlertEmail(job.id); setAlertEmailInput(job.alert_email || ''); }}
                          className="p-1.5 text-gray-400 hover:text-white transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {job.alert_email && (
                          <button
                            onClick={() => sendTestAlert(job)}
                            disabled={sendingTestAlert === job.id}
                            className="p-1.5 text-gold hover:text-gold-400 transition-colors disabled:opacity-50"
                            title="Send test alert"
                          >
                            {sendingTestAlert === job.id ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Send className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* Schedule Info */}
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-charcoal-600 rounded-xl p-3">
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                      <Timer className="w-3 h-3" />
                      Schedule
                    </div>
                    <p className="text-sm font-medium text-white">
                      {parseCronSchedule(job.schedule)}
                    </p>
                    <span className={`inline-block mt-2 px-2 py-0.5 text-xs rounded-full ${getScheduleBadgeColor(job.schedule)}`}>
                      {job.schedule}
                    </span>
                  </div>
                  <div className="bg-charcoal-600 rounded-xl p-3">
                    <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                      <Calendar className="w-3 h-3" />
                      Next Run
                    </div>
                    <p className="text-sm font-medium text-white">
                      {job.next_run_at ? formatRelativeTime(job.next_run_at) : 'Not scheduled'}
                    </p>
                    {job.next_run_at && (
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(job.next_run_at).toLocaleString()}
                      </p>
                    )}
                  </div>
                </div>

                {/* Last Run Info */}
                <div className="bg-charcoal-600 rounded-xl p-3 mb-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
                        <History className="w-3 h-3" />
                        Last Run
                      </div>
                      <p className="text-sm font-medium text-white">
                        {job.last_run_at ? formatRelativeTime(job.last_run_at) : 'Never'}
                      </p>
                    </div>
                    {job.last_run_at && (
                      <span className="text-xs text-gray-500">
                        {new Date(job.last_run_at).toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <button
                    onClick={() => runJobManually(job)}
                    disabled={runningJob === job.job_name || !job.is_enabled}
                    className="flex-1 py-3 bg-gold text-charcoal font-medium rounded-xl hover:bg-gold-400 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {runningJob === job.job_name ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Running...
                      </>
                    ) : (
                      <>
                        <Play className="w-4 h-4" />
                        Run Now
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => setSelectedJob(selectedJob === job.job_name ? null : job.job_name)}
                    className="px-4 py-3 bg-charcoal-600 text-gray-300 font-medium rounded-xl hover:bg-charcoal-500 transition-all flex items-center gap-2"
                  >
                    <History className="w-4 h-4" />
                    History
                    {selectedJob === job.job_name ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              {/* Job Run History */}
              {selectedJob === job.job_name && (
                <div className="border-t border-charcoal-600 p-6">
                  <h4 className="font-medium text-white mb-4 flex items-center gap-2">
                    <History className="w-4 h-4 text-gold" />
                    Execution History
                  </h4>

                  {runsLoading ? (
                    <div className="flex items-center justify-center py-8">
                      <Loader2 className="w-6 h-6 text-gold animate-spin" />
                    </div>
                  ) : jobRuns.length === 0 ? (
                    <div className="text-center py-8">
                      <Clock className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                      <p className="text-gray-400">No execution history yet</p>
                      <p className="text-sm text-gray-500">Run the job manually to see results here</p>
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {jobRuns.map((run) => (
                        <div
                          key={run.id}
                          className="bg-charcoal-600 rounded-xl overflow-hidden"
                        >
                          <button
                            onClick={() => setExpandedRun(expandedRun === run.id ? null : run.id)}
                            className="w-full p-4 flex items-center justify-between hover:bg-charcoal-500 transition-all"
                          >
                            <div className="flex items-center gap-3">
                              {run.status === 'completed' ? (
                                <CheckCircle className="w-5 h-5 text-green-400" />
                              ) : run.status === 'failed' ? (
                                <XCircle className="w-5 h-5 text-red-400" />
                              ) : (
                                <Loader2 className="w-5 h-5 text-gold animate-spin" />
                              )}
                              <div className="text-left">
                                <p className="text-sm font-medium text-white">
                                  {new Date(run.started_at).toLocaleString()}
                                </p>
                                <div className="flex items-center gap-2 mt-1">
                                  <span className={`px-2 py-0.5 text-xs rounded-full ${getStatusColor(run.status)}`}>
                                    {run.status.charAt(0).toUpperCase() + run.status.slice(1)}
                                  </span>
                                  <span className={`px-2 py-0.5 text-xs rounded-full ${getTriggerBadge(run.triggered_by).color}`}>
                                    {getTriggerBadge(run.triggered_by).label}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              {run.completed_at && (
                                <span className="text-xs text-gray-500">
                                  {Math.round((new Date(run.completed_at).getTime() - new Date(run.started_at).getTime()) / 1000)}s
                                </span>
                              )}
                              {expandedRun === run.id ? (
                                <ChevronUp className="w-4 h-4 text-gray-400" />
                              ) : (
                                <ChevronDown className="w-4 h-4 text-gray-400" />
                              )}
                            </div>
                          </button>

                          {expandedRun === run.id && (
                            <div className="px-4 pb-4 border-t border-charcoal-500">
                              {run.error_message ? (
                                <div className="mt-3 p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                                  <p className="text-xs text-red-400 font-medium mb-1">Error</p>
                                  <p className="text-sm text-gray-300">{run.error_message}</p>
                                </div>
                              ) : run.results ? (
                                <div className="mt-3">
                                  <p className="text-xs text-gray-400 font-medium mb-2">Results</p>
                                  <div className="bg-charcoal-700 rounded-lg p-3">
                                    {renderJobResults(run)}
                                  </div>
                                </div>
                              ) : (
                                <p className="mt-3 text-sm text-gray-500">No result data available</p>
                              )}
                              
                              {run.results?.results?.errors && run.results.results.errors.length > 0 && (
                                <div className="mt-3 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                                  <p className="text-xs text-yellow-400 font-medium mb-1">Warnings ({run.results.results.errors.length})</p>
                                  <div className="max-h-32 overflow-y-auto">
                                    {run.results.results.errors.slice(0, 5).map((err: string, i: number) => (
                                      <p key={i} className="text-xs text-gray-400 truncate">{err}</p>
                                    ))}
                                    {run.results.results.errors.length > 5 && (
                                      <p className="text-xs text-gray-500 mt-1">
                                        ... and {run.results.results.errors.length - 5} more
                                      </p>
                                    )}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Empty State */}
      {jobs.length === 0 && (
        <div className="bg-charcoal-700 rounded-2xl border border-charcoal-600 p-12 text-center">
          <Clock className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">No Scheduled Jobs</h3>
          <p className="text-gray-400 mb-4">
            Scheduled jobs will appear here once configured.
          </p>
          <button
            onClick={createDefaultJobs}
            disabled={creatingJobs}
            className="px-6 py-3 bg-gold text-charcoal font-medium rounded-xl hover:bg-gold-400 transition-all disabled:opacity-50 flex items-center gap-2 mx-auto"
          >
            {creatingJobs ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Plus className="w-4 h-4" />
            )}
            Create Default Jobs
          </button>
        </div>
      )}
    </div>
  );
};

export default ScheduledJobsPanel;
