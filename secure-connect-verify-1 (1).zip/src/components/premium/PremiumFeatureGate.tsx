import React, { useState } from 'react';
import { Lock, Crown, Sparkles } from 'lucide-react';
import { usePremium, PremiumFeatures } from '@/contexts/PremiumContext';
import FreemiumUpsell, { UpsellTrigger } from '@/components/dashboard/FreemiumUpsell';

interface PremiumFeatureGateProps {
  feature: keyof PremiumFeatures;
  trigger: UpsellTrigger;
  children: React.ReactNode;
  // If true, shows a locked preview instead of hiding content
  showLockedPreview?: boolean;
  // Custom locked state content
  lockedContent?: React.ReactNode;
  // Additional class for the wrapper
  className?: string;
  // If true, renders as inline element
  inline?: boolean;
}

/**
 * PremiumFeatureGate - Wraps content that requires premium access
 * 
 * Usage:
 * <PremiumFeatureGate feature="codeAnalytics" trigger="analytics">
 *   <AnalyticsDashboard />
 * </PremiumFeatureGate>
 */
export const PremiumFeatureGate: React.FC<PremiumFeatureGateProps> = ({
  feature,
  trigger,
  children,
  showLockedPreview = false,
  lockedContent,
  className = '',
  inline = false,
}) => {
  const { canUseFeature, isPremium } = usePremium();
  const [showUpsell, setShowUpsell] = useState(false);
  
  const hasAccess = canUseFeature(feature);

  if (hasAccess) {
    return <>{children}</>;
  }

  // Show custom locked content if provided
  if (lockedContent) {
    return (
      <>
        <div onClick={() => setShowUpsell(true)} className={`cursor-pointer ${className}`}>
          {lockedContent}
        </div>
        <FreemiumUpsell
          isOpen={showUpsell}
          onClose={() => setShowUpsell(false)}
          trigger={trigger}
        />
      </>
    );
  }

  // Show locked preview with overlay
  if (showLockedPreview) {
    return (
      <>
        <div className={`relative ${className}`}>
          {/* Blurred/faded content */}
          <div className="opacity-30 blur-sm pointer-events-none select-none">
            {children}
          </div>
          
          {/* Lock overlay */}
          <div 
            onClick={() => setShowUpsell(true)}
            className="absolute inset-0 flex items-center justify-center bg-charcoal-800/80 backdrop-blur-sm cursor-pointer group"
          >
            <div className="text-center p-6">
              <div className="w-14 h-14 bg-gold/10 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:bg-gold/20 transition-colors">
                <Lock className="w-7 h-7 text-gold" />
              </div>
              <p className="text-white font-medium mb-1">Premium Feature</p>
              <p className="text-sm text-gray-400 mb-3">Upgrade to unlock</p>
              <button className="px-4 py-2 bg-gold hover:bg-gold-400 text-charcoal font-medium rounded-lg transition-colors flex items-center gap-2 mx-auto">
                <Crown className="w-4 h-4" />
                Upgrade
              </button>
            </div>
          </div>
        </div>
        <FreemiumUpsell
          isOpen={showUpsell}
          onClose={() => setShowUpsell(false)}
          trigger={trigger}
        />
      </>
    );
  }

  // Default: show a locked button/card
  const Wrapper = inline ? 'span' : 'div';
  
  return (
    <>
      <Wrapper
        onClick={() => setShowUpsell(true)}
        className={`${inline ? 'inline-flex' : 'flex'} items-center gap-2 px-3 py-2 bg-charcoal-700 hover:bg-charcoal-600 border border-charcoal-600 rounded-lg cursor-pointer transition-colors group ${className}`}
      >
        <Lock className="w-4 h-4 text-gray-500 group-hover:text-gold transition-colors" />
        <span className="text-sm text-gray-400 group-hover:text-gray-300 transition-colors">
          Premium Feature
        </span>
        <Crown className="w-4 h-4 text-gold" />
      </Wrapper>
      <FreemiumUpsell
        isOpen={showUpsell}
        onClose={() => setShowUpsell(false)}
        trigger={trigger}
      />
    </>
  );
};

/**
 * PremiumBadge - Small badge to indicate premium-only features
 */
interface PremiumBadgeProps {
  onClick?: () => void;
  className?: string;
  size?: 'sm' | 'md';
}

export const PremiumBadge: React.FC<PremiumBadgeProps> = ({ 
  onClick, 
  className = '',
  size = 'sm' 
}) => {
  const sizeClasses = size === 'sm' 
    ? 'px-1.5 py-0.5 text-[10px]' 
    : 'px-2 py-1 text-xs';
    
  return (
    <span 
      onClick={onClick}
      className={`inline-flex items-center gap-1 bg-gold/20 text-gold font-medium rounded-full cursor-pointer hover:bg-gold/30 transition-colors ${sizeClasses} ${className}`}
    >
      <Crown className={size === 'sm' ? 'w-3 h-3' : 'w-3.5 h-3.5'} />
      Premium
    </span>
  );
};

/**
 * PremiumLockedCard - A card component for locked premium features
 */
interface PremiumLockedCardProps {
  title: string;
  description: string;
  icon: React.ElementType;
  iconColor?: string;
  trigger: UpsellTrigger;
  className?: string;
}

export const PremiumLockedCard: React.FC<PremiumLockedCardProps> = ({
  title,
  description,
  icon: Icon,
  iconColor = 'text-gray-400',
  trigger,
  className = '',
}) => {
  const [showUpsell, setShowUpsell] = useState(false);

  return (
    <>
      <button
        onClick={() => setShowUpsell(true)}
        className={`w-full p-4 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl border border-charcoal-600 hover:border-charcoal-500 transition-all text-left group ${className}`}
      >
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 bg-charcoal-600 group-hover:bg-charcoal-500 rounded-xl flex items-center justify-center transition-colors">
            <Icon className={`w-5 h-5 ${iconColor}`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <p className="text-sm font-medium text-white">{title}</p>
              <Lock className="w-3 h-3 text-gray-500" />
            </div>
            <p className="text-xs text-gray-400">{description}</p>
          </div>
          <Crown className="w-5 h-5 text-gold flex-shrink-0" />
        </div>
      </button>
      <FreemiumUpsell
        isOpen={showUpsell}
        onClose={() => setShowUpsell(false)}
        trigger={trigger}
      />
    </>
  );
};

/**
 * usePremiumFeature - Hook for checking and gating premium features
 */
export const usePremiumFeature = (feature: keyof PremiumFeatures, trigger: UpsellTrigger) => {
  const { canUseFeature, isPremium } = usePremium();
  const [showUpsell, setShowUpsell] = useState(false);
  
  const hasAccess = canUseFeature(feature);
  
  const checkAccess = (): boolean => {
    if (hasAccess) return true;
    setShowUpsell(true);
    return false;
  };
  
  const UpsellModal = () => (
    <FreemiumUpsell
      isOpen={showUpsell}
      onClose={() => setShowUpsell(false)}
      trigger={trigger}
    />
  );
  
  return {
    hasAccess,
    isPremium,
    checkAccess,
    showUpsell,
    setShowUpsell,
    UpsellModal,
  };
};

export default PremiumFeatureGate;
