import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  Printer,
  Download,
  Palette,
  MessageSquare,
  CreditCard,
  FileText,
  Grid3X3,
  ChevronDown,
  Check,
  Loader2,
  Eye,
  Scissors
} from 'lucide-react';

interface PrintableQRCardProps {
  isOpen: boolean;
  onClose: () => void;
  code: string;
  shareUrl: string;
  userName?: string;
}

type CardSize = 'business' | 'postcard' | 'a4-sheet';

interface CardColors {
  primary: string;
  accent: string;
  text: string;
  background: string;
}

const COLOR_PRESETS: { name: string; colors: CardColors }[] = [
  {
    name: 'Dwadido Gold',
    colors: { primary: '#D4AF37', accent: '#1a1a1a', text: '#ffffff', background: '#1a1a1a' }
  },
  {
    name: 'Classic White',
    colors: { primary: '#1a1a1a', accent: '#D4AF37', text: '#1a1a1a', background: '#ffffff' }
  },
  {
    name: 'Ocean Blue',
    colors: { primary: '#3b82f6', accent: '#1e40af', text: '#ffffff', background: '#0f172a' }
  },
  {
    name: 'Rose Gold',
    colors: { primary: '#f43f5e', accent: '#fda4af', text: '#ffffff', background: '#1f1f1f' }
  },
  {
    name: 'Emerald',
    colors: { primary: '#10b981', accent: '#065f46', text: '#ffffff', background: '#022c22' }
  },
  {
    name: 'Purple Dream',
    colors: { primary: '#8b5cf6', accent: '#a855f7', text: '#ffffff', background: '#1e1b4b' }
  },
  {
    name: 'Sunset',
    colors: { primary: '#f97316', accent: '#facc15', text: '#1a1a1a', background: '#fffbeb' }
  },
  {
    name: 'Minimalist',
    colors: { primary: '#374151', accent: '#6b7280', text: '#111827', background: '#f9fafb' }
  }
];

const CARD_SIZES: { id: CardSize; name: string; description: string; icon: React.ReactNode }[] = [
  {
    id: 'business',
    name: 'Business Card',
    description: '3.5" × 2" - Perfect for handing out',
    icon: <CreditCard className="w-5 h-5" />
  },
  {
    id: 'postcard',
    name: 'Postcard',
    description: '6" × 4" - Great for mailing',
    icon: <FileText className="w-5 h-5" />
  },
  {
    id: 'a4-sheet',
    name: 'A4 Sheet (8 cards)',
    description: 'Print multiple cards at once',
    icon: <Grid3X3 className="w-5 h-5" />
  }
];

// QR Code generation functions (same as QRCodeModal)
const GF256_EXP = new Uint8Array(512);
const GF256_LOG = new Uint8Array(256);

(function initGF256() {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF256_EXP[i] = x;
    GF256_LOG[x] = i;
    x = (x << 1) ^ (x >= 128 ? 0x11d : 0);
  }
  for (let i = 255; i < 512; i++) {
    GF256_EXP[i] = GF256_EXP[i - 255];
  }
})();

function gfMul(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return GF256_EXP[GF256_LOG[a] + GF256_LOG[b]];
}

function generateErrorCorrectionCodewords(data: number[], ecCount: number): number[] {
  const gen = [1];
  for (let i = 0; i < ecCount; i++) {
    const newGen = new Array(gen.length + 1).fill(0);
    for (let j = 0; j < gen.length; j++) {
      newGen[j] ^= gen[j];
      newGen[j + 1] ^= gfMul(gen[j], GF256_EXP[i]);
    }
    gen.length = 0;
    gen.push(...newGen);
  }

  const result = new Array(ecCount).fill(0);
  for (const byte of data) {
    const factor = byte ^ result[0];
    result.shift();
    result.push(0);
    for (let i = 0; i < ecCount; i++) {
      result[i] ^= gfMul(gen[i + 1], factor);
    }
  }
  return result;
}

function encodeByte(text: string): number[] {
  const bits: number[] = [];
  bits.push(0, 1, 0, 0);
  const countBits = text.length.toString(2).padStart(8, '0');
  for (const bit of countBits) bits.push(parseInt(bit));
  for (let i = 0; i < text.length; i++) {
    const charCode = text.charCodeAt(i);
    const charBits = charCode.toString(2).padStart(8, '0');
    for (const bit of charBits) bits.push(parseInt(bit));
  }
  return bits;
}

function getVersionForUrl(text: string): number {
  const byteCapacity = [0, 14, 26, 42, 62, 84, 106, 122, 152, 180, 213, 251, 287, 331, 362, 412, 450, 504, 560, 624, 666];
  for (let v = 1; v <= 20; v++) {
    if (text.length <= byteCapacity[v]) return v;
  }
  return 20;
}

function getModuleCount(version: number): number {
  return 17 + version * 4;
}

const VERSION_INFO: { [key: number]: { dataCodewords: number; ecCodewords: number } } = {
  1: { dataCodewords: 16, ecCodewords: 10 },
  2: { dataCodewords: 28, ecCodewords: 16 },
  3: { dataCodewords: 44, ecCodewords: 26 },
  4: { dataCodewords: 64, ecCodewords: 18 },
  5: { dataCodewords: 86, ecCodewords: 24 },
  6: { dataCodewords: 108, ecCodewords: 16 },
  7: { dataCodewords: 124, ecCodewords: 18 },
  8: { dataCodewords: 154, ecCodewords: 22 },
  9: { dataCodewords: 182, ecCodewords: 22 },
  10: { dataCodewords: 216, ecCodewords: 26 },
};

function createQRMatrix(text: string): boolean[][] {
  const version = Math.min(getVersionForUrl(text), 10);
  const size = getModuleCount(version);
  const matrix: (boolean | null)[][] = Array(size).fill(null).map(() => Array(size).fill(null));
  
  const addFinderPattern = (row: number, col: number) => {
    for (let r = -1; r <= 7; r++) {
      for (let c = -1; c <= 7; c++) {
        const nr = row + r, nc = col + c;
        if (nr < 0 || nr >= size || nc < 0 || nc >= size) continue;
        if (r === -1 || r === 7 || c === -1 || c === 7) {
          matrix[nr][nc] = false;
        } else if (r === 0 || r === 6 || c === 0 || c === 6) {
          matrix[nr][nc] = true;
        } else if (r >= 2 && r <= 4 && c >= 2 && c <= 4) {
          matrix[nr][nc] = true;
        } else {
          matrix[nr][nc] = false;
        }
      }
    }
  };
  
  addFinderPattern(0, 0);
  addFinderPattern(0, size - 7);
  addFinderPattern(size - 7, 0);
  
  for (let i = 8; i < size - 8; i++) {
    matrix[6][i] = i % 2 === 0;
    matrix[i][6] = i % 2 === 0;
  }
  
  matrix[size - 8][8] = true;
  
  for (let i = 0; i < 9; i++) {
    if (matrix[8][i] === null) matrix[8][i] = false;
    if (matrix[i][8] === null) matrix[i][8] = false;
    if (i < 8) {
      if (matrix[8][size - 1 - i] === null) matrix[8][size - 1 - i] = false;
      if (matrix[size - 1 - i][8] === null) matrix[size - 1 - i][8] = false;
    }
  }
  
  if (version >= 2) {
    const alignPos = size - 7;
    for (let r = -2; r <= 2; r++) {
      for (let c = -2; c <= 2; c++) {
        const nr = alignPos + r, nc = alignPos + c;
        if (Math.abs(r) === 2 || Math.abs(c) === 2) {
          matrix[nr][nc] = true;
        } else if (r === 0 && c === 0) {
          matrix[nr][nc] = true;
        } else {
          matrix[nr][nc] = false;
        }
      }
    }
  }
  
  const dataBits = encodeByte(text);
  const versionInfo = VERSION_INFO[version] || VERSION_INFO[1];
  const totalBits = versionInfo.dataCodewords * 8;
  
  const terminatorLength = Math.min(4, totalBits - dataBits.length);
  for (let i = 0; i < terminatorLength; i++) dataBits.push(0);
  while (dataBits.length % 8 !== 0) dataBits.push(0);
  
  const padPatterns = [0xEC, 0x11];
  let padIndex = 0;
  while (dataBits.length < totalBits) {
    const pad = padPatterns[padIndex % 2];
    for (let i = 7; i >= 0; i--) dataBits.push((pad >> i) & 1);
    padIndex++;
  }
  
  const dataBytes: number[] = [];
  for (let i = 0; i < dataBits.length; i += 8) {
    let byte = 0;
    for (let j = 0; j < 8; j++) {
      byte = (byte << 1) | (dataBits[i + j] || 0);
    }
    dataBytes.push(byte);
  }
  
  const ecBytes = generateErrorCorrectionCodewords(dataBytes, versionInfo.ecCodewords);
  const allBytes = [...dataBytes, ...ecBytes];
  const allBits: number[] = [];
  for (const byte of allBytes) {
    for (let i = 7; i >= 0; i--) {
      allBits.push((byte >> i) & 1);
    }
  }
  
  let bitIndex = 0;
  let upward = true;
  
  for (let col = size - 1; col >= 0; col -= 2) {
    if (col === 6) col = 5;
    const rows = upward ? 
      Array.from({ length: size }, (_, i) => size - 1 - i) :
      Array.from({ length: size }, (_, i) => i);
    for (const row of rows) {
      for (let c = 0; c < 2; c++) {
        const actualCol = col - c;
        if (matrix[row][actualCol] === null) {
          matrix[row][actualCol] = bitIndex < allBits.length ? allBits[bitIndex++] === 1 : false;
        }
      }
    }
    upward = !upward;
  }
  
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (isReserved(row, col, size, version)) continue;
      if ((row + col) % 2 === 0) {
        matrix[row][col] = !matrix[row][col];
      }
    }
  }
  
  const formatBits = [1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0, 1];
  for (let i = 0; i < 6; i++) matrix[8][i] = formatBits[i] === 1;
  matrix[8][7] = formatBits[6] === 1;
  matrix[8][8] = formatBits[7] === 1;
  matrix[7][8] = formatBits[8] === 1;
  for (let i = 9; i < 15; i++) matrix[14 - i][8] = formatBits[i] === 1;
  for (let i = 0; i < 8; i++) matrix[8][size - 8 + i] = formatBits[7 + i] === 1;
  for (let i = 0; i < 7; i++) matrix[size - 1 - i][8] = formatBits[i] === 1;
  
  return matrix.map(row => row.map(cell => cell === true));
}

function isReserved(row: number, col: number, size: number, version: number): boolean {
  if (row < 9 && col < 9) return true;
  if (row < 9 && col >= size - 8) return true;
  if (row >= size - 8 && col < 9) return true;
  if (row === 6 || col === 6) return true;
  if (version >= 2) {
    const alignPos = size - 7;
    if (Math.abs(row - alignPos) <= 2 && Math.abs(col - alignPos) <= 2) return true;
  }
  return false;
}

function drawQRCode(
  ctx: CanvasRenderingContext2D,
  qrMatrix: boolean[][],
  x: number,
  y: number,
  size: number,
  fgColor: string,
  bgColor: string
) {
  const moduleCount = qrMatrix.length;
  const moduleSize = size / moduleCount;
  
  // Background
  ctx.fillStyle = bgColor;
  ctx.fillRect(x, y, size, size);
  
  // Modules
  ctx.fillStyle = fgColor;
  for (let row = 0; row < moduleCount; row++) {
    for (let col = 0; col < moduleCount; col++) {
      if (qrMatrix[row][col]) {
        const mx = x + col * moduleSize;
        const my = y + row * moduleSize;
        const radius = moduleSize * 0.1;
        ctx.beginPath();
        ctx.roundRect(mx, my, moduleSize, moduleSize, radius);
        ctx.fill();
      }
    }
  }
}

const PrintableQRCard: React.FC<PrintableQRCardProps> = ({
  isOpen,
  onClose,
  code,
  shareUrl,
  userName = 'Anonymous'
}) => {
  const printRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cardSize, setCardSize] = useState<CardSize>('business');
  const [selectedPreset, setSelectedPreset] = useState(0);
  const [colors, setColors] = useState<CardColors>(COLOR_PRESETS[0].colors);
  const [personalMessage, setPersonalMessage] = useState('');
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [qrMatrix, setQrMatrix] = useState<boolean[][] | null>(null);

  useEffect(() => {
    if (isOpen && shareUrl) {
      try {
        const matrix = createQRMatrix(shareUrl);
        setQrMatrix(matrix);
      } catch (error) {
        console.error('QR generation error:', error);
      }
    }
  }, [isOpen, shareUrl]);

  const handlePresetSelect = (index: number) => {
    setSelectedPreset(index);
    setColors(COLOR_PRESETS[index].colors);
  };

  const generatePrintCanvas = (): HTMLCanvasElement | null => {
    if (!qrMatrix) return null;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    // DPI for print quality
    const dpi = 300;
    const inchToPx = (inches: number) => Math.round(inches * dpi);

    if (cardSize === 'business') {
      // Business card: 3.5" x 2"
      const cardWidth = inchToPx(3.5);
      const cardHeight = inchToPx(2);
      const tabHeight = inchToPx(0.5);
      const tabCount = 5;
      
      canvas.width = cardWidth;
      canvas.height = cardHeight + tabHeight;

      // Main card background
      ctx.fillStyle = colors.background;
      ctx.fillRect(0, 0, cardWidth, cardHeight);

      // QR Code
      const qrSize = inchToPx(1.2);
      const qrX = inchToPx(0.15);
      const qrY = (cardHeight - qrSize) / 2;
      drawQRCode(ctx, qrMatrix, qrX, qrY, qrSize, colors.accent, '#ffffff');

      // Branding
      ctx.fillStyle = colors.primary;
      ctx.font = `bold ${inchToPx(0.25)}px system-ui, sans-serif`;
      ctx.textAlign = 'left';
      ctx.fillText('Dwadido', qrX + qrSize + inchToPx(0.15), inchToPx(0.4));

      // User name
      ctx.fillStyle = colors.text;
      ctx.font = `bold ${inchToPx(0.18)}px system-ui, sans-serif`;
      ctx.fillText(userName, qrX + qrSize + inchToPx(0.15), inchToPx(0.7));

      // Code
      ctx.fillStyle = colors.primary;
      ctx.font = `bold ${inchToPx(0.22)}px monospace`;
      ctx.fillText(code, qrX + qrSize + inchToPx(0.15), inchToPx(1.0));

      // Personal message
      if (personalMessage) {
        ctx.fillStyle = colors.text;
        ctx.font = `italic ${inchToPx(0.1)}px system-ui, sans-serif`;
        const maxWidth = cardWidth - qrX - qrSize - inchToPx(0.3);
        wrapText(ctx, `"${personalMessage}"`, qrX + qrSize + inchToPx(0.15), inchToPx(1.25), maxWidth, inchToPx(0.12));
      }

      // Instructions
      ctx.fillStyle = colors.text;
      ctx.globalAlpha = 0.6;
      ctx.font = `${inchToPx(0.08)}px system-ui, sans-serif`;
      ctx.fillText('Scan QR or visit dwadido.com/redeem', qrX + qrSize + inchToPx(0.15), cardHeight - inchToPx(0.15));
      ctx.globalAlpha = 1;

      // Tear-off tabs
      const tabWidth = cardWidth / tabCount;
      ctx.fillStyle = colors.primary;
      ctx.fillRect(0, cardHeight, cardWidth, tabHeight);

      // Dashed line
      ctx.setLineDash([inchToPx(0.05), inchToPx(0.03)]);
      ctx.strokeStyle = colors.background;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, cardHeight);
      ctx.lineTo(cardWidth, cardHeight);
      ctx.stroke();
      ctx.setLineDash([]);

      // Scissors icon indicator
      ctx.fillStyle = colors.background;
      ctx.font = `${inchToPx(0.1)}px system-ui, sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText('✂', inchToPx(0.15), cardHeight + inchToPx(0.08));

      // Tab separators and codes
      for (let i = 0; i < tabCount; i++) {
        const tabX = i * tabWidth;
        
        // Separator line
        if (i > 0) {
          ctx.setLineDash([inchToPx(0.02), inchToPx(0.02)]);
          ctx.strokeStyle = colors.background;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(tabX, cardHeight);
          ctx.lineTo(tabX, cardHeight + tabHeight);
          ctx.stroke();
          ctx.setLineDash([]);
        }

        // Code on each tab
        ctx.fillStyle = colors.background;
        ctx.font = `bold ${inchToPx(0.1)}px monospace`;
        ctx.textAlign = 'center';
        ctx.fillText(code, tabX + tabWidth / 2, cardHeight + tabHeight / 2 + inchToPx(0.03));
      }

    } else if (cardSize === 'postcard') {
      // Postcard: 6" x 4"
      const cardWidth = inchToPx(6);
      const cardHeight = inchToPx(4);
      const tabHeight = inchToPx(0.6);
      const tabCount = 6;

      canvas.width = cardWidth;
      canvas.height = cardHeight + tabHeight;

      // Main card background
      ctx.fillStyle = colors.background;
      ctx.fillRect(0, 0, cardWidth, cardHeight);

      // QR Code
      const qrSize = inchToPx(2);
      const qrX = inchToPx(0.3);
      const qrY = (cardHeight - qrSize) / 2;
      drawQRCode(ctx, qrMatrix, qrX, qrY, qrSize, colors.accent, '#ffffff');

      // Branding
      ctx.fillStyle = colors.primary;
      ctx.font = `bold ${inchToPx(0.5)}px system-ui, sans-serif`;
      ctx.textAlign = 'left';
      ctx.fillText('Dwadido', qrX + qrSize + inchToPx(0.3), inchToPx(0.8));

      // Tagline
      ctx.fillStyle = colors.text;
      ctx.globalAlpha = 0.7;
      ctx.font = `${inchToPx(0.15)}px system-ui, sans-serif`;
      ctx.fillText('Connect with me!', qrX + qrSize + inchToPx(0.3), inchToPx(1.1));
      ctx.globalAlpha = 1;

      // User name
      ctx.fillStyle = colors.text;
      ctx.font = `bold ${inchToPx(0.25)}px system-ui, sans-serif`;
      ctx.fillText(userName, qrX + qrSize + inchToPx(0.3), inchToPx(1.6));

      // Code
      ctx.fillStyle = colors.primary;
      ctx.font = `bold ${inchToPx(0.35)}px monospace`;
      ctx.fillText(code, qrX + qrSize + inchToPx(0.3), inchToPx(2.1));

      // Personal message
      if (personalMessage) {
        ctx.fillStyle = colors.text;
        ctx.font = `italic ${inchToPx(0.14)}px system-ui, sans-serif`;
        const maxWidth = cardWidth - qrX - qrSize - inchToPx(0.6);
        wrapText(ctx, `"${personalMessage}"`, qrX + qrSize + inchToPx(0.3), inchToPx(2.6), maxWidth, inchToPx(0.18));
      }

      // Instructions
      ctx.fillStyle = colors.text;
      ctx.globalAlpha = 0.6;
      ctx.font = `${inchToPx(0.12)}px system-ui, sans-serif`;
      ctx.fillText('Scan the QR code or visit dwadido.com/redeem', qrX + qrSize + inchToPx(0.3), cardHeight - inchToPx(0.3));
      ctx.globalAlpha = 1;

      // Tear-off tabs
      const tabWidth = cardWidth / tabCount;
      ctx.fillStyle = colors.primary;
      ctx.fillRect(0, cardHeight, cardWidth, tabHeight);

      // Dashed line with scissors
      ctx.setLineDash([inchToPx(0.08), inchToPx(0.04)]);
      ctx.strokeStyle = colors.background;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, cardHeight);
      ctx.lineTo(cardWidth, cardHeight);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = colors.background;
      ctx.font = `${inchToPx(0.15)}px system-ui, sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText('✂', inchToPx(0.2), cardHeight + inchToPx(0.12));

      // Tab separators and codes
      for (let i = 0; i < tabCount; i++) {
        const tabX = i * tabWidth;
        
        if (i > 0) {
          ctx.setLineDash([inchToPx(0.03), inchToPx(0.03)]);
          ctx.strokeStyle = colors.background;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(tabX, cardHeight);
          ctx.lineTo(tabX, cardHeight + tabHeight);
          ctx.stroke();
          ctx.setLineDash([]);
        }

        ctx.fillStyle = colors.background;
        ctx.font = `bold ${inchToPx(0.12)}px monospace`;
        ctx.textAlign = 'center';
        ctx.fillText(code, tabX + tabWidth / 2, cardHeight + tabHeight / 2 + inchToPx(0.04));
      }

    } else if (cardSize === 'a4-sheet') {
      // A4 sheet: 8.27" x 11.69" with 8 business cards (2x4 grid)
      const pageWidth = inchToPx(8.27);
      const pageHeight = inchToPx(11.69);
      const cardWidth = inchToPx(3.5);
      const cardHeight = inchToPx(2);
      const tabHeight = inchToPx(0.4);
      const tabCount = 5;
      const marginX = (pageWidth - cardWidth * 2) / 3;
      const marginY = (pageHeight - (cardHeight + tabHeight) * 4) / 5;

      canvas.width = pageWidth;
      canvas.height = pageHeight;

      // Page background
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, pageWidth, pageHeight);

      // Draw 8 cards in 2x4 grid
      for (let row = 0; row < 4; row++) {
        for (let col = 0; col < 2; col++) {
          const startX = marginX + col * (cardWidth + marginX);
          const startY = marginY + row * (cardHeight + tabHeight + marginY);

          // Card background
          ctx.fillStyle = colors.background;
          ctx.fillRect(startX, startY, cardWidth, cardHeight);

          // Card border
          ctx.strokeStyle = '#e5e5e5';
          ctx.lineWidth = 1;
          ctx.strokeRect(startX, startY, cardWidth, cardHeight + tabHeight);

          // QR Code
          const qrSize = inchToPx(1.1);
          const qrX = startX + inchToPx(0.1);
          const qrY = startY + (cardHeight - qrSize) / 2;
          drawQRCode(ctx, qrMatrix, qrX, qrY, qrSize, colors.accent, '#ffffff');

          // Branding
          ctx.fillStyle = colors.primary;
          ctx.font = `bold ${inchToPx(0.2)}px system-ui, sans-serif`;
          ctx.textAlign = 'left';
          ctx.fillText('Dwadido', qrX + qrSize + inchToPx(0.1), startY + inchToPx(0.35));

          // User name
          ctx.fillStyle = colors.text;
          ctx.font = `bold ${inchToPx(0.14)}px system-ui, sans-serif`;
          ctx.fillText(userName, qrX + qrSize + inchToPx(0.1), startY + inchToPx(0.6));

          // Code
          ctx.fillStyle = colors.primary;
          ctx.font = `bold ${inchToPx(0.18)}px monospace`;
          ctx.fillText(code, qrX + qrSize + inchToPx(0.1), startY + inchToPx(0.85));

          // Personal message (shortened for small cards)
          if (personalMessage) {
            ctx.fillStyle = colors.text;
            ctx.font = `italic ${inchToPx(0.08)}px system-ui, sans-serif`;
            const shortMsg = personalMessage.length > 40 ? personalMessage.substring(0, 37) + '...' : personalMessage;
            ctx.fillText(`"${shortMsg}"`, qrX + qrSize + inchToPx(0.1), startY + inchToPx(1.05));
          }

          // Instructions
          ctx.fillStyle = colors.text;
          ctx.globalAlpha = 0.5;
          ctx.font = `${inchToPx(0.06)}px system-ui, sans-serif`;
          ctx.fillText('dwadido.com/redeem', qrX + qrSize + inchToPx(0.1), startY + cardHeight - inchToPx(0.1));
          ctx.globalAlpha = 1;

          // Tear-off tabs
          const tabWidth = cardWidth / tabCount;
          ctx.fillStyle = colors.primary;
          ctx.fillRect(startX, startY + cardHeight, cardWidth, tabHeight);

          // Dashed line
          ctx.setLineDash([inchToPx(0.04), inchToPx(0.02)]);
          ctx.strokeStyle = colors.background;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(startX, startY + cardHeight);
          ctx.lineTo(startX + cardWidth, startY + cardHeight);
          ctx.stroke();
          ctx.setLineDash([]);

          // Tab codes
          for (let i = 0; i < tabCount; i++) {
            const tabX = startX + i * tabWidth;
            
            if (i > 0) {
              ctx.setLineDash([inchToPx(0.02), inchToPx(0.02)]);
              ctx.strokeStyle = colors.background;
              ctx.lineWidth = 1;
              ctx.beginPath();
              ctx.moveTo(tabX, startY + cardHeight);
              ctx.lineTo(tabX, startY + cardHeight + tabHeight);
              ctx.stroke();
              ctx.setLineDash([]);
            }

            ctx.fillStyle = colors.background;
            ctx.font = `bold ${inchToPx(0.08)}px monospace`;
            ctx.textAlign = 'center';
            ctx.fillText(code, tabX + tabWidth / 2, startY + cardHeight + tabHeight / 2 + inchToPx(0.025));
          }
        }
      }
    }

    return canvas;
  };

  const wrapText = (
    ctx: CanvasRenderingContext2D,
    text: string,
    x: number,
    y: number,
    maxWidth: number,
    lineHeight: number
  ) => {
    const words = text.split(' ');
    let line = '';
    let currentY = y;

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxWidth && n > 0) {
        ctx.fillText(line.trim(), x, currentY);
        line = words[n] + ' ';
        currentY += lineHeight;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line.trim(), x, currentY);
  };

  const handlePrint = () => {
    setGenerating(true);
    
    setTimeout(() => {
      const canvas = generatePrintCanvas();
      if (!canvas) {
        setGenerating(false);
        return;
      }

      const printWindow = window.open('', '_blank');
      if (!printWindow) {
        setGenerating(false);
        return;
      }

      const imgData = canvas.toDataURL('image/png');
      
      printWindow.document.write(`
        <!DOCTYPE html>
        <html>
          <head>
            <title>Dwadido QR Card - ${code}</title>
            <style>
              @page {
                size: ${cardSize === 'a4-sheet' ? 'A4' : cardSize === 'postcard' ? '6in 4.6in' : '3.5in 2.5in'};
                margin: 0;
              }
              body {
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                background: #f5f5f5;
              }
              img {
                max-width: 100%;
                height: auto;
              }
              @media print {
                body {
                  background: white;
                }
                img {
                  width: 100%;
                  height: auto;
                }
              }
            </style>
          </head>
          <body>
            <img src="${imgData}" />
            <script>
              window.onload = function() {
                window.print();
                window.onafterprint = function() {
                  window.close();
                };
              };
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
      setGenerating(false);
    }, 100);
  };

  const handleDownload = () => {
    setGenerating(true);
    
    setTimeout(() => {
      const canvas = generatePrintCanvas();
      if (!canvas) {
        setGenerating(false);
        return;
      }

      const link = document.createElement('a');
      link.download = `dwadido-qr-card-${code}-${cardSize}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      setGenerating(false);
    }, 100);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-md"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-charcoal-800 rounded-2xl border border-charcoal-600 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in duration-200 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-charcoal-600 sticky top-0 bg-charcoal-800 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-pink-500 to-purple-500 rounded-xl flex items-center justify-center">
              <Printer className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Print QR Card</h3>
              <p className="text-sm text-gray-400">Create printable cards with tear-off tabs</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Card Size Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-3">
              Card Size
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {CARD_SIZES.map((size) => (
                <button
                  key={size.id}
                  onClick={() => setCardSize(size.id)}
                  className={`p-4 rounded-xl border-2 transition-all text-left ${
                    cardSize === size.id
                      ? 'border-gold bg-gold/10'
                      : 'border-charcoal-600 hover:border-charcoal-500 bg-charcoal-700'
                  }`}
                >
                  <div className="flex items-center gap-3 mb-2">
                    <div className={`p-2 rounded-lg ${cardSize === size.id ? 'bg-gold/20 text-gold' : 'bg-charcoal-600 text-gray-400'}`}>
                      {size.icon}
                    </div>
                    {cardSize === size.id && <Check className="w-4 h-4 text-gold ml-auto" />}
                  </div>
                  <p className="font-medium text-white text-sm">{size.name}</p>
                  <p className="text-xs text-gray-400 mt-1">{size.description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Color Customization */}
          <div>
            <button
              onClick={() => setShowColorPicker(!showColorPicker)}
              className="flex items-center justify-between w-full p-4 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl border border-charcoal-600 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-pink-500 via-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
                  <Palette className="w-5 h-5 text-white" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-white">Color Theme</p>
                  <p className="text-sm text-gray-400">{COLOR_PRESETS[selectedPreset].name}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex -space-x-1">
                  <div className="w-5 h-5 rounded-full border-2 border-charcoal-700" style={{ backgroundColor: colors.primary }} />
                  <div className="w-5 h-5 rounded-full border-2 border-charcoal-700" style={{ backgroundColor: colors.accent }} />
                  <div className="w-5 h-5 rounded-full border-2 border-charcoal-700" style={{ backgroundColor: colors.background }} />
                </div>
                <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${showColorPicker ? 'rotate-180' : ''}`} />
              </div>
            </button>

            {showColorPicker && (
              <div className="mt-3 p-4 bg-charcoal-700 rounded-xl border border-charcoal-600">
                <p className="text-sm text-gray-400 mb-3">Choose a color preset:</p>
                <div className="grid grid-cols-4 gap-2">
                  {COLOR_PRESETS.map((preset, index) => (
                    <button
                      key={preset.name}
                      onClick={() => handlePresetSelect(index)}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        selectedPreset === index
                          ? 'border-gold'
                          : 'border-transparent hover:border-charcoal-500'
                      }`}
                      style={{ backgroundColor: preset.colors.background }}
                    >
                      <div className="flex justify-center gap-1 mb-2">
                        <div className="w-4 h-4 rounded-full" style={{ backgroundColor: preset.colors.primary }} />
                        <div className="w-4 h-4 rounded-full" style={{ backgroundColor: preset.colors.accent }} />
                      </div>
                      <p className="text-xs truncate" style={{ color: preset.colors.text }}>{preset.name}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Personal Message */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              <MessageSquare className="w-4 h-4 inline mr-2" />
              Personal Message (optional)
            </label>
            <textarea
              value={personalMessage}
              onChange={(e) => setPersonalMessage(e.target.value)}
              placeholder="Add a personal touch... e.g., 'Looking forward to connecting!'"
              maxLength={100}
              rows={2}
              className="w-full px-4 py-3 bg-charcoal-700 border border-charcoal-600 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold focus:border-transparent resize-none"
            />
            <p className="text-xs text-gray-500 mt-1 text-right">{personalMessage.length}/100</p>
          </div>

          {/* Preview Card */}
          <div className="bg-charcoal-700 rounded-xl border border-charcoal-600 p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-sm font-medium text-gray-300">Preview</p>
              <div className="flex items-center gap-2 text-xs text-gray-500">
                <Scissors className="w-3 h-3" />
                <span>Tear-off tabs included</span>
              </div>
            </div>
            
            {/* Mini preview */}
            <div 
              className="rounded-lg overflow-hidden mx-auto"
              style={{ 
                backgroundColor: colors.background,
                maxWidth: cardSize === 'a4-sheet' ? '100%' : cardSize === 'postcard' ? '300px' : '200px'
              }}
            >
              <div className="p-4 flex items-center gap-4">
                {/* QR placeholder */}
                <div 
                  className="w-16 h-16 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: '#ffffff' }}
                >
                  {qrMatrix && (
                    <div className="w-12 h-12 grid" style={{ gridTemplateColumns: `repeat(${Math.min(qrMatrix.length, 21)}, 1fr)` }}>
                      {qrMatrix.slice(0, 21).map((row, i) => 
                        row.slice(0, 21).map((cell, j) => (
                          <div 
                            key={`${i}-${j}`} 
                            style={{ backgroundColor: cell ? colors.accent : '#ffffff' }}
                          />
                        ))
                      )}
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm" style={{ color: colors.primary }}>Dwadido</p>
                  <p className="text-xs truncate" style={{ color: colors.text }}>{userName}</p>
                  <p className="font-mono font-bold text-sm" style={{ color: colors.primary }}>{code}</p>
                  {personalMessage && (
                    <p className="text-xs italic truncate mt-1" style={{ color: colors.text }}>"{personalMessage}"</p>
                  )}
                </div>
              </div>
              {/* Tear-off tabs preview */}
              <div 
                className="h-6 flex items-center justify-around border-t-2 border-dashed"
                style={{ backgroundColor: colors.primary, borderColor: colors.background }}
              >
                {[...Array(5)].map((_, i) => (
                  <span 
                    key={i} 
                    className="text-xs font-mono font-bold"
                    style={{ color: colors.background }}
                  >
                    {code}
                  </span>
                ))}
              </div>
            </div>

            {cardSize === 'a4-sheet' && (
              <p className="text-xs text-gray-500 text-center mt-3">
                8 cards will be printed on a single A4 sheet
              </p>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={handlePrint}
              disabled={generating || !qrMatrix}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 disabled:from-charcoal-600 disabled:to-charcoal-600 text-white font-semibold rounded-xl transition-all"
            >
              {generating ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Printer className="w-5 h-5" />
              )}
              <span>Print Cards</span>
            </button>
            
            <button
              onClick={handleDownload}
              disabled={generating || !qrMatrix}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-charcoal-700 hover:bg-charcoal-600 disabled:bg-charcoal-600 text-white font-medium rounded-xl transition-all border border-charcoal-600"
            >
              {generating ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Download className="w-5 h-5" />
              )}
              <span>Download Image</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 pb-6">
          <div className="p-4 bg-charcoal-700/50 rounded-xl border border-charcoal-600">
            <div className="flex items-start gap-3">
              <Scissors className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-white">Tear-off Tabs</p>
                <p className="text-xs text-gray-400 mt-1">
                  Each card includes tear-off tabs at the bottom with your code. 
                  Perfect for handing out to people who can take a tab with your code!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrintableQRCard;
