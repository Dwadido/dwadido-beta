// AppLayout — Build 2026-02-19T16:37:00Z
import React, { useState, useEffect, useRef } from 'react';

import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import Header from './layout/Header';
import Hero from './landing/Hero';
import Features from './landing/Features';
import HowItWorks from './landing/HowItWorks';
import Stats from './landing/Stats';
import FAQ from './landing/FAQ';
import CTA from './landing/CTA';
import Footer from './landing/Footer';
import AuthModal from './auth/AuthModal';

const HERO_IMAGE = 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&auto=format&fit=crop&q=80';
const CARD_IMAGE = 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&auto=format&fit=crop&q=80';

// Maximum time to wait for loading before showing timeout error
const MAX_LOADING_TIME_MS = 20000; // 20 seconds

const AppLayout: React.FC = () => {
  const { user, loading, error, clearError } = useAuth();
  const navigate = useNavigate();
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signup');
  const [loadingTimedOut, setLoadingTimedOut] = useState(false);
  const loadingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Redirect to dashboard if user is logged in
  useEffect(() => {
    if (user && !loading) {
      navigate('/dashboard');
    }
  }, [user, loading, navigate]);

  // Handle loading timeout - prevent infinite loading states
  useEffect(() => {
    if (loading && !loadingTimedOut) {
      // Set a timeout to prevent infinite loading
      loadingTimeoutRef.current = setTimeout(() => {
        console.warn('[AppLayout] Loading timeout reached after', MAX_LOADING_TIME_MS, 'ms');
        setLoadingTimedOut(true);
      }, MAX_LOADING_TIME_MS);
    } else if (!loading) {
      // Clear timeout when loading completes
      if (loadingTimeoutRef.current) {
        clearTimeout(loadingTimeoutRef.current);
        loadingTimeoutRef.current = null;
      }
      setLoadingTimedOut(false);
    }

    return () => {
      if (loadingTimeoutRef.current) {
        clearTimeout(loadingTimeoutRef.current);
      }
    };
  }, [loading, loadingTimedOut]);

  const handleSignIn = () => {
    setAuthMode('signin');
    setAuthModalOpen(true);
  };

  const handleSignUp = () => {
    setAuthMode('signup');
    setAuthModalOpen(true);
  };

  const handleRetry = () => {
    clearError();
    setLoadingTimedOut(false);
    window.location.reload();
  };

  // Show error state if there's a connection/timeout error OR if loading timed out
  if ((error && !user) || loadingTimedOut) {
    const errorMessage = loadingTimedOut 
      ? 'Loading is taking longer than expected. This might be due to a slow connection.'
      : error;

    return (
      <div className="min-h-screen flex items-center justify-center bg-charcoal">
        <div className="text-center max-w-md mx-auto px-4">
          <div className="w-16 h-16 mx-auto mb-4 bg-charcoal-700 rounded-2xl flex items-center justify-center border border-red-500/30">
            <svg className="w-8 h-8 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h2 className="text-xl font-semibold text-white mb-2">
            {loadingTimedOut ? 'Connection Slow' : 'Connection Issue'}
          </h2>
          <p className="text-gray-400 mb-6">{errorMessage}</p>
          <button
            onClick={handleRetry}
            className="px-6 py-3 bg-gold text-charcoal font-medium rounded-lg hover:bg-gold-400 transition-colors"
          >
            Try Again
          </button>
          {loadingTimedOut && (
            <p className="text-gray-500 text-sm mt-4">
              If this keeps happening, please check your internet connection.
            </p>
          )}
        </div>
      </div>
    );
  }

  // Show loading state (but with timeout protection)
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-charcoal">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-charcoal-700 rounded-2xl flex items-center justify-center border border-gold/20 animate-pulse">
            <svg className="w-8 h-8 text-gold" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path 
                d="M20 35L17.09 32.3C8.14 24.2 2 18.55 2 11.5C2 5.85 6.42 1.5 12 1.5C15.09 1.5 18.09 2.97 20 5.27C21.91 2.97 24.91 1.5 28 1.5C33.58 1.5 38 5.85 38 11.5C38 18.55 31.86 24.2 22.91 32.3L20 35Z" 
                fill="#1C1C1C"
                stroke="#C9A24D"
                strokeWidth="2"
              />
              <path 
                d="M14 19L18 23L26 15" 
                stroke="#C9A24D" 
                strokeWidth="3" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              />
            </svg>
          </div>
          <p className="text-gray-400">Loading Dwadido...</p>
          <p className="text-gray-500 text-sm mt-2">This should only take a moment</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header
        onSignIn={handleSignIn}
        onSignUp={handleSignUp}
        transparent={true}
      />

      <main>
        <Hero
          onGetStarted={handleSignUp}
          heroImage={HERO_IMAGE}
        />

        <Stats />
        
        <section id="features">
          <Features />
        </section>
        
        <section id="how-it-works">
          <HowItWorks cardImage={CARD_IMAGE} />
        </section>

        <FAQ />
        
        <CTA onGetStarted={handleSignUp} />
      </main>

      <Footer />

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authMode}
      />
    </div>
  );
};

export default AppLayout;
