import React, { useState, useEffect } from 'react';
import { MessageCircle, User, Calendar, MoreVertical, Flag, ShieldOff, Heart, Users, Lock, Eye, Camera, Loader2, Check } from 'lucide-react';

import ReportUserModal from '../safety/ReportUserModal';
import BlockUserModal from '../safety/BlockUserModal';

import { IntentType, RelationshipStatusType, INTENT_LABELS, RELATIONSHIP_STATUS_LABELS, useAuth, CommunicationStyleType, LoveStyleType, LifestyleFactors } from '@/contexts/AuthContext';
import { supabase, getPublicPhotoUrl } from '@/lib/supabase';
import { useI18n } from '@/contexts/I18nContext';
import { calculateAge } from './MatchFilters';



// =============================================================================
// DWADIDO MATCH CARD — MUTUAL PHOTO REVEAL CONSENT
// 
// Photo visibility rules (DWADIDO concept):
// - Photos are HIDDEN by default for all matches
// - Each user has a "Reveal My Photo" button per match
// - Only when BOTH users opt in, photos become visible to each other
// - Uses photo_reveals table for consent tracking
// 
// Design: Calm, intentional, non-addictive
// =============================================================================

interface MatchCardProps {
  match: {
    id: string;
    status: string;
    stage: number;
    confirmed_at: string;
    expires_at: string;
    other_user: {
      id: string;
      display_name: string | null;
      avatar_url: string | null;
      bio: string | null;
      interest_tags: string[];
      intent?: IntentType | null;
      relationship_status?: RelationshipStatusType | null;
      photo_visibility?: 'private' | 'matches_only' | 'approved_only';
      date_of_birth?: string | null;
      communication_style?: CommunicationStyleType;
      love_style?: LoveStyleType;
      lifestyle_factors?: LifestyleFactors | null;
      city?: string | null;
      values_causes?: string[] | null;
    };
  };
  onOpenChat: (matchId: string) => void;
}

const MatchCard: React.FC<MatchCardProps> = ({ match, onOpenChat }) => {
  const { user, profile } = useAuth();
  const { t } = useI18n();
  const [showMenu, setShowMenu] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showBlockModal, setShowBlockModal] = useState(false);

  // ── Photo Reveal Consent State ──
  const [iRevealed, setIRevealed] = useState(false);
  const [theyRevealed, setTheyRevealed] = useState(false);
  const [revealLoading, setRevealLoading] = useState(true);
  const [revealToggling, setRevealToggling] = useState(false);
  const [otherUserPhotoUrl, setOtherUserPhotoUrl] = useState<string | null>(null);
  // ── Check if this match has any messages yet ──
  // When hasMessages is false, we show a "Start a conversation" prompt
  // on the connection card to encourage the first message.
  const [hasMessages, setHasMessages] = useState<boolean | null>(null);


  // ── FIX: Derive "has photo" from profile (AuthContext), NOT from user_photos table ──
  const myPhotoReady = !!(profile?.primary_photo_path || profile?.avatar_url);

  
  const confirmedDate = new Date(match.confirmed_at);
  const formattedDate = confirmedDate.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });

  const age = calculateAge(match.other_user.date_of_birth);

  // Mutual reveal = both users opted in
  const mutualReveal = iRevealed && theyRevealed;

  // ── Check reveal status + fetch photo if mutual ──
  useEffect(() => {
    if (!user || !match.id) return;

    const checkReveals = async () => {
      setRevealLoading(true);
      try {
        const { data: reveals, error } = await supabase
          .from('photo_reveals')
          .select('revealer_user_id')
          .eq('match_id', match.id);

        if (!error && reveals) {
          const myReveal = reveals.some(r => r.revealer_user_id === user.id);
          const theirReveal = reveals.some(r => r.revealer_user_id === match.other_user.id);
          setIRevealed(myReveal);
          setTheyRevealed(theirReveal);

          if (myReveal && theirReveal) {
            await fetchOtherUserPhoto();
          }
        }
      } catch (err) {
        console.error('[MatchCard] Error checking reveals:', err);
      }
      setRevealLoading(false);
    };

    checkReveals();
  }, [user, match.id, match.other_user.id]);

  // ── Check if this match has any messages (for "start a conversation" prompt) ──
  // Lightweight count query — only fetches 1 row to check existence.

  useEffect(() => {
    if (!match.id) return;

    const checkMessages = async () => {
      try {
        const { count, error } = await supabase
          .from('messages')
          .select('id', { count: 'exact', head: true })
          .eq('match_id', match.id)
          .limit(1);

        if (!error) {
          setHasMessages((count ?? 0) > 0);
        }
      } catch {
        // Fail silently — indicator just won't show
      }
    };

    checkMessages();
  }, [match.id]);



  // ── Helper: Fetch other user's photo from profiles table ──
  const fetchOtherUserPhoto = async () => {
    try {
      const { data: otherProfile } = await supabase
        .from('profiles')
        .select('primary_photo_path, primary_photo_updated_at, avatar_url')
        .eq('id', match.other_user.id)
        .single();

      if (otherProfile?.primary_photo_path) {
        const url = getPublicPhotoUrl(otherProfile.primary_photo_path, otherProfile.primary_photo_updated_at);
        if (url) {
          setOtherUserPhotoUrl(url);
          return;
        }
      }
      if (otherProfile?.avatar_url) {
        setOtherUserPhotoUrl(otherProfile.avatar_url);
      } else if (match.other_user.avatar_url) {
        setOtherUserPhotoUrl(match.other_user.avatar_url);
      }
    } catch {
      // Fail silently — photo just won't show
    }
  };


  // ── Toggle reveal ──
  const handleToggleReveal = async () => {
    if (!user || revealToggling) return;
    setRevealToggling(true);

    try {
      if (iRevealed) {
        await supabase
          .from('photo_reveals')
          .delete()
          .eq('match_id', match.id)
          .eq('revealer_user_id', user.id);
        setIRevealed(false);
        setOtherUserPhotoUrl(null);
      } else {
        const { error } = await supabase
          .from('photo_reveals')
          .insert({ match_id: match.id, revealer_user_id: user.id });
        
        if (!error) {
          setIRevealed(true);
          if (theyRevealed) {
            await fetchOtherUserPhoto();
          }
        }
      }
    } catch (err) {
      console.error('[MatchCard] Error toggling reveal:', err);
    }
    setRevealToggling(false);
  };

  return (
    <>
      <div className="bg-[#141414] rounded-2xl border border-[#2a2a2a] shadow-sm hover:border-[#C9A24D]/30 transition-all overflow-hidden group">
        <div className="p-5">
          {/* Status indicator */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/10 rounded-full border border-green-500/20">
              <div className="w-2 h-2 bg-green-500 rounded-full" />
              <span className="text-xs text-green-400 font-medium">Connected</span>
            </div>
          </div>

          <div className="flex items-start gap-4">
            {/* Avatar — only shows real photo if mutual reveal */}
            <div className="relative">
              {mutualReveal && otherUserPhotoUrl ? (
                <img
                  src={otherUserPhotoUrl}
                  alt={match.other_user.display_name || 'User'}
                  className="w-14 h-14 rounded-full object-cover ring-2 ring-[#C9A24D]/30"
                />
              ) : (
                <div className="w-14 h-14 rounded-full bg-[#C9A24D]/20 flex items-center justify-center border border-[#C9A24D]/30 relative">
                  <User className="w-7 h-7 text-[#C9A24D]" />
                  {/* Lock icon when photo is hidden */}
                  <div className="absolute -top-1 -right-1 p-1 bg-[#1a1a1a] rounded-full border border-[#2a2a2a]">
                    <Lock className="w-3 h-3 text-gray-400" />
                  </div>
                </div>
              )}
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-semibold text-white truncate">
                    {match.other_user.display_name || 'Anonymous'}
                  </h3>
                  {age !== null ? (
                    <span className="px-2 py-0.5 bg-[#2a2a2a] text-gray-300 text-xs font-medium rounded-full border border-[#3a3a3a]">
                      {age}
                    </span>
                  ) : (
                    <span className="text-xs text-gray-500 italic">Age not specified</span>
                  )}
                </div>

                <div className="relative">
                  <button
                    onClick={() => setShowMenu(!showMenu)}
                    className="p-1 text-gray-500 hover:text-gray-300 rounded-full hover:bg-[#2a2a2a] transition-all"
                  >
                    <MoreVertical className="w-4 h-4" />
                  </button>
                  {showMenu && (
                    <>
                      <div className="fixed inset-0 z-10" onClick={() => setShowMenu(false)} />
                      <div className="absolute right-0 top-8 z-20 w-48 bg-[#1a1a1a] rounded-xl shadow-lg border border-[#2a2a2a] py-1">
                        <button
                          onClick={() => {
                            setShowMenu(false);
                            setShowReportModal(true);
                          }}
                          className="w-full px-4 py-2 text-left text-sm text-red-400 hover:bg-red-500/10 flex items-center gap-2"
                        >
                          <Flag className="w-4 h-4" />
                          Report User
                        </button>
                        <button
                          onClick={() => {
                            setShowMenu(false);
                            setShowBlockModal(true);
                          }}
                          className="w-full px-4 py-2 text-left text-sm text-[#C9A24D] hover:bg-[#C9A24D]/10 flex items-center gap-2"
                        >
                          <ShieldOff className="w-4 h-4" />
                          Block User
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
              
              {match.other_user.bio && (
                <p className="text-gray-400 text-sm mt-1 line-clamp-2">{match.other_user.bio}</p>
              )}

              <div className="flex items-center gap-1 text-gray-500 text-xs mt-2">
                <Calendar className="w-3 h-3" />
                <span>Connected {formattedDate}</span>
              </div>
            </div>
          </div>

          {/* ── Photo Reveal Consent Section ── */}
          {!revealLoading && (
            <div className="mt-4 p-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <Camera className="w-4 h-4 text-[#C9A24D]" />
                <span className="text-sm font-medium text-white">Photo Reveal</span>
              </div>

              {mutualReveal ? (
                /* Both revealed — photos visible */
                <div className="flex items-center gap-2 text-green-400 text-xs mb-2">
                  <Check className="w-3.5 h-3.5" />
                  <span>Both photos revealed — you can see each other</span>
                </div>
              ) : (
                /* Status indicators */
                <div className="space-y-1 mb-2">
                  <div className="flex items-center gap-2 text-xs">
                    <div className={`w-2 h-2 rounded-full ${iRevealed ? 'bg-green-400' : 'bg-gray-500'}`} />
                    <span className={iRevealed ? 'text-green-400' : 'text-gray-400'}>
                      You: {iRevealed ? 'Revealed' : 'Hidden'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs">
                    <div className={`w-2 h-2 rounded-full ${theyRevealed ? 'bg-green-400' : 'bg-gray-500'}`} />
                    <span className={theyRevealed ? 'text-green-400' : 'text-gray-400'}>
                      {match.other_user.display_name || 'They'}: {theyRevealed ? 'Revealed' : 'Hidden'}
                    </span>
                  </div>
                </div>
              )}

              {/* Reveal / Un-reveal button */}
              {!myPhotoReady && !iRevealed ? (
                <p className="text-xs text-gray-500">Upload a photo first to reveal it to this match.</p>
              ) : (
                <button
                  onClick={handleToggleReveal}
                  disabled={revealToggling}
                  className={`w-full py-2 text-sm font-medium rounded-lg transition-all flex items-center justify-center gap-2 ${
                    iRevealed
                      ? 'bg-[#2a2a2a] text-gray-300 hover:bg-[#333] border border-[#3a3a3a]'
                      : 'bg-[#C9A24D]/20 text-[#C9A24D] hover:bg-[#C9A24D]/30 border border-[#C9A24D]/30'
                  }`}
                >
                  {revealToggling ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : iRevealed ? (
                    <>
                      <Eye className="w-4 h-4" />
                      Hide My Photo
                    </>
                  ) : (
                    <>
                      <Camera className="w-4 h-4" />
                      Reveal My Photo to This Match
                    </>
                  )}
                </button>
              )}

              {/* Explanation text */}
              {!mutualReveal && (
                <p className="text-xs text-gray-500 mt-2">
                  Photos are only visible when both people choose to reveal.
                </p>
              )}
            </div>
          )}

          {/* Intent & Relationship Status */}
          {(match.other_user.intent || match.other_user.relationship_status) && (
            <div className="mt-4 p-3 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl">
              <div className="flex flex-wrap gap-4">
                {match.other_user.intent && (
                  <div className="flex items-center gap-2">
                    <Heart className="w-4 h-4 text-[#C9A24D]" />
                    <span className="text-gray-400 text-sm">Looking for:</span>
                    <span className="text-white text-sm font-medium">
                      {INTENT_LABELS[match.other_user.intent]}
                    </span>
                  </div>
                )}
                {match.other_user.relationship_status && (
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-[#C9A24D]" />
                    <span className="text-gray-400 text-sm">Status:</span>
                    <span className="text-white text-sm font-medium">
                      {RELATIONSHIP_STATUS_LABELS[match.other_user.relationship_status]}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Interest tags */}
          {match.other_user.interest_tags && match.other_user.interest_tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mt-4">
              {match.other_user.interest_tags.slice(0, 4).map((tag, index) => (
                <span
                  key={index}
                  className="px-2.5 py-1 bg-[#C9A24D]/10 text-[#C9A24D] text-xs font-medium rounded-full border border-[#C9A24D]/20"
                >
                  {tag}
                </span>
              ))}
              {match.other_user.interest_tags.length > 4 && (
                <span className="px-2.5 py-1 bg-[#1a1a1a] text-gray-400 text-xs font-medium rounded-full">
                  +{match.other_user.interest_tags.length - 4}
                </span>
              )}
            </div>
          )}

          {/* ── New Conversation Prompt ──
              Shown on the MatchCard when no messages have been exchanged yet.
              Encourages the user to send the first message. */}
          {hasMessages === false && (
            <button
              onClick={() => onOpenChat(match.id)}
              className="w-full mt-3 p-3 bg-[#C9A24D]/10 hover:bg-[#C9A24D]/15 border border-[#C9A24D]/20 hover:border-[#C9A24D]/30 rounded-xl transition-all text-left group/starters"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 bg-[#C9A24D]/20 rounded-lg flex items-center justify-center flex-shrink-0 group-hover/starters:bg-[#C9A24D]/30 transition-colors">
                  <MessageCircle className="w-4 h-4 text-[#C9A24D]" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-[#C9A24D]">Start a Conversation</p>
                  <p className="text-xs text-gray-500 mt-0.5">
                    Say hello — you met in person, now connect here
                  </p>
                </div>
                <MessageCircle className="w-4 h-4 text-[#C9A24D]/60 flex-shrink-0" />
              </div>
            </button>
          )}


          {/* Chat button */}
          <button
            onClick={() => onOpenChat(match.id)}
            className="w-full mt-4 py-2.5 bg-[#C9A24D] hover:bg-[#d4af5a] text-[#141414] font-medium rounded-xl flex items-center justify-center gap-2 transition-all shadow-[0_4px_20px_rgba(201,162,77,0.3)]"
          >
            <MessageCircle className="w-4 h-4" />
            Send Message
          </button>
        </div>
      </div>



      {/* Report Modal */}
      <ReportUserModal
        isOpen={showReportModal}
        onClose={() => setShowReportModal(false)}
        reportedUserId={match.other_user.id}
        reportedUserName={match.other_user.display_name || undefined}
      />

      {/* Block Modal */}
      <BlockUserModal
        isOpen={showBlockModal}
        onClose={() => setShowBlockModal(false)}
        userId={match.other_user.id}
        userName={match.other_user.display_name || undefined}
      />
    </>
  );
};

export default MatchCard;
