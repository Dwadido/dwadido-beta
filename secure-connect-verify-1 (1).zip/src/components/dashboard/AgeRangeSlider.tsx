import React, { useState, useRef, useCallback, useEffect } from 'react';

interface AgeRangeSliderProps {
  minAge: number;
  maxAge: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (min: number, max: number) => void;
  disabled?: boolean;
}

const AgeRangeSlider: React.FC<AgeRangeSliderProps> = ({
  minAge,
  maxAge,
  min = 18,
  max = 80,
  step = 1,
  onChange,
  disabled = false,
}) => {
  const [localMin, setLocalMin] = useState(minAge);
  const [localMax, setLocalMax] = useState(maxAge);
  const [dragging, setDragging] = useState<'min' | 'max' | null>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  // Sync with props
  useEffect(() => {
    setLocalMin(minAge);
    setLocalMax(maxAge);
  }, [minAge, maxAge]);

  const getPercentage = (value: number) => {
    return ((value - min) / (max - min)) * 100;
  };

  const getValueFromPosition = useCallback((clientX: number) => {
    if (!trackRef.current) return min;
    const rect = trackRef.current.getBoundingClientRect();
    const percentage = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    const rawValue = min + percentage * (max - min);
    return Math.round(rawValue / step) * step;
  }, [min, max, step]);

  const handleMouseDown = (e: React.MouseEvent, handle: 'min' | 'max') => {
    if (disabled) return;
    e.preventDefault();
    setDragging(handle);
  };

  const handleTouchStart = (e: React.TouchEvent, handle: 'min' | 'max') => {
    if (disabled) return;
    setDragging(handle);
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!dragging) return;
      const value = getValueFromPosition(e.clientX);
      
      if (dragging === 'min') {
        const newMin = Math.min(value, localMax - step);
        setLocalMin(Math.max(min, newMin));
      } else {
        const newMax = Math.max(value, localMin + step);
        setLocalMax(Math.min(max, newMax));
      }
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!dragging || !e.touches[0]) return;
      const value = getValueFromPosition(e.touches[0].clientX);
      
      if (dragging === 'min') {
        const newMin = Math.min(value, localMax - step);
        setLocalMin(Math.max(min, newMin));
      } else {
        const newMax = Math.max(value, localMin + step);
        setLocalMax(Math.min(max, newMax));
      }
    };

    const handleEnd = () => {
      if (dragging) {
        onChange(localMin, localMax);
        setDragging(null);
      }
    };

    if (dragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleEnd);
      document.addEventListener('touchmove', handleTouchMove);
      document.addEventListener('touchend', handleEnd);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleEnd);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleEnd);
    };
  }, [dragging, localMin, localMax, min, max, step, onChange, getValueFromPosition]);

  const handleTrackClick = (e: React.MouseEvent) => {
    if (disabled) return;
    const value = getValueFromPosition(e.clientX);
    
    // Determine which handle is closer
    const distToMin = Math.abs(value - localMin);
    const distToMax = Math.abs(value - localMax);
    
    if (distToMin < distToMax) {
      const newMin = Math.min(value, localMax - step);
      setLocalMin(Math.max(min, newMin));
      onChange(Math.max(min, newMin), localMax);
    } else {
      const newMax = Math.max(value, localMin + step);
      setLocalMax(Math.min(max, newMax));
      onChange(localMin, Math.min(max, newMax));
    }
  };

  const minPercent = getPercentage(localMin);
  const maxPercent = getPercentage(localMax);

  return (
    <div className={`w-full ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}>
      {/* Value display */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-2xl font-bold text-gold">{localMin}</span>
          <span className="text-gray-400">-</span>
          <span className="text-2xl font-bold text-gold">{localMax}</span>
          <span className="text-sm text-gray-400 ml-1">years</span>
        </div>
      </div>

      {/* Slider track */}
      <div 
        ref={trackRef}
        className="relative h-2 bg-charcoal-600 rounded-full cursor-pointer"
        onClick={handleTrackClick}
      >
        {/* Active range */}
        <div
          className="absolute h-full bg-gradient-to-r from-gold to-gold-400 rounded-full"
          style={{
            left: `${minPercent}%`,
            width: `${maxPercent - minPercent}%`,
          }}
        />

        {/* Min handle */}
        <div
          className={`absolute top-1/2 -translate-y-1/2 w-6 h-6 bg-gold rounded-full shadow-lg cursor-grab border-2 border-white transition-transform ${
            dragging === 'min' ? 'scale-110 cursor-grabbing' : 'hover:scale-105'
          } ${disabled ? 'cursor-not-allowed' : ''}`}
          style={{ left: `calc(${minPercent}% - 12px)` }}
          onMouseDown={(e) => handleMouseDown(e, 'min')}
          onTouchStart={(e) => handleTouchStart(e, 'min')}
        >
          <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-charcoal-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            {localMin}
          </div>
        </div>

        {/* Max handle */}
        <div
          className={`absolute top-1/2 -translate-y-1/2 w-6 h-6 bg-gold rounded-full shadow-lg cursor-grab border-2 border-white transition-transform ${
            dragging === 'max' ? 'scale-110 cursor-grabbing' : 'hover:scale-105'
          } ${disabled ? 'cursor-not-allowed' : ''}`}
          style={{ left: `calc(${maxPercent}% - 12px)` }}
          onMouseDown={(e) => handleMouseDown(e, 'max')}
          onTouchStart={(e) => handleTouchStart(e, 'max')}
        >
          <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-charcoal-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            {localMax}
          </div>
        </div>
      </div>

      {/* Range labels */}
      <div className="flex justify-between mt-2 text-xs text-gray-500">
        <span>{min}</span>
        <span>{max}+</span>
      </div>
    </div>
  );
};

export default AgeRangeSlider;
