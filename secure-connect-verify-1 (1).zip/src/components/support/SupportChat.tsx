import React, { useState, useRef, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { usePremium } from '@/contexts/PremiumContext';
import { useI18n } from '@/contexts/I18nContext';
import { 
  MessageCircle, 
  X, 
  Send, 
  Loader2, 
  Bot, 
  User, 
  HelpCircle,
  Shield,
  CreditCard,
  Settings,
  Minimize2,
  Maximize2,
  RefreshCw,
  Receipt,
  XCircle,
  AlertCircle,
  Crown,
  Smartphone,
  Wifi,
  Camera,
  Bell,
  Video,
  MapPin,
  LogIn,
  Image,
  AlertTriangle,
  ArrowLeft,
  Wrench,
  UserCheck,
  Phone,
  ExternalLink,
  Globe
} from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  escalation?: {
    triggered: boolean;
    type: string;
    reason: string;
    priority: string;
  };
  isEscalated?: boolean;
}

interface FAQ {
  category: string;
  questions: { q: string; a: string }[];
}

interface DeviceInfo {
  platform: string;
  osVersion: string;
  appVersion: string;
  browser: string;
  connectionType: string;
}

interface EscalationState {
  isEscalated: boolean;
  type: string;
  priority: string;
}

// UI text translations for the support chat component
const UI_TEXT = {
  en: {
    needHelp: 'Need help?',
    supportChat: 'Support Chat',
    aiAssistant: 'AI Assistant',
    aiDisclosure: "You're chatting with an AI assistant. For complex issues, I can escalate to human review.",
    teamWillReview: 'Our team will review',
    welcomeTitle: "Hi! I'm Dwadido's AI Support",
    welcomeSubtitle: 'I can help with account issues, Crush Codes, safety, billing, technical problems, and more.',
    quickTopics: {
      codes: 'Crush Codes',
      safety: 'Safety & Privacy',
      billing: 'Premium & Billing',
      technical: 'Technical Help'
    },
    commonQuestions: 'Common Questions',
    billingTitle: 'Premium & Billing Support',
    billingSubtitle: 'I can help with subscriptions, payments, refunds, and billing questions.',
    whatNeedHelp: 'What do you need help with?',
    billingActions: {
      subscription_status: 'Check my subscription',
      cancel: 'Cancel subscription',
      refund: 'Request a refund',
      payment_issue: 'Payment problem',
      receipt: 'Find my receipt'
    },
    backToTopics: 'Back to all topics',
    billingFAQs: 'Billing FAQs',
    technicalTitle: 'Technical Support',
    technicalSubtitle: 'I can help diagnose and troubleshoot common app issues.',
    whatIssue: 'What issue are you experiencing?',
    technicalActions: {
      crash: "App crashes or won't open",
      loading: 'Slow or not loading',
      photos: 'Photo upload issues',
      notifications: 'Not receiving notifications',
      video: 'Video call problems',
      map: 'Map not working',
      login: "Can't log in",
      permissions: 'Permission issues'
    },
    technicalFAQs: 'Technical FAQs',
    thinking: 'Thinking...',
    startNew: 'Start new conversation',
    requestHuman: 'Request human review',
    escalatedTitle: 'Issue Escalated for Review',
    escalatedSubtitle: 'Our team will review this and may reach out via email. You can continue chatting or close this window.',
    addMoreDetails: 'Add more details...',
    describeIssue: 'Describe your issue...',
    premiumActive: 'Active',
    premiumCancelled: 'Cancelled',
    freeAccount: 'Free account',
    closeChat: 'Close chat',
    escalationBadges: {
      safety_harm: 'Urgent Safety Review',
      safety_harassment: 'Safety Team Review',
      legal: 'Legal Review',
      billing_dispute: 'Billing Review',
      technical_systemwide: 'Engineering Review',
      user_requested: 'Human Review Requested'
    }
  },
  es: {
    needHelp: '¿Necesitas ayuda?',
    supportChat: 'Chat de Soporte',
    aiAssistant: 'Asistente IA',
    aiDisclosure: 'Estás chateando con un asistente de IA. Para problemas complejos, puedo escalar a revisión humana.',
    teamWillReview: 'Nuestro equipo revisará',
    welcomeTitle: '¡Hola! Soy el Soporte IA de Dwadido',
    welcomeSubtitle: 'Puedo ayudarte con problemas de cuenta, Crush Codes, seguridad, facturación, problemas técnicos y más.',
    quickTopics: {
      codes: 'Crush Codes',
      safety: 'Seguridad y Privacidad',
      billing: 'Premium y Facturación',
      technical: 'Ayuda Técnica'
    },
    commonQuestions: 'Preguntas Frecuentes',
    billingTitle: 'Soporte de Premium y Facturación',
    billingSubtitle: 'Puedo ayudarte con suscripciones, pagos, reembolsos y preguntas de facturación.',
    whatNeedHelp: '¿Con qué necesitas ayuda?',
    billingActions: {
      subscription_status: 'Verificar mi suscripción',
      cancel: 'Cancelar suscripción',
      refund: 'Solicitar reembolso',
      payment_issue: 'Problema de pago',
      receipt: 'Encontrar mi recibo'
    },
    backToTopics: 'Volver a todos los temas',
    billingFAQs: 'Preguntas de Facturación',
    technicalTitle: 'Soporte Técnico',
    technicalSubtitle: 'Puedo ayudar a diagnosticar y solucionar problemas comunes de la app.',
    whatIssue: '¿Qué problema estás experimentando?',
    technicalActions: {
      crash: 'La app se cierra o no abre',
      loading: 'Lento o no carga',
      photos: 'Problemas al subir fotos',
      notifications: 'No recibo notificaciones',
      video: 'Problemas con videollamadas',
      map: 'El mapa no funciona',
      login: 'No puedo iniciar sesión',
      permissions: 'Problemas de permisos'
    },
    technicalFAQs: 'Preguntas Técnicas',
    thinking: 'Pensando...',
    startNew: 'Iniciar nueva conversación',
    requestHuman: 'Solicitar revisión humana',
    escalatedTitle: 'Problema Escalado para Revisión',
    escalatedSubtitle: 'Nuestro equipo revisará esto y puede contactarte por email. Puedes continuar chateando o cerrar esta ventana.',
    addMoreDetails: 'Agregar más detalles...',
    describeIssue: 'Describe tu problema...',
    premiumActive: 'Activo',
    premiumCancelled: 'Cancelado',
    freeAccount: 'Cuenta gratuita',
    closeChat: 'Cerrar chat',
    escalationBadges: {
      safety_harm: 'Revisión de Seguridad Urgente',
      safety_harassment: 'Revisión del Equipo de Seguridad',
      legal: 'Revisión Legal',
      billing_dispute: 'Revisión de Facturación',
      technical_systemwide: 'Revisión de Ingeniería',
      user_requested: 'Revisión Humana Solicitada'
    }
  },
  fr: {
    needHelp: "Besoin d'aide?",
    supportChat: 'Chat Support',
    aiAssistant: 'Assistant IA',
    aiDisclosure: "Vous discutez avec un assistant IA. Pour les problèmes complexes, je peux escalader vers une révision humaine.",
    teamWillReview: 'Notre équipe examinera',
    welcomeTitle: "Bonjour! Je suis le Support IA de Dwadido",
    welcomeSubtitle: "Je peux vous aider avec les problèmes de compte, les Crush Codes, la sécurité, la facturation, les problèmes techniques et plus encore.",
    quickTopics: {
      codes: 'Crush Codes',
      safety: 'Sécurité et Confidentialité',
      billing: 'Premium et Facturation',
      technical: 'Aide Technique'
    },
    commonQuestions: 'Questions Fréquentes',
    billingTitle: 'Support Premium et Facturation',
    billingSubtitle: 'Je peux vous aider avec les abonnements, paiements, remboursements et questions de facturation.',
    whatNeedHelp: "De quoi avez-vous besoin d'aide?",
    billingActions: {
      subscription_status: 'Vérifier mon abonnement',
      cancel: 'Annuler abonnement',
      refund: 'Demander un remboursement',
      payment_issue: 'Problème de paiement',
      receipt: 'Trouver mon reçu'
    },
    backToTopics: 'Retour à tous les sujets',
    billingFAQs: 'FAQ Facturation',
    technicalTitle: 'Support Technique',
    technicalSubtitle: "Je peux aider à diagnostiquer et résoudre les problèmes courants de l'app.",
    whatIssue: 'Quel problème rencontrez-vous?',
    technicalActions: {
      crash: "L'app plante ou ne s'ouvre pas",
      loading: 'Lent ou ne charge pas',
      photos: 'Problèmes de téléchargement de photos',
      notifications: 'Je ne reçois pas de notifications',
      video: 'Problèmes d\'appels vidéo',
      map: 'La carte ne fonctionne pas',
      login: 'Je ne peux pas me connecter',
      permissions: 'Problèmes de permissions'
    },
    technicalFAQs: 'FAQ Techniques',
    thinking: 'Réflexion...',
    startNew: 'Nouvelle conversation',
    requestHuman: 'Demander révision humaine',
    escalatedTitle: 'Problème Escaladé pour Révision',
    escalatedSubtitle: "Notre équipe examinera ceci et pourra vous contacter par email. Vous pouvez continuer à discuter ou fermer cette fenêtre.",
    addMoreDetails: 'Ajouter plus de détails...',
    describeIssue: 'Décrivez votre problème...',
    premiumActive: 'Actif',
    premiumCancelled: 'Annulé',
    freeAccount: 'Compte gratuit',
    closeChat: 'Fermer le chat',
    escalationBadges: {
      safety_harm: 'Révision de Sécurité Urgente',
      safety_harassment: "Révision de l'Équipe de Sécurité",
      legal: 'Révision Légale',
      billing_dispute: 'Révision de Facturation',
      technical_systemwide: "Révision d'Ingénierie",
      user_requested: 'Révision Humaine Demandée'
    }
  },
  de: {
    needHelp: 'Brauchen Sie Hilfe?',
    supportChat: 'Support-Chat',
    aiAssistant: 'KI-Assistent',
    aiDisclosure: 'Sie chatten mit einem KI-Assistenten. Bei komplexen Problemen kann ich an menschliche Überprüfung eskalieren.',
    teamWillReview: 'Unser Team wird überprüfen',
    welcomeTitle: 'Hallo! Ich bin der KI-Support von Dwadido',
    welcomeSubtitle: 'Ich kann bei Kontoproblemen, Crush Codes, Sicherheit, Abrechnung, technischen Problemen und mehr helfen.',
    quickTopics: {
      codes: 'Crush Codes',
      safety: 'Sicherheit & Datenschutz',
      billing: 'Premium & Abrechnung',
      technical: 'Technische Hilfe'
    },
    commonQuestions: 'Häufige Fragen',
    billingTitle: 'Premium & Abrechnungs-Support',
    billingSubtitle: 'Ich kann bei Abonnements, Zahlungen, Rückerstattungen und Abrechnungsfragen helfen.',
    whatNeedHelp: 'Wobei brauchen Sie Hilfe?',
    billingActions: {
      subscription_status: 'Mein Abonnement prüfen',
      cancel: 'Abonnement kündigen',
      refund: 'Rückerstattung anfordern',
      payment_issue: 'Zahlungsproblem',
      receipt: 'Meine Quittung finden'
    },
    backToTopics: 'Zurück zu allen Themen',
    billingFAQs: 'Abrechnungs-FAQ',
    technicalTitle: 'Technischer Support',
    technicalSubtitle: 'Ich kann bei der Diagnose und Behebung häufiger App-Probleme helfen.',
    whatIssue: 'Welches Problem haben Sie?',
    technicalActions: {
      crash: 'App stürzt ab oder öffnet nicht',
      loading: 'Langsam oder lädt nicht',
      photos: 'Foto-Upload-Probleme',
      notifications: 'Erhalte keine Benachrichtigungen',
      video: 'Videoanruf-Probleme',
      map: 'Karte funktioniert nicht',
      login: 'Kann mich nicht anmelden',
      permissions: 'Berechtigungsprobleme'
    },
    technicalFAQs: 'Technische FAQ',
    thinking: 'Denke nach...',
    startNew: 'Neue Konversation starten',
    requestHuman: 'Menschliche Überprüfung anfordern',
    escalatedTitle: 'Problem zur Überprüfung Eskaliert',
    escalatedSubtitle: 'Unser Team wird dies überprüfen und Sie möglicherweise per E-Mail kontaktieren. Sie können weiter chatten oder dieses Fenster schließen.',
    addMoreDetails: 'Mehr Details hinzufügen...',
    describeIssue: 'Beschreiben Sie Ihr Problem...',
    premiumActive: 'Aktiv',
    premiumCancelled: 'Gekündigt',
    freeAccount: 'Kostenloses Konto',
    closeChat: 'Chat schließen',
    escalationBadges: {
      safety_harm: 'Dringende Sicherheitsüberprüfung',
      safety_harassment: 'Sicherheitsteam-Überprüfung',
      legal: 'Rechtliche Überprüfung',
      billing_dispute: 'Abrechnungsüberprüfung',
      technical_systemwide: 'Technische Überprüfung',
      user_requested: 'Menschliche Überprüfung Angefordert'
    }
  }
};

type SupportedLanguage = 'en' | 'es' | 'fr' | 'de';

const SupportChat: React.FC = () => {
  const { user } = useAuth();
  const { subscription, isPremium } = usePremium();
  const { language: appLanguage } = useI18n();
  
  // Normalize language to supported ones
  const language: SupportedLanguage = ['en', 'es', 'fr', 'de'].includes(appLanguage) 
    ? appLanguage as SupportedLanguage 
    : 'en';
  
  const text = UI_TEXT[language];
  
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');

  const [isLoading, setIsLoading] = useState(false);

  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [showFAQ, setShowFAQ] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showBillingActions, setShowBillingActions] = useState(false);
  const [showTechnicalActions, setShowTechnicalActions] = useState(false);
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo | null>(null);
  const [escalationState, setEscalationState] = useState<EscalationState>({
    isEscalated: false,
    type: '',
    priority: ''
  });

  // Cooldown ref: when SupportChat is closed by another modal (e.g. AuthModal),
  // block re-open via custom events for 1 second to prevent race conditions.
  const closeCooldownRef = useRef(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const QUICK_TOPICS = [
    { id: 'codes', label: text.quickTopics.codes, icon: HelpCircle },
    { id: 'safety', label: text.quickTopics.safety, icon: Shield },
    { id: 'billing', label: text.quickTopics.billing, icon: CreditCard },
    { id: 'technical', label: text.quickTopics.technical, icon: Wrench },
  ];

  const BILLING_QUICK_ACTIONS = [
    { id: 'subscription_status', label: text.billingActions.subscription_status, icon: Crown },
    { id: 'cancel', label: text.billingActions.cancel, icon: XCircle },
    { id: 'refund', label: text.billingActions.refund, icon: RefreshCw },
    { id: 'payment_issue', label: text.billingActions.payment_issue, icon: AlertCircle },
    { id: 'receipt', label: text.billingActions.receipt, icon: Receipt },
  ];

  const TECHNICAL_QUICK_ACTIONS = [
    { id: 'crash', label: text.technicalActions.crash, icon: AlertTriangle },
    { id: 'loading', label: text.technicalActions.loading, icon: Wifi },
    { id: 'photos', label: text.technicalActions.photos, icon: Image },
    { id: 'notifications', label: text.technicalActions.notifications, icon: Bell },
    { id: 'video', label: text.technicalActions.video, icon: Video },
    { id: 'map', label: text.technicalActions.map, icon: MapPin },
    { id: 'login', label: text.technicalActions.login, icon: LogIn },
    { id: 'permissions', label: text.technicalActions.permissions, icon: Settings },
  ];

  // =========================================================================
  // FULL CLOSE: resets every piece of internal state
  // No more body scroll lock — we use overflow:hidden on <html> instead
  // =========================================================================
  const handleFullClose = useCallback(() => {
    setIsOpen(false);
    setIsMinimized(false);
    setMessages([]);
    setInputValue('');
    setIsLoading(false);
    setShowFAQ(true);
    setSelectedCategory(null);
    setShowBillingActions(false);
    setShowTechnicalActions(false);
    setEscalationState({ isEscalated: false, type: '', priority: '' });
  }, []);

  // =========================================================================
  // Lightweight scroll prevention — no position:fixed on body (mobile-safe)
  // We only add overflow:hidden to <html> which is much less disruptive on
  // mobile Chrome/Safari than the old position:fixed approach.
  // =========================================================================
  useEffect(() => {
    const panelVisible = isOpen && !isMinimized;

    if (panelVisible) {
      document.documentElement.style.overflow = 'hidden';
    } else {
      document.documentElement.style.overflow = '';
    }

    return () => {
      document.documentElement.style.overflow = '';
    };
  }, [isOpen, isMinimized]);

  // =========================================================================
  // Listen for "requestCloseSupportChat" — fired by other modals (AuthModal,
  // ChatModal, ProfileEditor) when they open. Ensures only one modal is
  // interactive at a time. Sets a cooldown to prevent immediate re-open.
  // =========================================================================
  useEffect(() => {
    const handleCloseRequest = () => {
      if (isOpen) {
        handleFullClose();
      }
      // Set cooldown so openSupportChat events are ignored briefly
      closeCooldownRef.current = true;
      setTimeout(() => {
        closeCooldownRef.current = false;
      }, 1000);
    };

    window.addEventListener('requestCloseSupportChat', handleCloseRequest);
    return () => window.removeEventListener('requestCloseSupportChat', handleCloseRequest);
  }, [isOpen, handleFullClose]);

  // =========================================================================
  // Escape key closes the support chat
  // =========================================================================
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleFullClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, handleFullClose]);

  // Detect device info on mount
  useEffect(() => {
    const detectDeviceInfo = (): DeviceInfo => {
      const ua = navigator.userAgent;
      let platform = 'Unknown';
      let osVersion = 'Unknown';
      let browser = 'Unknown';
      
      if (/iPhone|iPad|iPod/.test(ua)) {
        platform = 'iOS';
        const match = ua.match(/OS (\d+[._]\d+)/);
        if (match) osVersion = match[1].replace('_', '.');
      } else if (/Android/.test(ua)) {
        platform = 'Android';
        const match = ua.match(/Android (\d+\.?\d*)/);
        if (match) osVersion = match[1];
      } else if (/Windows/.test(ua)) {
        platform = 'Windows';
        const match = ua.match(/Windows NT (\d+\.\d+)/);
        if (match) osVersion = match[1];
      } else if (/Mac OS X/.test(ua)) {
        platform = 'macOS';
        const match = ua.match(/Mac OS X (\d+[._]\d+)/);
        if (match) osVersion = match[1].replace('_', '.');
      } else if (/Linux/.test(ua)) {
        platform = 'Linux';
      }
      
      if (/Chrome/.test(ua) && !/Chromium|Edge/.test(ua)) {
        browser = 'Chrome';
      } else if (/Firefox/.test(ua)) {
        browser = 'Firefox';
      } else if (/Safari/.test(ua) && !/Chrome/.test(ua)) {
        browser = 'Safari';
      } else if (/Edge/.test(ua)) {
        browser = 'Edge';
      }
      
      const connection = (navigator as any).connection;
      const connectionType = connection?.effectiveType || 'Unknown';
      
      return {
        platform,
        osVersion,
        appVersion: '1.0.0',
        browser,
        connectionType
      };
    };
    
    setDeviceInfo(detectDeviceInfo());
  }, []);

  // Listen for custom event to open support chat
  // Respects cooldown to prevent re-open after another modal force-closed us
  useEffect(() => {
    const handleOpenSupport = (event?: CustomEvent) => {
      // Don't open if we're in cooldown (another modal just closed us)
      if (closeCooldownRef.current) return;

      setIsOpen(true);
      setIsMinimized(false);
      if (event?.detail?.category === 'billing') {
        setShowBillingActions(true);
        setShowTechnicalActions(false);
        setSelectedCategory('billing');
      } else if (event?.detail?.category === 'technical') {
        setShowTechnicalActions(true);
        setShowBillingActions(false);
        setSelectedCategory('technical');
      }
    };
    
    window.addEventListener('openSupportChat', handleOpenSupport as EventListener);
    return () => window.removeEventListener('openSupportChat', handleOpenSupport as EventListener);
  }, []);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Load FAQs when chat opens or language changes
  useEffect(() => {
    if (isOpen) {
      loadFAQs();
    }
  }, [isOpen, language]);

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen && !isMinimized) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen, isMinimized]);

  const loadFAQs = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('customer-support', {
        body: { action: 'get_faq', language }
      });
      if (data?.faqs) {
        setFaqs(data.faqs);
      }
    } catch (err) {
      console.error('Failed to load FAQs:', err);
    }
  };

  const getSubscriptionData = () => {
    if (!subscription) return null;
    return {
      status: subscription.status,
      plan: subscription.plan,
      startedAt: subscription.startedAt,
      expiresAt: subscription.expiresAt,
      cancelledAt: subscription.cancelledAt
    };
  };

  const sendMessage = async (messageText: string) => {
    if (!messageText.trim() || isLoading) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: messageText.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setShowFAQ(false);
    setShowBillingActions(false);
    setShowTechnicalActions(false);
    setIsLoading(true);

    try {
      const conversationHistory = messages.map(m => ({
        role: m.role,
        content: m.content
      }));

      const { data, error } = await supabase.functions.invoke('customer-support', {
        body: {
          action: 'chat',
          message: messageText.trim(),
          conversationHistory,
          category: selectedCategory,
          subscriptionData: getSubscriptionData(),
          deviceInfo: deviceInfo,
          language
        }
      });

      if (error) throw error;

      if (data.escalation?.triggered) {
        setEscalationState({
          isEscalated: true,
          type: data.escalation.type,
          priority: data.escalation.priority
        });
      }

      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.message,
        timestamp: new Date(data.timestamp),
        escalation: data.escalation,
        isEscalated: data.needsEscalation
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (err) {
      console.error('Support chat error:', err);
      const errorMessages: Record<SupportedLanguage, string> = {
        en: "I apologize, but I'm having trouble connecting right now. Please try again in a moment, or check our FAQ section for quick answers.",
        es: "Lo siento, pero tengo problemas para conectarme ahora. Por favor, inténtalo de nuevo en un momento, o revisa nuestra sección de preguntas frecuentes.",
        fr: "Je m'excuse, mais j'ai des difficultés à me connecter en ce moment. Veuillez réessayer dans un instant, ou consultez notre section FAQ.",
        de: "Es tut mir leid, aber ich habe gerade Verbindungsprobleme. Bitte versuchen Sie es in einem Moment erneut, oder schauen Sie in unsere FAQ-Sektion."
      };
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        role: 'assistant',
        content: errorMessages[language],
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(inputValue);
  };

  const handleQuickTopic = (topicId: string) => {
    setSelectedCategory(topicId);
    
    if (topicId === 'billing') {
      setShowBillingActions(true);
      setShowTechnicalActions(false);
      return;
    }
    
    if (topicId === 'technical') {
      setShowTechnicalActions(true);
      setShowBillingActions(false);
      return;
    }
    
    const topicMessages: Record<SupportedLanguage, Record<string, string>> = {
      en: {
        codes: "I have a question about Crush Codes",
        safety: "I need help with safety or privacy settings"
      },
      es: {
        codes: "Tengo una pregunta sobre los Crush Codes",
        safety: "Necesito ayuda con la configuración de seguridad o privacidad"
      },
      fr: {
        codes: "J'ai une question sur les Crush Codes",
        safety: "J'ai besoin d'aide avec les paramètres de sécurité ou de confidentialité"
      },
      de: {
        codes: "Ich habe eine Frage zu den Crush Codes",
        safety: "Ich brauche Hilfe mit den Sicherheits- oder Datenschutzeinstellungen"
      }
    };
    sendMessage(topicMessages[language][topicId] || topicMessages.en[topicId] || "I need help");
  };

  const handleBillingAction = (actionId: string) => {
    const billingMessages: Record<SupportedLanguage, Record<string, string>> = {
      en: {
        subscription_status: "What is the status of my Premium subscription? When does it renew?",
        cancel: "I want to cancel my Premium subscription. How do I do that?",
        refund: "I would like to request a refund for my Premium subscription. What are my options?",
        payment_issue: "I'm having a problem with my payment. My card was declined or I was charged incorrectly.",
        receipt: "Where can I find my receipt or invoice for my Premium subscription?"
      },
      es: {
        subscription_status: "¿Cuál es el estado de mi suscripción Premium? ¿Cuándo se renueva?",
        cancel: "Quiero cancelar mi suscripción Premium. ¿Cómo lo hago?",
        refund: "Me gustaría solicitar un reembolso por mi suscripción Premium. ¿Cuáles son mis opciones?",
        payment_issue: "Tengo un problema con mi pago. Mi tarjeta fue rechazada o me cobraron incorrectamente.",
        receipt: "¿Dónde puedo encontrar mi recibo o factura de mi suscripción Premium?"
      },
      fr: {
        subscription_status: "Quel est le statut de mon abonnement Premium ? Quand se renouvelle-t-il ?",
        cancel: "Je veux annuler mon abonnement Premium. Comment faire ?",
        refund: "Je voudrais demander un remboursement pour mon abonnement Premium. Quelles sont mes options ?",
        payment_issue: "J'ai un problème avec mon paiement. Ma carte a été refusée ou j'ai été facturé incorrectement.",
        receipt: "Où puis-je trouver mon reçu ou ma facture pour mon abonnement Premium ?"
      },
      de: {
        subscription_status: "Was ist der Status meines Premium-Abonnements? Wann wird es verlängert?",
        cancel: "Ich möchte mein Premium-Abonnement kündigen. Wie mache ich das?",
        refund: "Ich möchte eine Rückerstattung für mein Premium-Abonnement beantragen. Was sind meine Optionen?",
        payment_issue: "Ich habe ein Problem mit meiner Zahlung. Meine Karte wurde abgelehnt oder mir wurde falsch berechnet.",
        receipt: "Wo finde ich meine Quittung oder Rechnung für mein Premium-Abonnement?"
      }
    };
    sendMessage(billingMessages[language][actionId] || billingMessages.en[actionId] || "I have a billing question");
  };

  const handleTechnicalAction = (actionId: string) => {
    const technicalMessages: Record<SupportedLanguage, Record<string, string>> = {
      en: {
        crash: `I'm experiencing app crashes or the app won't open. My device: ${deviceInfo?.platform || 'Unknown'} ${deviceInfo?.osVersion || ''}`,
        loading: `The app is running slowly or content isn't loading properly. I'm using ${deviceInfo?.browser || 'the app'} on ${deviceInfo?.platform || 'my device'}. Connection: ${deviceInfo?.connectionType || 'Unknown'}`,
        photos: `I'm having trouble uploading photos. My device: ${deviceInfo?.platform || 'Unknown'}`,
        notifications: `I'm not receiving notifications. My device: ${deviceInfo?.platform || 'Unknown'} ${deviceInfo?.osVersion || ''}`,
        video: `Video calls aren't working properly. I'm using ${deviceInfo?.browser || 'the app'} on ${deviceInfo?.platform || 'my device'}`,
        map: `The map feature isn't loading or working correctly. My device: ${deviceInfo?.platform || 'Unknown'}`,
        login: `I can't log in to my account. I'm trying on ${deviceInfo?.platform || 'my device'} using ${deviceInfo?.browser || 'the app'}`,
        permissions: `I'm having issues with app permissions (camera, location, notifications). My device: ${deviceInfo?.platform || 'Unknown'} ${deviceInfo?.osVersion || ''}`
      },
      es: {
        crash: `La app se cierra o no abre. Mi dispositivo: ${deviceInfo?.platform || 'Desconocido'} ${deviceInfo?.osVersion || ''}`,
        loading: `La app está lenta o el contenido no carga correctamente. Estoy usando ${deviceInfo?.browser || 'la app'} en ${deviceInfo?.platform || 'mi dispositivo'}. Conexión: ${deviceInfo?.connectionType || 'Desconocida'}`,
        photos: `Tengo problemas para subir fotos. Mi dispositivo: ${deviceInfo?.platform || 'Desconocido'}`,
        notifications: `No recibo notificaciones. Mi dispositivo: ${deviceInfo?.platform || 'Desconocido'} ${deviceInfo?.osVersion || ''}`,
        video: `Las videollamadas no funcionan correctamente. Estoy usando ${deviceInfo?.browser || 'la app'} en ${deviceInfo?.platform || 'mi dispositivo'}`,
        map: `El mapa no carga o no funciona correctamente. Mi dispositivo: ${deviceInfo?.platform || 'Desconocido'}`,
        login: `No puedo iniciar sesión en mi cuenta. Estoy intentando en ${deviceInfo?.platform || 'mi dispositivo'} usando ${deviceInfo?.browser || 'la app'}`,
        permissions: `Tengo problemas con los permisos de la app (cámara, ubicación, notificaciones). Mi dispositivo: ${deviceInfo?.platform || 'Desconocido'} ${deviceInfo?.osVersion || ''}`
      },
      fr: {
        crash: `L'app plante ou ne s'ouvre pas. Mon appareil: ${deviceInfo?.platform || 'Inconnu'} ${deviceInfo?.osVersion || ''}`,
        loading: `L'app est lente ou le contenu ne charge pas correctement. J'utilise ${deviceInfo?.browser || "l'app"} sur ${deviceInfo?.platform || 'mon appareil'}. Connexion: ${deviceInfo?.connectionType || 'Inconnue'}`,
        photos: `J'ai des problèmes pour télécharger des photos. Mon appareil: ${deviceInfo?.platform || 'Inconnu'}`,
        notifications: `Je ne reçois pas de notifications. Mon appareil: ${deviceInfo?.platform || 'Inconnu'} ${deviceInfo?.osVersion || ''}`,
        video: `Les appels vidéo ne fonctionnent pas correctement. J'utilise ${deviceInfo?.browser || "l'app"} sur ${deviceInfo?.platform || 'mon appareil'}`,
        map: `La carte ne charge pas ou ne fonctionne pas correctement. Mon appareil: ${deviceInfo?.platform || 'Inconnu'}`,
        login: `Je ne peux pas me connecter à mon compte. J'essaie sur ${deviceInfo?.platform || 'mon appareil'} avec ${deviceInfo?.browser || "l'app"}`,
        permissions: `J'ai des problèmes avec les permissions de l'app (caméra, localisation, notifications). Mon appareil: ${deviceInfo?.platform || 'Inconnu'} ${deviceInfo?.osVersion || ''}`
      },
      de: {
        crash: `Die App stürzt ab oder öffnet nicht. Mein Gerät: ${deviceInfo?.platform || 'Unbekannt'} ${deviceInfo?.osVersion || ''}`,
        loading: `Die App ist langsam oder Inhalte laden nicht richtig. Ich verwende ${deviceInfo?.browser || 'die App'} auf ${deviceInfo?.platform || 'meinem Gerät'}. Verbindung: ${deviceInfo?.connectionType || 'Unbekannt'}`,
        photos: `Ich habe Probleme beim Hochladen von Fotos. Mein Gerät: ${deviceInfo?.platform || 'Unbekannt'}`,
        notifications: `Ich erhalte keine Benachrichtigungen. Mein Gerät: ${deviceInfo?.platform || 'Unbekannt'} ${deviceInfo?.osVersion || ''}`,
        video: `Videoanrufe funktionieren nicht richtig. Ich verwende ${deviceInfo?.browser || 'die App'} auf ${deviceInfo?.platform || 'meinem Gerät'}`,
        map: `Die Karte lädt nicht oder funktioniert nicht richtig. Mein Gerät: ${deviceInfo?.platform || 'Unbekannt'}`,
        login: `Ich kann mich nicht in mein Konto einloggen. Ich versuche es auf ${deviceInfo?.platform || 'meinem Gerät'} mit ${deviceInfo?.browser || 'der App'}`,
        permissions: `Ich habe Probleme mit App-Berechtigungen (Kamera, Standort, Benachrichtigungen). Mein Gerät: ${deviceInfo?.platform || 'Unbekannt'} ${deviceInfo?.osVersion || ''}`
      }
    };
    sendMessage(technicalMessages[language][actionId] || technicalMessages.en[actionId] || "I'm experiencing a technical issue");
  };

  const handleFAQClick = (question: string, answer: string) => {
    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: question,
      timestamp: new Date()
    };
    const assistantMsg: Message = {
      id: `assistant-${Date.now() + 1}`,
      role: 'assistant',
      content: answer,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, userMsg, assistantMsg]);
    setShowFAQ(false);
    setShowBillingActions(false);
    setShowTechnicalActions(false);
  };

  const resetChat = () => {
    setMessages([]);
    setShowFAQ(true);
    setShowBillingActions(false);
    setShowTechnicalActions(false);
    setSelectedCategory(null);
    setEscalationState({ isEscalated: false, type: '', priority: '' });
  };

  const goBackToTopics = () => {
    setShowBillingActions(false);
    setShowTechnicalActions(false);
    setSelectedCategory(null);
  };

  const requestHumanEscalation = async (escalationType?: string) => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('customer-support', {
        body: {
          action: 'escalate',
          reason: 'User requested human review',
          issueType: escalationType || selectedCategory || 'user_requested',
          conversationSummary: messages.map(m => `${m.role}: ${m.content}`).join('\n'),
          userId: user?.id,
          priority: escalationType === 'safety_harm' ? 'critical' : 'medium',
          language
        }
      });

      if (error) throw error;

      setEscalationState({
        isEscalated: true,
        type: escalationType || 'user_requested',
        priority: data.escalationDetails?.priority || 'medium'
      });

      const escalationMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.message,
        timestamp: new Date(),
        isEscalated: true
      };

      setMessages(prev => [...prev, escalationMessage]);
    } catch (err) {
      console.error('Escalation error:', err);
      const errorMessages: Record<SupportedLanguage, string> = {
        en: "I apologize, but I couldn't process the escalation request. Please try again or email support@dwadido.com directly.",
        es: "Lo siento, pero no pude procesar la solicitud de escalación. Por favor, inténtalo de nuevo o envía un email a support@dwadido.com directamente.",
        fr: "Je m'excuse, mais je n'ai pas pu traiter la demande d'escalade. Veuillez réessayer ou envoyer un email à support@dwadido.com directement.",
        de: "Es tut mir leid, aber ich konnte die Eskalationsanfrage nicht verarbeiten. Bitte versuchen Sie es erneut oder senden Sie eine E-Mail an support@dwadido.com."
      };
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        role: 'assistant',
        content: errorMessages[language],
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const formatMessageContent = (content: string) => {
    return content
      .split('\n')
      .map((line, i) => {
        if (line.trim().startsWith('- ') || line.trim().startsWith('• ')) {
          return (
            <li key={i} className="ml-4 list-disc">
              {line.replace(/^[-•]\s*/, '')}
            </li>
          );
        }
        if (/^\d+\.\s/.test(line.trim())) {
          return (
            <li key={i} className="ml-4 list-decimal">
              {line.replace(/^\d+\.\s*/, '')}
            </li>
          );
        }
        if (line.includes('**')) {
          const parts = line.split(/\*\*(.*?)\*\*/g);
          return (
            <p key={i} className="mb-2 last:mb-0">
              {parts.map((part, j) => 
                j % 2 === 1 ? <strong key={j}>{part}</strong> : part
              )}
            </p>
          );
        }
        return line ? <p key={i} className="mb-2 last:mb-0">{line}</p> : null;
      })
      .filter(Boolean);
  };

  const getEscalationBadge = (type: string, priority: string) => {
    const badges: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
      safety_harm: { 
        label: text.escalationBadges.safety_harm, 
        color: 'bg-red-500/20 text-red-300 border-red-500/30',
        icon: <AlertTriangle className="w-3 h-3" />
      },
      safety_harassment: { 
        label: text.escalationBadges.safety_harassment, 
        color: 'bg-orange-500/20 text-orange-300 border-orange-500/30',
        icon: <Shield className="w-3 h-3" />
      },
      legal: { 
        label: text.escalationBadges.legal, 
        color: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
        icon: <ExternalLink className="w-3 h-3" />
      },
      billing_dispute: { 
        label: text.escalationBadges.billing_dispute, 
        color: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
        icon: <CreditCard className="w-3 h-3" />
      },
      technical_systemwide: { 
        label: text.escalationBadges.technical_systemwide, 
        color: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
        icon: <Wrench className="w-3 h-3" />
      },
      user_requested: { 
        label: text.escalationBadges.user_requested, 
        color: 'bg-green-500/20 text-green-300 border-green-500/30',
        icon: <UserCheck className="w-3 h-3" />
      }
    };
    
    return badges[type] || badges.user_requested;
  };

  // =========================================================================
  // RENDER: Closed state — floating button
  // z-40 so it sits BELOW AuthModal (z-50) and other critical modals
  // =========================================================================
  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-gold hover:bg-gold-400 text-charcoal rounded-full shadow-lg hover:shadow-xl transition-all flex items-center justify-center group"
        aria-label="Open support chat"
      >
        <MessageCircle className="w-6 h-6" />
        <span className="absolute right-full mr-3 px-3 py-1.5 bg-charcoal-700 text-white text-sm rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap border border-charcoal-600 pointer-events-none">
          {text.needHelp}
        </span>
      </button>
    );
  }

  // =========================================================================
  // RENDER: Minimized state — small bar (no backdrop, no scroll lock)
  // z-40 to stay below AuthModal
  // =========================================================================
  if (isMinimized) {
    return (
      <div className="fixed bottom-6 right-6 z-40">
        <button
          onClick={() => setIsMinimized(false)}
          className="flex items-center gap-3 px-4 py-3 bg-charcoal-700 hover:bg-charcoal-600 text-white rounded-xl shadow-lg border border-charcoal-600 transition-all"
        >
          <div className="w-8 h-8 bg-gold/20 rounded-full flex items-center justify-center">
            <Bot className="w-4 h-4 text-gold" />
          </div>
          <span className="font-medium">{text.supportChat}</span>
          {escalationState.isEscalated && (
            <span className="w-2 h-2 bg-green-500 rounded-full" />
          )}
          <Maximize2 className="w-4 h-4 text-gray-400" />
        </button>
      </div>
    );
  }

  // =========================================================================
  // RENDER: Open state — panel with backdrop overlay
  //
  // MOBILE FIX (launch blocker):
  //   • z-[45] backdrop + z-[46] panel — BELOW AuthModal (z-50)
  //   • max-h-[75vh] on mobile so it never covers the full screen
  //   • Large 44×44px close (X) button in header — always visible
  //   • Extra "Close chat" button at the very bottom of the panel
  //   • No position:fixed body scroll lock (uses overflow:hidden on <html>)
  //   • On mobile: full-width with small margin (inset-x-3 bottom-3)
  //   • On desktop: fixed width positioned bottom-right
  // =========================================================================
  return (
    <>
      {/* Backdrop overlay — click/tap to close */}
      <div
        className="fixed inset-0 z-[45] bg-black/40 backdrop-blur-[2px]"
        onClick={handleFullClose}
        aria-hidden="true"
      />

      {/* Chat panel */}
      <div
        className="
          fixed z-[46] bg-charcoal-800 rounded-2xl shadow-2xl border border-charcoal-600 flex flex-col overflow-hidden
          inset-x-3 bottom-3 max-h-[75vh]
          sm:inset-x-auto sm:bottom-6 sm:right-6 sm:w-96 sm:max-w-[calc(100vw-3rem)] sm:max-h-[calc(100vh-6rem)]
        "
        role="dialog"
        aria-modal="true"
        aria-label="Support Chat"
      >
        {/* Header — sticky with large, always-visible close button */}
        <div className="flex items-center justify-between px-4 py-3 bg-charcoal-700 border-b border-charcoal-600 flex-shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 bg-gold/20 rounded-full flex items-center justify-center flex-shrink-0">
              <Bot className="w-5 h-5 text-gold" />
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-white text-sm truncate">Dwadido Support</h3>
              <div className="flex items-center gap-1.5">
                <p className="text-xs text-gray-400">{text.aiAssistant}</p>
                <Globe className="w-3 h-3 text-gray-500" />
                <span className="text-xs text-gray-500 uppercase">{language}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            <button
              onClick={() => setIsMinimized(true)}
              className="p-2 text-gray-400 hover:text-white hover:bg-charcoal-600 rounded-lg transition-colors"
              aria-label="Minimize"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
            {/* LARGE close button — 44×44px minimum tap target for mobile */}
            <button
              onClick={handleFullClose}
              className="w-11 h-11 flex items-center justify-center text-gray-300 hover:text-white hover:bg-red-500/20 rounded-xl transition-colors border border-transparent hover:border-red-500/30"
              aria-label="Close support chat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* AI Disclosure Banner */}
        <div className="px-4 py-2 bg-blue-500/10 border-b border-blue-500/20 flex-shrink-0">
          <p className="text-xs text-blue-300 flex items-center gap-2">
            <Bot className="w-3 h-3 flex-shrink-0" />
            {text.aiDisclosure}
          </p>
        </div>

        {/* Escalation Status Banner */}
        {escalationState.isEscalated && (
          <div className={`px-4 py-2 border-b flex-shrink-0 ${getEscalationBadge(escalationState.type, escalationState.priority).color}`}>
            <div className="flex items-center gap-2">
              {getEscalationBadge(escalationState.type, escalationState.priority).icon}
              <span className="text-xs font-medium">
                {getEscalationBadge(escalationState.type, escalationState.priority).label}
              </span>
              <span className="text-xs opacity-75">• {text.teamWillReview}</span>
            </div>
          </div>
        )}

        {/* Context Banner (Billing or Technical) */}
        {(selectedCategory === 'billing' || selectedCategory === 'technical') && messages.length === 0 && !escalationState.isEscalated && (
          <div className={`px-4 py-2 border-b flex-shrink-0 ${
            selectedCategory === 'billing' 
              ? (isPremium ? 'bg-gold/10 border-gold/20' : 'bg-charcoal-700 border-charcoal-600')
              : 'bg-purple-500/10 border-purple-500/20'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {selectedCategory === 'billing' ? (
                  <>
                    <Crown className={`w-4 h-4 ${isPremium ? 'text-gold' : 'text-gray-500'}`} />
                    <span className={`text-xs ${isPremium ? 'text-gold' : 'text-gray-400'}`}>
                      {isPremium 
                        ? `Premium ${subscription?.plan || ''} • ${subscription?.status === 'cancelled' ? text.premiumCancelled : text.premiumActive}`
                        : text.freeAccount
                      }
                    </span>
                  </>
                ) : (
                  <>
                    <Smartphone className="w-4 h-4 text-purple-400" />
                    <span className="text-xs text-purple-300">
                      {deviceInfo?.platform || 'Unknown'} {deviceInfo?.osVersion || ''} • {deviceInfo?.browser || 'App'}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-0">
          {messages.length === 0 && showFAQ && !showBillingActions && !showTechnicalActions ? (
            <>
              {/* Welcome Message */}
              <div className="text-center py-4">
                <div className="w-16 h-16 mx-auto mb-3 bg-gold/20 rounded-full flex items-center justify-center">
                  <Bot className="w-8 h-8 text-gold" />
                </div>
                <h4 className="font-semibold text-white mb-1">{text.welcomeTitle}</h4>
                <p className="text-sm text-gray-400">
                  {text.welcomeSubtitle}
                </p>
              </div>

              {/* Quick Topics */}
              <div className="grid grid-cols-2 gap-2">
                {QUICK_TOPICS.map(topic => (
                  <button
                    key={topic.id}
                    onClick={() => handleQuickTopic(topic.id)}
                    className="flex items-center gap-2 p-3 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl text-left transition-colors border border-charcoal-600"
                  >
                    <topic.icon className="w-4 h-4 text-gold" />
                    <span className="text-sm text-gray-300">{topic.label}</span>
                  </button>
                ))}
              </div>

              {/* FAQ Section */}
              {faqs.length > 0 && (
                <div className="mt-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">{text.commonQuestions}</p>
                  <div className="space-y-2">
                    {faqs.slice(0, 2).map(category => (
                      <div key={category.category}>
                        {category.questions.slice(0, 2).map((faq, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleFAQClick(faq.q, faq.a)}
                            className="w-full text-left p-2 text-sm text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-lg transition-colors"
                          >
                            {faq.q}
                          </button>
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : messages.length === 0 && showBillingActions ? (
            <>
              {/* Billing Actions */}
              <div className="text-center py-4">
                <div className="w-16 h-16 mx-auto mb-3 bg-gold/20 rounded-full flex items-center justify-center">
                  <CreditCard className="w-8 h-8 text-gold" />
                </div>
                <h4 className="font-semibold text-white mb-1">{text.billingTitle}</h4>
                <p className="text-sm text-gray-400">
                  {text.billingSubtitle}
                </p>
              </div>

              {/* Billing Quick Actions */}
              <div className="space-y-2">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">{text.whatNeedHelp}</p>
                {BILLING_QUICK_ACTIONS.map(action => (
                  <button
                    key={action.id}
                    onClick={() => handleBillingAction(action.id)}
                    className="w-full flex items-center gap-3 p-3 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl text-left transition-colors border border-charcoal-600"
                  >
                    <action.icon className="w-5 h-5 text-gold flex-shrink-0" />
                    <span className="text-sm text-gray-300">{action.label}</span>
                  </button>
                ))}
              </div>

              {/* Back button */}
              <button
                onClick={goBackToTopics}
                className="w-full mt-2 py-2 text-xs text-gray-500 hover:text-gray-300 transition-colors flex items-center justify-center gap-1"
              >
                <ArrowLeft className="w-3 h-3" />
                {text.backToTopics}
              </button>

              {/* Billing FAQs */}
              {faqs.length > 0 && (
                <div className="mt-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">{text.billingFAQs}</p>
                  <div className="space-y-1">
                    {faqs
                      .find(f => f.category === 'Premium & Billing' || f.category === 'Premium y Facturación' || f.category === 'Premium et Facturation' || f.category === 'Premium und Abrechnung')
                      ?.questions.map((faq, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleFAQClick(faq.q, faq.a)}
                          className="w-full text-left p-2 text-sm text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-lg transition-colors"
                        >
                          {faq.q}
                        </button>
                      ))}
                  </div>
                </div>
              )}
            </>
          ) : messages.length === 0 && showTechnicalActions ? (
            <>
              {/* Technical Actions */}
              <div className="text-center py-4">
                <div className="w-16 h-16 mx-auto mb-3 bg-purple-500/20 rounded-full flex items-center justify-center">
                  <Wrench className="w-8 h-8 text-purple-400" />
                </div>
                <h4 className="font-semibold text-white mb-1">{text.technicalTitle}</h4>
                <p className="text-sm text-gray-400">
                  {text.technicalSubtitle}
                </p>
              </div>

              {/* Technical Quick Actions */}
              <div className="space-y-2">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">{text.whatIssue}</p>
                <div className="grid grid-cols-2 gap-2">
                  {TECHNICAL_QUICK_ACTIONS.map(action => (
                    <button
                      key={action.id}
                      onClick={() => handleTechnicalAction(action.id)}
                      className="flex items-center gap-2 p-3 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl text-left transition-colors border border-charcoal-600"
                    >
                      <action.icon className="w-4 h-4 text-purple-400 flex-shrink-0" />
                      <span className="text-xs text-gray-300">{action.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Back button */}
              <button
                onClick={goBackToTopics}
                className="w-full mt-2 py-2 text-xs text-gray-500 hover:text-gray-300 transition-colors flex items-center justify-center gap-1"
              >
                <ArrowLeft className="w-3 h-3" />
                {text.backToTopics}
              </button>

              {/* Technical FAQs */}
              {faqs.length > 0 && (
                <div className="mt-4">
                  <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">{text.technicalFAQs}</p>
                  <div className="space-y-1">
                    {faqs
                      .find(f => f.category === 'Technical Help' || f.category === 'Ayuda Técnica' || f.category === 'Aide Technique' || f.category === 'Technische Hilfe')
                      ?.questions.slice(0, 4).map((faq, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleFAQClick(faq.q, faq.a)}
                          className="w-full text-left p-2 text-sm text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-lg transition-colors"
                        >
                          {faq.q}
                        </button>
                      ))}
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              {/* Chat Messages */}
              {messages.map(message => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.role === 'user' 
                      ? 'bg-gold/20' 
                      : message.isEscalated 
                        ? 'bg-green-500/20'
                        : 'bg-charcoal-600'
                  }`}>
                    {message.role === 'user' ? (
                      <User className="w-4 h-4 text-gold" />
                    ) : message.isEscalated ? (
                      <UserCheck className="w-4 h-4 text-green-400" />
                    ) : (
                      <Bot className="w-4 h-4 text-gray-400" />
                    )}
                  </div>
                  <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 ${
                    message.role === 'user'
                      ? 'bg-gold text-charcoal rounded-br-md'
                      : message.isEscalated
                        ? 'bg-green-500/10 text-gray-200 rounded-bl-md border border-green-500/20'
                        : 'bg-charcoal-700 text-gray-200 rounded-bl-md'
                  }`}>
                    {/* Escalation badge on message */}
                    {message.escalation?.triggered && (
                      <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs mb-2 ${getEscalationBadge(message.escalation.type, message.escalation.priority).color}`}>
                        {getEscalationBadge(message.escalation.type, message.escalation.priority).icon}
                        <span>{getEscalationBadge(message.escalation.type, message.escalation.priority).label}</span>
                      </div>
                    )}
                    <div className="text-sm leading-relaxed">
                      {formatMessageContent(message.content)}
                    </div>
                    <p className={`text-xs mt-1 ${
                      message.role === 'user' ? 'text-charcoal/60' : 'text-gray-500'
                    }`}>
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}

              {/* Loading indicator */}
              {isLoading && (
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-charcoal-600 flex items-center justify-center">
                    <Bot className="w-4 h-4 text-gray-400" />
                  </div>
                  <div className="bg-charcoal-700 rounded-2xl rounded-bl-md px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 text-gold animate-spin" />
                      <span className="text-sm text-gray-400">{text.thinking}</span>
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        {/* Action Buttons (when there are messages) */}
        {messages.length > 0 && (
          <div className="px-4 pb-2 flex gap-2 flex-shrink-0">
            <button
              onClick={resetChat}
              className="flex-1 py-2 text-xs text-gray-500 hover:text-gray-300 transition-colors"
            >
              {text.startNew}
            </button>
            {!escalationState.isEscalated && (
              <button
                onClick={() => requestHumanEscalation()}
                disabled={isLoading}
                className="flex-1 py-2 text-xs text-blue-400 hover:text-blue-300 transition-colors disabled:opacity-50 flex items-center justify-center gap-1"
              >
                <UserCheck className="w-3 h-3" />
                {text.requestHuman}
              </button>
            )}
          </div>
        )}

        {/* Escalation Confirmation (when escalated) */}
        {escalationState.isEscalated && messages.length > 0 && (
          <div className="px-4 pb-2 flex-shrink-0">
            <div className="p-3 bg-green-500/10 rounded-lg border border-green-500/20">
              <div className="flex items-start gap-2">
                <UserCheck className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-xs text-green-300 font-medium">{text.escalatedTitle}</p>
                  <p className="text-xs text-gray-400 mt-1">
                    {text.escalatedSubtitle}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Input Area */}
        <form onSubmit={handleSubmit} className="p-4 border-t border-charcoal-600 flex-shrink-0">
          <div className="flex gap-2">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder={escalationState.isEscalated ? text.addMoreDetails : text.describeIssue}
              className="flex-1 px-4 py-2.5 bg-charcoal-700 border border-charcoal-600 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-gold/50 focus:border-gold/50 text-sm"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={!inputValue.trim() || isLoading}
              className="px-4 py-2.5 bg-gold hover:bg-gold-400 text-charcoal rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </form>

        {/* ================================================================
            MOBILE CLOSE BUTTON — always visible at the very bottom
            Large, prominent, impossible to miss on any screen size.
            Only shown on small screens (sm:hidden) since desktop has
            the header X button easily accessible.
            ================================================================ */}
        <div className="sm:hidden border-t border-charcoal-600 flex-shrink-0">
          <button
            onClick={handleFullClose}
            className="w-full flex items-center justify-center gap-2 py-3.5 text-sm font-medium text-gray-300 hover:text-white hover:bg-charcoal-700 active:bg-charcoal-600 transition-colors"
          >
            <X className="w-4 h-4" />
            {text.closeChat}
          </button>
        </div>
      </div>
    </>
  );
};

export default SupportChat;
