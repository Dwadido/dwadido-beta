import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth, IntentType, RelationshipStatusType, INTENT_LABELS, RELATIONSHIP_STATUS_LABELS } from '@/contexts/AuthContext';
import { usePremium } from '@/contexts/PremiumContext';
import { useSupportChatVisibility } from '@/contexts/SupportChatContext';

import { X, Send, User, Loader2, Check, CheckCheck, AlertTriangle, Shield, Flag, ShieldOff, MoreVertical, Heart, Users, ChevronDown, ChevronUp, MessageSquareOff, ThumbsUp, ThumbsDown, Video, Lock, Unlock, RefreshCw, Calendar, MapPin } from 'lucide-react';




import ReportUserModal from '../safety/ReportUserModal';
import BlockUserModal from '../safety/BlockUserModal';

import VideoCallModal from '../chat/VideoCallModal';





import PremiumFeatureModal from '../premium/PremiumFeatureModal';
import { calculateAge } from './MatchFilters';
import {
  fetchRestrictionState,
  removeMyRestriction,
  type RestrictionState,
} from '@/lib/contactRestriction';

import {
  sendChatMessage,
  validateMessageContent,
  validatePastedContent,
} from '@/lib/messageSender';


interface Message {
  id: string;
  sender_id: string;
  content: string;
  created_at: string;
  read_at: string | null;
  _optimistic?: boolean; // Client-side flag for optimistic messages
  _failed?: boolean;     // Client-side flag for failed messages (timeout or error)
  _originalText?: string; // Original text for retry
}



interface VideoCall {
  id: string;
  status: 'pending' | 'accepted' | 'declined' | 'active' | 'ended' | 'expired';
  initiator_id: string;
  recipient_id: string;
  duration_minutes: number;
}

interface ChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  matchId: string;
  otherUser: {
    id: string;
    display_name: string | null;
    avatar_url: string | null;
    intent?: IntentType | null;
    relationship_status?: RelationshipStatusType | null;
    photo_visibility?: 'private' | 'matches_only' | 'approved_only';

    date_of_birth?: string | null;
  };
  onChatEnded?: (matchId: string, feedback?: 'positive' | 'negative' | 'neutral') => void;
}

const ChatModal: React.FC<ChatModalProps> = ({ isOpen, onClose, matchId, otherUser, onChatEnded }) => {


  const { user, profile } = useAuth();
  const { canUseFeature } = usePremium();

  const { hide: hideSupportChat, show: showSupportChat } = useSupportChatVisibility();



  // Calculate age from date of birth
  const age = calculateAge(otherUser.date_of_birth);

  const [messages, setMessages] = useState<Message[]>([]);

  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [showIntentDetails, setShowIntentDetails] = useState(false);
  const [showEndChatConfirm, setShowEndChatConfirm] = useState(false);
  const [showFeedbackPrompt, setShowFeedbackPrompt] = useState(false);
  const [endingChat, setEndingChat] = useState(false);
  const [endChatError, setEndChatError] = useState<string | null>(null);


  // Video call state
  const [activeVideoCall, setActiveVideoCall] = useState<VideoCall | null>(null);
  const [showVideoCall, setShowVideoCall] = useState(false);
  const [initiatingCall, setInitiatingCall] = useState(false);
  const [showCallDurationPicker, setShowCallDurationPicker] = useState(false);
  const [selectedDuration, setSelectedDuration] = useState(5);
  const [showPremiumModal, setShowPremiumModal] = useState(false);




  // Photo permission state
  const [canViewPhotos, setCanViewPhotos] = useState(false);
  const [primaryPhoto, setPrimaryPhoto] = useState<string | null>(null);
  const [loadingPhoto, setLoadingPhoto] = useState(true);
  



  // ── Contact Restriction State (two-key mutual consent) ──
  const [restrictionState, setRestrictionState] = useState<RestrictionState>({
    myRestrictionRemoved: false,
    theirRestrictionRemoved: false,
    fullyUnlocked: false,
  });
  const [restrictionLoading, setRestrictionLoading] = useState(true);
  const [showRemoveRestrictionConfirm, setShowRemoveRestrictionConfirm] = useState(false);
  const [removingRestriction, setRemovingRestriction] = useState(false);
  const [blockedMessageError, setBlockedMessageError] = useState<string | null>(null);
  // DB trigger error code for debugging (e.g., CONTACT_RESTRICTION_BLOCKED_PHONE)
  const [lastTriggerErrorCode, setLastTriggerErrorCode] = useState<string | null>(null);
  // Real-time input validation warning (shown as user types)
  const [inputRestrictionWarning, setInputRestrictionWarning] = useState<string | null>(null);

  const [matchConnectionDate, setMatchConnectionDate] = useState<string | null>(null);
  const [sharedInterests, setSharedInterests] = useState<string[]>([]);


  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  // Track message IDs we've seen to prevent duplicates from realtime
  const seenMessageIdsRef = useRef<Set<string>>(new Set());
  // Counter for optimistic message temp IDs
  const optimisticCounterRef = useRef(0);




  // Whether the restriction is currently active (blocking personal info)
  const isRestrictionActive = !restrictionState.fullyUnlocked;





  // =========================================================================
  // SUPPORT CHAT UNMOUNT: Context-based conditional unmount (replaces events)
  // =========================================================================
  // When ChatModal opens, SupportChat is FULLY UNMOUNTED from the React tree
  // via SupportChatContext. This guarantees zero DOM presence — no floating
  // button, no z-index stacking, no ghost touch targets on iOS Safari.
  //
  // Previous approach used CustomEvents (requestHideSupportChat) which were
  // fragile on iOS Safari due to mount-order race conditions.
  // =========================================================================
  useEffect(() => {
    if (isOpen) {
      hideSupportChat();
      // Also fire the legacy event for backward compat (AuthModal, ProfileEditor)
      window.dispatchEvent(new CustomEvent('requestCloseSupportChat'));
    }
    return () => {
      // Re-mount SupportChat when ChatModal unmounts or closes
      showSupportChat();
    };
  }, [isOpen, hideSupportChat, showSupportChat]);

  // Handle body scroll lock for iOS
  useEffect(() => {
    if (isOpen) {
      const scrollY = window.scrollY;
      document.body.style.position = 'fixed';
      document.body.style.top = `-${scrollY}px`;
      document.body.style.width = '100%';
    } else {
      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);
    }

    return () => {
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
    };
  }, [isOpen]);





  // ── Reliable scroll-to-bottom ──
  // Uses requestAnimationFrame to ensure DOM has updated before scrolling
  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    requestAnimationFrame(() => {
      messagesEndRef.current?.scrollIntoView({ behavior });
    });
  }, []);

  // ── Fetch messages + subscribe to realtime ──
  useEffect(() => {
    if (!isOpen || !matchId) return;

    // Reset seen IDs when chat opens
    seenMessageIdsRef.current.clear();

    const fetchMessages = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('match_id', matchId)
        .order('created_at', { ascending: true });

      if (!error && data) {
        // Build seen-IDs set from fetched messages
        const ids = new Set<string>();
        data.forEach(m => ids.add(m.id));
        seenMessageIdsRef.current = ids;

        setMessages(data);

        const unreadIds = data
          .filter(m => m.sender_id !== user?.id && !m.read_at)
          .map(m => m.id);
        
        if (unreadIds.length > 0) {
          await supabase
            .from('messages')
            .update({ read_at: new Date().toISOString() })
            .in('id', unreadIds);
        }
      } else if (error) {
        console.error('[ChatModal] Failed to fetch messages:', error);
      }
      setLoading(false);
      // Scroll to bottom after initial load (instant, no animation)
      setTimeout(() => scrollToBottom('auto'), 100);
    };


    fetchMessages();
    checkForActiveCall();

    // ── Realtime subscription with deduplication ──
    const channel = supabase
      .channel(`messages:${matchId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `match_id=eq.${matchId}`
        },
        (payload) => {
          const newMsg = payload.new as Message;
          
          // ── DEDUPLICATION ──
          // Skip if we've already seen this message ID (from optimistic insert or prior fetch)
          if (seenMessageIdsRef.current.has(newMsg.id)) {
            console.log('[ChatModal] Realtime: skipping duplicate message', newMsg.id);
            // But DO replace the optimistic version with the real one (to get real ID, timestamps, etc.)
            setMessages(prev => {
              // Find and replace any optimistic message that matches this content + sender
              const optimisticIndex = prev.findIndex(
                m => m._optimistic && m.sender_id === newMsg.sender_id && m.content === newMsg.content
              );
              if (optimisticIndex >= 0) {
                const updated = [...prev];
                updated[optimisticIndex] = { ...newMsg, _optimistic: false };
                return updated;
              }
              return prev;
            });
            return;
          }

          // Mark as seen
          seenMessageIdsRef.current.add(newMsg.id);

          setMessages(prev => {
            // Check if there's an optimistic message to replace
            const optimisticIndex = prev.findIndex(
              m => m._optimistic && m.sender_id === newMsg.sender_id && m.content === newMsg.content
            );

            if (optimisticIndex >= 0) {
              // Replace optimistic message with real one
              console.log('[ChatModal] Realtime: replacing optimistic message with real one', newMsg.id);
              const updated = [...prev];
              updated[optimisticIndex] = { ...newMsg, _optimistic: false };
              return updated;
            }

            // Check if message already exists by ID (safety net)
            if (prev.some(m => m.id === newMsg.id)) {
              console.log('[ChatModal] Realtime: message already in state', newMsg.id);
              return prev;
            }

            // New message from other user (or our own if optimistic failed)
            console.log('[ChatModal] Realtime: adding new message', newMsg.id);
            return [...prev, newMsg];
          });
          
          // Mark as read if from other user
          if (newMsg.sender_id !== user?.id) {
            supabase
              .from('messages')
              .update({ read_at: new Date().toISOString() })
              .eq('id', newMsg.id);
          }

          // Scroll to bottom for new messages
          scrollToBottom();
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'messages',
          filter: `match_id=eq.${matchId}`
        },
        (payload) => {
          // Update read receipts in real-time
          const updatedMsg = payload.new as Message;
          setMessages(prev =>
            prev.map(m => m.id === updatedMsg.id ? { ...m, read_at: updatedMsg.read_at } : m)
          );
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'video_calls',
          filter: `match_id=eq.${matchId}`
        },
        () => {
          // Check for video call updates
          checkForActiveCall();
        }
      )
      .subscribe((status) => {
        console.log('[ChatModal] Realtime subscription status:', status);
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [isOpen, matchId, user?.id, scrollToBottom]);

  // ── Contact Restriction: Fetch state + realtime subscription ──
  useEffect(() => {
    if (!isOpen || !matchId || !user?.id) return;

    const loadRestrictionState = async () => {
      setRestrictionLoading(true);
      const state = await fetchRestrictionState(matchId, user.id, otherUser.id);
      setRestrictionState(state);
      setRestrictionLoading(false);
    };

    loadRestrictionState();

    // Listen for realtime changes to contact_restriction_removals
    const restrictionChannel = supabase
      .channel(`restriction:${matchId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'contact_restriction_removals',
          filter: `match_id=eq.${matchId}`
        },
        () => {
          // Re-fetch restriction state when either user removes restriction
          loadRestrictionState();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(restrictionChannel);
    };
  }, [isOpen, matchId, user?.id, otherUser.id]);

  // ── Empty state: Fetch match connection date + compute shared interests ──
  // Non-AI, purely data-driven. Runs once when modal opens.
  useEffect(() => {
    if (!isOpen || !matchId || !user?.id) return;

    let cancelled = false;

    const fetchMatchMetadata = async () => {
      try {
        // 1. Fetch match confirmed_at / created_at for connection date
        const { data: matchRow } = await supabase
          .from('matches')
          .select('confirmed_at, created_at')
          .eq('id', matchId)
          .single();

        if (!cancelled && matchRow) {
          setMatchConnectionDate(matchRow.confirmed_at || matchRow.created_at || null);
        }

        // 2. Fetch other user's interest_tags to compute shared interests
        const { data: otherProfile } = await supabase
          .from('profiles')
          .select('interest_tags')
          .eq('id', otherUser.id)
          .single();

        if (!cancelled) {
          const myTags: string[] = profile?.interest_tags || [];
          const theirTags: string[] = otherProfile?.interest_tags || [];

          if (myTags.length > 0 && theirTags.length > 0) {
            const shared = myTags.filter(tag =>
              theirTags.some(t => t.toLowerCase() === tag.toLowerCase())
            );
            setSharedInterests(shared);
          } else {
            setSharedInterests([]);
          }
        }
      } catch (err) {
        console.error('[ChatModal] Error fetching match metadata for empty state:', err);
      }
    };

    fetchMatchMetadata();

    return () => { cancelled = true; };
  }, [isOpen, matchId, user?.id, otherUser.id, profile?.interest_tags]);




  // ── Contact Restriction: Handle permanent removal ──
  const handleRemoveRestriction = async () => {
    if (!user?.id || removingRestriction) return;
    setRemovingRestriction(true);

    const result = await removeMyRestriction(matchId, user.id);

    if (result.success) {
      setRestrictionState(prev => ({
        ...prev,
        myRestrictionRemoved: true,
        fullyUnlocked: prev.theirRestrictionRemoved,
      }));
      setShowRemoveRestrictionConfirm(false);
    } else {
      console.error('[ContactRestriction] Failed to remove:', result.error);
      // Show the error to the user if it's a window-expired error
      if (result.error?.includes('expired') || result.error?.includes('ended')) {
        setBlockedMessageError(result.error);
      }
    }
    setRemovingRestriction(false);
  };


  // Check for active video calls
  const checkForActiveCall = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('video-call', {
        body: { action: 'get_active', match_id: matchId }
      });
      
      if (!error && data?.call) {
        setActiveVideoCall(data.call);
        // If there's an incoming call and we're the recipient, show the modal
        if (data.call.status === 'pending' && data.call.recipient_id === user?.id) {
          setShowVideoCall(true);
        }
      } else {
        setActiveVideoCall(null);
      }
    } catch (err) {
      console.error('Error checking for active call:', err);
    }
  };

  // Initiate video call
  const handleInitiateVideoCall = async () => {
    setInitiatingCall(true);
    try {
      const { data, error } = await supabase.functions.invoke('video-call', {
        body: {
          action: 'initiate',
          match_id: matchId,
          recipient_id: otherUser.id,
          duration_minutes: selectedDuration
        }
      });

      if (error) throw error;
      if (data?.call) {
        setActiveVideoCall(data.call);
        setShowVideoCall(true);
        setShowCallDurationPicker(false);
      }
    } catch (err: any) {
      console.error('Error initiating call:', err);
    } finally {
      setInitiatingCall(false);
    }
  };


  // Scroll to bottom when messages change
  useEffect(() => {
    if (messages.length > 0 && !loading) {
      scrollToBottom();
    }
  }, [messages.length, loading, scrollToBottom]);

  // ── Real-time input validation for contact restriction ──
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setNewMessage(value);
    // Clear blocked error and trigger code when user modifies input
    if (blockedMessageError) {
      setBlockedMessageError(null);
      setLastTriggerErrorCode(null);
    }

    // Real-time validation: show warning as user types restricted content
    if (isRestrictionActive && value.trim().length > 3) {
      const validation = validateMessageContent(value, true);
      if (validation.blocked) {
        setInputRestrictionWarning(
          'This message contains restricted content. It will be blocked when sent.'
        );
      } else {
        setInputRestrictionWarning(null);
      }
    } else {
      setInputRestrictionWarning(null);
    }
  };

  // ── Paste event interception for contact restriction ──
  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    if (!isRestrictionActive) return; // Allow paste when unrestricted

    const pastedText = e.clipboardData.getData('text');
    if (!pastedText) return;

    const validation = validatePastedContent(pastedText, true);
    if (!validation.allowed) {
      e.preventDefault(); // Block the paste
      setBlockedMessageError(validation.reason);
    }
  };

  // ══════════════════════════════════════════════════════════════════════
  // OPTIMISTIC MESSAGE HELPER
  // ══════════════════════════════════════════════════════════════════════

  /**
   * Create an optimistic message and add it to the messages state immediately.
   * This makes the message appear in the chat thread BEFORE the DB insert completes.
   * The realtime subscription will later replace it with the real message.
   */
  const addOptimisticMessage = useCallback((content: string): string => {
    const tempId = `optimistic-${Date.now()}-${++optimisticCounterRef.current}`;
    const optimisticMsg: Message = {
      id: tempId,
      sender_id: user?.id || '',
      content: content.trim(),
      created_at: new Date().toISOString(),
      read_at: null,
      _optimistic: true,
    };

    console.log('[ChatModal] Adding optimistic message:', tempId);
    setMessages(prev => [...prev, optimisticMsg]);

    // Scroll to bottom immediately after adding
    scrollToBottom();

    return tempId;
  }, [user?.id, scrollToBottom]);

  /**
   * Remove an optimistic message (on send failure).
   */
  const removeOptimisticMessage = useCallback((tempId: string) => {
    console.log('[ChatModal] Removing failed optimistic message:', tempId);
    setMessages(prev => prev.filter(m => m.id !== tempId));
  }, []);

  /**
   * Immediately confirm an optimistic message by replacing it with the real DB row.
   * Called after sendChatMessage returns success with insertedMessage data.
   * This eliminates the dependency on realtime for confirming the sender's own messages.
   */
  const confirmOptimisticMessage = useCallback((tempId: string, realMessage: Message) => {
    console.log('[ChatModal] Confirming optimistic message:', tempId, '→', realMessage.id);
    seenMessageIdsRef.current.add(realMessage.id);
    setMessages(prev =>
      prev.map(m => m.id === tempId ? { ...realMessage, _optimistic: false, _failed: false } : m)
    );
  }, []);

  /**
   * Force-confirm an optimistic message when the server said success but we
   * couldn't fetch the real DB row. This removes the spinner and marks the
   * message as "delivered" using the optimistic data (temp ID, client timestamp).
   * The realtime subscription will later reconcile with the real row if it arrives.
   *
   * This is the CRITICAL FALLBACK that prevents messages from being stuck in
   * "loading/pending" spinner state forever on slow networks (4G, etc.).
   */
  const forceConfirmOptimistic = useCallback((tempId: string) => {
    console.log('[ChatModal] Force-confirming optimistic message (no real row):', tempId);
    setMessages(prev =>
      prev.map(m => m.id === tempId ? { ...m, _optimistic: false, _failed: false } : m)
    );
  }, []);


  /**
   * Mark an optimistic message as failed (timeout or error).
   * Shows "Not delivered / Retry" UI instead of spinner.
   */
  const failOptimisticMessage = useCallback((tempId: string) => {
    console.log('[ChatModal] Marking optimistic message as failed:', tempId);
    setMessages(prev =>
      prev.map(m => m.id === tempId ? { ...m, _optimistic: true, _failed: true } : m)
    );
  }, []);

  // ── Timeout for pending optimistic messages (10s) ──
  // Checks every 3s for optimistic messages that have been pending too long.
  // If found, marks them as failed with "Not delivered / Retry" UI.
  useEffect(() => {
    if (!isOpen) return;

    const OPTIMISTIC_TIMEOUT_MS = 10_000; // 10 seconds
    const CHECK_INTERVAL_MS = 3_000; // Check every 3 seconds

    const intervalId = setInterval(() => {
      const now = Date.now();
      setMessages(prev => {
        let changed = false;
        const updated = prev.map(m => {
          if (m._optimistic && !m._failed) {
            const msgAge = now - new Date(m.created_at).getTime();
            if (msgAge > OPTIMISTIC_TIMEOUT_MS) {
              changed = true;
              console.warn('[ChatModal] Optimistic message timed out after', msgAge, 'ms:', m.id);
              return { ...m, _failed: true };
            }
          }
          return m;
        });
        return changed ? updated : prev; // Only trigger re-render if something changed
      });
    }, CHECK_INTERVAL_MS);

    return () => clearInterval(intervalId);
  }, [isOpen]);

  /**
   * Retry sending a failed optimistic message.
   * Removes the failed message and re-sends through the normal pipeline.
   */
  const handleRetryMessage = useCallback(async (failedMessage: Message) => {
    if (!user?.id) return;

    const messageText = failedMessage.content;
    
    // Remove the failed message
    setMessages(prev => prev.filter(m => m.id !== failedMessage.id));

    // Re-add as a fresh optimistic message
    const tempId = addOptimisticMessage(messageText);

    const result = await sendChatMessage({
      matchId,
      senderId: user.id,
      content: messageText,
      otherUserId: otherUser.id,
      skipRestrictionCheck: false,
      cachedRestrictionState: restrictionState,
    });

    if (result.success) {
      // ── IMMEDIATE CONFIRMATION: Replace optimistic with real row ──
      if (result.insertedMessage) {
        confirmOptimisticMessage(tempId, result.insertedMessage as Message);
      } else {
        // Edge function path: quick fetch
        let confirmed = false;
        try {
          const { data: latestMsg } = await supabase
            .from('messages')
            .select('*')
            .eq('match_id', matchId)
            .eq('sender_id', user.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .single();
          if (latestMsg && latestMsg.content === messageText) {
            confirmOptimisticMessage(tempId, latestMsg);
            confirmed = true;
          }
        } catch {
          console.warn('[ChatModal] Quick fetch after retry send failed');
        }
        // ── CRITICAL FALLBACK: Force-confirm if fetch failed ──
        if (!confirmed) {
          forceConfirmOptimistic(tempId);
        }
      }
      console.log('[ChatModal] Retry succeeded');

    } else {
      // Retry also failed — mark as failed again
      failOptimisticMessage(tempId);
      console.error('[ChatModal] Retry failed:', {
        error: result.error,
        technicalError: result.technicalError,
        blockedByRestriction: result.blockedByRestriction,
      });
      if (result.error) {
        setBlockedMessageError(result.error);
      }
    }
  }, [user?.id, matchId, otherUser.id, restrictionState, addOptimisticMessage, confirmOptimisticMessage, failOptimisticMessage]);

  // ══════════════════════════════════════════════════════════════════════
  // CENTRALIZED MESSAGE SEND — ALL messages go through sendChatMessage()
  // ══════════════════════════════════════════════════════════════════════

  /**
   * Send a user-typed message. Enforces contact restriction.
   * Uses optimistic UI for instant feedback.
   * On success, immediately confirms the optimistic message with the real DB row.
   */
  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || sending || !user?.id) return;

    const messageText = newMessage.trim();

    // ── OPTIMISTIC UI: Show message immediately ──
    const tempId = addOptimisticMessage(messageText);
    setNewMessage('');
    setSending(true);
    setBlockedMessageError(null);
    setLastTriggerErrorCode(null);
    setInputRestrictionWarning(null);

    const result = await sendChatMessage({
      matchId,
      senderId: user.id,
      content: messageText,
      otherUserId: otherUser.id,
      skipRestrictionCheck: false,
      cachedRestrictionState: restrictionState,
    });

    if (result.success) {
      // ── IMMEDIATE CONFIRMATION: Replace optimistic with real row ──
      // This is the PRIMARY fix — don't rely on realtime to flip the spinner.
      if (result.insertedMessage) {
        confirmOptimisticMessage(tempId, result.insertedMessage as Message);
      } else {
        // Edge function path: no insertedMessage returned.
        // Do a quick targeted fetch to get the real row.
        let confirmed = false;
        try {
          const { data: latestMsg } = await supabase
            .from('messages')
            .select('*')
            .eq('match_id', matchId)
            .eq('sender_id', user.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .single();
          if (latestMsg && latestMsg.content === messageText) {
            confirmOptimisticMessage(tempId, latestMsg);
            confirmed = true;
          }
        } catch {
          console.warn('[ChatModal] Quick fetch after send failed');
        }
        // ── CRITICAL FALLBACK: Server said success but we couldn't get the real row.
        // Force-confirm to remove the spinner. Realtime will reconcile later.
        if (!confirmed) {
          console.warn('[ChatModal] Force-confirming: server success but no row fetched');
          forceConfirmOptimistic(tempId);
        }
      }
      console.log('[ChatModal] Message sent successfully');

    } else {
      // ── SEND FAILED: Remove optimistic message and show error ──
      removeOptimisticMessage(tempId);
      setNewMessage(messageText); // Restore the text so user doesn't lose it

      // Log full error details for debugging
      console.error('[ChatModal] Send failed:', {
        error: result.error,
        technicalError: result.technicalError,
        blockedByRestriction: result.blockedByRestriction,
        triggerErrorCode: result.triggerErrorCode,
      });

      if (result.blockedByRestriction) {
        setBlockedMessageError(result.error || 'Message blocked by contact restriction.');

        // Surface the DB trigger error code for debugging false positives
        if (result.triggerErrorCode) {
          setLastTriggerErrorCode(result.triggerErrorCode);
        }
      } else {
        // Non-restriction error (network, DB, RLS, JWT, etc.)
        // Show user-friendly error based on technical details
        const techErr = result.technicalError || '';
        if (techErr.includes('JWT') || techErr.includes('PGRST301')) {
          setBlockedMessageError('Your session has expired. Please refresh the page and try again.');
        } else if (techErr.includes('42501') || techErr.includes('permission')) {
          setBlockedMessageError('Permission denied. You may not have access to send messages in this chat.');
        } else if (techErr.includes('timed out') || techErr.includes('network') || techErr.includes('Failed to fetch')) {
          setBlockedMessageError('Network error. Please check your connection and try again.');
        } else {
          setBlockedMessageError(result.error || 'Failed to send message. Please try again.');
        }
      }
    }

    setSending(false);
  };









  const handleEndChat = async () => {
    setEndingChat(true);
    setEndChatError(null);

    try {
      // ── PRIMARY: Update match status to 'ended' ──
      // Only set `status` first — ended_at / ended_by may not exist as columns
      // and would cause the entire UPDATE to fail silently.
      const { error: statusError } = await supabase
        .from('matches')
        .update({ status: 'ended' })
        .eq('id', matchId);

      if (statusError) {
        // Log full error details for debugging
        console.error('[EndChat] Failed to update match status:', {
          message: statusError.message,
          code: statusError.code,
          details: statusError.details,
          hint: statusError.hint,
          matchId,
          userId: user?.id,
        });

        // Check if this is an RLS / permission error
        if (statusError.code === '42501' || statusError.message?.includes('permission')) {
          setEndChatError('Permission denied. You may not have access to end this chat. Please contact support.');
        } else if (statusError.code === 'PGRST301' || statusError.message?.includes('JWT')) {
          setEndChatError('Your session has expired. Please refresh the page and try again.');
        } else {
          setEndChatError(`Failed to end chat: ${statusError.message || 'Unknown error'}. You can force-close below.`);
        }
        setEndingChat(false);
        return;
      }

      // ── SECONDARY: Best-effort set ended_at and ended_by (non-blocking) ──
      // These columns may not exist on the table. If they fail, we don't care —
      // the status is already 'ended' which is what matters.
      supabase
        .from('matches')
        .update({
          ended_at: new Date().toISOString(),
          ended_by: user?.id,
        })
        .eq('id', matchId)
        .then(({ error: metaError }) => {
          if (metaError) {
            console.warn('[EndChat] Non-critical: could not set ended_at/ended_by:', metaError.message);
          }
        });

      // ── SUCCESS: Proceed to feedback prompt ──
      console.log('[EndChat] Match ended successfully:', matchId);
      setShowEndChatConfirm(false);
      setShowFeedbackPrompt(true);
    } catch (err: any) {
      console.error('[EndChat] Unexpected error:', err);
      setEndChatError(`Unexpected error: ${err?.message || 'Please try again.'}`);
    }

    setEndingChat(false);
  };

  /**
   * Force-close: remove the match from the UI even if the DB update failed.
   * This ensures the user isn't stuck with a broken chat they can't dismiss.
   */
  const handleForceEndChat = () => {
    console.warn('[EndChat] Force-closing chat (DB update may have failed):', matchId);
    setShowEndChatConfirm(false);
    setEndChatError(null);
    onChatEnded?.(matchId);
    onClose();
  };


  const handleFeedback = async (feedback: 'positive' | 'negative' | 'neutral') => {
    // Store feedback
    await supabase
      .from('match_feedback')
      .insert({
        match_id: matchId,
        user_id: user?.id,
        feedback_type: feedback
      });

    setShowFeedbackPrompt(false);
    onChatEnded?.(matchId, feedback);
    onClose();
  };

  const handleSkipFeedback = () => {
    setShowFeedbackPrompt(false);
    onChatEnded?.(matchId);
    onClose();
  };

  // ── Determine if there are any user messages (ignore system messages) ──
  // A "user message" is one sent by either participant (user.id or otherUser.id).
  // System-generated messages (e.g., from a bot or null sender) are excluded.
  const hasUserMessages = useMemo(() => {
    return messages.some(m =>
      m.sender_id === user?.id || m.sender_id === otherUser.id
    );
  }, [messages, user?.id, otherUser.id]);

  // Format connection date for the empty state card
  const formattedConnectionDate = useMemo(() => {
    if (!matchConnectionDate) return null;
    try {
      return new Date(matchConnectionDate).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      });
    } catch {
      return null;
    }
  }, [matchConnectionDate]);

  if (!isOpen) return null;


  // End Chat Confirmation Modal
  if (showEndChatConfirm) {
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden">
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={() => { setShowEndChatConfirm(false); setEndChatError(null); }} />
        
        <div className="relative min-h-full flex items-center justify-center p-4">
          <div className="relative w-full max-w-sm bg-[#141414] rounded-2xl shadow-2xl overflow-hidden border border-[#2a2a2a] p-6">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-amber-500/10 rounded-full flex items-center justify-center border border-amber-500/20">
                <MessageSquareOff className="w-8 h-8 text-amber-400" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">End This Chat?</h3>
              <p className="text-gray-400 text-sm mb-6">
                This will permanently close the conversation with {otherUser.display_name || 'this person'}. This action cannot be undone.
              </p>

              {/* Error feedback — shown when DB update fails */}
              {endChatError && (
                <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-left">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                    <p className="text-red-400 text-xs">{endChatError}</p>
                  </div>
                </div>
              )}
              
              <div className="flex gap-3">
                <button
                  onClick={() => { setShowEndChatConfirm(false); setEndChatError(null); }}
                  className="flex-1 py-3 bg-[#2a2a2a] hover:bg-[#333] text-white rounded-xl transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={handleEndChat}
                  disabled={endingChat}
                  className="flex-1 py-3 bg-red-500 hover:bg-red-600 text-white rounded-xl transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {endingChat ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    endChatError ? 'Retry' : 'End Chat'
                  )}
                </button>
              </div>

              {/* Force-close fallback — only shown after a DB error */}
              {endChatError && (
                <button
                  onClick={handleForceEndChat}
                  className="mt-3 w-full py-2.5 text-amber-400 text-sm hover:bg-amber-500/10 rounded-xl transition-all border border-amber-500/20"
                >
                  Force Close (remove from your view)
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }


  // Feedback Prompt Modal
  if (showFeedbackPrompt) {
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden">
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" />
        
        <div className="relative min-h-full flex items-center justify-center p-4">
          <div className="relative w-full max-w-sm bg-[#141414] rounded-2xl shadow-2xl overflow-hidden border border-[#2a2a2a] p-6">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-[#C9A24D]/10 rounded-full flex items-center justify-center border border-[#C9A24D]/20">
                <Heart className="w-8 h-8 text-[#C9A24D]" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">How did it go?</h3>
              <p className="text-gray-400 text-sm mb-6">
                Your feedback is private and helps us improve Dwadido. This is completely optional.
              </p>
              
              <div className="space-y-3">
                <button
                  onClick={() => handleFeedback('positive')}
                  className="w-full py-3 bg-green-500/10 hover:bg-green-500/20 text-green-400 rounded-xl transition-all flex items-center justify-center gap-2 border border-green-500/20"
                >
                  <ThumbsUp className="w-5 h-5" />
                  It worked out!
                </button>
                <button
                  onClick={() => handleFeedback('negative')}
                  className="w-full py-3 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl transition-all flex items-center justify-center gap-2 border border-red-500/20"
                >
                  <ThumbsDown className="w-5 h-5" />
                  It didn't work out
                </button>
                <button
                  onClick={() => handleFeedback('neutral')}
                  className="w-full py-3 bg-[#2a2a2a] hover:bg-[#333] text-gray-400 rounded-xl transition-all"
                >
                  Prefer not to say
                </button>
              </div>
              
              <button
                onClick={handleSkipFeedback}
                className="mt-4 text-gray-500 text-sm hover:text-gray-400 transition-all"
              >
                Skip
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden" style={{ WebkitOverflowScrolling: 'touch' }}>
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
        
        <div className="relative min-h-full flex items-center justify-center p-4 py-8">
          <div className="relative w-full max-w-lg h-[600px] max-h-[85vh] bg-[#141414] rounded-2xl shadow-2xl overflow-hidden flex flex-col animate-in fade-in zoom-in duration-300 border border-[#2a2a2a]">

          {/* Header */}
          <div className="flex items-center gap-3 p-4 border-b border-[#2a2a2a] bg-[#1a1a1a]">
            <div className="relative">
              {otherUser.avatar_url ? (
                <img
                  src={otherUser.avatar_url}
                  alt={otherUser.display_name || 'User'}
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-[#C9A24D]/30"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-[#C9A24D]/20 flex items-center justify-center border border-[#C9A24D]/30">
                  <User className="w-5 h-5 text-[#C9A24D]" />
                </div>
              )}


            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-semibold text-white">
                  {otherUser.display_name || 'Anonymous'}
                </h3>
                {/* Age Badge */}
                {age !== null ? (
                  <span className="px-2 py-0.5 bg-[#2a2a2a] text-gray-300 text-xs font-medium rounded-full border border-[#3a3a3a]">
                    {age}
                  </span>
                ) : (
                  <span className="text-xs text-gray-500 italic">Age not specified</span>
                )}


              </div>
              <span className="text-gray-400 text-xs">Active Connection</span>
            </div>




            
            {/* Menu button */}

            <div className="relative">
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="p-2 text-gray-400 hover:text-white hover:bg-[#2a2a2a] rounded-full transition-all"
              >
                <MoreVertical className="w-5 h-5" />
              </button>
              {showMenu && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setShowMenu(false)} />
                  <div className="absolute right-0 top-10 z-20 w-48 bg-[#1a1a1a] rounded-xl shadow-lg border border-[#2a2a2a] py-1">
                    <button
                      onClick={() => {
                        setShowMenu(false);
                        setShowEndChatConfirm(true);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-amber-400 hover:bg-amber-500/10 flex items-center gap-2"
                    >
                      <MessageSquareOff className="w-4 h-4" />
                      End Chat
                    </button>
                    {/* Contact Restriction Menu Item */}
                    {!restrictionState.myRestrictionRemoved && !restrictionLoading && !restrictionState.windowExpired && (
                      <>
                        <div className="border-t border-[#2a2a2a] my-1" />
                        <button
                          onClick={() => {
                            setShowMenu(false);
                            setShowRemoveRestrictionConfirm(true);
                          }}
                          className="w-full px-4 py-2 text-left text-sm text-blue-400 hover:bg-blue-500/10 flex items-center gap-2"
                        >
                          <Unlock className="w-4 h-4" />
                          Remove Chat Restriction
                        </button>
                      </>
                    )}
                    <div className="border-t border-[#2a2a2a] my-1" />

                    <button
                      onClick={() => {
                        setShowMenu(false);
                        setShowReportModal(true);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-red-400 hover:bg-red-500/10 flex items-center gap-2"
                    >
                      <Flag className="w-4 h-4" />
                      Report User
                    </button>
                    <button
                      onClick={() => {
                        setShowMenu(false);
                        setShowBlockModal(true);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-[#C9A24D] hover:bg-[#C9A24D]/10 flex items-center gap-2"
                    >
                      <ShieldOff className="w-4 h-4" />
                      Block User
                    </button>
                  </div>
                </>
              )}
            </div>
            
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white hover:bg-[#2a2a2a] rounded-full transition-all"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Intent Details Banner - Collapsible */}
          {(otherUser.intent || otherUser.relationship_status) && (
            <div className="border-b border-[#2a2a2a] bg-[#1a1a1a]">
              <button
                onClick={() => setShowIntentDetails(!showIntentDetails)}
                className="w-full px-4 py-2 flex items-center justify-between text-sm hover:bg-[#2a2a2a]/50 transition-all"
              >
                <div className="flex items-center gap-2 text-[#C9A24D]">
                  <Heart className="w-4 h-4" />
                  <span className="font-medium">Verified Intent</span>
                </div>
                {showIntentDetails ? (
                  <ChevronUp className="w-4 h-4 text-gray-400" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                )}
              </button>
              
              {showIntentDetails && (
                <div className="px-4 pb-3 space-y-2">
                  {otherUser.intent && (
                    <div className="flex items-center gap-2">
                      <Heart className="w-4 h-4 text-[#C9A24D]" />
                      <span className="text-gray-400 text-sm">Looking for:</span>
                      <span className="text-white text-sm font-medium">
                        {INTENT_LABELS[otherUser.intent]}
                      </span>
                    </div>
                  )}
                  {otherUser.relationship_status && (
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-[#C9A24D]" />
                      <span className="text-gray-400 text-sm">Status:</span>
                      <span className="text-white text-sm font-medium">
                        {RELATIONSHIP_STATUS_LABELS[otherUser.relationship_status]}
                      </span>
                    </div>
                  )}


                </div>
              )}

            </div>
          )}

          {/* ── Contact Restriction Status Banner ── */}
          {!restrictionLoading && (
            <div className={`px-4 py-2 border-b border-[#2a2a2a] flex items-center gap-2 text-xs ${
              restrictionState.fullyUnlocked
                ? 'bg-green-500/10 text-green-400'
                : restrictionState.myRestrictionRemoved
                  ? 'bg-blue-500/10 text-blue-400'
                  : 'bg-[#1a1a1a] text-gray-400'
            }`}>
              {restrictionState.fullyUnlocked ? (
                <>
                  <Unlock className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>Chat restriction removed by both users. Contact details allowed.</span>
                </>
              ) : restrictionState.myRestrictionRemoved ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 flex-shrink-0 animate-spin" />
                  <span>You have removed restriction. Waiting for the other user.</span>
                </>
              ) : restrictionState.windowExpired ? (
                <>
                  <Lock className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>Contact restriction ON — chat window expired.</span>
                </>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>Contact restriction ON — personal details blocked.</span>
                  <button
                    onClick={() => setShowRemoveRestrictionConfirm(true)}
                    className="ml-auto text-blue-400 hover:text-blue-300 font-medium whitespace-nowrap"
                  >
                    Remove
                  </button>
                </>
              )}
            </div>
          )}


          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#0d0d0d]">
            {loading ? (
              <div className="flex items-center justify-center h-full">
                <Loader2 className="w-8 h-8 text-[#C9A24D] animate-spin" />
              </div>
            ) : !hasUserMessages ? (
              /* ── Premium Empty State Card (non-AI) ──
               * Shown when zero user messages exist (system messages ignored).
               * Displays: other user's name, CTA, shared interests, connection date.
               * No AI components. No edge function calls. */
              <div className="flex flex-col items-center justify-center h-full px-2">
                <div className="w-full max-w-xs">
                  {/* Card */}
                  <div className="bg-[#1a1a1a] rounded-2xl border border-[#2a2a2a] p-5 shadow-lg">
                    {/* Avatar + Name */}
                    <div className="flex flex-col items-center mb-4">
                      {otherUser.avatar_url ? (
                        <img
                          src={otherUser.avatar_url}
                          alt={otherUser.display_name || 'User'}
                          className="w-14 h-14 rounded-full object-cover ring-2 ring-[#C9A24D]/30 mb-2.5"
                        />
                      ) : (
                        <div className="w-14 h-14 rounded-full bg-[#C9A24D]/15 flex items-center justify-center border border-[#C9A24D]/25 mb-2.5">
                          <User className="w-7 h-7 text-[#C9A24D]" />
                        </div>
                      )}
                      <h4 className="text-white font-semibold text-base">
                        {otherUser.display_name || 'Anonymous'}
                      </h4>
                    </div>

                    {/* CTA text */}
                    <div className="flex items-center justify-center gap-2 mb-4">
                      <MapPin className="w-3.5 h-3.5 text-[#C9A24D] flex-shrink-0" />
                      <p className="text-gray-300 text-sm text-center">
                        You connected in person — say hello!
                      </p>
                    </div>

                    {/* Shared Interests */}
                    {sharedInterests.length > 0 && (
                      <div className="mb-4">
                        <p className="text-gray-500 text-[11px] font-medium uppercase tracking-wider mb-2 text-center">
                          Shared Interests
                        </p>
                        <div className="flex flex-wrap justify-center gap-1.5">
                          {sharedInterests.slice(0, 6).map((interest, idx) => (
                            <span
                              key={idx}
                              className="px-2.5 py-1 bg-[#C9A24D]/10 text-[#C9A24D] text-xs font-medium rounded-full border border-[#C9A24D]/20"
                            >
                              {interest}
                            </span>
                          ))}
                          {sharedInterests.length > 6 && (
                            <span className="px-2.5 py-1 bg-[#2a2a2a] text-gray-400 text-xs font-medium rounded-full">
                              +{sharedInterests.length - 6}
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Connection Date */}
                    {formattedConnectionDate && (
                      <div className="flex items-center justify-center gap-1.5 pt-3 border-t border-[#2a2a2a]">
                        <Calendar className="w-3.5 h-3.5 text-gray-500" />
                        <p className="text-gray-500 text-xs">
                          Connected {formattedConnectionDate}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

            ) : (
              messages.map((message) => {
                const isOwn = message.sender_id === user?.id;
                const isOptimistic = !!message._optimistic;
                const isFailed = !!message._failed;
                
                return (
                  <div key={message.id} className="space-y-1">

                    
                    <div className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}>
                      <div
                        className={`max-w-[75%] px-4 py-2.5 rounded-2xl ${
                          isOwn
                            ? `rounded-br-md ${
                                isFailed
                                  ? 'bg-red-900/40 text-red-200 border border-red-500/30'
                                  : isOptimistic
                                    ? 'bg-[#C9A24D]/60 text-[#141414]'
                                    : 'bg-[#C9A24D] text-[#141414]'
                              }`
                            : 'bg-[#1a1a1a] text-white shadow-sm rounded-bl-md border border-[#2a2a2a]'
                        }`}
                      >
                        <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>
                        <div className={`flex items-center justify-end gap-1 mt-1 ${
                          isFailed ? 'text-red-400' : isOwn ? 'text-[#141414]/60' : 'text-gray-500'
                        }`}>
                          <span className="text-[10px]">
                            {new Date(message.created_at).toLocaleTimeString('en-US', {
                              hour: 'numeric',
                              minute: '2-digit'
                            })}
                          </span>
                          {isOwn && (
                            isFailed ? (
                              // Failed indicator — "Not delivered"
                              <AlertTriangle className="w-3 h-3 text-red-400" />
                            ) : isOptimistic ? (
                              // Sending indicator for optimistic messages (spinner)
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : message.read_at ? (
                              <CheckCheck className="w-3 h-3" />
                            ) : (
                              <Check className="w-3 h-3" />
                            )
                          )}
                        </div>
                      </div>
                    </div>

                    {/* "Not delivered / Retry" bar — shown below failed messages */}
                    {isFailed && isOwn && (
                      <div className="flex justify-end">
                        <div className="flex items-center gap-2 text-[10px] mr-1">
                          <span className="text-red-400">Not delivered</span>
                          <button
                            onClick={() => handleRetryMessage(message)}
                            className="text-red-300 hover:text-white underline flex items-center gap-0.5 py-0.5 px-1 rounded hover:bg-red-500/10 transition-all"
                          >
                            <RefreshCw className="w-3 h-3" />
                            Retry
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })

            )}
            <div ref={messagesEndRef} />
          </div>










          {/* Real-time input restriction warning */}
          {inputRestrictionWarning && (
            <div className="px-4 py-1.5 bg-amber-500/10 border-t border-amber-500/20 text-amber-400 text-xs flex items-center gap-2">
              <AlertTriangle className="w-3 h-3 flex-shrink-0" />
              <span>{inputRestrictionWarning}</span>
            </div>
          )}

          {/* Blocked message error + DB trigger code debug display */}
          {blockedMessageError && (
            <div className="px-4 py-2 bg-red-500/10 border-t border-red-500/30 text-red-400 text-xs flex items-start gap-2">
              <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <p>{blockedMessageError}</p>
                {/* Debug: Show the exact DB trigger error code (DEV ONLY — never in production) */}
                {import.meta.env.DEV && lastTriggerErrorCode && (
                  <p className="mt-1 px-2 py-1 bg-[#1a1a1a] border border-[#2a2a2a] rounded font-mono text-[10px] text-yellow-400 break-all">
                    DB Trigger: {lastTriggerErrorCode}
                  </p>
                )}

                <button
                  onClick={() => {
                    setBlockedMessageError(null);
                    setLastTriggerErrorCode(null);
                  }}
                  className="text-red-300 underline mt-1"
                >
                  Dismiss
                </button>
              </div>
            </div>
          )}


          {/* Input Area */}
          <form onSubmit={handleSend} className="p-3 border-t border-[#2a2a2a] bg-[#141414]">

            <div className="flex items-center gap-2">
              {/* LEFT SIDE: Video Call button */}

              <div className="flex items-center gap-1 flex-shrink-0">
                {/* Video Call Button - Premium Gated */}
                <button
                  type="button"
                  onClick={() => {
                    if (canUseFeature('videoSpeedDate')) {
                      setShowCallDurationPicker(true);
                    } else {
                      setShowPremiumModal(true);
                    }
                  }}
                  disabled={!!activeVideoCall}
                  className={`relative p-2.5 rounded-xl border transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                    canUseFeature('videoSpeedDate')
                      ? 'text-green-400 hover:bg-[#2a2a2a] bg-[#1a1a1a] border-[#2a2a2a]'
                      : 'text-gray-500 bg-[#1a1a1a] border-[#2a2a2a]'
                  }`}
                  title={canUseFeature('videoSpeedDate') ? 'Start video speed date' : 'Premium feature - Video Speed Date'}
                >
                  <Video className="w-5 h-5" />
                  {!canUseFeature('videoSpeedDate') && (
                    <Lock className="w-3 h-3 absolute -top-1 -right-1 text-gold" />
                  )}
                </button>




              </div>

              {/* TEXT INPUT — fills remaining space */}
              <input
                ref={inputRef}
                type="text"
                value={newMessage}
                onChange={handleInputChange}
                onPaste={handlePaste}
                placeholder="Type a message..."
                className="flex-1 min-w-0 px-4 py-2.5 bg-[#1a1a1a] text-white placeholder-gray-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#C9A24D]/50 border border-[#2a2a2a] transition-all text-sm"
              />

              {/* SEND BUTTON */}

              <button
                type="submit"
                disabled={!newMessage.trim() || sending}
                className="p-2.5 bg-[#C9A24D] text-[#141414] rounded-xl hover:bg-[#d4af5a] disabled:opacity-50 disabled:cursor-not-allowed transition-all flex-shrink-0"
              >
                {sending ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </button>
            </div>
            <p className="text-center text-gray-500 text-[10px] mt-1.5">
              Messages are monitored for safety. Be respectful.
            </p>
          </form>

          </div>
        </div>
      </div>

      {/* Call Duration Picker Modal */}
      {showCallDurationPicker && (
        <div className="fixed inset-0 z-[55] overflow-y-auto overflow-x-hidden">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowCallDurationPicker(false)} />
          
          <div className="relative min-h-full flex items-center justify-center p-4">
            <div className="relative w-full max-w-sm bg-[#141414] rounded-2xl shadow-2xl overflow-hidden border border-[#2a2a2a] p-6">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-green-500/10 rounded-full flex items-center justify-center border border-green-500/20">
                  <Video className="w-8 h-8 text-green-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Video Speed Date</h3>
                <p className="text-gray-400 text-sm mb-6">
                  Choose the duration for your video call. Both parties must consent to start.
                </p>
                
                <div className="space-y-3 mb-6">
                  {[5, 7, 10].map((duration) => (
                    <button
                      key={duration}
                      onClick={() => setSelectedDuration(duration)}
                      className={`w-full py-3 rounded-xl transition-all flex items-center justify-center gap-2 ${
                        selectedDuration === duration
                          ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                          : 'bg-[#2a2a2a] text-gray-400 hover:bg-[#333] border border-transparent'
                      }`}
                    >
                      {duration} minutes
                    </button>
                  ))}
                </div>
                
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowCallDurationPicker(false)}
                    className="flex-1 py-3 bg-[#2a2a2a] hover:bg-[#333] text-white rounded-xl transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleInitiateVideoCall}
                    disabled={initiatingCall}
                    className="flex-1 py-3 bg-green-500 hover:bg-green-600 text-white rounded-xl transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {initiatingCall ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <>
                        <Video className="w-5 h-5" />
                        Start Call
                      </>
                    )}
                  </button>
                </div>
                
                <p className="text-gray-500 text-xs mt-4">
                  {otherUser.display_name || 'The other user'} will need to accept the call to begin.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Video Call Modal */}
      {showVideoCall && activeVideoCall && (
        <VideoCallModal
          isOpen={showVideoCall}
          onClose={() => {
            setShowVideoCall(false);
            setActiveVideoCall(null);
          }}
          matchId={matchId}
          callId={activeVideoCall.id}
          otherUser={otherUser}
          isIncoming={activeVideoCall.recipient_id === user?.id}
          onCallEnded={() => {
            setActiveVideoCall(null);
            checkForActiveCall();
          }}
        />
      )}

      {/* Report Modal */}
      <ReportUserModal
        isOpen={showReportModal}
        onClose={() => setShowReportModal(false)}
        reportedUserId={otherUser.id}
        reportedUserName={otherUser.display_name || undefined}
      />

      {/* Block Modal */}
      <BlockUserModal
        isOpen={showBlockModal}
        onClose={() => setShowBlockModal(false)}
        userId={otherUser.id}
        userName={otherUser.display_name || undefined}
        onBlocked={onClose}
      />

      {/* Premium Feature Modal */}
      <PremiumFeatureModal
        isOpen={showPremiumModal}
        onClose={() => setShowPremiumModal(false)}
        featureId="videoSpeedDate"
      />

      {/* Contact Restriction Confirmation Modal */}
      {showRemoveRestrictionConfirm && (
        <div className="fixed inset-0 z-[60] overflow-y-auto overflow-x-hidden">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowRemoveRestrictionConfirm(false)} />
          <div className="relative min-h-full flex items-center justify-center p-4">
            <div className="relative w-full max-w-sm bg-[#141414] rounded-2xl shadow-2xl overflow-hidden border border-[#2a2a2a] p-6">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-blue-500/10 rounded-full flex items-center justify-center border border-blue-500/20">
                  <Unlock className="w-8 h-8 text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Remove Chat Restriction?</h3>
                <p className="text-gray-400 text-sm mb-3">
                  This will signal that you're willing to share personal contact details (phone, email, social media) with {otherUser.display_name || 'this person'}.
                </p>
                <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 mb-6">
                  <div className="flex items-center gap-2 text-amber-400 text-xs font-medium">
                    <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                    <span>This action cannot be undone.</span>
                  </div>
                  <p className="text-amber-400/70 text-xs mt-1">
                    Contact sharing only unlocks when both users remove the restriction.
                  </p>
                </div>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowRemoveRestrictionConfirm(false)}
                    className="flex-1 py-3 bg-[#2a2a2a] hover:bg-[#333] text-white rounded-xl transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleRemoveRestriction}
                    disabled={removingRestriction}
                    className="flex-1 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {removingRestriction ? (
                      <Loader2 className="w-5 h-5 animate-spin" />
                    ) : (
                      <>
                        <Unlock className="w-5 h-5" />
                        Remove
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>

  );
};

export default ChatModal;
