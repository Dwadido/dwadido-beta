import React, { useState } from 'react';
import { supabase, SUPABASE_URL } from '@/lib/supabase';

import { useAuth } from '@/contexts/AuthContext';
import { usePremium } from '@/contexts/PremiumContext';
import {
  X,
  Copy,
  Check,
  Share2,
  ExternalLink,
  BarChart3,
  Loader2,
  Mail,
  Clock,
  Link2,
  ChevronDown,
  AlertCircle,
  MessageSquare,
  Smartphone,
  QrCode,
  Printer,
  Crown,
  Lock,
  History
} from 'lucide-react';
import LinkHistorySection from './LinkHistorySection';
import QRCodeModal from './QRCodeModal';
import PrintableQRCard from './PrintableQRCard';
import FreemiumUpsell, { UpsellTrigger } from './FreemiumUpsell';

interface ShareStats {
  total: number;
  twitter: number;
  facebook: number;
  whatsapp: number;
  email: number;
  sms: number;
  link_copies: number;
  time_limited: number;
  qr_code: number;
  printed_cards: number;
}

interface TimeLimitedLink {
  id: string;
  token: string;
  expires_at: string;
  expiration_hours: number;
  code: string;
}

interface CrushCodeShareProps {
  isOpen: boolean;
  onClose: () => void;
  code: string;
  codeId: string;
  initialStats?: ShareStats;
  onShareTracked?: (stats: ShareStats) => void;
}

const CrushCodeShare: React.FC<CrushCodeShareProps> = ({
  isOpen,
  onClose,
  code,
  codeId,
  initialStats,
  onShareTracked
}) => {
  const { user, profile } = useAuth();
  const { isPremium, canUseFeature } = usePremium();
  const [copied, setCopied] = useState(false);
  const [timeLimitedCopied, setTimeLimitedCopied] = useState(false);
  const [tracking, setTracking] = useState<string | null>(null);
  const [stats, setStats] = useState<ShareStats>(initialStats || {
    total: 0,
    twitter: 0,
    facebook: 0,
    whatsapp: 0,
    email: 0,
    sms: 0,
    link_copies: 0,
    time_limited: 0,
    qr_code: 0,
    printed_cards: 0
  });
  const [showStats, setShowStats] = useState(false);
  
  // Time-limited link state
  const [showTimeLimitedSection, setShowTimeLimitedSection] = useState(false);
  const [selectedExpiration, setSelectedExpiration] = useState<1 | 6 | 24>(24);
  const [creatingLink, setCreatingLink] = useState(false);
  const [timeLimitedLink, setTimeLimitedLink] = useState<TimeLimitedLink | null>(null);
  const [linkError, setLinkError] = useState<string | null>(null);
  
  // Link history state
  const [showLinkHistory, setShowLinkHistory] = useState(false);
  
  // QR Code modal state
  const [showQRModal, setShowQRModal] = useState(false);
  
  // Print QR Card modal state
  const [showPrintModal, setShowPrintModal] = useState(false);
  
  // Freemium upsell modal state
  const [upsellModal, setUpsellModal] = useState<{
    isOpen: boolean;
    trigger: UpsellTrigger;
  }>({ isOpen: false, trigger: 'printing' });


  const shareUrl = `${window.location.origin}/redeem?code=${code}`;
  const ogPreviewUrl = `${SUPABASE_URL}/functions/v1/og-preview?code=${code}`;

  const shareText = `I want to connect with you! Use my Crush Code: ${code}`;
  const shareTitle = 'Dwadido - Connect with me';



  const trackShare = async (platform: 'twitter' | 'facebook' | 'whatsapp' | 'email' | 'sms' | 'link_copy' | 'time_limited_link' | 'qr_code' | 'printed_card') => {
    setTracking(platform);
    try {
      const { data, error } = await supabase.functions.invoke('track-crush-share', {
        body: {
          code_id: codeId,
          platform,
          user_id: user?.id
        }
      });

      if (!error && data?.shares) {
        setStats(data.shares);
        onShareTracked?.(data.shares);
      }
    } catch (err) {
      console.error('Error tracking share:', err);
    } finally {
      setTracking(null);
    }
  };

  // Premium-gated: Print QR Card
  const handlePrintCard = async () => {
    if (!canUseFeature('printQRCards')) {
      setUpsellModal({ isOpen: true, trigger: 'printing' });
      return;
    }
    setShowPrintModal(true);
    await trackShare('printed_card');
  };

  // Premium-gated: Time-limited links
  const handleTimeLimitedSection = () => {
    if (!canUseFeature('shareLinkExpiration')) {
      setUpsellModal({ isOpen: true, trigger: 'time_limited_links' });
      return;
    }
    setShowTimeLimitedSection(!showTimeLimitedSection);
  };

  // Premium-gated: Link history
  const handleLinkHistory = () => {
    if (!canUseFeature('linkHistoryView')) {
      setUpsellModal({ isOpen: true, trigger: 'link_history' });
      return;
    }
    setShowLinkHistory(!showLinkHistory);
  };

  // Premium-gated: Analytics
  const handleShowStats = () => {
    if (!canUseFeature('codeAnalytics')) {
      setUpsellModal({ isOpen: true, trigger: 'analytics' });
      return;
    }
    setShowStats(!showStats);
  };

  // Use OG preview URL for social media sharing to get beautiful link previews
  const handleTwitterShare = async () => {
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(ogPreviewUrl)}`;
    window.open(twitterUrl, '_blank', 'width=550,height=420');
    await trackShare('twitter');
  };

  const handleFacebookShare = async () => {
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(ogPreviewUrl)}&quote=${encodeURIComponent(shareText)}`;
    window.open(facebookUrl, '_blank', 'width=550,height=420');
    await trackShare('facebook');
  };

  const handleWhatsAppShare = async () => {
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(`${shareText}\n\n${ogPreviewUrl}`)}`;
    window.open(whatsappUrl, '_blank');
    await trackShare('whatsapp');
  };


  const handleEmailShare = async () => {
    const emailSubject = encodeURIComponent(shareTitle);
    const emailBody = encodeURIComponent(
      `Hi there!\n\n` +
      `I'd love to connect with you on Dwadido!\n\n` +
      `Here's my personal connection code: ${code}\n\n` +
      `Click the link below to redeem it and start our conversation:\n` +
      `${shareUrl}\n\n` +
      `Looking forward to connecting with you!\n\n` +
      `---\n` +
      `Dwadido - Where meaningful connections begin`
    );
    
    const mailtoUrl = `mailto:?subject=${emailSubject}&body=${emailBody}`;
    window.location.href = mailtoUrl;
    await trackShare('email');
  };

  const handleSMSShare = async () => {
    const smsBody = encodeURIComponent(
      `Hey! I'd love to connect with you on Dwadido. ` +
      `Use my code: ${code}\n\n` +
      `${shareUrl}`
    );
    
    const smsUrl = `sms:?body=${smsBody}`;
    window.location.href = smsUrl;
    await trackShare('sms');
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      await trackShare('link_copy');
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: shareTitle,
          text: shareText,
          url: shareUrl
        });
        await trackShare('link_copy');
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          console.error('Share failed:', err);
        }
      }
    }
  };

  const handleGenerateQRCode = async () => {
    setShowQRModal(true);
    await trackShare('qr_code');
  };

  // Time-limited link functions
  const createTimeLimitedLink = async () => {
    setCreatingLink(true);
    setLinkError(null);
    
    try {
      const { data, error } = await supabase.functions.invoke('time-limited-link', {
        body: {
          action: 'create',
          code_id: codeId,
          code: code,
          expiration_hours: selectedExpiration,
          user_id: user?.id
        }
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setTimeLimitedLink(data.link);
      await trackShare('time_limited_link');
    } catch (err: any) {
      console.error('Error creating time-limited link:', err);
      setLinkError(err.message || 'Failed to create link');
    } finally {
      setCreatingLink(false);
    }
  };

  const getTimeLimitedUrl = () => {
    if (!timeLimitedLink) return '';
    return `${window.location.origin}/redeem?t=${timeLimitedLink.token}`;
  };

  const handleCopyTimeLimitedLink = async () => {
    try {
      await navigator.clipboard.writeText(getTimeLimitedUrl());
      setTimeLimitedCopied(true);
      setTimeout(() => setTimeLimitedCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const getExpirationLabel = (hours: number) => {
    if (hours === 1) return '1 hour';
    if (hours === 6) return '6 hours';
    return '24 hours';
  };

  const formatExpirationTime = (expiresAt: string) => {
    const date = new Date(expiresAt);
    return date.toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <div 
          className="absolute inset-0 bg-black/70 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Modal */}
        <div className="relative bg-charcoal-800 rounded-2xl border border-charcoal-600 w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200 max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-charcoal-600 sticky top-0 bg-charcoal-800 z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center">
                <Share2 className="w-5 h-5 text-gold" />
              </div>
              <div>
                <h3 className="font-semibold text-white">Share Your Code</h3>
                <p className="text-sm text-gray-400">Invite someone to connect</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white hover:bg-charcoal-700 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="p-6">
            {/* Link Preview Card */}
            <div className="bg-charcoal-700 rounded-xl border border-charcoal-600 overflow-hidden mb-6">
              <div className="bg-gradient-to-r from-gold/20 to-gold/10 p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 bg-gold rounded-md flex items-center justify-center">
                    <span className="text-charcoal font-bold text-xs">D</span>
                  </div>
                  <span className="text-sm text-gray-300">dwadido.com</span>
                </div>
                <h4 className="font-semibold text-white mb-1">{shareTitle}</h4>
                <p className="text-sm text-gray-400 line-clamp-2">
                  Someone wants to connect with you! Enter their unique Crush Code to start a conversation.
                </p>

              </div>
              <div className="p-4 bg-charcoal-800">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">Your Code</p>
                    <p className="font-mono text-2xl font-bold text-gold tracking-widest">{code}</p>
                  </div>
                  <div className="w-16 h-16 bg-gold/10 rounded-xl flex items-center justify-center">
                    <svg className="w-8 h-8 text-gold" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                    </svg>
                  </div>
                </div>
              </div>
            </div>

            {/* Share Buttons */}
            <div className="space-y-3">
              {/* Social Platforms - 5 columns */}
              <div className="grid grid-cols-5 gap-2">
                {/* Twitter/X */}
                <button
                  onClick={handleTwitterShare}
                  disabled={tracking === 'twitter'}
                  className="flex flex-col items-center gap-2 p-3 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl transition-all group border border-charcoal-600 hover:border-charcoal-500"
                >
                  {tracking === 'twitter' ? (
                    <Loader2 className="w-5 h-5 text-gray-400 animate-spin" />
                  ) : (
                    <svg className="w-5 h-5 text-gray-300 group-hover:text-white transition-colors" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                    </svg>
                  )}
                  <span className="text-[10px] text-gray-400 group-hover:text-gray-300">X</span>
                </button>

                {/* Facebook */}
                <button
                  onClick={handleFacebookShare}
                  disabled={tracking === 'facebook'}
                  className="flex flex-col items-center gap-2 p-3 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl transition-all group border border-charcoal-600 hover:border-charcoal-500"
                >
                  {tracking === 'facebook' ? (
                    <Loader2 className="w-5 h-5 text-gray-400 animate-spin" />
                  ) : (
                    <svg className="w-5 h-5 text-gray-300 group-hover:text-[#1877F2] transition-colors" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                    </svg>
                  )}
                  <span className="text-[10px] text-gray-400 group-hover:text-gray-300">Facebook</span>
                </button>

                {/* WhatsApp */}
                <button
                  onClick={handleWhatsAppShare}
                  disabled={tracking === 'whatsapp'}
                  className="flex flex-col items-center gap-2 p-3 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl transition-all group border border-charcoal-600 hover:border-charcoal-500"
                >
                  {tracking === 'whatsapp' ? (
                    <Loader2 className="w-5 h-5 text-gray-400 animate-spin" />
                  ) : (
                    <svg className="w-5 h-5 text-gray-300 group-hover:text-[#25D366] transition-colors" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                    </svg>
                  )}
                  <span className="text-[10px] text-gray-400 group-hover:text-gray-300">WhatsApp</span>
                </button>

                {/* SMS */}
                <button
                  onClick={handleSMSShare}
                  disabled={tracking === 'sms'}
                  className="flex flex-col items-center gap-2 p-3 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl transition-all group border border-charcoal-600 hover:border-charcoal-500"
                >
                  {tracking === 'sms' ? (
                    <Loader2 className="w-5 h-5 text-gray-400 animate-spin" />
                  ) : (
                    <MessageSquare className="w-5 h-5 text-gray-300 group-hover:text-[#34C759] transition-colors" />
                  )}
                  <span className="text-[10px] text-gray-400 group-hover:text-gray-300">SMS</span>
                </button>

                {/* Email */}
                <button
                  onClick={handleEmailShare}
                  disabled={tracking === 'email'}
                  className="flex flex-col items-center gap-2 p-3 bg-charcoal-700 hover:bg-charcoal-600 rounded-xl transition-all group border border-charcoal-600 hover:border-charcoal-500"
                >
                  {tracking === 'email' ? (
                    <Loader2 className="w-5 h-5 text-gray-400 animate-spin" />
                  ) : (
                    <Mail className="w-5 h-5 text-gray-300 group-hover:text-[#EA4335] transition-colors" />
                  )}
                  <span className="text-[10px] text-gray-400 group-hover:text-gray-300">Email</span>
                </button>
              </div>

              {/* QR Code Generation Button */}
              <button
                onClick={handleGenerateQRCode}
                disabled={tracking === 'qr_code'}
                className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-purple-500/10 to-indigo-500/10 hover:from-purple-500/20 hover:to-indigo-500/20 border border-purple-500/30 hover:border-purple-500/50 rounded-xl transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
                    {tracking === 'qr_code' ? (
                      <Loader2 className="w-5 h-5 text-purple-400 animate-spin" />
                    ) : (
                      <QrCode className="w-5 h-5 text-purple-400" />
                    )}
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-medium text-white">Generate QR Code</p>
                    <p className="text-xs text-gray-400">Create a scannable code for easy sharing</p>
                  </div>
                </div>
                <ChevronDown className="w-5 h-5 text-gray-400 -rotate-90 group-hover:text-purple-400 transition-colors" />
              </button>

              {/* Print QR Card Button - PREMIUM GATED */}
              <button
                onClick={handlePrintCard}
                disabled={tracking === 'printed_card'}
                className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-pink-500/10 to-rose-500/10 hover:from-pink-500/20 hover:to-rose-500/20 border border-pink-500/30 hover:border-pink-500/50 rounded-xl transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-pink-500/20 rounded-lg flex items-center justify-center">
                    {tracking === 'printed_card' ? (
                      <Loader2 className="w-5 h-5 text-pink-400 animate-spin" />
                    ) : (
                      <Printer className="w-5 h-5 text-pink-400" />
                    )}
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-medium text-white flex items-center gap-2">
                      Print QR Card
                      {!isPremium && <Lock className="w-3 h-3 text-gray-500" />}
                    </p>
                    <p className="text-xs text-gray-400">Business cards with tear-off tabs</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {!isPremium && <Crown className="w-4 h-4 text-gold" />}
                  <ChevronDown className="w-5 h-5 text-gray-400 -rotate-90 group-hover:text-pink-400 transition-colors" />
                </div>
              </button>

              {/* Copy Link Button */}
              <button
                onClick={handleCopyLink}
                disabled={tracking === 'link_copy'}
                className="w-full flex items-center justify-center gap-3 py-3 bg-charcoal-700 hover:bg-charcoal-600 text-gray-300 hover:text-white rounded-xl font-medium transition-all border border-charcoal-600 hover:border-charcoal-500"
              >
                {tracking === 'link_copy' ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : copied ? (
                  <Check className="w-5 h-5 text-gold" />
                ) : (
                  <Copy className="w-5 h-5" />
                )}
                {copied ? 'Link Copied!' : 'Copy Shareable Link'}
              </button>

              {/* Time-Limited Link Section - PREMIUM GATED */}
              <div className="border border-charcoal-600 rounded-xl overflow-hidden">
                <button
                  onClick={handleTimeLimitedSection}
                  className="w-full flex items-center justify-between p-4 bg-charcoal-700 hover:bg-charcoal-600 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center">
                      <Clock className="w-4 h-4 text-purple-400" />
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-medium text-white flex items-center gap-2">
                        Time-Limited Link
                        {!isPremium && <Lock className="w-3 h-3 text-gray-500" />}
                      </p>
                      <p className="text-xs text-gray-400">Create a link that expires</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {!isPremium && <Crown className="w-4 h-4 text-gold" />}
                    <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${showTimeLimitedSection ? 'rotate-180' : ''}`} />
                  </div>
                </button>

                {showTimeLimitedSection && isPremium && (
                  <div className="p-4 bg-charcoal-800 border-t border-charcoal-600 space-y-4">
                    {!timeLimitedLink ? (
                      <>
                        {/* Expiration Selection */}
                        <div>
                          <label className="block text-xs text-gray-400 mb-2">Link expires in:</label>
                          <div className="grid grid-cols-3 gap-2">
                            {([1, 6, 24] as const).map((hours) => (
                              <button
                                key={hours}
                                onClick={() => setSelectedExpiration(hours)}
                                className={`py-2 px-3 rounded-lg text-sm font-medium transition-all ${
                                  selectedExpiration === hours
                                    ? 'bg-purple-500/20 text-purple-400 border border-purple-500/50'
                                    : 'bg-charcoal-700 text-gray-400 border border-charcoal-600 hover:border-charcoal-500'
                                }`}
                              >
                                {getExpirationLabel(hours)}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Info Text */}
                        <div className="flex items-start gap-2 p-3 bg-charcoal-700/50 rounded-lg">
                          <AlertCircle className="w-4 h-4 text-purple-400 mt-0.5 flex-shrink-0" />
                          <p className="text-xs text-gray-400">
                            Time-limited links expire independently of your crush code. 
                            Perfect for sharing with someone you want to connect with soon!
                          </p>
                        </div>

                        {linkError && (
                          <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg">
                            <p className="text-sm text-red-400">{linkError}</p>
                          </div>
                        )}

                        {/* Create Button */}
                        <button
                          onClick={createTimeLimitedLink}
                          disabled={creatingLink}
                          className="w-full py-3 bg-purple-500 hover:bg-purple-600 disabled:bg-charcoal-600 text-white font-medium rounded-xl transition-all flex items-center justify-center gap-2"
                        >
                          {creatingLink ? (
                            <Loader2 className="w-5 h-5 animate-spin" />
                          ) : (
                            <>
                              <Link2 className="w-5 h-5" />
                              Create Time-Limited Link
                            </>
                          )}
                        </button>
                      </>
                    ) : (
                      <>
                        {/* Generated Link Display */}
                        <div className="p-4 bg-purple-500/10 border border-purple-500/30 rounded-xl">
                          <div className="flex items-center gap-2 mb-2">
                            <Check className="w-5 h-5 text-purple-400" />
                            <span className="text-sm font-medium text-purple-400">Link Created!</span>
                          </div>
                          <p className="text-xs text-gray-400 mb-3">
                            Expires: {formatExpirationTime(timeLimitedLink.expires_at)}
                          </p>
                          <div className="bg-charcoal-800 rounded-lg p-3 mb-3">
                            <p className="text-xs text-gray-500 break-all font-mono">
                              {getTimeLimitedUrl()}
                            </p>
                          </div>
                          <button
                            onClick={handleCopyTimeLimitedLink}
                            className="w-full py-2 bg-purple-500 hover:bg-purple-600 text-white font-medium rounded-lg transition-all flex items-center justify-center gap-2"
                          >
                            {timeLimitedCopied ? (
                              <>
                                <Check className="w-4 h-4" />
                                Copied!
                              </>
                            ) : (
                              <>
                                <Copy className="w-4 h-4" />
                                Copy Time-Limited Link
                              </>
                            )}
                          </button>
                        </div>

                        {/* Create Another */}
                        <button
                          onClick={() => setTimeLimitedLink(null)}
                          className="w-full py-2 text-sm text-gray-400 hover:text-white transition-colors"
                        >
                          Create another link
                        </button>
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Link History Section - PREMIUM GATED */}
              <div className="border border-charcoal-600 rounded-xl overflow-hidden">
                <button
                  onClick={handleLinkHistory}
                  className="w-full flex items-center justify-between p-4 bg-charcoal-700 hover:bg-charcoal-600 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-indigo-500/20 rounded-lg flex items-center justify-center">
                      <History className="w-4 h-4 text-indigo-400" />
                    </div>
                    <div className="text-left">
                      <p className="text-sm font-medium text-white flex items-center gap-2">
                        Link History
                        {!isPremium && <Lock className="w-3 h-3 text-gray-500" />}
                      </p>
                      <p className="text-xs text-gray-400">View all your shared links</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {!isPremium && <Crown className="w-4 h-4 text-gold" />}
                    <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${showLinkHistory ? 'rotate-180' : ''}`} />
                  </div>
                </button>

                {showLinkHistory && isPremium && (
                  <div className="border-t border-charcoal-600">
                    <LinkHistorySection
                      codeId={codeId}
                      isExpanded={true}
                      onToggle={() => {}}
                    />
                  </div>
                )}
              </div>

              {/* Native Share (if available) */}
              {typeof navigator !== 'undefined' && navigator.share && (
                <button
                  onClick={handleNativeShare}
                  className="w-full flex items-center justify-center gap-3 py-3 bg-gold hover:bg-gold-400 text-charcoal rounded-xl font-semibold transition-all"
                >
                  <ExternalLink className="w-5 h-5" />
                  More Sharing Options
                </button>
              )}
            </div>

            {/* Share Stats Toggle - PREMIUM GATED */}
            <button
              onClick={handleShowStats}
              className="w-full mt-4 flex items-center justify-center gap-2 py-2 text-gray-400 hover:text-gold transition-colors"
            >
              <BarChart3 className="w-4 h-4" />
              <span className="text-sm">{showStats ? 'Hide' : 'View'} Share Analytics</span>
              {!isPremium && (
                <>
                  <Lock className="w-3 h-3 text-gray-500" />
                  <Crown className="w-4 h-4 text-gold" />
                </>
              )}
            </button>

            {/* Share Stats Panel - Only for Premium */}
            {showStats && isPremium && (
              <div className="mt-4 p-4 bg-charcoal-700 rounded-xl border border-charcoal-600">
                <h4 className="text-sm font-medium text-white mb-3">Share Statistics</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-charcoal-800 rounded-lg p-3">
                    <p className="text-2xl font-bold text-gold">{stats.total}</p>
                    <p className="text-xs text-gray-400">Total Shares</p>
                  </div>
                  <div className="bg-charcoal-800 rounded-lg p-3">
                    <p className="text-2xl font-bold text-white">{stats.link_copies}</p>
                    <p className="text-xs text-gray-400">Link Copies</p>
                  </div>
                </div>
                <div className="mt-3 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">X / Twitter</span>
                    <span className="text-white font-medium">{stats.twitter}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Facebook</span>
                    <span className="text-white font-medium">{stats.facebook}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">WhatsApp</span>
                    <span className="text-white font-medium">{stats.whatsapp}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-gray-400">
                      <MessageSquare className="w-4 h-4 text-green-400" />
                      SMS / Text
                    </div>
                    <span className="text-white font-medium">{stats.sms}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Email</span>
                    <span className="text-white font-medium">{stats.email}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-gray-400">
                      <QrCode className="w-4 h-4 text-purple-400" />
                      QR Codes
                    </div>
                    <span className="text-white font-medium">{stats.qr_code}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2 text-gray-400">
                      <Printer className="w-4 h-4 text-pink-400" />
                      Printed Cards
                    </div>
                    <span className="text-white font-medium">{stats.printed_cards}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Time-Limited Links</span>
                    <span className="text-white font-medium">{stats.time_limited}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-6 pb-6">
            <p className="text-xs text-gray-500 text-center">
              When someone opens your link, they'll see a preview and can enter your code to connect.
            </p>
          </div>
        </div>
      </div>

      {/* QR Code Modal */}
      <QRCodeModal
        isOpen={showQRModal}
        onClose={() => setShowQRModal(false)}
        code={code}
        shareUrl={shareUrl}
        onPrintCard={handlePrintCard}
      />


      {/* Print QR Card Modal - Only render if premium */}
      {isPremium && (
        <PrintableQRCard
          isOpen={showPrintModal}
          onClose={() => setShowPrintModal(false)}
          code={code}
          shareUrl={shareUrl}
          userName={profile?.display_name || 'Anonymous'}
        />
      )}

      {/* Freemium Upsell Modal */}
      <FreemiumUpsell
        isOpen={upsellModal.isOpen}
        onClose={() => setUpsellModal({ ...upsellModal, isOpen: false })}
        trigger={upsellModal.trigger}
      />
    </>
  );
};

export default CrushCodeShare;
