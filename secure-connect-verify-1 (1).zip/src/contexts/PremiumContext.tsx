import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from './AuthContext';
import { withTimeout, TimeoutError } from '@/lib/utils';

// Timeout configuration
const DB_TIMEOUT_MS = 10000; // 10 seconds

// =============================================================================
// DWADIDO FEATURE TIERS - Offline-to-Online Dating
// Core principle: QR codes and Crush Codes are central
// =============================================================================

// Comprehensive Premium Features Interface
export interface PremiumFeatures {
  // ==========================================================================
  // CORE QR FLOW - FREE FOR ALL USERS (Essential for offline-to-online matching)
  // ==========================================================================
  coreQRScanFlow: boolean; // FREE: Scan QR → View profile → Match (core app functionality)
  
  // ==========================================================================
  // CORE CODE FEATURES
  // ==========================================================================
  maxActiveCodes: number;
  codeValidityDays: number;
  unlimitedCodes: boolean;
  codeRenewal: boolean; // PREMIUM: Renew expired codes
  bulkGeneration: boolean; // PREMIUM: Generate multiple codes at once
  
  // ==========================================================================
  // QR & PRINTING - PREMIUM ONLY (advanced QR features are premium)
  // ==========================================================================
  digitalQRSharing: boolean; // FREE: Basic on-screen QR display
  printQRCards: boolean; // PREMIUM: Print-ready QR cards (PDF/templates)
  cardTemplates: boolean; // PREMIUM: Professional card designs
  animatedQRCodes: boolean; // PREMIUM: Branded/animated QR codes
  batchPrintHistory: boolean; // PREMIUM: Track print jobs
  qrScanHistory: boolean; // PREMIUM: QR scan history & analytics
  trackPrintAnalytics: boolean; // PREMIUM: Print analytics
  
  // ==========================================================================
  // ==========================================================================
  // ANALYTICS & INSIGHTS - PREMIUM ONLY
  // NOTE: Dwadido does NOT use compatibility scores or profile completion scores
  // AI explains in natural language, never obscures with hidden rankings
  // ==========================================================================
  codeAnalytics: boolean; // PREMIUM: Code analytics dashboard
  matchAnalytics: boolean; // PREMIUM: Match analytics dashboard
  matchInsights: boolean; // PREMIUM: AI-powered insights (explanations, not scores)
  // REMOVED: compatibilityScores - Dwadido philosophy prohibits scoring
  // REMOVED: profileCompletionScores - Dwadido philosophy prohibits scoring
  verificationAnalytics: boolean;

  // ==========================================================================
  // MATCH ALERTS - Tiered (Basic FREE, Advanced PREMIUM)
  // NOTE: Per Dwadido design, basic alerts should be calm and explain WHY
  // the match exists, not just "You have a new match!" gamification
  // ==========================================================================
  basicMatchAlerts: boolean; // FREE: Calm notification explaining why you connected
  advancedMatchAlerts: boolean; // PREMIUM: Match history, reminders, analytics
  matchAlertHistory: boolean; // PREMIUM: View past match alerts
  matchReminders: boolean; // PREMIUM: Gentle reminders (not urgent "Don't forget!")
  matchAlertAnalytics: boolean; // PREMIUM: Alert engagement analytics

  // ==========================================================================
  // NOTIFICATIONS
  // ==========================================================================
  matchNotifications: boolean; // FREE: Basic match notifications
  pushNotifications: boolean; // PREMIUM: Push notifications
  smsNotifications: boolean; // PREMIUM: SMS for high-intent events
  emailNotifications: boolean; // PREMIUM: Customizable email notifications
  matchExpiringReminders: boolean; // PREMIUM: Match expiring reminders
  offlineMessageAlerts: boolean; // PREMIUM: Offline message alerts
  notificationDigestControl: boolean; // PREMIUM: Full digest control
  basicExpirationAlerts: boolean; // FREE: Basic 24h expiration alerts
  advancedExpirationAlerts: boolean; // PREMIUM: Customizable timing (12h, 6h, 1h)
  notificationHistoryLog: boolean; // PREMIUM: View sent notifications, delivery status, timestamps

  // ==========================================================================
  // CONTACT SETUP (Phone Number is FREE for trust/recovery)
  // ==========================================================================
  phoneNumberSetup: boolean; // FREE: Optional phone number for trust & account recovery

  // ==========================================================================
  // SHARING & GROWTH
  // ==========================================================================
  advancedQRSharing: boolean;
  shareLinkPreview: boolean;
  shareLinkExpiration: boolean;
  linkHistoryView: boolean;
  linkClickTracking: boolean;
  referralRewards: boolean; // PREMIUM: Referral rewards system
  
  // ==========================================================================
  // VERIFICATION & SAFETY
  // ==========================================================================
  profileVerification: boolean;
  ageVerificationBadge: boolean;
  verificationHistory: boolean;
  autoExpireVerifications: boolean;
  adminVerificationDashboard: boolean;
  
  // ==========================================================================
  // LEGACY FEATURES (kept for backwards compatibility)
  // ==========================================================================
  advancedFilters: boolean;
  verificationPriority: boolean;
  videoSpeedDate: boolean;
  earlyPhotoRequest: boolean;
  readReceiptControl: boolean;
}

export interface PremiumSubscription {
  id: string;
  userId: string;
  status: 'active' | 'inactive' | 'cancelled' | 'expired';
  plan: 'monthly' | 'yearly';
  startedAt: string | null;
  expiresAt: string | null;
  cancelledAt: string | null;
  features: PremiumFeatures;
}

// =============================================================================
// FREE TIER - Core dating functionality
// Focus: Basic QR flow (scan → match → chat) + simple match alerts
// =============================================================================
const FREE_FEATURES: PremiumFeatures = {
  // Core QR Flow - FREE for all users (essential for offline-to-online matching)
  coreQRScanFlow: true, // FREE: This is the core app functionality
  
  // Core Code Features - Single active Crush Code
  maxActiveCodes: 1,
  codeValidityDays: 7, // Fixed-time code expiration (auto-expires after 7 days)
  unlimitedCodes: false,
  codeRenewal: false, // PREMIUM only
  bulkGeneration: false, // PREMIUM only
  
  // QR & Printing - Digital QR sharing only (no printing)
  digitalQRSharing: true, // FREE: On-screen QR display
  printQRCards: false, // PREMIUM only
  cardTemplates: false, // PREMIUM only
  animatedQRCodes: false, // PREMIUM only
  batchPrintHistory: false, // PREMIUM only
  qrScanHistory: false, // PREMIUM only
  trackPrintAnalytics: false, // PREMIUM only
  
  // Analytics & Insights - All locked (no scoring features per Dwadido philosophy)
  codeAnalytics: false, // PREMIUM only
  matchAnalytics: false, // PREMIUM only
  matchInsights: false, // PREMIUM only
  // NOTE: compatibilityScores and profileCompletionScores removed - Dwadido prohibits scoring
  verificationAnalytics: false,

  // Match Alerts - Basic only (calm notification explaining why you connected)
  // Per Dwadido design: No "You have X new matches!" gamification
  basicMatchAlerts: true, // FREE: Calm notification explaining why you connected
  advancedMatchAlerts: false, // PREMIUM only
  matchAlertHistory: false, // PREMIUM only
  matchReminders: false, // PREMIUM only
  matchAlertAnalytics: false, // PREMIUM only

  
  // Notifications - Basic match notifications only
  matchNotifications: true, // FREE: Basic match notifications
  pushNotifications: false, // PREMIUM only
  smsNotifications: false, // PREMIUM only
  emailNotifications: false, // PREMIUM only
  matchExpiringReminders: false, // PREMIUM only
  offlineMessageAlerts: false, // PREMIUM only
  notificationDigestControl: false, // PREMIUM only
  basicExpirationAlerts: true, // FREE: Basic 24h expiration alerts
  advancedExpirationAlerts: false, // PREMIUM only
  notificationHistoryLog: false, // PREMIUM only - view sent notifications, delivery status, timestamps

  // Contact Setup - Phone Number is FREE for trust/recovery
  phoneNumberSetup: true, // FREE: Optional phone number for trust & account recovery

  // Sharing & Growth - Basic only
  advancedQRSharing: false,
  shareLinkPreview: false,
  shareLinkExpiration: false,
  linkHistoryView: false,
  linkClickTracking: false,
  referralRewards: false, // PREMIUM only
  
  // Verification & Safety - All locked
  profileVerification: false,
  ageVerificationBadge: false,
  verificationHistory: false,
  autoExpireVerifications: false,
  adminVerificationDashboard: false,
  
  // Legacy features
  advancedFilters: false,
  verificationPriority: false,
  videoSpeedDate: false,
  earlyPhotoRequest: false,
  readReceiptControl: false,
};

// =============================================================================
// PREMIUM TIER - Full power & control
// Focus: Control, clarity, and advanced features
// =============================================================================
const PREMIUM_FEATURES: PremiumFeatures = {
  // Core QR Flow - FREE for all users (essential for offline-to-online matching)
  coreQRScanFlow: true, // FREE: This is the core app functionality (same as free tier)
  
  // Core Code Features - Multiple active codes
  maxActiveCodes: 999,
  codeValidityDays: 90,
  unlimitedCodes: true,
  codeRenewal: true, // Expired code renewal
  bulkGeneration: true, // Bulk code generation
  
  // QR & Printing - Full features
  digitalQRSharing: true,
  printQRCards: true, // Print-ready QR cards (PDF/templates)
  cardTemplates: true, // Professional card designs
  animatedQRCodes: true, // Branded/animated QR codes
  batchPrintHistory: true,
  qrScanHistory: true, // QR scan history
  trackPrintAnalytics: true,
  
  // Analytics & Insights - Full dashboards (no scoring per Dwadido philosophy)
  codeAnalytics: true, // Code analytics dashboard
  matchAnalytics: true, // Match analytics dashboard
  matchInsights: true, // AI-powered insights (explanations, not scores)
  // NOTE: compatibilityScores and profileCompletionScores removed - Dwadido prohibits scoring
  verificationAnalytics: true,


  // Match Alerts - Full features (basic + advanced)
  // Premium users get advanced features like history, reminders, analytics
  // Note: Per Dwadido design, even premium reminders should be gentle, not urgent
  basicMatchAlerts: true, // Calm notification explaining why you connected
  advancedMatchAlerts: true, // Match history, reminders, analytics
  matchAlertHistory: true, // View past match alerts
  matchReminders: true, // Gentle reminders (not urgent "Don't forget!")
  matchAlertAnalytics: true, // Alert engagement analytics

  
  // Notifications - Advanced notifications (SMS, Email, Push)
  matchNotifications: true,
  pushNotifications: true, // Push notifications
  smsNotifications: true, // SMS for high-intent events
  emailNotifications: true, // Customizable email notifications
  matchExpiringReminders: true,
  offlineMessageAlerts: true,
  notificationDigestControl: true,
  basicExpirationAlerts: true,
  advancedExpirationAlerts: true, // 12h, 6h, 1h customizable alerts
  notificationHistoryLog: true, // View sent notifications, delivery status, timestamps

  // Contact Setup - Phone Number is FREE for all users
  phoneNumberSetup: true, // Available for all users

  // Sharing & Growth
  advancedQRSharing: true,
  shareLinkPreview: true,
  shareLinkExpiration: true,
  linkHistoryView: true,
  linkClickTracking: true,
  referralRewards: true, // Referral rewards system
  
  // Verification & Safety
  profileVerification: true,
  ageVerificationBadge: true,
  verificationHistory: true,
  autoExpireVerifications: true,
  adminVerificationDashboard: true,
  
  // Legacy features
  advancedFilters: true,
  verificationPriority: true,
  videoSpeedDate: true,
  earlyPhotoRequest: true,
  readReceiptControl: true,
};




// Feature categories for UI display
export type FeatureCategory = 
  | 'printing_qr'
  | 'analytics'
  | 'notifications'
  | 'sharing'
  | 'verification'
  | 'codes';

// =============================================================================
// MVP PRIORITY FLAGS
// Use these to conditionally show/hide features in the UI
// =============================================================================
export const MVP_FEATURES = {
  // -------------------------------------------------------------------------
  // CORE MVP (Priority 1) - Must work for launch
  // -------------------------------------------------------------------------
  coreQRFlow: true, // scan → match → chat (FREE for all users)
  basicMatchAlerts: true, // Simple match notifications (FREE for all users)
  basicExpirationAlerts: true, // Basic code expiration alerts (FREE)
  featureFlags: true, // Free vs Premium tier gating
  
  // -------------------------------------------------------------------------
  // INTERNAL/BACKEND ONLY - Not user-facing features
  // These are infrastructure requirements, not monetizable features
  // -------------------------------------------------------------------------
  stripeSubscription: true, // Internal: Payment processing backend
  // Note: Stripe setup is internal/admin only - not exposed to users
  
  // -------------------------------------------------------------------------
  // POST-MVP (Priority 2) - User-facing features, deferred
  // -------------------------------------------------------------------------
  matchAnalyticsPage: false, // Premium feature, staged for later
  referralRewards: true, // Now enabled for Premium tier
  advancedDashboards: false, // Bulk tooling, analytics
  
  // -------------------------------------------------------------------------
  // POST-MVP (Priority 3) - Enterprise/Admin features, deprioritized
  // These should NOT be prominently displayed until after MVP launch
  // -------------------------------------------------------------------------
  slackAlerts: false, // Slack integration for job alerts
  autoJobRecovery: false, // Automatic job recovery
  abTesting: false, // A/B testing framework
  opsDashboards: false, // Operations dashboards
  enterpriseFeatures: false, // Enterprise-level features
};



// =============================================================================
// FEATURE CATEGORIES FOR UI DISPLAY
// =============================================================================
export const FEATURE_CATEGORIES: Record<FeatureCategory, {
  title: string;
  description: string;
  features: (keyof PremiumFeatures)[];
}> = {
  codes: {
    title: 'Crush Codes',
    description: 'Create and manage your connection codes',
    features: ['unlimitedCodes', 'codeRenewal', 'bulkGeneration', 'basicExpirationAlerts', 'advancedExpirationAlerts'],
  },
  printing_qr: {
    title: 'Printing & QR',
    description: 'Print professional cards and QR codes',
    features: ['digitalQRSharing', 'printQRCards', 'cardTemplates', 'animatedQRCodes', 'batchPrintHistory', 'qrScanHistory', 'trackPrintAnalytics'],
  },
  analytics: {
    title: 'Analytics & Insights',
    description: 'Track and optimize your connections',
    features: ['codeAnalytics', 'matchAnalytics', 'matchInsights', 'verificationAnalytics'],
    // NOTE: compatibilityScores and profileCompletionScores removed - Dwadido prohibits scoring
  },

  notifications: {
    title: 'Notifications',
    description: 'Stay updated on your matches',
    features: ['matchNotifications', 'pushNotifications', 'smsNotifications', 'emailNotifications', 'matchExpiringReminders', 'offlineMessageAlerts'],
  },
  sharing: {
    title: 'Sharing & Growth',
    description: 'Advanced sharing and tracking',
    features: ['advancedQRSharing', 'shareLinkPreview', 'shareLinkExpiration', 'linkHistoryView', 'linkClickTracking', 'referralRewards'],
  },
  verification: {
    title: 'Verification & Safety',
    description: 'Build trust with verified profiles',
    features: ['profileVerification', 'ageVerificationBadge', 'verificationHistory', 'autoExpireVerifications'],
  },
};


interface PremiumContextType {
  isPremium: boolean;
  subscription: PremiumSubscription | null;
  features: PremiumFeatures;
  loading: boolean;
  error: string | null;
  refreshSubscription: () => Promise<void>;
  canUseFeature: (feature: keyof PremiumFeatures) => boolean;
  daysRemaining: number | null;
  getFeatureCategory: (feature: keyof PremiumFeatures) => FeatureCategory | null;
  clearError: () => void;
}

const PremiumContext = createContext<PremiumContextType | undefined>(undefined);

export const PremiumProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { user, profile } = useAuth();
  const [subscription, setSubscription] = useState<PremiumSubscription | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const clearError = () => setError(null);

  const fetchSubscription = async (userId: string) => {
    try {
      // First check the profiles table for quick premium status
      const profileQuery = supabase
        .from('profiles')
        .select('is_premium, subscription_status, stripe_customer_id, stripe_subscription_id')
        .eq('id', userId)
        .single();

      // Then get detailed subscription info
      const subscriptionQuery = supabase
        .from('premium_subscriptions')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      // Run both queries with timeout
      const [profileResult, subscriptionResult] = await Promise.all([
        withTimeout(profileQuery, DB_TIMEOUT_MS, 'Fetch profile premium status').catch(err => {
          console.warn('[Premium] Profile query failed:', err);
          return { data: null, error: err };
        }),
        withTimeout(subscriptionQuery, DB_TIMEOUT_MS, 'Fetch subscription').catch(err => {
          console.warn('[Premium] Subscription query failed:', err);
          return { data: null, error: err };
        })
      ]);

      const profileData = profileResult.data;
      const data = subscriptionResult.data;
      const subscriptionError = subscriptionResult.error;

      if (subscriptionError && !(subscriptionError instanceof TimeoutError)) {
        console.error('Error fetching subscription:', subscriptionError);
        // Don't set error state for non-timeout errors - just use free tier
      }

      if (data) {
        // Check if subscription has expired
        const isExpired = data.expires_at && new Date(data.expires_at) < new Date();
        
        // Use the most accurate status - prefer profile's subscription_status if available
        let status = data.status;
        if (profileData?.subscription_status) {
          // Map Stripe statuses to our internal statuses
          const stripeStatus = profileData.subscription_status;
          if (stripeStatus === 'active' || stripeStatus === 'trialing') {
            status = 'active';
          } else if (stripeStatus === 'past_due') {
            status = 'active'; // Still active during grace period
          } else if (stripeStatus === 'cancelled' || stripeStatus === 'canceled') {
            status = 'cancelled';
          } else if (isExpired) {
            status = 'expired';
          }
        } else if (isExpired) {
          status = 'expired';
        }

        setSubscription({
          id: data.id,
          userId: data.user_id,
          status,
          plan: data.plan,
          startedAt: data.started_at,
          expiresAt: data.expires_at,
          cancelledAt: data.cancelled_at,
          features: PREMIUM_FEATURES, // Premium users get all features
        });
      } else if (profileData?.is_premium) {
        // Profile says premium but no subscription record - create a basic one
        setSubscription({
          id: 'profile-premium',
          userId: userId,
          status: 'active',
          plan: 'monthly',
          startedAt: null,
          expiresAt: null,
          cancelledAt: null,
          features: PREMIUM_FEATURES,
        });
      } else {
        setSubscription(null);
      }
    } catch (err) {
      if (err instanceof TimeoutError) {
        console.error('[Premium] Subscription fetch timed out');
        setError('Loading subscription status is taking longer than expected.');
        // Fall back to free tier on timeout
        setSubscription(null);
      } else {
        console.error('Error fetching subscription:', err);
        // Fall back to free tier on error
        setSubscription(null);
      }
    } finally {
      setLoading(false);
    }
  };

  const refreshSubscription = async () => {
    if (user) {
      setLoading(true);
      setError(null);
      await fetchSubscription(user.id);
    }
  };

  useEffect(() => {
    if (user) {
      fetchSubscription(user.id);
    } else {
      setSubscription(null);
      setLoading(false);
    }
  }, [user]);



  const isPremium = subscription?.status === 'active';

  const features = isPremium ? PREMIUM_FEATURES : FREE_FEATURES;

  const canUseFeature = (feature: keyof PremiumFeatures): boolean => {
    const value = features[feature];
    if (typeof value === 'boolean') {
      return value;
    }
    // For numeric features, always return true (the limit is checked elsewhere)
    return true;
  };

  const getFeatureCategory = (feature: keyof PremiumFeatures): FeatureCategory | null => {
    for (const [category, config] of Object.entries(FEATURE_CATEGORIES)) {
      if (config.features.includes(feature)) {
        return category as FeatureCategory;
      }
    }
    return null;
  };

  const daysRemaining = subscription?.expiresAt
    ? Math.max(0, Math.ceil((new Date(subscription.expiresAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))
    : null;

  return (
    <PremiumContext.Provider
      value={{
        isPremium,
        subscription,
        features,
        loading,
        error,
        refreshSubscription,
        canUseFeature,
        daysRemaining,
        getFeatureCategory,
        clearError,
      }}
    >
      {children}
    </PremiumContext.Provider>
  );
};

export const usePremium = () => {
  const context = useContext(PremiumContext);
  if (context === undefined) {
    throw new Error('usePremium must be used within a PremiumProvider');
  }
  return context;
};

// Premium plan pricing (EUR for Europe)
export const PREMIUM_PLANS = {
  monthly: {
    id: 'monthly',
    name: 'Monthly',
    price: 9.99,
    currency: 'EUR',
    currencySymbol: '€',
    interval: 'month',
    description: 'Billed monthly',
  },
  yearly: {
    id: 'yearly',
    name: 'Yearly',
    price: 79.99,
    currency: 'EUR',
    currencySymbol: '€',
    interval: 'year',
    description: 'Save 33% - Billed annually',
    savings: '33%',
  },
};


// =============================================================================
// PREMIUM FEATURE DESCRIPTIONS FOR MARKETING/UI
// Organized by tier clarity: FREE vs PREMIUM
// =============================================================================
export const PREMIUM_FEATURE_DESCRIPTIONS = [
  // -------------------------------------------------------------------------
  // CODES - Core to Dwadido
  // -------------------------------------------------------------------------
  {
    id: 'unlimited_codes',
    title: 'Unlimited Crush Codes',
    description: 'Create as many codes as you want, whenever you want',
    icon: 'infinity',
    category: 'codes',
    free: '1 code (single-use)',
    premium: 'Unlimited codes',
  },
  {
    id: 'code_renewal',
    title: 'Code Renewal',
    description: 'Extend or renew expired codes to keep connections alive',
    icon: 'refresh-cw',
    category: 'codes',
    free: 'No renewal',
    premium: 'Unlimited renewals',
  },
  {
    id: 'bulk_generation',
    title: 'Bulk Code Generation',
    description: 'Generate multiple codes at once for events or networking',
    icon: 'layers',
    category: 'codes',
    free: 'Not available',
    premium: 'Up to 20 at once',
  },
  // -------------------------------------------------------------------------
  // PRINTING & QR - Premium tier
  // -------------------------------------------------------------------------
  {
    id: 'print_qr_cards',
    title: 'Print QR Cards',
    description: 'Create beautiful printable business cards with your QR code',
    icon: 'printer',
    category: 'printing_qr',
    free: 'Digital only',
    premium: 'PDF & templates',
  },
  {
    id: 'card_templates',
    title: 'Card Templates',
    description: 'Choose from professional card designs and color themes',
    icon: 'palette',
    category: 'printing_qr',
    free: 'Not available',
    premium: '8+ templates',
  },
  {
    id: 'qr_scan_history',
    title: 'QR Scan History',
    description: 'Track when and where your QR codes are scanned',
    icon: 'history',
    category: 'printing_qr',
    free: 'Not available',
    premium: 'Full history',
  },
  {
    id: 'animated_qr',
    title: 'Animated QR Codes',
    description: 'Stand out with branded, animated QR codes',
    icon: 'sparkles',
    category: 'printing_qr',
    free: 'Not available',
    premium: 'Animated & branded',
  },
  // -------------------------------------------------------------------------
  // ANALYTICS - Premium tier
  // -------------------------------------------------------------------------
  {
    id: 'code_analytics',
    title: 'Code Analytics Dashboard',
    description: 'Track scans, shares, timestamps, and conversion rates',
    icon: 'bar-chart-3',
    category: 'analytics',
    free: 'Not available',
    premium: 'Full analytics',
  },
  {
    id: 'match_analytics',
    title: 'Match Analytics',
    description: 'Understand your matching patterns and success rates',
    icon: 'trending-up',
    category: 'analytics',
    free: 'Not available',
    premium: 'Detailed insights',
  },
  {
    id: 'match_insights',
    title: 'Match Insights',
    description: 'Get AI-powered insights about your connections',
    icon: 'sparkles',
    category: 'analytics',
    free: 'Not available',
    premium: 'AI insights',
  },
  // -------------------------------------------------------------------------
  // NOTIFICATIONS - Advanced is Premium
  // -------------------------------------------------------------------------
  {
    id: 'push_notifications',
    title: 'Push Notifications',
    description: 'Get instant alerts for matches and messages',
    icon: 'bell',
    category: 'notifications',
    free: 'Not available',
    premium: 'Real-time alerts',
  },
  {
    id: 'sms_notifications',
    title: 'SMS Notifications',
    description: 'Receive SMS for high-intent events like mutual matches',
    icon: 'smartphone',
    category: 'notifications',
    free: 'Not available',
    premium: 'High-intent SMS',
  },
  {
    id: 'email_notifications',
    title: 'Email Notifications',
    description: 'Receive customizable email updates about your connections',
    icon: 'mail',
    category: 'notifications',
    free: 'Not available',
    premium: 'Customizable',
  },
  {

    id: 'match_expiring_reminders',
    title: 'Connection Reminders',
    description: 'Optional, gentle reminders about your connections when you want them',
    icon: 'clock',
    category: 'notifications',
    free: 'Not available',
    premium: 'Supportive reminders',
  },

  // -------------------------------------------------------------------------
  // SHARING - Premium tier
  // -------------------------------------------------------------------------
  {
    id: 'link_history',
    title: 'Link History',
    description: 'View and manage all your shared links',
    icon: 'link',
    category: 'sharing',
    free: 'Not available',
    premium: 'Full history',
  },
  {
    id: 'link_click_tracking',
    title: 'Link Click Tracking',
    description: 'See who clicked your shared links',
    icon: 'mouse-pointer',
    category: 'sharing',
    free: 'Not available',
    premium: 'Detailed tracking',
  },
  {
    id: 'time_limited_links',
    title: 'Time-Limited Links',
    description: 'Create links that expire after a set time',
    icon: 'timer',
    category: 'sharing',
    free: 'Not available',
    premium: '1h, 6h, 24h options',
  },
  {
    id: 'referral_rewards',
    title: 'Referral Rewards',
    description: 'Earn rewards for referring friends to Dwadido',
    icon: 'heart',
    category: 'sharing',
    free: 'Not available',
    premium: 'Earn rewards',
  },
  // -------------------------------------------------------------------------
  // VERIFICATION - Premium tier
  // -------------------------------------------------------------------------
  {
    id: 'profile_verification',
    title: 'Profile Verification',
    description: 'Get verified to build trust with matches',
    icon: 'badge-check',
    category: 'verification',
    free: 'Not available',
    premium: 'Priority processing',
  },
  {
    id: 'age_verification',
    title: 'Age Verification Badge',
    description: 'Display a verified age badge on your profile',
    icon: 'shield-check',
    category: 'verification',
    free: 'Not available',
    premium: 'Verified badge',
  },
];

// Export FREE_FEATURES and PREMIUM_FEATURES for testing/reference
export { FREE_FEATURES, PREMIUM_FEATURES };
