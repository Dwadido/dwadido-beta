import React, { useState, useEffect } from 'react';
import { Bell, BellOff, X, Check } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import {
  isPushSupported,
  getNotificationPermission,
  requestNotificationPermission,
  subscribeToPush,
  registerServiceWorker,
} from '@/lib/notifications';

// =============================================================================
// DWADIDO NOTIFICATION PERMISSION BANNER
// 
// Design Philosophy (from Dwadido AI Matching Instructions):
// - Calm, non-urgent language
// - NO urgency phrases like "Never miss!" or "Stay in the loop!"
// - Respectful, user-controlled approach
// - Clear explanation of what notifications do
// 
// Users should feel: Understood, Respected, In control
// =============================================================================

interface NotificationPermissionBannerProps {
  variant?: 'banner' | 'modal' | 'inline';
  onDismiss?: () => void;
  showOnlyOnce?: boolean;
}

const NotificationPermissionBanner: React.FC<NotificationPermissionBannerProps> = ({
  variant = 'banner',
  onDismiss,
  showOnlyOnce = true,
}) => {
  const { user } = useAuth();
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isVisible, setIsVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Check if notifications are supported
    if (!isPushSupported()) {
      setIsVisible(false);
      return;
    }

    // Check current permission
    const currentPermission = getNotificationPermission();
    setPermission(currentPermission);

    // Check if user has dismissed before
    if (showOnlyOnce) {
      const hasDismissed = localStorage.getItem('notification_banner_dismissed');
      if (hasDismissed === 'true') {
        setDismissed(true);
        setIsVisible(false);
        return;
      }
    }

    // Show banner only if permission is 'default' (not yet asked)
    if (currentPermission === 'default' && user) {
      // Delay showing the banner slightly for better UX
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [user, showOnlyOnce]);

  const handleEnableNotifications = async () => {
    setIsLoading(true);

    try {
      // Register service worker first
      await registerServiceWorker();

      // Request permission
      const newPermission = await requestNotificationPermission();
      setPermission(newPermission);

      if (newPermission === 'granted' && user) {
        // Subscribe to push notifications
        await subscribeToPush(user.id);
        setShowSuccess(true);

        // Hide after showing success
        setTimeout(() => {
          handleDismiss();
        }, 2000);
      } else if (newPermission === 'denied') {
        // Permission denied, hide banner
        setTimeout(() => {
          handleDismiss();
        }, 3000);
      }
    } catch (error) {
      console.error('Error enabling notifications:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDismiss = () => {
    setIsVisible(false);
    setDismissed(true);
    
    if (showOnlyOnce) {
      localStorage.setItem('notification_banner_dismissed', 'true');
    }
    
    onDismiss?.();
  };

  const handleRemindLater = () => {
    setIsVisible(false);
    // Don't set dismissed in localStorage so it shows again next session
    onDismiss?.();
  };

  if (!isVisible || dismissed || !user) return null;

  // Success state - calm confirmation
  if (showSuccess) {
    return (
      <div className={`${variant === 'banner' ? 'fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-50' : ''}`}>
        <div className="bg-green-500/20 border border-green-500/30 rounded-2xl p-4 backdrop-blur-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500/20 rounded-full flex items-center justify-center">
              <Check className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="font-medium text-green-400">Notifications enabled</p>
              <p className="text-sm text-green-300/70">You'll receive updates for new connections and messages.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Permission denied state - calm, informative
  if (permission === 'denied') {
    return (
      <div className={`${variant === 'banner' ? 'fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-50' : ''}`}>
        <div className="bg-charcoal-700 border border-charcoal-600 rounded-2xl p-4 shadow-xl">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 bg-amber-500/20 rounded-full flex items-center justify-center flex-shrink-0">
              <BellOff className="w-5 h-5 text-amber-400" />
            </div>
            <div className="flex-1">
              <p className="font-medium text-white">Notifications disabled</p>
              <p className="text-sm text-gray-400 mt-1">
                You can enable them anytime in your browser settings if you change your mind.
              </p>
              <button
                onClick={handleDismiss}
                className="mt-3 text-sm text-[#C9A24D] hover:text-[#d4af5a] font-medium"
              >
                Got it
              </button>
            </div>
            <button
              onClick={handleDismiss}
              className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-charcoal-600 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Banner variant - calm, non-urgent
  if (variant === 'banner') {
    return (
      <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-50 animate-in slide-in-from-bottom-4 duration-300">
        <div className="bg-charcoal-700 border border-charcoal-600 rounded-2xl p-4 shadow-xl">
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 bg-[#C9A24D]/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <Bell className="w-6 h-6 text-[#C9A24D]" />
            </div>
            <div className="flex-1 min-w-0">
              {/* Calm, non-urgent language */}
              <p className="font-semibold text-white">Browser notifications</p>
              <p className="text-sm text-gray-400 mt-1">
                Receive updates when you have new connections or messages, even when you're not on this page.
              </p>
              <div className="flex items-center gap-2 mt-3">
                <button
                  onClick={handleEnableNotifications}
                  disabled={isLoading}
                  className="px-4 py-2 bg-[#C9A24D] text-charcoal text-sm font-semibold rounded-xl hover:bg-[#d4af5a] transition-all disabled:opacity-50 flex items-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-charcoal border-t-transparent rounded-full animate-spin" />
                      Enabling...
                    </>
                  ) : (
                    <>
                      <Bell className="w-4 h-4" />
                      Enable
                    </>
                  )}
                </button>
                <button
                  onClick={handleRemindLater}
                  className="px-4 py-2 text-sm text-gray-400 hover:text-white transition-colors"
                >
                  Not now
                </button>
              </div>
            </div>
            <button
              onClick={handleDismiss}
              className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-charcoal-600 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Modal variant - calm, informative
  if (variant === 'modal') {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <div className="bg-charcoal-700 border border-charcoal-600 rounded-2xl p-6 max-w-md w-full shadow-2xl animate-in zoom-in-95 duration-200">
          <div className="text-center">
            <div className="w-16 h-16 bg-[#C9A24D]/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Bell className="w-8 h-8 text-[#C9A24D]" />
            </div>
            {/* Calm, non-urgent language */}
            <h3 className="text-xl font-bold text-white mb-2">Browser notifications</h3>
            <p className="text-gray-400 mb-6">
              Would you like to receive updates when you have new connections or messages?
            </p>

            {/* Benefits - calm language */}
            <div className="bg-charcoal-600 rounded-xl p-4 mb-6 text-left">
              <p className="text-sm font-medium text-gray-300 mb-3">You'll be notified about:</p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 text-sm text-gray-400">
                  <div className="w-5 h-5 bg-[#C9A24D]/20 rounded-full flex items-center justify-center">
                    <Check className="w-3 h-3 text-[#C9A24D]" />
                  </div>
                  New connections
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-400">
                  <div className="w-5 h-5 bg-blue-500/20 rounded-full flex items-center justify-center">
                    <Check className="w-3 h-3 text-blue-400" />
                  </div>
                  Messages from connections
                </li>
                <li className="flex items-center gap-2 text-sm text-gray-400">
                  <div className="w-5 h-5 bg-green-500/20 rounded-full flex items-center justify-center">
                    <Check className="w-3 h-3 text-green-400" />
                  </div>
                  Meeting suggestions
                </li>
              </ul>
            </div>

            <div className="flex flex-col gap-3">
              <button
                onClick={handleEnableNotifications}
                disabled={isLoading}
                className="w-full py-3 bg-[#C9A24D] text-charcoal font-semibold rounded-xl hover:bg-[#d4af5a] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-charcoal border-t-transparent rounded-full animate-spin" />
                    Enabling...
                  </>
                ) : (
                  <>
                    <Bell className="w-5 h-5" />
                    Enable notifications
                  </>
                )}
              </button>
              <button
                onClick={handleDismiss}
                className="w-full py-3 text-gray-400 hover:text-white font-medium transition-colors"
              >
                Not now
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Inline variant - calm, non-urgent
  return (
    <div className="bg-[#C9A24D]/10 border border-[#C9A24D]/20 rounded-xl p-4">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 bg-[#C9A24D]/20 rounded-xl flex items-center justify-center flex-shrink-0">
          <Bell className="w-5 h-5 text-[#C9A24D]" />
        </div>
        <div className="flex-1">
          {/* Calm, non-urgent language */}
          <p className="font-medium text-white">Browser notifications</p>
          <p className="text-sm text-gray-400 mt-1">
            Receive updates for new connections and messages when you're not on this page.
          </p>
          <button
            onClick={handleEnableNotifications}
            disabled={isLoading}
            className="mt-3 px-4 py-2 bg-[#C9A24D] text-charcoal text-sm font-semibold rounded-xl hover:bg-[#d4af5a] transition-all disabled:opacity-50 flex items-center gap-2"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-charcoal border-t-transparent rounded-full animate-spin" />
                Enabling...
              </>
            ) : (
              <>
                <Bell className="w-4 h-4" />
                Enable
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default NotificationPermissionBanner;
