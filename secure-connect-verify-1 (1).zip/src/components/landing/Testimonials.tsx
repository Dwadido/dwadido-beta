import React from 'react';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Sarah Chen',
    role: 'Product Designer',
    avatar: null,
    content: 'Finally, a platform where I feel safe connecting. The verified intent system means I only talk to people who genuinely want to connect.',
    rating: 5
  },
  {
    name: 'Marcus Johnson',
    role: 'Software Engineer',
    avatar: null,
    content: 'The 17-day window encourages real-world connection. It\'s refreshing to use an app that actually wants you to meet people offline.',
    rating: 5
  },
  {
    name: 'Emily Rodriguez',
    role: 'Marketing Manager',
    avatar: null,
    content: 'I use Dwadido for professional networking too. The mutual consent model works perfectly for business introductions.',
    rating: 5
  },
  {
    name: 'David Kim',
    role: 'Entrepreneur',
    avatar: null,
    content: 'No more spam, no more unwanted messages. Every connection on Dwadido is intentional and meaningful.',
    rating: 5
  },
  {
    name: 'Lisa Thompson',
    role: 'Event Coordinator',
    avatar: null,
    content: 'Perfect for events! Attendees can exchange codes and only connect if both parties are interested. Game changer.',
    rating: 5
  },
  {
    name: 'James Wilson',
    role: 'Consultant',
    avatar: null,
    content: 'The controlled progression stages give me confidence that my privacy is protected at every step.',
    rating: 5
  }
];

const Testimonials: React.FC = () => {
  return (
    <section className="py-24 bg-charcoal">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold/10 rounded-full text-gold font-medium text-sm mb-6 border border-gold/20">
            <Star className="w-4 h-4" />
            Testimonials
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
            Loved by thousands of
            <span className="text-gold"> verified users</span>
          </h2>
          <p className="text-lg text-gray-400">
            See what our community says about the verified intent connection experience.
          </p>
        </div>

        {/* Testimonials grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-charcoal-700 rounded-2xl p-8 border border-charcoal-600 hover:border-gold/30 transition-all duration-300"
            >
              {/* Quote icon */}
              <div className="mb-4">
                <Quote className="w-8 h-8 text-gold/30" />
              </div>

              {/* Content */}
              <p className="text-gray-300 mb-6 leading-relaxed">
                "{testimonial.content}"
              </p>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-gold text-gold" />
                ))}
              </div>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gold/10 border border-gold/30 flex items-center justify-center text-gold font-semibold">
                  {testimonial.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <p className="font-semibold text-white">{testimonial.name}</p>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Trust indicator */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-2 text-gray-400">
            <div className="flex -space-x-2">
              {['SC', 'MJ', 'ER', 'DK', 'LT'].map((initials, i) => (
                <div
                  key={i}
                  className="w-8 h-8 rounded-full border-2 border-charcoal bg-gold/10 flex items-center justify-center text-gold text-xs font-medium"
                >
                  {initials}
                </div>
              ))}
            </div>
            <span className="ml-2">Join <strong className="text-gold">25,000+</strong> verified users</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
