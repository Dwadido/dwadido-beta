import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { 
  Download, Trash2, Loader2, CheckCircle, AlertTriangle, 
  FileText, Shield, Clock, X 
} from 'lucide-react';

const GDPRSettings: React.FC = () => {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  
  const [exporting, setExporting] = useState(false);
  const [exportComplete, setExportComplete] = useState(false);
  const [exportData, setExportData] = useState<any>(null);
  
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteReason, setDeleteReason] = useState('');
  const [confirmText, setConfirmText] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState('');

  // Handle body scroll lock for iOS when modal is open
  useEffect(() => {
    if (showDeleteModal) {
      const scrollY = window.scrollY;
      document.body.style.position = 'fixed';
      document.body.style.top = `-${scrollY}px`;
      document.body.style.width = '100%';
    } else {
      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);
    }

    return () => {
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.width = '';
    };
  }, [showDeleteModal]);

  const handleExportData = async () => {
    setExporting(true);
    try {
      const { data, error } = await supabase.functions.invoke('export-user-data', {
        body: {}
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);

      setExportData(data.data);
      setExportComplete(true);
    } catch (err: any) {
      console.error('Export failed:', err);
      alert(err.message || 'Failed to export data');
    } finally {
      setExporting(false);
    }
  };

  const downloadExport = () => {
    if (!exportData) return;
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dwadido-data-export-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDeleteAccount = async () => {
    if (confirmText !== 'DELETE') {
      setDeleteError('Please type DELETE to confirm');
      return;
    }

    setDeleting(true);
    setDeleteError('');

    try {
      const { data, error } = await supabase.functions.invoke('delete-user-account', {
        body: {
          reason: deleteReason || undefined,
          confirm_deletion: true
        }
      });

      if (error) throw error;
      if (data.error) throw new Error(data.error);

      await signOut();
      navigate('/');
    } catch (err: any) {
      setDeleteError(err.message || 'Failed to delete account');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Data Export Section */}
      <div className="bg-[#1C1C1C] rounded-2xl border border-[#2a2a2a] p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-[#C9A24D]/20 rounded-xl flex items-center justify-center flex-shrink-0">
            <Download className="w-6 h-6 text-[#C9A24D]" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-white">Export Your Data</h3>
            <p className="text-gray-400 mt-1 text-sm">
              Download a copy of all your personal data in JSON format.
            </p>

            <div className="mt-4 p-4 bg-[#141414] rounded-xl border border-[#2a2a2a]">
              <h4 className="font-medium text-white mb-2 flex items-center gap-2">
                <FileText className="w-4 h-4 text-[#C9A24D]" />
                What's included:
              </h4>
              <ul className="text-sm text-gray-400 space-y-1">
                <li>• Profile information</li>
                <li>• Crush Codes you've created</li>

                <li>• Connection history & Messages</li>
              </ul>
            </div>

            {exportComplete && exportData ? (
              <div className="mt-4 p-4 bg-[#C9A24D]/10 border border-[#C9A24D]/30 rounded-xl">
                <div className="flex items-center gap-2 text-[#C9A24D] font-medium mb-2">
                  <CheckCircle className="w-5 h-5" />
                  Export Ready
                </div>
                <button
                  onClick={downloadExport}
                  className="px-4 py-2 bg-[#C9A24D] text-[#141414] font-medium rounded-xl hover:bg-[#D4AF5B] transition-all flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Download JSON File
                </button>
              </div>
            ) : (
              <button
                onClick={handleExportData}
                disabled={exporting}
                className="mt-4 px-6 py-3 bg-[#C9A24D] text-[#141414] font-medium rounded-xl hover:bg-[#D4AF5B] transition-all disabled:opacity-50 flex items-center gap-2"
              >
                {exporting ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Preparing Export...
                  </>
                ) : (
                  <>
                    <Download className="w-5 h-5" />
                    Request Data Export
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Account Deletion Section */}
      <div className="bg-[#1C1C1C] rounded-2xl border border-red-500/30 p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-red-500/20 rounded-xl flex items-center justify-center flex-shrink-0">
            <Trash2 className="w-6 h-6 text-red-400" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-red-400">Delete Your Account</h3>
            <p className="text-gray-400 mt-1 text-sm">
              Permanently delete your account and all associated data.
            </p>

            <button
              onClick={() => setShowDeleteModal(true)}
              className="mt-4 px-6 py-3 bg-red-500 text-white font-medium rounded-xl hover:bg-red-600 transition-all flex items-center gap-2"
            >
              <Trash2 className="w-5 h-5" />
              Delete My Account
            </button>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden" style={{ WebkitOverflowScrolling: 'touch' }}>
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setShowDeleteModal(false)} />
          
          <div className="relative min-h-full flex items-center justify-center p-4 py-8">
            <div className="relative bg-[#1C1C1C] rounded-2xl w-full max-w-md shadow-2xl border border-[#2a2a2a]">
              <div className="flex items-center justify-between p-6 border-b border-[#2a2a2a]">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-red-500/20 rounded-xl flex items-center justify-center">
                    <AlertTriangle className="w-5 h-5 text-red-400" />
                  </div>
                  <h2 className="text-lg font-bold text-white">Delete Account</h2>
                </div>
                <button
                  onClick={() => setShowDeleteModal(false)}
                  className="p-2 hover:bg-[#2a2a2a] rounded-xl transition-colors"
                >
                  <X className="w-5 h-5 text-gray-400" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl">
                  <p className="text-red-400 font-medium">
                    This action is permanent and cannot be undone.
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Type <span className="font-bold text-red-400">DELETE</span> to confirm
                  </label>
                  <input
                    type="text"
                    value={confirmText}
                    onChange={(e) => setConfirmText(e.target.value)}
                    placeholder="Type DELETE"
                    className="w-full px-4 py-3 bg-[#141414] border border-[#2a2a2a] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>

                {deleteError && (
                  <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-sm">
                    {deleteError}
                  </div>
                )}

                <div className="flex gap-3">
                  <button
                    onClick={() => setShowDeleteModal(false)}
                    className="flex-1 py-3 bg-[#2a2a2a] text-gray-300 font-medium rounded-xl hover:bg-[#333333] transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleDeleteAccount}
                    disabled={deleting || confirmText !== 'DELETE'}
                    className="flex-1 py-3 bg-red-500 text-white font-medium rounded-xl hover:bg-red-600 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {deleting ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Deleting...
                      </>
                    ) : (
                      'Delete Forever'
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GDPRSettings;
