// Global data for countries, cities, and timezones
// This provides static data that can be used before database is loaded

// ============================================================================
// DWADIDO CORE CONSTANTS
// ============================================================================

/**
 * Dwadido code expiration: 17 days (the core concept window).
 * All code generation must use this value — NOT 48h, 72h, or 7d.
 * 17 days × 24 hours = 408 hours.
 */
export const DWADIDO_CODE_EXPIRY_HOURS = 408;
export const DWADIDO_CODE_EXPIRY_DAYS = 17;


export interface Country {
  code: string;
  name: string;
  flag: string;
}

export interface City {
  name: string;
  countryCode: string;
  timezone: string;
}

export interface Timezone {
  value: string;
  label: string;
  offset: string;
}

// Major countries with flag emojis
export const COUNTRIES: Country[] = [
  { code: 'US', name: 'United States', flag: '🇺🇸' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦' },
  { code: 'AU', name: 'Australia', flag: '🇦🇺' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪' },
  { code: 'FR', name: 'France', flag: '🇫🇷' },
  { code: 'ES', name: 'Spain', flag: '🇪🇸' },
  { code: 'IT', name: 'Italy', flag: '🇮🇹' },
  { code: 'NL', name: 'Netherlands', flag: '🇳🇱' },
  { code: 'JP', name: 'Japan', flag: '🇯🇵' },
  { code: 'KR', name: 'South Korea', flag: '🇰🇷' },
  { code: 'SG', name: 'Singapore', flag: '🇸🇬' },
  { code: 'IN', name: 'India', flag: '🇮🇳' },
  { code: 'BR', name: 'Brazil', flag: '🇧🇷' },
  { code: 'MX', name: 'Mexico', flag: '🇲🇽' },
  { code: 'AE', name: 'United Arab Emirates', flag: '🇦🇪' },
  { code: 'SE', name: 'Sweden', flag: '🇸🇪' },
  { code: 'NO', name: 'Norway', flag: '🇳🇴' },
  { code: 'DK', name: 'Denmark', flag: '🇩🇰' },
  { code: 'FI', name: 'Finland', flag: '🇫🇮' },
  { code: 'CH', name: 'Switzerland', flag: '🇨🇭' },
  { code: 'AT', name: 'Austria', flag: '🇦🇹' },
  { code: 'BE', name: 'Belgium', flag: '🇧🇪' },
  { code: 'PT', name: 'Portugal', flag: '🇵🇹' },
  { code: 'IE', name: 'Ireland', flag: '🇮🇪' },
  { code: 'NZ', name: 'New Zealand', flag: '🇳🇿' },
  { code: 'ZA', name: 'South Africa', flag: '🇿🇦' },
  { code: 'PL', name: 'Poland', flag: '🇵🇱' },
  { code: 'CZ', name: 'Czech Republic', flag: '🇨🇿' },
  { code: 'GR', name: 'Greece', flag: '🇬🇷' },
];

// Major cities organized by country
export const CITIES: City[] = [
  // United States
  { name: 'New York', countryCode: 'US', timezone: 'America/New_York' },
  { name: 'Los Angeles', countryCode: 'US', timezone: 'America/Los_Angeles' },
  { name: 'Chicago', countryCode: 'US', timezone: 'America/Chicago' },
  { name: 'Houston', countryCode: 'US', timezone: 'America/Chicago' },
  { name: 'Miami', countryCode: 'US', timezone: 'America/New_York' },
  { name: 'San Francisco', countryCode: 'US', timezone: 'America/Los_Angeles' },
  { name: 'Seattle', countryCode: 'US', timezone: 'America/Los_Angeles' },
  { name: 'Boston', countryCode: 'US', timezone: 'America/New_York' },
  { name: 'Denver', countryCode: 'US', timezone: 'America/Denver' },
  { name: 'Austin', countryCode: 'US', timezone: 'America/Chicago' },
  { name: 'Atlanta', countryCode: 'US', timezone: 'America/New_York' },
  { name: 'Washington D.C.', countryCode: 'US', timezone: 'America/New_York' },
  
  // United Kingdom
  { name: 'London', countryCode: 'GB', timezone: 'Europe/London' },
  { name: 'Manchester', countryCode: 'GB', timezone: 'Europe/London' },
  { name: 'Birmingham', countryCode: 'GB', timezone: 'Europe/London' },
  { name: 'Edinburgh', countryCode: 'GB', timezone: 'Europe/London' },
  { name: 'Glasgow', countryCode: 'GB', timezone: 'Europe/London' },
  { name: 'Liverpool', countryCode: 'GB', timezone: 'Europe/London' },
  { name: 'Bristol', countryCode: 'GB', timezone: 'Europe/London' },
  { name: 'Leeds', countryCode: 'GB', timezone: 'Europe/London' },
  
  // Canada
  { name: 'Toronto', countryCode: 'CA', timezone: 'America/Toronto' },
  { name: 'Vancouver', countryCode: 'CA', timezone: 'America/Vancouver' },
  { name: 'Montreal', countryCode: 'CA', timezone: 'America/Montreal' },
  { name: 'Calgary', countryCode: 'CA', timezone: 'America/Edmonton' },
  { name: 'Ottawa', countryCode: 'CA', timezone: 'America/Toronto' },
  
  // Australia
  { name: 'Sydney', countryCode: 'AU', timezone: 'Australia/Sydney' },
  { name: 'Melbourne', countryCode: 'AU', timezone: 'Australia/Melbourne' },
  { name: 'Brisbane', countryCode: 'AU', timezone: 'Australia/Brisbane' },
  { name: 'Perth', countryCode: 'AU', timezone: 'Australia/Perth' },
  { name: 'Adelaide', countryCode: 'AU', timezone: 'Australia/Adelaide' },
  
  // Germany
  { name: 'Berlin', countryCode: 'DE', timezone: 'Europe/Berlin' },
  { name: 'Munich', countryCode: 'DE', timezone: 'Europe/Berlin' },
  { name: 'Hamburg', countryCode: 'DE', timezone: 'Europe/Berlin' },
  { name: 'Frankfurt', countryCode: 'DE', timezone: 'Europe/Berlin' },
  { name: 'Cologne', countryCode: 'DE', timezone: 'Europe/Berlin' },
  
  // France
  { name: 'Paris', countryCode: 'FR', timezone: 'Europe/Paris' },
  { name: 'Lyon', countryCode: 'FR', timezone: 'Europe/Paris' },
  { name: 'Marseille', countryCode: 'FR', timezone: 'Europe/Paris' },
  { name: 'Nice', countryCode: 'FR', timezone: 'Europe/Paris' },
  { name: 'Bordeaux', countryCode: 'FR', timezone: 'Europe/Paris' },
  
  // Spain
  { name: 'Madrid', countryCode: 'ES', timezone: 'Europe/Madrid' },
  { name: 'Barcelona', countryCode: 'ES', timezone: 'Europe/Madrid' },
  { name: 'Valencia', countryCode: 'ES', timezone: 'Europe/Madrid' },
  { name: 'Seville', countryCode: 'ES', timezone: 'Europe/Madrid' },
  
  // Italy
  { name: 'Rome', countryCode: 'IT', timezone: 'Europe/Rome' },
  { name: 'Milan', countryCode: 'IT', timezone: 'Europe/Rome' },
  { name: 'Florence', countryCode: 'IT', timezone: 'Europe/Rome' },
  { name: 'Venice', countryCode: 'IT', timezone: 'Europe/Rome' },
  { name: 'Naples', countryCode: 'IT', timezone: 'Europe/Rome' },
  
  // Netherlands
  { name: 'Amsterdam', countryCode: 'NL', timezone: 'Europe/Amsterdam' },
  { name: 'Rotterdam', countryCode: 'NL', timezone: 'Europe/Amsterdam' },
  { name: 'The Hague', countryCode: 'NL', timezone: 'Europe/Amsterdam' },
  
  // Japan
  { name: 'Tokyo', countryCode: 'JP', timezone: 'Asia/Tokyo' },
  { name: 'Osaka', countryCode: 'JP', timezone: 'Asia/Tokyo' },
  { name: 'Kyoto', countryCode: 'JP', timezone: 'Asia/Tokyo' },
  { name: 'Yokohama', countryCode: 'JP', timezone: 'Asia/Tokyo' },
  
  // South Korea
  { name: 'Seoul', countryCode: 'KR', timezone: 'Asia/Seoul' },
  { name: 'Busan', countryCode: 'KR', timezone: 'Asia/Seoul' },
  { name: 'Incheon', countryCode: 'KR', timezone: 'Asia/Seoul' },
  
  // Singapore
  { name: 'Singapore', countryCode: 'SG', timezone: 'Asia/Singapore' },
  
  // India
  { name: 'Mumbai', countryCode: 'IN', timezone: 'Asia/Kolkata' },
  { name: 'Delhi', countryCode: 'IN', timezone: 'Asia/Kolkata' },
  { name: 'Bangalore', countryCode: 'IN', timezone: 'Asia/Kolkata' },
  { name: 'Chennai', countryCode: 'IN', timezone: 'Asia/Kolkata' },
  { name: 'Hyderabad', countryCode: 'IN', timezone: 'Asia/Kolkata' },
  
  // Brazil
  { name: 'São Paulo', countryCode: 'BR', timezone: 'America/Sao_Paulo' },
  { name: 'Rio de Janeiro', countryCode: 'BR', timezone: 'America/Sao_Paulo' },
  { name: 'Brasília', countryCode: 'BR', timezone: 'America/Sao_Paulo' },
  
  // Mexico
  { name: 'Mexico City', countryCode: 'MX', timezone: 'America/Mexico_City' },
  { name: 'Guadalajara', countryCode: 'MX', timezone: 'America/Mexico_City' },
  { name: 'Monterrey', countryCode: 'MX', timezone: 'America/Monterrey' },
  
  // UAE
  { name: 'Dubai', countryCode: 'AE', timezone: 'Asia/Dubai' },
  { name: 'Abu Dhabi', countryCode: 'AE', timezone: 'Asia/Dubai' },
  
  // Scandinavian countries
  { name: 'Stockholm', countryCode: 'SE', timezone: 'Europe/Stockholm' },
  { name: 'Oslo', countryCode: 'NO', timezone: 'Europe/Oslo' },
  { name: 'Copenhagen', countryCode: 'DK', timezone: 'Europe/Copenhagen' },
  { name: 'Helsinki', countryCode: 'FI', timezone: 'Europe/Helsinki' },
  
  // Other European cities
  { name: 'Zurich', countryCode: 'CH', timezone: 'Europe/Zurich' },
  { name: 'Geneva', countryCode: 'CH', timezone: 'Europe/Zurich' },
  { name: 'Vienna', countryCode: 'AT', timezone: 'Europe/Vienna' },
  { name: 'Brussels', countryCode: 'BE', timezone: 'Europe/Brussels' },
  { name: 'Lisbon', countryCode: 'PT', timezone: 'Europe/Lisbon' },
  { name: 'Porto', countryCode: 'PT', timezone: 'Europe/Lisbon' },
  { name: 'Dublin', countryCode: 'IE', timezone: 'Europe/Dublin' },
  { name: 'Warsaw', countryCode: 'PL', timezone: 'Europe/Warsaw' },
  { name: 'Prague', countryCode: 'CZ', timezone: 'Europe/Prague' },
  { name: 'Athens', countryCode: 'GR', timezone: 'Europe/Athens' },
  
  // Other
  { name: 'Auckland', countryCode: 'NZ', timezone: 'Pacific/Auckland' },
  { name: 'Wellington', countryCode: 'NZ', timezone: 'Pacific/Auckland' },
  { name: 'Cape Town', countryCode: 'ZA', timezone: 'Africa/Johannesburg' },
  { name: 'Johannesburg', countryCode: 'ZA', timezone: 'Africa/Johannesburg' },
];

// Common timezones with friendly labels
export const TIMEZONES: Timezone[] = [
  { value: 'Pacific/Honolulu', label: 'Hawaii', offset: 'UTC-10' },
  { value: 'America/Anchorage', label: 'Alaska', offset: 'UTC-9' },
  { value: 'America/Los_Angeles', label: 'Pacific Time (US & CA)', offset: 'UTC-8' },
  { value: 'America/Denver', label: 'Mountain Time (US & CA)', offset: 'UTC-7' },
  { value: 'America/Chicago', label: 'Central Time (US & MX)', offset: 'UTC-6' },
  { value: 'America/New_York', label: 'Eastern Time (US & CA)', offset: 'UTC-5' },
  { value: 'America/Sao_Paulo', label: 'São Paulo / Brasília', offset: 'UTC-3' },
  { value: 'Europe/London', label: 'London / Dublin / Lisbon', offset: 'UTC+0' },
  { value: 'Europe/Paris', label: 'Central Europe (Paris, Berlin, Rome)', offset: 'UTC+1' },
  { value: 'Europe/Helsinki', label: 'Eastern Europe (Helsinki, Athens)', offset: 'UTC+2' },
  { value: 'Africa/Johannesburg', label: 'South Africa', offset: 'UTC+2' },
  { value: 'Europe/Moscow', label: 'Moscow', offset: 'UTC+3' },
  { value: 'Asia/Dubai', label: 'Dubai / Gulf', offset: 'UTC+4' },
  { value: 'Asia/Kolkata', label: 'India', offset: 'UTC+5:30' },
  { value: 'Asia/Bangkok', label: 'Bangkok / Indochina', offset: 'UTC+7' },
  { value: 'Asia/Singapore', label: 'Singapore / Hong Kong / Perth', offset: 'UTC+8' },
  { value: 'Asia/Tokyo', label: 'Tokyo / Seoul', offset: 'UTC+9' },
  { value: 'Australia/Adelaide', label: 'Adelaide', offset: 'UTC+9:30' },
  { value: 'Australia/Sydney', label: 'Sydney / Melbourne / Brisbane', offset: 'UTC+10' },
  { value: 'Pacific/Auckland', label: 'Auckland / Wellington', offset: 'UTC+12' },
];

// ============================================================================
// TIMEZONE NORMALIZATION
// Maps any IANA timezone (from browser or city data) to the closest value
// in the TIMEZONES dropdown list above. This prevents the <select> from
// showing the first option (Hawaii) when the stored/detected timezone
// doesn't exactly match a dropdown value.
// ============================================================================

// Explicit alias map: IANA timezone → TIMEZONES dropdown value
const TIMEZONE_ALIAS_MAP: Record<string, string> = {
  // Already in TIMEZONES (identity mappings not needed, but listed for clarity)
  'Pacific/Honolulu': 'Pacific/Honolulu',
  'America/Anchorage': 'America/Anchorage',
  'America/Los_Angeles': 'America/Los_Angeles',
  'America/Denver': 'America/Denver',
  'America/Chicago': 'America/Chicago',
  'America/New_York': 'America/New_York',
  'America/Sao_Paulo': 'America/Sao_Paulo',
  'Europe/London': 'Europe/London',
  'Europe/Paris': 'Europe/Paris',
  'Europe/Helsinki': 'Europe/Helsinki',
  'Africa/Johannesburg': 'Africa/Johannesburg',
  'Europe/Moscow': 'Europe/Moscow',
  'Asia/Dubai': 'Asia/Dubai',
  'Asia/Kolkata': 'Asia/Kolkata',
  'Asia/Bangkok': 'Asia/Bangkok',
  'Asia/Singapore': 'Asia/Singapore',
  'Asia/Tokyo': 'Asia/Tokyo',
  'Australia/Adelaide': 'Australia/Adelaide',
  'Australia/Sydney': 'Australia/Sydney',
  'Pacific/Auckland': 'Pacific/Auckland',

  // ── US aliases ──
  'America/Phoenix': 'America/Denver',
  'America/Boise': 'America/Denver',
  'America/Indiana/Indianapolis': 'America/New_York',
  'America/Indiana/Knox': 'America/Chicago',
  'America/Detroit': 'America/New_York',
  'America/Kentucky/Louisville': 'America/New_York',
  'America/Kentucky/Monticello': 'America/New_York',
  'America/Menominee': 'America/Chicago',
  'America/Nome': 'America/Anchorage',
  'America/Adak': 'Pacific/Honolulu',
  'US/Eastern': 'America/New_York',
  'US/Central': 'America/Chicago',
  'US/Mountain': 'America/Denver',
  'US/Pacific': 'America/Los_Angeles',
  'US/Alaska': 'America/Anchorage',
  'US/Hawaii': 'Pacific/Honolulu',

  // ── Canada aliases ──
  'America/Toronto': 'America/New_York',
  'America/Montreal': 'America/New_York',
  'America/Vancouver': 'America/Los_Angeles',
  'America/Edmonton': 'America/Denver',
  'America/Winnipeg': 'America/Chicago',
  'America/Halifax': 'America/New_York',
  'America/Regina': 'America/Chicago',
  'America/St_Johns': 'America/New_York',
  'Canada/Eastern': 'America/New_York',
  'Canada/Central': 'America/Chicago',
  'Canada/Mountain': 'America/Denver',
  'Canada/Pacific': 'America/Los_Angeles',

  // ── Mexico aliases ──
  'America/Mexico_City': 'America/Chicago',
  'America/Monterrey': 'America/Chicago',
  'America/Cancun': 'America/New_York',
  'America/Tijuana': 'America/Los_Angeles',

  // ── Europe UTC+0 aliases ──
  'Europe/Dublin': 'Europe/London',
  'Europe/Lisbon': 'Europe/London',

  // ── Europe UTC+1 aliases (Central European Time) ──
  'Europe/Berlin': 'Europe/Paris',
  'Europe/Rome': 'Europe/Paris',
  'Europe/Madrid': 'Europe/Paris',
  'Europe/Amsterdam': 'Europe/Paris',
  'Europe/Brussels': 'Europe/Paris',
  'Europe/Zurich': 'Europe/Paris',
  'Europe/Vienna': 'Europe/Paris',
  'Europe/Stockholm': 'Europe/Paris',
  'Europe/Oslo': 'Europe/Paris',
  'Europe/Copenhagen': 'Europe/Paris',
  'Europe/Warsaw': 'Europe/Paris',
  'Europe/Prague': 'Europe/Paris',
  'Europe/Budapest': 'Europe/Paris',
  'Europe/Belgrade': 'Europe/Paris',
  'Europe/Bratislava': 'Europe/Paris',
  'Europe/Ljubljana': 'Europe/Paris',
  'Europe/Luxembourg': 'Europe/Paris',
  'Europe/Monaco': 'Europe/Paris',
  'Europe/Malta': 'Europe/Paris',
  'Europe/Andorra': 'Europe/Paris',
  'Europe/Tirane': 'Europe/Paris',
  'Europe/Podgorica': 'Europe/Paris',
  'Europe/Sarajevo': 'Europe/Paris',
  'Europe/Skopje': 'Europe/Paris',
  'Europe/Zagreb': 'Europe/Paris',

  // ── Europe UTC+2 aliases (Eastern European Time) ──
  'Europe/Athens': 'Europe/Helsinki',
  'Europe/Bucharest': 'Europe/Helsinki',
  'Europe/Sofia': 'Europe/Helsinki',
  'Europe/Vilnius': 'Europe/Helsinki',
  'Europe/Riga': 'Europe/Helsinki',
  'Europe/Tallinn': 'Europe/Helsinki',
  'Europe/Kiev': 'Europe/Helsinki',
  'Europe/Kyiv': 'Europe/Helsinki',
  'Europe/Chisinau': 'Europe/Helsinki',
  'Europe/Istanbul': 'Europe/Moscow',

  // ── Africa aliases ──
  'Africa/Cairo': 'Europe/Helsinki',
  'Africa/Casablanca': 'Europe/London',
  'Africa/Lagos': 'Europe/Paris',
  'Africa/Nairobi': 'Europe/Moscow',
  'Africa/Cape_Town': 'Africa/Johannesburg',

  // ── Asia aliases ──
  'Asia/Seoul': 'Asia/Tokyo',
  'Asia/Shanghai': 'Asia/Singapore',
  'Asia/Hong_Kong': 'Asia/Singapore',
  'Asia/Taipei': 'Asia/Singapore',
  'Asia/Kuala_Lumpur': 'Asia/Singapore',
  'Asia/Manila': 'Asia/Singapore',
  'Asia/Jakarta': 'Asia/Bangkok',
  'Asia/Ho_Chi_Minh': 'Asia/Bangkok',
  'Asia/Saigon': 'Asia/Bangkok',
  'Asia/Karachi': 'Asia/Kolkata',
  'Asia/Dhaka': 'Asia/Bangkok',
  'Asia/Colombo': 'Asia/Kolkata',
  'Asia/Calcutta': 'Asia/Kolkata',
  'Asia/Riyadh': 'Europe/Moscow',
  'Asia/Kuwait': 'Europe/Moscow',
  'Asia/Qatar': 'Europe/Moscow',
  'Asia/Bahrain': 'Europe/Moscow',
  'Asia/Muscat': 'Asia/Dubai',
  'Asia/Tehran': 'Asia/Dubai',
  'Asia/Kabul': 'Asia/Kolkata',
  'Asia/Yekaterinburg': 'Asia/Kolkata',
  'Asia/Almaty': 'Asia/Bangkok',
  'Asia/Tashkent': 'Asia/Kolkata',

  // ── Australia aliases ──
  'Australia/Melbourne': 'Australia/Sydney',
  'Australia/Brisbane': 'Australia/Sydney',
  'Australia/Perth': 'Asia/Singapore',
  'Australia/Hobart': 'Australia/Sydney',
  'Australia/Darwin': 'Australia/Adelaide',
  'Australia/Canberra': 'Australia/Sydney',
  'Australia/ACT': 'Australia/Sydney',

  // ── Pacific aliases ──
  'Pacific/Fiji': 'Pacific/Auckland',
  'Pacific/Guam': 'Australia/Sydney',
  'Pacific/Samoa': 'Pacific/Honolulu',

  // ── Generic / legacy aliases ──
  'UTC': 'Europe/London',
  'GMT': 'Europe/London',
  'Etc/UTC': 'Europe/London',
  'Etc/GMT': 'Europe/London',
};

// Build a Set of valid TIMEZONES values for quick lookup
const VALID_TIMEZONE_VALUES = new Set(TIMEZONES.map(tz => tz.value));

/**
 * Normalize any IANA timezone string to the closest value in the TIMEZONES
 * dropdown list. Uses an explicit alias map first, then falls back to
 * computing the UTC offset and finding the closest match.
 */
export function normalizeTimezone(tz: string | null | undefined): string {
  // ── NULL / EMPTY HANDLING ──
  // If no timezone provided, detect from browser. Do NOT default to TIMEZONES[0]
  // (Hawaii) — that was the root cause of the "stuck on Hawaii" bug.
  if (!tz || tz.trim() === '') {
    try {
      const browserTz = Intl.DateTimeFormat().resolvedOptions().timeZone;
      if (browserTz) {
        // Normalize the browser timezone (but guard against infinite recursion
        // by checking if browserTz is valid FIRST before recursing)
        if (VALID_TIMEZONE_VALUES.has(browserTz)) return browserTz;
        const browserAlias = TIMEZONE_ALIAS_MAP[browserTz];
        if (browserAlias && VALID_TIMEZONE_VALUES.has(browserAlias)) return browserAlias;
        // Fall through to offset-based detection below
      }
    } catch {
      // Intl API not available — fall through
    }
    // Offset-based fallback for null input
    return _bestTimezoneByBrowserOffset();
  }

  // Already a valid dropdown value — return as-is
  if (VALID_TIMEZONE_VALUES.has(tz)) return tz;

  // Check alias map
  const alias = TIMEZONE_ALIAS_MAP[tz];
  if (alias && VALID_TIMEZONE_VALUES.has(alias)) return alias;

  // Fallback: compute UTC offset from the given timezone string and find closest match
  try {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: tz,
      timeZoneName: 'shortOffset',
    });
    const parts = formatter.formatToParts(now);
    const tzPart = parts.find(p => p.type === 'timeZoneName');
    if (tzPart) {
      const match = tzPart.value.match(/GMT([+-]?\d+)?(?::(\d+))?/);
      if (match) {
        const hours = parseInt(match[1] || '0', 10);
        const minutes = parseInt(match[2] || '0', 10);
        const totalMinutes = hours * 60 + (hours >= 0 ? minutes : -minutes);
        return _bestTimezoneByOffset(totalMinutes);
      }
    }
  } catch {
    // Intl API failed — fall through
  }

  // Ultimate fallback: use browser offset
  return _bestTimezoneByBrowserOffset();
}

// ── Internal helpers (not exported) ──

const OFFSET_MAP: [string, number][] = [
  ['Pacific/Honolulu', -600],
  ['America/Anchorage', -540],
  ['America/Los_Angeles', -480],
  ['America/Denver', -420],
  ['America/Chicago', -360],
  ['America/New_York', -300],
  ['America/Sao_Paulo', -180],
  ['Europe/London', 0],
  ['Europe/Paris', 60],
  ['Europe/Helsinki', 120],
  ['Africa/Johannesburg', 120],
  ['Europe/Moscow', 180],
  ['Asia/Dubai', 240],
  ['Asia/Kolkata', 330],
  ['Asia/Bangkok', 420],
  ['Asia/Singapore', 480],
  ['Asia/Tokyo', 540],
  ['Australia/Adelaide', 570],
  ['Australia/Sydney', 600],
  ['Pacific/Auckland', 720],
];

function _bestTimezoneByOffset(offsetMinutes: number): string {
  let bestMatch = 'Europe/London'; // sensible default, NOT Hawaii
  let bestDiff = Infinity;
  for (const [tzValue, offsetMin] of OFFSET_MAP) {
    const diff = Math.abs(offsetMinutes - offsetMin);
    if (diff < bestDiff) {
      bestDiff = diff;
      bestMatch = tzValue;
    }
  }
  return bestMatch;
}

function _bestTimezoneByBrowserOffset(): string {
  try {
    const offsetMinutes = -new Date().getTimezoneOffset(); // JS offset is inverted
    return _bestTimezoneByOffset(offsetMinutes);
  } catch {
    return 'Europe/London'; // safe default for a global app, NOT Hawaii
  }
}

// Helper functions
export function getCountryByCode(code: string): Country | undefined {
  return COUNTRIES.find(c => c.code === code);
}

export function getCitiesByCountry(countryCode: string): City[] {
  return CITIES.filter(c => c.countryCode === countryCode);
}

export function getCityByName(name: string, countryCode: string): City | undefined {
  return CITIES.find(c => c.name === name && c.countryCode === countryCode);
}

export function getTimezoneByValue(value: string): Timezone | undefined {
  return TIMEZONES.find(t => t.value === value);
}

export function getTimezoneForCity(cityName: string, countryCode: string): string {
  const city = getCityByName(cityName, countryCode);
  return city?.timezone || 'UTC';
}

// Get user's detected timezone — normalized to a TIMEZONES dropdown value
export function detectUserTimezone(): string {
  try {
    const raw = Intl.DateTimeFormat().resolvedOptions().timeZone;
    return normalizeTimezone(raw);
  } catch {
    return normalizeTimezone(null);
  }
}

// Format time in a specific timezone
export function formatTimeInTimezone(date: Date, timezone: string): string {
  try {
    return date.toLocaleTimeString('en-US', {
      timeZone: timezone,
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return date.toLocaleTimeString();
  }
}

// Get current time in a timezone
export function getCurrentTimeInTimezone(timezone: string): string {
  return formatTimeInTimezone(new Date(), timezone);
}
