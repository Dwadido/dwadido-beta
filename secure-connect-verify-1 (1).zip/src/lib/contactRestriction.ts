/**
 * =============================================================================
 * DWADIDO CONTACT RESTRICTION SYSTEM
 * =============================================================================
 *
 * Default: All matches start with contact restriction ON.
 * Each user can permanently remove their restriction (one-way, irreversible).
 * Personal info sharing is only allowed when BOTH users have removed restriction.
 *
 * Data model: `contact_restriction_removals` table
 *   - match_id (uuid, FK → matches.id)
 *   - user_id (uuid, FK → auth.users.id) — the user who removed their restriction
 *   - created_at (timestamptz, default now())
 *   - UNIQUE(match_id, user_id) — prevents duplicate removals
 *
 * Enforcement layers:
 *   1. CLIENT-SIDE: Content filtering in `checkMessageForRestrictedContent()`
 *      - Runs before every message send via `sendChatMessage()` in messageSender.ts
 *      - Blocks phone numbers, emails, URLs, social handles, obfuscation attempts
 *
 *   2. SERVER-SIDE (edge function): `send-chat-message`
 *      - Re-validates restriction state + content server-side
 *      - Cannot be bypassed by modifying client code
 *
 *   3. DATABASE TRIGGER (PostgreSQL): `enforce_contact_restriction()`
 *      - BEFORE INSERT OR UPDATE trigger on `messages` table
 *      - Final enforcement layer — blocks even direct API inserts
 *      - See messageSender.ts for the full trigger SQL
 *
 * 17-day window:
 *   - Restriction removal is only allowed during the active chat window
 *   - After the 17-day window closes (match.expires_at), restriction state is frozen
 *   - The match itself becomes read-only after expiry
 *
 * =============================================================================
 * REGEX / HEURISTIC PATTERNS — FULL DOCUMENTATION
 * =============================================================================
 *
 * Category 1: PHONE NUMBERS
 *   - PHONE_STANDARD: +1234567890, (123)456-7890, 123-456-7890, 123.456.7890
 *     Requires 7+ digits after stripping separators (avoids "17 days", "2 people")
 *   - PHONE_DIGITS: 7+ consecutive digits with optional separators (\d[\d\s.\-()]{6,}\d)
 *   - PHONE_SPACED: Digits separated by spaces: "1 2 3 4 5 6 7 8 9 0"
 *   - NUMBER_WORDS: Written-out numbers: "zero one two three four five six seven eight nine"
 *     Triggers when 5+ number words appear in a single message
 *   - PHONE_CONTEXT: Intent phrases: "call me", "text me", "my number", "reach me at"
 *
 * Category 2: EMAIL ADDRESSES
 *   - EMAIL_STANDARD: user@domain.com (standard RFC-like pattern)
 *   - EMAIL_OBFUSCATED: "user at domain dot com", "user [at] domain [dot] com"
 *   - EMAIL_CONTEXT: Intent phrases: "my email is", "email me at"
 *
 * Category 3: URLs AND LINKS
 *   - URL_STANDARD: http://, https://, www. prefixed URLs
 *   - URL_DOMAIN: Bare domains like "example.com" (50+ TLDs covered)
 *     Excludes false positives: "e.g.", "i.e.", "etc."
 *   - URL_SHORTENER: bit.ly, t.co, tinyurl, etc.
 *   - URL_CONTEXT: "link in bio", "check my link", "my website"
 *
 * Category 4: SOCIAL MEDIA
 *   - SOCIAL_HANDLE: @username (3+ chars after @)
 *   - SOCIAL_PLATFORMS: 30+ platform names (instagram, snapchat, telegram, whatsapp, etc.)
 *   - SOCIAL_CONTEXT: "add me on snap", "dm me on instagram", "find me on"
 *   - SOCIAL_IS_PATTERN: "my insta is", "my snap: username"
 *   - SOCIAL_DM_PATTERN: "dm me", "add me", "hmu", "slide into my dm"
 *
 * Category 5: BYPASS ATTEMPTS
 *   - AT_SUBSTITUTION: [at], (at), {at}, <at> — email obfuscation
 *   - DOT_SUBSTITUTION: [dot], (dot), {dot}, <dot> — domain obfuscation
 *   - LEET_DIGITS: Sequences of 7+ digit-like characters (0-9, o, O, l, I, !, |)
 *
 * =============================================================================
 */

import { supabase } from './supabase';

// ─── Types ──────────────────────────────────────────────────────────────

export interface RestrictionState {
  myRestrictionRemoved: boolean;
  theirRestrictionRemoved: boolean;
  /** True when BOTH users have removed restriction */
  fullyUnlocked: boolean;
  /** True if the 17-day window has expired (restriction state is frozen) */
  windowExpired?: boolean;
}

// ─── DB Helpers ─────────────────────────────────────────────────────────

/**
 * Fetch the restriction state for a match.
 * Returns which users have permanently removed their restriction.
 * Also checks if the 17-day window has expired.
 */
export async function fetchRestrictionState(
  matchId: string,
  myUserId: string,
  otherUserId: string
): Promise<RestrictionState> {
  try {
    // Fetch restriction removals AND match expiry in parallel
    const [restrictionResult, matchResult] = await Promise.all([
      supabase
        .from('contact_restriction_removals')
        .select('user_id')
        .eq('match_id', matchId),
      supabase
        .from('matches')
        .select('expires_at, status')
        .eq('id', matchId)
        .single(),
    ]);

    if (restrictionResult.error) {
      // Table may not exist yet — treat as both restricted
      console.warn('[ContactRestriction] Error fetching state:', restrictionResult.error.message);
      return { myRestrictionRemoved: false, theirRestrictionRemoved: false, fullyUnlocked: false };
    }

    const myRemoved = restrictionResult.data?.some(r => r.user_id === myUserId) ?? false;
    const theirRemoved = restrictionResult.data?.some(r => r.user_id === otherUserId) ?? false;

    // Check if 17-day window has expired
    let windowExpired = false;
    if (matchResult.data) {
      const expiresAt = matchResult.data.expires_at;
      const status = matchResult.data.status;
      if (expiresAt && new Date(expiresAt) < new Date()) {
        windowExpired = true;
      }
      if (status === 'ended' || status === 'expired') {
        windowExpired = true;
      }
    }

    return {
      myRestrictionRemoved: myRemoved,
      theirRestrictionRemoved: theirRemoved,
      fullyUnlocked: myRemoved && theirRemoved,
      windowExpired,
    };
  } catch {
    return { myRestrictionRemoved: false, theirRestrictionRemoved: false, fullyUnlocked: false };
  }
}

/**
 * Permanently remove the current user's contact restriction for a match.
 * This is irreversible — there is no "re-enable" function.
 *
 * Checks:
 * - User hasn't already removed restriction (idempotent via UNIQUE constraint)
 * - Match is still within the 17-day window
 * - Match status is 'active'
 */
export async function removeMyRestriction(
  matchId: string,
  userId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    // First, verify the match is still active and within window
    const { data: match, error: matchError } = await supabase
      .from('matches')
      .select('expires_at, status')
      .eq('id', matchId)
      .single();

    if (matchError) {
      console.error('[ContactRestriction] Error checking match:', matchError.message);
      // Proceed anyway — the insert will fail if match doesn't exist (FK constraint)
    } else if (match) {
      if (match.status === 'ended' || match.status === 'expired') {
        return { success: false, error: 'This chat has ended. Restriction cannot be changed.' };
      }
      if (match.expires_at && new Date(match.expires_at) < new Date()) {
        return { success: false, error: 'The 17-day chat window has expired. Restriction cannot be changed.' };
      }
    }

    // Insert the restriction removal
    const { error } = await supabase
      .from('contact_restriction_removals')
      .insert({
        match_id: matchId,
        user_id: userId,
      });

    if (error) {
      // Duplicate insert (already removed) — treat as success
      if (error.code === '23505') {
        return { success: true };
      }
      console.error('[ContactRestriction] Error removing restriction:', error.message);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || 'Unknown error' };
  }
}

// ─── Content Filtering ──────────────────────────────────────────────────

/**
 * Comprehensive regex/heuristic patterns for detecting personal contact info.
 *
 * Categories:
 * 1. Phone numbers (standard + spaced/obfuscated)
 * 2. Email addresses (standard + obfuscated)
 * 3. URLs and links
 * 4. Social media handles and platform references
 * 5. Bypass attempts (spaced digits, "at gmail dot com", etc.)
 *
 * IMPORTANT: All checks run against THREE representations of the text:
 *   - raw:     original text, lowercased
 *   - norm:    obfuscation tokens resolved (" at "→"@", " dot "→"."), spaces collapsed
 *   - nospace: all whitespace stripped from norm (catches "g mail"→"gmail")
 */

// ── 1. Phone numbers ──

// Standard phone formats: +1234567890, (123)456-7890, 123-456-7890, 123.456.7890
const PHONE_STANDARD = /(?:\+?\d{1,4}[\s.-]?)?\(?\d{2,4}\)?[\s.-]?\d{2,4}[\s.-]?\d{2,9}/;

// 7+ consecutive digits (with optional separators)
const PHONE_DIGITS = /\d[\d\s.\-()]{6,}\d/;

// Spaced-out digits: "1 2 3 4 5 6 7 8 9 0" (7+ digits separated by spaces/dots/dashes)
const PHONE_SPACED = /(?:\d\s+){6,}\d/;

// Written-out numbers: "zero one two three..." (detect 5+ number words in sequence)
const NUMBER_WORDS = /\b(?:zero|one|two|three|four|five|six|seven|eight|nine|oh)\b/gi;

// "call me", "text me", "my number", "phone number", "reach me at"
const PHONE_CONTEXT = /\b(?:call\s+me|text\s+me|my\s+(?:number|phone|cell|mobile)|phone\s*(?:number|#|no)|reach\s+me\s+at|hit\s+me\s+(?:up\s+)?(?:at|on)|ring\s+me|dial\s+me|contact\s+(?:me\s+)?(?:at|on))\b/i;

// ── 2. Email addresses ──

// Standard email
const EMAIL_STANDARD = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/;

// Obfuscated email: "user at domain dot com", "user [at] domain [dot] com"
const EMAIL_OBFUSCATED = /[a-zA-Z0-9._%+\-]+\s*[\[\(]?\s*(?:at|@)\s*[\]\)]?\s*[a-zA-Z0-9.\-]+\s*[\[\(]?\s*(?:dot|\.)\s*[\]\)]?\s*(?:com|org|net|io|co|me|info|edu|gov|uk|au|ca|de|fr|es|it|nl|se|no|fi|dk|jp|kr|cn|in|br|ru|za|nz)\b/i;

// Bare " at " + " dot " pattern (no brackets): "collied78 at gmail dot com"
const EMAIL_BARE_AT_DOT = /[a-zA-Z0-9._]+\s+at\s+[a-zA-Z0-9._]+\s+dot\s+[a-zA-Z]+/i;

// "my email is", "email me at", "send me an email"
const EMAIL_CONTEXT = /\b(?:my\s+email|email\s+(?:me|is|address)|send\s+(?:me\s+)?an?\s+email|e-?mail\s*(?::|is|address))\b/i;

// ── 3. URLs and links ──

// Standard URLs
const URL_STANDARD = /(?:https?:\/\/|www\.)[^\s<>]+/i;

// Domain patterns without protocol: something.com, something.org, etc.
const URL_DOMAIN = /\b[a-zA-Z0-9](?:[a-zA-Z0-9\-]*[a-zA-Z0-9])?\.(?:com|org|net|io|co|me|info|app|dev|xyz|online|site|website|link|page|bio|ly|gl|gg|cc|tv|fm|am|be|to|in|us|uk|ca|au|de|fr|es|it|nl|se|no|fi|dk|jp|kr|cn|br|ru|za|nz)\b/i;

// URL shorteners
const URL_SHORTENER = /\b(?:bit\.ly|t\.co|goo\.gl|tinyurl|is\.gd|v\.gd|buff\.ly|ow\.ly|rb\.gy|shorturl|cutt\.ly|tiny\.cc)\b/i;

// "link in bio", "check my link", "my website"
const URL_CONTEXT = /\b(?:link\s+in\s+(?:my\s+)?bio|check\s+(?:my|the)\s+link|my\s+(?:website|site|page|link|url)|visit\s+(?:my|the)|go\s+to\s+(?:my|the))\b/i;

// ── 4. Social media handles and platforms ──

// @username pattern (3+ chars after @)
const SOCIAL_HANDLE = /@[a-zA-Z0-9_]{3,}/;

// Social platform names
const SOCIAL_PLATFORMS = /\b(?:instagram|insta|ig|snapchat|snap|sc|telegram|tg|whatsapp|whats\s*app|wa|facebook|fb|messenger|twitter|x\.com|tiktok|tik\s*tok|signal|line|wechat|we\s*chat|kakao|kakaotalk|viber|discord|linkedin|pinterest|tumblr|reddit|youtube|yt|twitch|onlyfans|of)\b/i;

// "my insta is", "add me on snap", "dm me on", "find me on", "follow me"
const SOCIAL_CONTEXT = /\b(?:(?:my|add\s+me\s+on|dm\s+me\s+on|find\s+me\s+on|follow\s+me\s+on|hit\s+me\s+(?:up\s+)?on|message\s+me\s+on|reach\s+me\s+on|i(?:'m|\s+am)\s+on|hmu\s+on|connect\s+(?:with\s+me\s+)?on)\s*(?:instagram|insta|ig|snapchat|snap|sc|telegram|tg|whatsapp|whats\s*app|wa|facebook|fb|messenger|twitter|x|tiktok|tik\s*tok|signal|line|wechat|we\s*chat|kakao|viber|discord|linkedin))\b/i;

// "my [platform] is [username]" pattern
const SOCIAL_IS_PATTERN = /\b(?:my\s+)?(?:instagram|insta|ig|snapchat|snap|sc|telegram|tg|whatsapp|wa|facebook|fb|twitter|tiktok|signal|line|wechat|kakao|viber|discord|linkedin)\s+(?:is|:|handle|username|name|id|account)\s*/i;

// "add me", "dm me", "message me" (without platform — still suspicious)
const SOCIAL_DM_PATTERN = /\b(?:add\s+me|dm\s+me|slide\s+(?:into|in)\s+(?:my\s+)?dm|hmu|hit\s+me\s+up)\b/i;

// ── 5. Bypass attempts ──

// "at" substitutions: [at], (at), {at}, <at>
const AT_SUBSTITUTION = /[\[\({<]\s*at\s*[\]\)}>]/i;

// "dot" substitutions: [dot], (dot), {dot}, <dot>
const DOT_SUBSTITUTION = /[\[\({<]\s*dot\s*[\]\)}>]/i;

// Leetspeak digits in sequence (e.g., "thr33 f0ur s1x...")
const LEET_DIGITS = /(?:[0-9oOlI!|][\s.,-]*){7,}/;

// ─── Normalization ──────────────────────────────────────────────────────

/**
 * Normalize text for contact-info detection.
 * Mirrors the DB trigger's normalization logic exactly:
 *   1. Lowercase
 *   2. Replace bracket-wrapped [at]/(at)/{at}/<at> → @
 *   3. Replace bracket-wrapped [dot]/(dot)/{dot}/<dot> → .
 *   4. Replace bare " at " → "@"
 *   5. Replace bare " dot " → "."
 *   6. Collapse whitespace runs to single space, trim
 *
 * @returns { norm, nospace } — normalized and fully-despaced versions
 */
function normalizeForDetection(text: string): { norm: string; nospace: string } {
  let s = text.toLowerCase();

  // Bracket-wrapped tokens → symbols
  s = s.replace(/[\[\({<]\s*at\s*[\]\)}>]/gi, '@');
  s = s.replace(/[\[\({<]\s*dot\s*[\]\)}>]/gi, '.');

  // Bare word tokens with surrounding whitespace
  s = s.replace(/\s+at\s+/gi, '@');
  s = s.replace(/\s+dot\s+/gi, '.');

  // Collapse whitespace
  s = s.replace(/\s+/g, ' ').trim();

  const norm = s;
  const nospace = s.replace(/\s+/g, '');

  return { norm, nospace };
}

// ─── Main Filter Function ───────────────────────────────────────────────

export interface FilterResult {
  blocked: boolean;
  reasons: string[];
}

/**
 * Check if a message contains restricted personal contact information.
 *
 * Runs detection against three representations:
 *   - raw (lowercased original) — for literal pattern matching
 *   - norm (obfuscation tokens resolved, spaces collapsed) — catches " at "/" dot " tricks
 *   - nospace (all whitespace stripped from norm) — catches "g mail" → "gmail"
 *
 * @param text - The message text to check
 * @returns FilterResult with blocked=true if restricted content found
 */
export function checkMessageForRestrictedContent(text: string): FilterResult {
  const reasons: string[] = [];
  const raw = text.toLowerCase();
  const { norm, nospace } = normalizeForDetection(text);

  // ── Phone numbers (checked on raw — spacing matters for digit patterns) ──
  if (PHONE_STANDARD.test(text)) {
    const match = text.match(PHONE_STANDARD);
    if (match) {
      const digitsOnly = match[0].replace(/\D/g, '');
      if (digitsOnly.length >= 7) {
        reasons.push('Phone number detected');
      }
    }
  }

  if (PHONE_DIGITS.test(text)) {
    const match = text.match(PHONE_DIGITS);
    if (match) {
      const digitsOnly = match[0].replace(/\D/g, '');
      if (digitsOnly.length >= 7) {
        reasons.push('Phone number sequence detected');
      }
    }
  }

  if (PHONE_SPACED.test(text)) {
    reasons.push('Spaced-out phone number detected');
  }

  // Written-out numbers: count number words
  const numberWordMatches = raw.match(NUMBER_WORDS);
  if (numberWordMatches && numberWordMatches.length >= 5) {
    reasons.push('Written-out number sequence detected');
  }

  if (PHONE_CONTEXT.test(text)) {
    reasons.push('Phone number sharing context detected');
  }

  // ── Email (checked on raw, norm, AND nospace) ──

  // Standard email on raw
  if (EMAIL_STANDARD.test(text)) {
    reasons.push('Email address detected');
  }

  // Standard email on normalized (catches "user at domain dot com")
  if (EMAIL_STANDARD.test(norm)) {
    reasons.push('Obfuscated email address detected (at/dot substitution)');
  }

  // Email on nospace with TLD whitelist (catches "user at g mail . com" → "user@gmail.com")
  // Uses explicit TLD list to avoid false positives like "meet at the park dot on the hill"
  const NOSPACE_EMAIL_TLD = /[a-z0-9._%+-]+@[a-z0-9.-]+\.(com|org|net|io|co|me|info|edu|gov|uk|au|ca|de|fr|es|it|nl|se|no|fi|dk|jp|kr|cn|br|ru|za|nz|app|dev|xyz|online|site|link|page|bio|ly|gl|gg|cc|tv|fm|be|to|us)/i;
  if (NOSPACE_EMAIL_TLD.test(nospace)) {
    reasons.push('Obfuscated email address detected (spaced domain)');
  }

  // Legacy obfuscated pattern on raw (bracket-wrapped)
  if (EMAIL_OBFUSCATED.test(text)) {
    reasons.push('Obfuscated email address detected');
  }

  // Bare " at " + " dot " pattern without brackets
  if (EMAIL_BARE_AT_DOT.test(text)) {
    reasons.push('Obfuscated email address detected (bare at/dot)');
  }

  if (EMAIL_CONTEXT.test(text)) {
    reasons.push('Email sharing context detected');
  }


  // ── URLs (checked on raw, norm, AND nospace) ──

  if (URL_STANDARD.test(text)) {
    reasons.push('URL/link detected');
  }

  // Domain on raw
  if (URL_DOMAIN.test(text)) {
    const domainMatch = text.match(URL_DOMAIN);
    if (domainMatch && !['e.g', 'i.e', 'etc'].includes(domainMatch[0].toLowerCase())) {
      reasons.push('Website domain detected');
    }
  }

  // Domain on normalized (catches "gmail dot com" → "gmail.com")
  if (URL_DOMAIN.test(norm)) {
    const domainMatch = norm.match(URL_DOMAIN);
    if (domainMatch && !['e.g', 'i.e', 'etc'].includes(domainMatch[0].toLowerCase())) {
      reasons.push('Website domain detected (dot substitution)');
    }
  }

  // Domain on nospace (catches "g mail . com" → "gmail.com")
  if (/[a-z0-9]([a-z0-9-]*[a-z0-9])?\.(com|org|net|io|co|me|info|app|dev|xyz|online|site|link|page|bio|ly|gl|gg|cc|tv|fm|be|to|us|uk|ca|au|de|fr|es|it|nl|se|no|fi|dk|jp|kr|cn|br|ru|za|nz)/i.test(nospace)) {
    if (!/(?:e\.g|i\.e)/i.test(nospace)) {
      reasons.push('Website domain detected (spaced)');
    }
  }

  if (URL_SHORTENER.test(text)) {
    reasons.push('URL shortener detected');
  }

  if (URL_CONTEXT.test(text)) {
    reasons.push('Link sharing context detected');
  }

  // ── Social media (checked on raw — platform names don't get obfuscated as much) ──

  if (SOCIAL_HANDLE.test(text)) {
    reasons.push('Social media handle (@username) detected');
  }

  // Also check norm for @handle (catches "[at]username" → "@username")
  if (SOCIAL_HANDLE.test(norm)) {
    reasons.push('Social media handle detected (obfuscated @)');
  }

  if (SOCIAL_CONTEXT.test(text)) {
    reasons.push('Social media sharing context detected');
  }

  if (SOCIAL_IS_PATTERN.test(text)) {
    reasons.push('Social media username sharing detected');
  }

  // Social platform name + something that looks like a username nearby
  if (SOCIAL_PLATFORMS.test(text)) {
    const platformMatch = text.match(SOCIAL_PLATFORMS);
    if (platformMatch) {
      const idx = text.toLowerCase().indexOf(platformMatch[0].toLowerCase());
      const after = text.substring(idx + platformMatch[0].length, idx + platformMatch[0].length + 40);
      if (/^\s*[:=\-]\s*[a-zA-Z0-9_]/.test(after) || /^\s+(?:is|handle|username|name|id)\s/i.test(after)) {
        reasons.push('Social media platform + username detected');
      }
    }
  }

  if (SOCIAL_DM_PATTERN.test(text)) {
    reasons.push('Direct message/contact request detected');
  }

  // ── Bypass attempts ──

  if (AT_SUBSTITUTION.test(text) || DOT_SUBSTITUTION.test(text)) {
    reasons.push('Obfuscated contact info detected (bracket substitution)');
  }

  if (LEET_DIGITS.test(text)) {
    const match = text.match(LEET_DIGITS);
    if (match) {
      const cleaned = match[0].replace(/[\s.,-]/g, '');
      if (cleaned.length >= 7) {
        reasons.push('Obfuscated number sequence detected');
      }
    }
  }

  // Deduplicate reasons
  const uniqueReasons = [...new Set(reasons)];

  return {
    blocked: uniqueReasons.length > 0,
    reasons: uniqueReasons,
  };
}

/**
 * Get a user-friendly blocked message explanation.
 */
export function getBlockedMessageText(reasons: string[]): string {
  if (reasons.length === 0) return '';
  
  return 'This message was blocked because it appears to contain personal contact information (phone numbers, email addresses, social media handles, or links). Both users must remove the chat restriction before sharing contact details.';
}
